#######################################################################
#### Author: chenxiaokang                                           ###
#### Date: 2015.1.13												###
#### Description: message build function							###	
#### Modify reason:													###
#### Version: 1.0													###
#### bugs report to hp104@hupu.net									###
#######################################################################
require 'json'
module Switch
	class Message
		attr_accessor :head, :body
		@@head_dic = {"MessageMethod" => nil, "MessageType" => nil, "CompressType" => nil, \
				 	  "DateTime" => nil, "ControllerCode" => nil, "Address" => nil, \
					  "StatusCode" => nil, "MessageLength" => nil }
		def Message.head_keys
			@@head_dic.keys
		end
		def Message.head_dic
			@@head_dic
		end
		def initialize
			@sw_log = Switch.sw_log
			self.head = {}
			self.body = {}
			@@head_keys = Message.head_keys
			@@head_keys.each{|key| self.head[key] = nil}
		end
		def set_head(heads)
			keys = heads.keys
			keys.each do |key|
				if self.head.has_key? key
					self.head[key] = heads[key]
				else
					Log.error "input key = #{key} error"
				end
			end
		end
		def get_head
			msg_head = ""
			@@head_keys.each do |key|
				if self.head[key] != nil
					msg_head += key + ": #{self.head[key]}" + "\r\n"
				end
			end
			msg_head
		end
		def init_head
			self.head = {}
		end
		def msg_package(msg, msg_info)
			Log.debug "msg_package msg_info = #{msg_info}"
			package = nil
			set_head "MessageMethod"	 => msg_info["method"] 
			set_head "MessageType"		 => "json"
			set_head "CompressType"		 => "nil"
			set_head "DateTime"			 => DateTime.now.httpdate.gsub(/:/, '.')
			#set_head "ControllerCode"	 => get_controller_code
			set_head "ControllerCode"	 => $ascId
			if msg_info.has_key?("flag")
				set_head "StatusCode"    => msg_info["status"] != nil ? "#{msg_info["status"]}":nil
				set_head "Address"       => msg_info.has_key?("ip") ? msg_info["ip"] : nil
				if msg_info["flag"] == -1
					set_head "MessageLength" => "0"
					package = get_head
					Log.info "ret msg head:\n#{package}"
				else
					set_head "MessageLength" => msg.bytesize
					package = get_head
					Log.info "ret msg head:\n#{package}"
					msg += "\r\n"
					package += msg
					Log.debug"ret msg content:\n#{package}"
				end
			else
				set_head "StatusCode"    => "201"
				set_head "MessageLength" => "0"
				package = get_head
				Log.info "ret msg head:\n#{package}"
			end
			#Log.debug "return package:\n#{package}"
			return package
		end
		def get_controller_code
            controller_code = `head -n1 /nac/config/nac_device_id.conf 2>/dev/null`
            controller_code = controller_code.chomp
            if controller_code.length == 0
                Log.error "get controller_code error from nac_device_id.conf"
                controller_code = `ifconfig | grep "HWaddr"|head -n1 |awk '{print $5}'`
            end
            return controller_code.chomp.gsub(/:/, '-')
		end
	end
	class ParseMsg
		def initialize
			@rev_msg = ""
		end
		def parse(json_data)
			@rev_msg += json_data if json_data != nil
			msgs = []
			head = {}
			body = {}
			msg_mark = 0
			rev_data = @rev_msg.split("\r\n")
			len_arry = Array(0..rev_data.length-1)
			len_arry.each do |j|
				#puts "#########rev_data = #{rev_data[j]}ength = #{rev_data[j].size}"
				arry_msg = rev_data[j].split(":")
				if arry_msg.length >= 2 && Message.head_dic.has_key?(arry_msg[0].strip)
					head[arry_msg[0].strip] = arry_msg[1].strip
					msg_mark = 1
					next unless (head.has_key?("MessageLength") && head["MessageLength"].to_i == 0)
				end
				if head.has_key?("MessageLength") && (head["MessageLength"].to_i == 0) && (msg_mark == 1)
					msg = {}
					msg["head"] = head
					msg["body"] = nil
					head = {}
					msgs << msg
					@rev_msg = "" if j == len_arry.length - 1
					next
				elsif head.has_key?("MessageLength") && (head["MessageLength"].to_i == rev_data[j].length) && (msg_mark == 1)
					msg = {}
					msg["head"] = head
					msg["body"] = JSON.parse(rev_data[j])
					msgs << msg
					head = {}
					msg_mark = 0
					@rev_msg = "" if j == len_arry.length - 1
				elsif
					Log.info "message not complete"
					if j == len_arry.length - 1
						@rev_msg = rev_data[j]
					end
					if j < len_arry.length - 1
						@rev_msg = ""
						rev_data[j..-1].each {|last_msg| @rev_msg += "\r\n"+last_msg}
					end

				end
				
			end
			#puts msgs
			#Log.debug msgs
			return msgs
		end
	end
end
