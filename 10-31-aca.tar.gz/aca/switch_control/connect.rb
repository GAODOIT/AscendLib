#######################################################################
#### Author: chenxiaokang                                           ###
#### Date: 2015.1.13												###
#### Description: connect to server function						###
#### Modify reason:													###
#### Version: 1.0													###
#### bugs report to hp104@hupu.net									###
#######################################################################
require "socket"
module Switch
	$switch_log = nil
	$log_describe = {}
	class << self
		def sw_log
			if $switch_log == nil
				if $env_type == 1
					$switch_log = Logger.new(STDERR)
					$switch_log.level = Logger::DEBUG
				else
					$switch_log = Logger.new('/var/log/switch.log', 5, 1024000*25)
					$switch_log.level = Logger::INFO
				end
				#$switch_log.level = Logger::ERROR
				$switch_log.datetime_format = '%Y-%m-%d %H:%M:%S'
			end
			$switch_log
		end
		def log
			Switch::sw_log
		end
		def nac(status = nil)
			if status != nil
				$nac_status = status
			end
			return $nac_status
		end
	end
	class Log
		class << self
			def debug(msg=nil, name=nil)
				#puts "Log debug##################3"
				log_value(msg, "#{name} DEBUG ", 0)
				#puts "msg = #{msg}"
				$switch_log.add(Logger::DEBUG, msg, name)
				# log_txt = ''
				# msg.to_s.each_byte do |char_ord|
				# 	if char_ord == 10 || (char_ord >31 && char_ord <127)
				# 		log_txt += char_ord.chr
				# 	end
				# end
				# $switch_log.add(Logger::DEBUG, log_txt, name)
			end
			def info(msg=nil, name=nil)
				log_value(msg, "#{name} INFO ", 1)
				$switch_log.add(Logger::INFO, msg, name)
				# log_txt = ''
				# msg.to_s.each_byte do |char_ord|
				# 	if char_ord == 10 || (char_ord >31 && char_ord <127)
				# 		log_txt += char_ord.chr
				# 	end
				# end
				# $switch_log.add(Logger::INFO, log_txt, name)
			end
			def warn(msg=nil, name=nil)
				log_value(msg, "#{name} WARN ", 2)
				$switch_log.add(Logger::WARN, msg, name)
			end
			def error(msg=nil, name=nil)
				log_value(msg, "#{name} ERROR ", 3)
				$switch_log.add(Logger::ERROR, msg, name)
				# log_txt = ''
				# msg.to_s.each_byte do |char_ord|
				# 	if char_ord == 10 || (char_ord >31 && char_ord <127)
				# 		log_txt += char_ord.chr
				# 	end
				# end
				# $switch_log.add(Logger::ERROR, log_txt, name)
			end
			def log_value(msg = nil,name = nil, level = 0)
				$log_describe.each do |key, value|
					value.call("#{DateTime.now.to_time.to_s}[#{name}]--#{msg}") if $switch_log.level <= level
				end
				Switch::sw_log
			end
			def log_level_set(level = nil)
				case level
				when "debug"
					$switch_log.level = Logger::DEBUG
				when "info"
					$switch_log.level = Logger::INFO
				when "warn"
					$switch_log.level = Logger::WARN
				when "error"
					$switch_log.level = Logger::ERROR
				else
					error("log level args error")
				end
			end
		end
	end
	class ConnectServer
		include Socket::Constants
		attr_accessor :host, :port, :flag
		attr_accessor :mgIp, :ascId
		attr_reader   :link_fd, :nac_status
		def initialize(host=nil, port = nil)
			@sw_log = Switch.sw_log
			@host = host
			@port = 6003
			@nac_status = "false"
			@flag = 0
            @link_fd = nil
			@nac_cfg = "/var/tmp/ruby_switch.conf"
			#@nac_cfg = "/home/kang/nac_license"
			@mgIp = ""
			@ascId = ""
		end
		def connect
            @flag = 0
            ret = 0
			read_config
			if @nac_status == "true" && @host != "0.0.0.0"
				begin
					@link_fd = Socket.new(AF_INET, SOCK_STREAM, 0)
					@link_fd.setsockopt(Socket::SOL_SOCKET, Socket::SO_KEEPALIVE, 30)
					@link_fd.setsockopt(Socket::SOL_SOCKET, Socket::SO_SNDTIMEO, [3, 0].pack("l_2"))
					server_addr = Socket.pack_sockaddr_in( @port, @host)
					@link_fd.connect server_addr
					# @link_fd = TCPSocket.open(@host, @port)
					@flag = 0
					Switch.log.info "connect server #{@link_fd}--#{@host}:#{@port} success"
				rescue => error
					Switch.log.error error
					@flag = -1
					@link_fd = nil
					Switch.log.error "connect server #{@host}:#{@port} fail"
				end
			else
				Switch.log.warn("nac status = #{@nac_status} #{@host}:#{@port} not connect to server")
				@flag = -1
			end
			Log.info "get nac status = #{@nac_status}"
			Log.info "get nac host = #{@host} port = #{@port}"
			Log.info "get nac mgIp = #{@mgIp}"
			Log.info "get nac ascId = #{$ascId}"
			return @flag
		end

		def read
			ret = 0
			msg = ""
			begin
				if @flag == 0 && @link_fd.respond_to?(:readpartial)
					msg = @link_fd.readpartial(4096)
				end
			rescue => error
				Switch.log.error error
				@flag = -2
				#self.reconnect
                @link_fd = nil
				close
			end
			if @link_fd == nil
				sleep(1)
			end
			return @flag, msg 
		end
		def write(data)
			begin
			@link_fd.puts(data) if Switch.nac == true
			rescue => error
				Switch.log.error error
				@flag = -3
				#self.reconnect
                @link_fd = nil
				close
			end
			return @flag
		end
		def close
			begin
				@link_fd.close
			rescue => error
				#Switch.log.error error
				@flag = -4
			ensure
				@link_fd = nil
			end
			return @flag
		end
		def reconnect
			times = 0
			loop do
				if connect != 0
					sleep(0.5)
				else
					break
				end
				times += 1
				if times == 3
					break
				end
			end
		end
		def read_config
			if File.exist?(@nac_cfg)
				config = File.read(@nac_cfg)
				config.each_line do |line|
					if /ascEable/ =~ line
						@nac_status = line.chomp.split("=")[1]
						if @nac_status == "true"
							Switch.nac(true)
						else
							Switch.nac(false)
							@link_fd = nil
						end
						#Switch.log.info "get nac status #{@nac_status}"
					end
					if /serverAddr/ =~ line
						@host = line.chomp.split("=")[1]
						@port = 6003
					end
					if /mgIp/ =~ line
						@mgIp = line.chomp.split("=")[1]
					end
					if /ascID/ =~ line
						$ascId = line.chomp.split("=")[1]
					end
				end
			end
		end
		private
	end
	class Server
		attr_accessor :server
		attr_accessor :udp_socket
		def initialize
			#@server = TCPServer.new 6800
			@udp_socket = Socket.udp_server_sockets("0.0.0.0", 6800)
		end

	end
end
