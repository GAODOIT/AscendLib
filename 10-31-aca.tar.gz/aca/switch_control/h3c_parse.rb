#######################################################################
#### Author: rubyer                                                 ###
#### Date: 2015.1.23												###
#### Description: parse h3c_switch methods function					###	
#### Modify reason:													###
#### Version: 1.0													###
#### Support switch list:                                           ###   
#### H3c: 5510                                                      ###
#### bugs report to hp104@hupu.net									###
#######################################################################
module Switch
	class Fetch
        def Fetch.get_h3c_arp(recv_text)
        	arp_list_array = []
            recv_text = recv_text.gsub("---- More ----\r\e[M", "")
        	recv_text.each_line do |line|
        		if /^([0-9]{1,3}[.]){3}[0-9]{1,3}/ =~ line	
        			arp_item_dic = {}
        			line_tmp = line.chomp
        			tmp_array = line_tmp.split
        			arp_item_dic["ip"] = tmp_array[0]
        			arp_item_dic["mac"] = format_mac_addr(tmp_array[1], "-").upcase	
        			#arp_item_dic["vlan"] = tmp_array[2]
        			#arp_item_dic["port"] = tmp_array[3]
        			arp_list_array.push(arp_item_dic)
        		end	
        	end
        	return arp_list_array
        end

        #"  ---- More ----\r\e[Mc03f-d538-c492     1       Learned          GigabitEthernet0/1     AGING\n"
        def Fetch.get_h3c_mac_addr(recv_text)
        	mac_addr_array = []
            recv_text = recv_text.gsub("---- More ----\r\e[M", "")
        	recv_text.each_line do |line| 
        		if /LEARNED/i =~ line
        			line = line.chomp		
        			mac_addr_item_dic = {}
        			tmp_array = line.split
        			mac_addr_item_dic["port"] = tmp_array[3]
        			mac_addr_item_dic["mac"]  = format_mac_addr(tmp_array[0], "-").upcase
        			mac_addr_item_dic["vlan"] = tmp_array[1]
        			mac_addr_array.push(mac_addr_item_dic)	
        		end
        	end
        
        	return mac_addr_array
        end
        
        
        #Eth1/0/8 == Ethernet1/0/24
        #GE1/1/3  == GigabitEthernet1/1/3
        #GE1/0/25             ADM  auto    A      A    1
        
        def Fetch.get_h3c_port_status(recv_text)
        	port_status_array = []
        	recv_text.each_line do |line|
        		if /^Eth/ =~ line || /^GE/ =~ line
        			line = line.chomp	
        			port_status_item_dic = {}
        			tmp_array = line.split
        			if /^Eth/ =~ tmp_array[0]
        				port_name = tmp_array[0].sub(/Eth/, "Ethernet")
        			elsif /^GE/ =~ tmp_array[0]	
        				port_name = tmp_array[0].sub(/GE/, "GigabitEthernet")
        			end
        			port_status_item_dic["port"] = port_name
        			port_status_item_dic["describe"] = tmp_array[6..-1].join(" ")
        			port_status_item_dic["status"] = tmp_array[1]
        			port_status_item_dic["vlan"] = tmp_array[5]
        			port_status_item_dic["iftrunk"] = "0"
        			port_status_array.push(port_status_item_dic)
        		end	
        	end
        	return port_status_array
        end
        
        def Fetch.get_h3c_s5024p_port_status(recv_text) 
        	port_status_array = []
            port_tmp_array = recv_text.split("[H3C]")
        
            port_tmp_array.each do |each_item|
                port_status_item_dic = {}
                port_name_match_data  = nil
                port_name_match_data = /^display interface.*\d$/.match(each_item)
                if port_name_match_data != nil
                    port_status_item_dic["port"] = /(Gi|Et).*\d$/.match(port_name_match_data[0])[0]
                end
                port_status_item_dic["describe"] = ""
        
                port_status_str = /current state.*$/.match(each_item)[0]
                tmp_array = port_status_str.split(": ")
                port_status_item_dic["status"] = tmp_array[-1]
        
                /^PVID:\s+([0-9]+)$/ =~ each_item
                port_status_item_dic["vlan"] = $1
        
                /^Port link-type:\s+([a-z]+)$/ =~ each_item
                if $1 == "access"
                    port_status_item_dic["iftrunk"] = "0"
                elsif $1 == "trunk"
                    port_status_item_dic["iftrunk"] = "1"
                end
        
                port_status_item_dic["mac"] = /([0-9a-f]{4}[-]){2}[0-9a-f]{4}$/.match(each_item)[0]
        
                port_status_array.push(port_status_item_dic)
            end
        
            return port_status_array
        end
        
        def Fetch.get_h3c_current_config(recv_text)
        	config_port_status_list = {}
        	config_tmp_array = []
            recv_text = recv_text.gsub("---- More ----\r\e[M", "")
        	config_tmp_array = recv_text.split(/#\n/)
        	config_tmp_array.each do |each_item|
        		if /^interface E/ =~ each_item || /^interface G/ =~ each_item
        			config_port_status_dic = {}
                    each_item = each_item.chomp.lstrip.rstrip
        			port_name = /^interface .*\d$/.match(each_item)[0]
        			array_tmp = port_name.split
        			config_port_status_dic["port"] = array_tmp[1]	
        			config_port_status_dic["describe"] = ""	
        			config_port_status_dic["vlan"] = "1"	
        			config_port_status_dic["iftrunk"] = "0"
        
        			access_vlan = /port access vlan \d*/.match(each_item)
        			if access_vlan != nil
        				config_port_status_dic["vlan"] = /\d+/.match(access_vlan[0])[0]
        			end
        
        			if /port link-type trunk/ =~ each_item
        				config_port_status_dic["iftrunk"] = "1"
        			end
        
        			trunk_vlan = /port trunk pvid vlan \d*/.match(each_item)
        			if trunk_vlan != nil
        				config_port_status_dic["vlan"] = /\d+/.match(trunk_vlan[0])[0]
        			end
        
        			config_port_status_list[config_port_status_dic["port"]] = config_port_status_dic		
        		end
        	end
        	return config_port_status_list
        end
        
        def Fetch.get_h3c_vlan_id(recv_text)
            vlan_id_text = ""
            line_valid_status = 0
            recv_text.each_line do |line|
                line = line.lstrip.chomp
                if /\A\d+/ =~ line
                    vlan_id_text += line
                    line_valid_status = 1
                elsif /\A\d+/ =~line && line_valid_status == 1
                    vlan_id_text += line
                elsif /\w*\]/  =~line
                    line_valid_status = 0
                end
            end
        
            ret_vlan_id = vlan_id_text.split(", ")
            if ret_vlan_id.length > 0
                ret_vlan_id[0] = /\d+/.match(ret_vlan_id[0])[0]
                ret_vlan_id[-1] = /\d+/.match(ret_vlan_id[-1])[0]
            end
            return ret_vlan_id
        end

	end #end class Fetch

end #end module Switch
