#ifndef __console__
    #include <zebra.h>
    #include <pthread.h>
    #include "command.h"
    #include "vtysh.h"
    #include<string.h> //memset
    #include<stdlib.h> //exit(0);
    #include<arpa/inet.h>
    #include<sys/socket.h>
    #include <sys/time.h>
    #include <sys/types.h>
    #include <unistd.h>
    #include <locale.h>
    #include "json.h"
#endif
