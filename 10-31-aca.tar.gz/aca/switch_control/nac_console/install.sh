#!/bin/bash
echo ""
echo "Extracting Installer install switch control "
echo ""
SWITCH_R="/nac"
TMPDIR=`mktemp -d /tmp/switch.XXXX`

ARCHIVE=`awk '/^__ARCHIVE_BELOW__/ {print NR + 1; exit 0; }' $0`
tail -n +$ARCHIVE $0 | tar zx -C $TMPDIR
CDIR=`pwd`
if [ -d "$SWITCH_R/switch" ]; then
	mkdir -p /bak/upgrade/nac_backup/switch
	rm -rf /bak/upgrade/nac_backup/switch/*
	TIME_S=`date +%s`
	mv $SWITCH_R/switch /bak/upgrade/nac_backup/switch/switch-$TIME_S
fi
cp -r $TMPDIR/switch $SWITCH_R/
cd $SWITCH_R/switch
cp -a mjson/lib/* /usr/lib
rm -rf mjson
GEM=`ls *.gem`
gem uninstall switch -a -x
gem install -l $GEM
rm -rf /nac/switch.bin
cd $CDIR
rm -rf $TMPDIR

exit 0

__ARCHIVE_BELOW__
