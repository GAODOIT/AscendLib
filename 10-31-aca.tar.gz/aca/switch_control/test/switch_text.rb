module Switch
	class SwitchText
		attr_accessor :arp, :vlan, :interface, :config, :mac, :result
		def initialize(name)
			fd = File.read("text/#{name}.yaml")
			#puts "fd = #{fd}"
			list = YAML.load(fd)
			#puts "list = #{list}"
			@arp = list["arp_list"]
			@vlan = list["vlan_list"]
			@interface = list["interface_list"]
			@config = list["config_list"]
			@mac = list["mac_list"]
            @result = {}
            @result["ip"] = "127.0.0.1"
            @result["status"] = 200
            @result["method"] = "UploadSwitchInfo"
			@result["sw_type"] = "rj_7609"
            res = {}
            res["show_arp"] = @arp
            res["show_mac_address_table"] = @mac
            res["show_interfaces_status"] = @interface
            res["show_running_config"]  = @config
            @result["result"] = res
		end
	end
end
