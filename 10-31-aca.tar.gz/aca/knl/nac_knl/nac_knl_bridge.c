/*
 *
 * Part:        nac framwork.
 *
 * Author:      ydh
 *
 */

#include "include/precomp.h"

int nac_knl_bridge(struct sk_buff *skb, unsigned short vlan_id)
{
    int nac_ret = NAC_KNL_ERR;
    struct net_device *vlan_dev;

    if(!skb
        || !skb->dev)
    {
        return NAC_KNL_ERR;
    }

    nac_ret = nac_mvg_pbr_check(skb, vlan_id);
    if(nac_ret == NAC_FORWARD)
    {
        if(skb->dev->ifindex == st_in_out_eth.us_in_index
            && pst_out_interface[0])
        {
            skb->dev = pst_out_interface[0];
        }
        else if(skb->dev->ifindex == st_in_out_eth.us_out_index
                && pst_in_interface[0])
        {
            skb->dev = pst_in_interface[0];
        }
        else
        {
            return NAC_KNL_ERR;
        }

        if(vlan_id > 0)
        {
            skb->vlan_tci = vlan_id | VLAN_TAG_PRESENT;
        }

        if(!skb->dev)
        {
           return NAC_KNL_ERR;
        }
        nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_knl_bridge-->forward, vlan_id = %u, skb->dev->name = %s\n", vlan_id, skb->dev->name);

        skb_forward_csum(skb);
        skb_push(skb, ETH_HLEN);
        dev_queue_xmit(skb);
        return NAC_KNL_OK;
    }

    if(nac_ret == NAC_REDIRECT)
    {
        return NAC_KNL_OK;
    }
	return NAC_KNL_ERR;
}


int nac_knl_bridge_init(void)
{
	return NAC_KNL_OK;
}

void nac_knl_bridge_exit(void)
{

}


