#include "include/precomp.h"

DEFINE_SPINLOCK(nac_knl_url_wm);
WM_STRUCT *pst_url_wm = (WM_STRUCT *)NULL;

DEFINE_SPINLOCK(nac_knl_user_agent_wm);
WM_STRUCT *pst_user_agent_wm = (WM_STRUCT *)NULL;




int nac_knl_wm_add(char *pc_string, int len, int isolation_id,
                   WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock, char *pc)
{
    int iRet;
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_wm_add-->%s = %s\n", pc, pc_string);

    if(len >= 64
        || strlen(pc_string) != len)
    {
        printk("nac_knl_wm_add-->error, len = %d\n", len);
        return NAC_KNL_ERR;
    }

    spin_lock_bh(&nac_knl_wm_lock);
    iRet = wm_add_pattern(pst_wm, pc_string , strlen(pc_string), isolation_id);
    if(iRet == NAC_KNL_ERR)
    {
        wm_free_all(pst_wm);
        spin_unlock_bh(&nac_knl_wm_lock);
        return iRet;
    }
    iRet = wm_prep_patterns(pst_wm);
    if(iRet == NAC_KNL_ERR)
    {
        wm_free_all(pst_wm);
        spin_unlock_bh(&nac_knl_wm_lock);
        return iRet;
    }
    spin_unlock_bh(&nac_knl_wm_lock);
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_wm_add-->%s iRet = %d\n", pc, iRet);
    return iRet;
}

int nac_knl_wm_rmv(char *pc_string, int len, WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock, char *pc)
{
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_wm_rmv->%s = %s\n", pc, pc_string);
    spin_lock_bh(&nac_knl_wm_lock);
    wm_rmv_single(pst_wm, pc_string);
    spin_unlock_bh(&nac_knl_wm_lock);
    return NAC_KNL_OK;
}

int nac_knl_wm_add_finish(WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock)
{
    int iRet;
    spin_lock_bh(&nac_knl_wm_lock);
    iRet = wm_prep_patterns(pst_wm);
    spin_unlock_bh(&nac_knl_wm_lock);
    return iRet;
}

int nac_knl_wm_search(char *pc_string, WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock, char *pc)
{
    int iRet;
    if(strlen(pc_string) <= 3)
    {
        //printk("nac_knl_url_search error size = %d\n", strlen(pc_url));
        return NAC_KNL_ERR;
    }
    iRet = wm_search(pst_wm, pc_string, strlen(pc_string));
    nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_knl_wm_search-->%s string = %s, len = %d, iRet = %d\n", pc, pc_string, strlen(pc_string), iRet);
    return iRet;
}

void nac_knl_wm_show(WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock, char *pc)
{
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "%s start\n", pc);
	spin_lock_bh(&nac_knl_wm_lock);
    wm_show(pst_wm);
	spin_unlock_bh(&nac_knl_wm_lock);
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "%s end\n", pc);
}


int nac_knl_wm_flush(WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock)
{
    spin_lock_bh(&nac_knl_wm_lock);
    wm_free_all(pst_wm);
    spin_unlock_bh(&nac_knl_wm_lock);
    return NAC_KNL_OK;
}

int nac_knl_wm_init(WM_STRUCT **pst_wm)
{
    *pst_wm = wm_new();
    if(!(*pst_wm))
    {
        return NAC_KNL_ERR;
    }
	return NAC_KNL_OK;
}

void nac_knl_wm_exit(WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock)
{
    spin_lock_bh(&nac_knl_wm_lock);
    if(pst_wm)
    {
        wm_free_all(pst_wm);
    }
    if(pst_wm)
    {
        kfree(pst_wm);
    }
    spin_unlock_bh(&nac_knl_wm_lock);
}


