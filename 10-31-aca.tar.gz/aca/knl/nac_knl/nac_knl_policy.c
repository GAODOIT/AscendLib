/*
 *
 * Part:        nac framwork.
 *
 * Author:      ydh
 *
 */

#include "include/precomp.h"


NAC_MODE nac_mode = NAC_PBR_MODE;

struct nac_knl_net_app gst_net_app;
struct nac_knl_ip_info gst_ip_info =
{
    .ac_redirect_ip         = "0.0.0.0",
    .ac_control_manager_ip  = "0.0.0.0",
    .ac_server_manager_ip   = "0.0.0.0",
};
unsigned int ui_redirect_ip         = 0;
unsigned int ui_control_manager_ip  = 0;
unsigned int ui_control_untrust_ip  = 0;
unsigned int ui_control_trust_ip    = 0;
unsigned int ui_server_manager_ip   = 0;
unsigned int ui_vrrp_ip             = 0;

char ac_get_proxy[50];
nac_knl_in_out_eth st_in_out_eth;

//////////////////
static LIST_HEAD(nac_knl_policy_obj_list);
static LIST_HEAD(nac_knl_policy_mode_list);
static LIST_HEAD(nac_knl_policy_vlan_map_list);
static LIST_HEAD(nac_knl_policy_bypass_ip_range_list);
struct list_head nac_knl_policy_bypass_list[1024];

/* Policy pool */
struct list_head *nac_knl_policy_pool[NAC_KNL_POLICY_NUM] =
{
	NULL,
	&nac_knl_policy_obj_list,
	&nac_knl_policy_mode_list,
	&nac_knl_policy_vlan_map_list,
	&nac_knl_policy_bypass_ip_range_list,
	nac_knl_policy_bypass_list,
};
/////////////

static inline int nac_knl_policy_invalid(struct nac_knl_policy *policy)
{
	if(unlikely(!policy))
    {
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_policy_invalid-->empty policy %p\n", policy);
		return NAC_KNL_ERR;
	}

	if(!policy->entry.type
        ||policy->entry.type >= NAC_KNL_POLICY_NUM
        || !nac_knl_policy_pool[policy->entry.type])
    {
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_policy_invalid-->invalid policy type %d\n", policy->entry.type);
		return NAC_KNL_ERR;
	}

	return NAC_KNL_OK;
}


int nac_knl_policy_add(const struct nac_knl_policy_hdr *hdr, unsigned int len)
{
	struct nac_knl_policy *pst_policy, *pst_policy_tmp;
	nac_knl_policy_attr *attr;
	struct list_head *plist;

	int err = 0;
    int pn;
    int size = 0;

    size = sizeof(struct nac_knl_policy_hdr) + sizeof(nac_knl_policy_attr) + sizeof(struct nac_knl_policy);

	if (len < size
        || !hdr
        || hdr->policy_nr <= 0)
	{
		return -EINVAL;
	}

	pn = hdr->policy_nr;

	mutex_lock(&nac_knl_app_mutex);

	attr = (char *)(hdr) + sizeof(struct nac_knl_policy_hdr);
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_policy_add-->len = %d, attr->l = %d\n", len, attr->l);
	while (pn)
    {
		--pn;
		if(unlikely(attr->l < sizeof(*pst_policy))
            || 0 != nac_knl_policy_invalid((void *)attr->v))
        {
			err = -EINVAL;
			goto OUT;
		}

		pst_policy = kmalloc(attr->l, GFP_KERNEL);
		if(!pst_policy)
        {
			err = -ENOMEM;
			goto OUT;
		}
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_policy_add-->1\n");
		if(0 != copy_from_user(pst_policy, attr->v, attr->l))
        {
			err = -EACCES;
			kfree(pst_policy);
			goto OUT;
		}
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_policy_add-->2\n");
		if(pst_policy->entry.type < NAC_KNL_POLICY_BYPASS)
        {
			plist = nac_knl_policy_pool[pst_policy->entry.type];
		}
        else
        {
			int idx;

			//idx = jhash_1word(pst_policy->selector.u.acl.daddr_min, 0) & (1024 -1);
			//plist = &nac_knl_policy_list[pst_policy->entry.type][idx];
		}
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_policy_add-->3\n");
		list_for_each_entry(pst_policy_tmp, plist, policy_list)
        {
            nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_policy_add-->4\n");
			if (pst_policy->entry.priority >= pst_policy_tmp->entry.priority)
            {
				__list_add_rcu(&pst_policy->policy_list, pst_policy_tmp->policy_list.prev, &pst_policy_tmp->policy_list);
				goto FOUND;
			}
            else if (pst_policy_tmp->entry.priority &&	pst_policy_tmp->entry.priority == pst_policy->entry.priority)
            {
				err = -EEXIST;
				kfree(pst_policy);
				goto OUT;
			}
		}

		list_add_tail_rcu(&pst_policy->policy_list, plist);

FOUND:
		// To make sure, policy really in the list
		synchronize_rcu();
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_policy_add-->policy ID %lu TYPE %d SYNC %d PRIORITY %d OBJ_MASK %lu\n",
                                              pst_policy->entry.policy_id, pst_policy->entry.type,
                                              pst_policy->entry.sync, pst_policy->entry.priority,
                                              pst_policy->entry.obj_mask);
        /*
		ktpn_policy_sync(po);
        */
		//attr = TPN_NPD(attr);
	}

OUT:
	mutex_unlock(&nac_knl_app_mutex);
	return err;
}

int nac_knl_policy_del(const struct nac_knl_policy_hdr *hdr, unsigned int len)
{
	struct nac_knl_policy *pst_policy, *pst_policy_tmp, *tmp;
	nac_knl_policy_attr *attr;
	struct list_head *plist;

	int err = 0;
    int pn;
    int size = 0;

    size = sizeof(struct nac_knl_policy_hdr) + sizeof(nac_knl_policy_attr) + sizeof(struct nac_knl_policy);

	if (len < size
        || !hdr
        || hdr->policy_nr <= 0)
	{
		return -EINVAL;
	}

	pn = hdr->policy_nr;

	mutex_lock(&nac_knl_app_mutex);

	attr = (char *)(hdr) + sizeof(struct nac_knl_policy_hdr);
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_policy_del-->len = %d, attr->l = %d\n", len, attr->l);
	while (pn)
    {
		--pn;
		if(unlikely(attr->l < sizeof(*pst_policy))
            || 0 != nac_knl_policy_invalid((void *)attr->v))
        {
			err = -EINVAL;
			goto OUT;
		}

		pst_policy_tmp = (void *)attr->v;

		BUG_ON(pst_policy_tmp->entry.type >= NAC_KNL_POLICY_NUM);

		if(pst_policy_tmp->entry.type < NAC_KNL_POLICY_BYPASS)
        {
			plist = nac_knl_policy_pool[pst_policy_tmp->entry.type];
		}
        else
        {
			int idx;
			//idx = jhash_1word(pst_policy_tmp->selector.u.acl.daddr_min, 0) & (1024 -1);
			//plist = &tpn_policy_list[pst_policy_tmp->entry.type][idx];
		}

		list_for_each_entry_safe(pst_policy, tmp, plist, policy_list)
        {
			if (pst_policy->entry.policy_id == pst_policy_tmp->entry.policy_id
                && pst_policy->entry.type == pst_policy_tmp->entry.type)
            {

				list_del_rcu(&pst_policy->policy_list);
				synchronize_rcu();

				//nac_knl_policy_sync(pst_policy);
				nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_policy_del-->policy ID %lu TYPE %d SYNC %d PRIORITY %d OBJ_MASK %lu\n",
                                              pst_policy->entry.policy_id, pst_policy->entry.type,
                                              pst_policy->entry.sync, pst_policy->entry.priority,
                                              pst_policy->entry.obj_mask);

				kfree(pst_policy);
			}
		}
		//attr = NAC_NPD(attr);
	}

OUT:
	mutex_unlock(&nac_knl_app_mutex);
	return err;
}

void nac_knl_policy_flush(ENUM_POLICY_TYPE policy_type)
{
	struct nac_knl_policy *pst_policy, *tmp;
	int i, c = 1;
	struct list_head *plist;


    spin_lock_bh(&nac_knl_vlan_map);
    for(i = 0; i < VLAN_MAX_RANGE; i++)
    {
        vlan_ago_after_map_table[i] = 0;
        vlan_in_index[i]  = 0;
        vlan_out_index[i] = 0;
    }
    pst_in_interface[0]  = NULL;
    pst_out_interface[0] = NULL;

    memset(&st_in_out_eth, '\0', sizeof(st_in_out_eth));
    st_in_out_eth.us_in_index  = 0;
    st_in_out_eth.us_out_index = 0;

    memset(&gst_net_app, 0, sizeof(struct nac_knl_net_app));
    nac_knl_flag = 0;
    nat_ip_num   = 0;
    atomic_set(&g_domain_number, 0);

    memset(ac_get_proxy, '\0', sizeof(ac_get_proxy));
    ui_redirect_ip         = 0;
    ui_control_manager_ip  = 0;
    ui_server_manager_ip   = 0;
    ui_control_untrust_ip  = 0;
    ui_control_trust_ip    = 0;
    memset(&gst_ip_info, '\0', sizeof(gst_ip_info));
    nac_knl_dhcp_flag = DHCP_CLOSE;
    spin_unlock_bh(&nac_knl_vlan_map);

    //nac_mode = NAC_NULL_MODE;

	mutex_lock(&nac_knl_app_mutex);
    printk(KERN_DEBUG "nac_knl_policy_flush-->policy_type = %d\n", policy_type);
	for(i = 1; i < NAC_KNL_POLICY_NUM; i++)
    {
		if(i < NAC_KNL_POLICY_BYPASS)
        {
			c = 1;
			plist = nac_knl_policy_pool[i];
		}
        else
        {
			c = 1024;
			plist = &nac_knl_policy_pool[i][0];
		}

		while(c > 0)
        {
			list_for_each_entry_safe(pst_policy, tmp, plist, policy_list)
            {
				list_del_rcu(&pst_policy->policy_list);
				synchronize_rcu();
                nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_policy_flush-->policy ID %lu TYPE %d SYNC %d PRIORITY %d OBJ_MASK %lu\n",
                                              pst_policy->entry.policy_id, pst_policy->entry.type,
                                              pst_policy->entry.sync, pst_policy->entry.priority,
                                              pst_policy->entry.obj_mask);
				kfree(pst_policy);
			}
			--c;
			++plist;
		}
	}

	mutex_unlock(&nac_knl_app_mutex);

}


static inline int in_range(unsigned long val, unsigned long min, unsigned long max)
{
	return (val <= max && val >= min);
}

static int nac_knl_policy_selector_match(const struct nac_knl_selector *selector,
                                          ENUM_POLICY_TYPE policy_type,
                                          unsigned long ip_address)
{
    int iRet = 0;

	switch(policy_type)
    {
	case NAC_KNL_POLICY_BYPASS_IP_RANGE:
         iRet = in_range(ip_address, selector->u.bypass_ipseg.min_addr, selector->u.bypass_ipseg.max_addr);
		break;
	default:
        break;
	}

	return iRet;
}

int __nac_knl_lookup_policy(ENUM_POLICY_TYPE type, void *buf, int len)
{
	struct nac_knl_policy *pst_policy;
	struct list_head *plist;
    int iRet = NAC_KNL_ERR;

	if(type < NAC_KNL_POLICY_BYPASS)
	{
		plist = nac_knl_policy_pool[type];
	}
	else
    {
		int idx;
		idx = jhash_1word(66, 0)&(1024 - 1);
		plist = &nac_knl_policy_pool[type][idx];
	}

	list_for_each_entry_rcu(pst_policy, plist, policy_list)
    {
        if(type == NAC_KNL_POLICY_BYPASS_IP_RANGE)
        {
            unsigned int ip_address = nac_knl_get_u32(buf, 0);
            if(nac_knl_policy_selector_match(&pst_policy->selector, type, ip_address))
            {
                iRet = NAC_KNL_OK;
            }
        }
	}
    return iRet;
}

int nac_knl_policy_set_mode(NAC_MODE nac_mode_tmp)
{
    nac_mode = nac_mode_tmp;
    return NAC_KNL_OK;
}

int nac_knl_policy_pbr_2_eth_switch(int eth_switch)
{
    eth_switch > 0 ? (nac_knl_flag |= NAC_KNL_PBR_TWO_ETH ):(nac_knl_flag &= ~NAC_KNL_PBR_TWO_ETH);
    if(nac_knl_flag & NAC_KNL_PBR_TWO_ETH)
    {
        pst_out_interface[0] = dev_get_by_name(&init_net, st_in_out_eth.ac_out_eth);
    }
    else
    {
        pst_out_interface[0] = dev_get_by_name(&init_net, st_in_out_eth.ac_in_eth);
    }
    return NAC_KNL_OK;
}

int nac_knl_policy_pbr_2_eth_mac(nac_knl_eth3_mac *pst_eth3, unsigned int len)
{
    if(sizeof(nac_knl_eth3_mac) != len)
    {
        return NAC_KNL_ERR;
    }
    memcpy(&st_eth3, pst_eth3, len);
    return NAC_KNL_OK;
}

int nac_knl_policy_eth0_mac(char *pc_mac, unsigned int len)
{
    char ac_mac[ETH_ALEN];
    if(ETH_ALEN != len)
    {
        return NAC_KNL_ERR;
    }
    memcpy(ac_mac, pc_mac, ETH_ALEN);
    sprintf(pc_eth0_mac, "%02X-%02X-%02X-%02X-%02X-%02X", MAC_FORMAT(ac_mac));
    return NAC_KNL_OK;
}

int nac_knl_policy_in_out_eth(nac_knl_in_out_eth *pst_in_out_eth, unsigned int len)
{
    struct net_device *dev = NULL;
    if(sizeof(nac_knl_in_out_eth) != len)
    {
        return NAC_KNL_ERR;
    }
    memcpy(&st_in_out_eth, pst_in_out_eth, len);

    if(nac_mode == NAC_PBR_MODE
        && !(nac_knl_flag & NAC_KNL_PBR_TWO_ETH))
    {
        dev = dev_get_by_name(&init_net, st_in_out_eth.ac_in_eth);
        if(dev)
        {
            st_in_out_eth.us_out_index = dev->ifindex;
			st_in_out_eth.us_in_index  = dev->ifindex;
            pst_out_interface[0]       = dev;
        }
    }

    if(nac_mode == NAC_MVG_MODE
       || nac_mode == NAC_BRIDGE_MODE
       || nac_knl_flag & NAC_KNL_PBR_TWO_ETH)
    {
        dev = dev_get_by_name(&init_net, st_in_out_eth.ac_in_eth);
        if(dev)
        {
            st_in_out_eth.us_in_index = dev->ifindex;
            pst_in_interface[0]       = dev;
        }
        dev = dev_get_by_name(&init_net, st_in_out_eth.ac_out_eth);
        if(dev)
        {
            st_in_out_eth.us_out_index = dev->ifindex;
            pst_out_interface[0]       = dev;
        }
    }

    return NAC_KNL_OK;
}

int nac_knl_policy_set_vlan_map(const nac_knl_policy_vlap *pst_vlan_map, unsigned int len, int action)
{
    if(sizeof(nac_knl_policy_vlap) != len)
    {
        return NAC_KNL_ERR;
    }
    if(pst_vlan_map->insulate_vlan >= VLAN_MAX_RANGE
        || pst_vlan_map->pass_vlan >= VLAN_MAX_RANGE)
    {
        return NAC_KNL_ERR;
    }
    spin_lock_bh(&nac_knl_vlan_map);
    if(NAC_CMD_SYS_SET_VLAN_MAP == action)
    {
        vlan_ago_after_map_table[pst_vlan_map->insulate_vlan] = pst_vlan_map->pass_vlan;
        vlan_ago_after_map_table[pst_vlan_map->pass_vlan]     = pst_vlan_map->insulate_vlan;
        vlan_in_index[pst_vlan_map->insulate_vlan] = 1;
        vlan_out_index[pst_vlan_map->pass_vlan]    = 1;
    }
    if(NAC_CMD_SYS_FLUSH_VLAN_MAP == action)
    {
        vlan_ago_after_map_table[pst_vlan_map->insulate_vlan] = 0;
        vlan_ago_after_map_table[pst_vlan_map->pass_vlan]     = 0;
        vlan_in_index[pst_vlan_map->insulate_vlan] = 0;
        vlan_out_index[pst_vlan_map->pass_vlan]    = 0;
    }
    spin_unlock_bh(&nac_knl_vlan_map);

    return NAC_KNL_OK;
}

int nac_knl_policy_set_net_app(const struct nac_knl_net_app *pst_net_app, unsigned int len)
{
    if(sizeof(struct nac_knl_net_app) != len)
    {
        return NAC_KNL_ERR;
    }

    gst_net_app = *pst_net_app;
    if(gst_net_app.switc == 0)
    {
        nac_knl_rbtree_flush_single(NAC_KNL_RBTREE_NETAPP_SERVER);
        nac_knl_rbtree_flush_single(NAC_KNL_RBTREE_EXCEPT_NET_APP);
    }

    return NAC_KNL_OK;
}

int nac_knl_policy_set_ip_info(const struct nac_knl_ip_info *pst_ip_info, unsigned int len)
{
    if(sizeof(struct nac_knl_ip_info) != len)
    {
        return NAC_KNL_ERR;
    }
    if(strlen(gst_ip_info.ac_redirect_ip) > 0)
    {
        nac_knl_wm_rmv(gst_ip_info.ac_redirect_ip, strlen(gst_ip_info.ac_redirect_ip), pst_url_wm, nac_knl_url_wm, "url");
    }
    memcpy(&gst_ip_info, pst_ip_info, len);

    ui_redirect_ip         = in_aton(gst_ip_info.ac_redirect_ip);
    ui_control_manager_ip  = in_aton(gst_ip_info.ac_control_manager_ip);
    ui_server_manager_ip   = in_aton(gst_ip_info.ac_server_manager_ip);
    ui_control_untrust_ip  = in_aton(gst_ip_info.ac_control_untrust_ip);
    ui_control_trust_ip    = in_aton(gst_ip_info.ac_control_trust_ip);

	memset(ac_get_proxy, '\0', sizeof(ac_get_proxy));
    strcat(ac_get_proxy, "GET http://");
    strcat(ac_get_proxy, gst_ip_info.ac_redirect_ip);
	
    if(strlen(gst_ip_info.ac_redirect_ip) > 0)
    {
        nac_knl_wm_add(gst_ip_info.ac_redirect_ip, strlen(gst_ip_info.ac_redirect_ip), GLOBAL_DOMAIN,
                       pst_url_wm, nac_knl_url_wm, "url");
    }
    return NAC_KNL_OK;
}


int nac_knl_policy_set_bypass(const nac_knl_policy_pass_ip *pst_pass_ip, unsigned int len)
{
    //nac_knl_policy_pool[NAC_KNL_POLICY_BYPASS_IP_RANGE]
}

int nac_knl_policy_show(void)
{
	struct net_device *dev = NULL;
    char ac_nac_mode[10]   = "";
    struct nac_knl_policy *pst_policy;
	int i, j, k, m;

    switch(nac_mode)
    {
    case NAC_MVG_MODE:
        strcpy(ac_nac_mode, "vg+");
        break;
    case NAC_PBR_MODE:
        strcpy(ac_nac_mode, "pbr");
        break;
    case NAC_BRIDGE_MODE:
        strcpy(ac_nac_mode, "bridge");
        break;
    default:
        strcpy(ac_nac_mode, "empty");
        break;
    }
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_mode            = %s\n", ac_nac_mode);
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_status          = %s\n", nac_knl_switch==1?"stop":"start");
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_switch          = %s\n", nac_knl_pass_switch==0?"enable":"disable");
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "nat_auto_check_swit = %s\n", nat_swit==NAT_ENABLE?"enable":"disable");
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "redirect_flag       = %s\n", gst_ip_info.en_redirect_flag==NAC_KNL_POLICY_REDIRECT?"redirect":"drop");
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "redirect_ip         = %s\n", gst_ip_info.ac_redirect_ip);
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "control_manager_ip  = %s\n", gst_ip_info.ac_control_manager_ip);
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "server_manager_ip   = %s\n", gst_ip_info.ac_server_manager_ip);
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "control_untrust_ip  = %s\n", gst_ip_info.ac_control_untrust_ip);
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "control_trust_ip    = %s\n", gst_ip_info.ac_control_trust_ip);
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "manager_mac         = %s\n", pc_eth0_mac);
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "g_domain_number     = %d\n", atomic_read(&g_domain_number));
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "nat_ip_num          = %u\n", nat_ip_num);


    if(nac_mode == NAC_PBR_MODE)
    {
        if (nac_knl_flag & NAC_KNL_PBR_TWO_ETH)
        {
            nac_knl_debug(NAC_KNL_MODULE_POLICY, "in-->out            = %s-%d--->%s-%d\n", st_in_out_eth.ac_in_eth, st_in_out_eth.us_in_index, st_in_out_eth.ac_out_eth, st_in_out_eth.us_out_index);
            nac_knl_debug(NAC_KNL_MODULE_POLICY, "eth3_mac            = %02X-%02X-%02X-%02X-%02X-%02X\n", MAC_FORMAT(st_eth3.ac_eth3_mac));
            nac_knl_debug(NAC_KNL_MODULE_POLICY, "eth3_sw_mac         = %02X-%02X-%02X-%02X-%02X-%02X\n", MAC_FORMAT(st_eth3.ac_eth3_sw_mac));
        }
        else
        {
            nac_knl_debug(NAC_KNL_MODULE_POLICY, "in-->out            = %s-%d--->%s-%d\n", st_in_out_eth.ac_in_eth, st_in_out_eth.us_in_index, st_in_out_eth.ac_in_eth, st_in_out_eth.us_in_index);
        }
        if(pst_out_interface[0])
        {
            dev = pst_out_interface[0];
            nac_knl_debug(NAC_KNL_MODULE_POLICY, "out_interface       = %s\n", dev->name);
        }
    }
    else
    {
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "in-->out            = %s-%d--->%s-%d\n", st_in_out_eth.ac_in_eth, st_in_out_eth.us_in_index, st_in_out_eth.ac_out_eth, st_in_out_eth.us_out_index);
    }

    if(nac_mode == NAC_MVG_MODE)
    {
        spin_lock_bh(&nac_knl_vlan_map);
        for(i = 0; i < VLAN_MAX_RANGE; i++)
        {
            if(vlan_ago_after_map_table[i] != 0)
            {
                nac_knl_debug(NAC_KNL_MODULE_POLICY, "vlan_ago_after_map_table[%d] = %d\n", i, vlan_ago_after_map_table[i]);
            }
        }
        dev = pst_in_interface[0];
        if(dev)
        {
            nac_knl_debug(NAC_KNL_MODULE_POLICY, "in_interface  = %s(%p)\n", dev->name, dev);
        }

        dev = pst_out_interface[0];
        if(dev)
        {
            nac_knl_debug(NAC_KNL_MODULE_POLICY, "out_interface = %s(%p)\n", dev->name, dev);
        }
        spin_unlock_bh(&nac_knl_vlan_map);
    }

    nac_knl_rbtree_show();
    nac_knl_wm_show(pst_url_wm, nac_knl_url_wm, "url");	

	return NAC_KNL_OK;
}

int nac_knl_policy_init(void)
{
	int i;
    printk("nac_knl_policy_init\n");
    memset(ac_get_proxy, '\0', sizeof(ac_get_proxy));
	ui_vrrp_ip = in_aton("224.0.0.18");
	for(i = 0; i < NAC_KNL_POLICY_BYPASS; i++)
    {
		if(nac_knl_policy_pool[i])
		{
			INIT_LIST_HEAD(nac_knl_policy_pool[i]);
		}
	}

    for(i = NAC_KNL_POLICY_BYPASS; i < NAC_KNL_POLICY_NUM; i++)
    {
		if(nac_knl_policy_pool[i])
        {
			int j;
			for (j = 0; j < 1024; j++)
			{
				INIT_LIST_HEAD(&nac_knl_policy_pool[i][j]);
			}
		}
	}
	
    memset(&gst_net_app, 0, sizeof(struct nac_knl_net_app));
	return NAC_KNL_OK;
}

void nac_knl_policy_exit(void)
{
    printk("nac_knl_policy_exit\n");
}

