#ifndef __NAC_KNL_URL_H__
#define __NAC_KNL_URL_H__


extern spinlock_t nac_knl_url_wm;
extern WM_STRUCT *pst_url_wm;

extern spinlock_t nac_knl_user_agent_wm;
extern WM_STRUCT *pst_user_agent_wm;



int nac_knl_wm_add(char *pc_string, int len, int isolation_id,
                   WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock, char *pc);
int nac_knl_wm_rmv(char *pc_string, int len, WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock, char *pc);
int nac_knl_wm_add_finish(WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock);
int nac_knl_wm_search(char *pc_string, WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock, char *pc);
int nac_knl_wm_flush(WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock);
void nac_knl_wm_show(WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock, char *pc);
int nac_knl_wm_init(WM_STRUCT **pst_wm);
void nac_knl_wm_exit(WM_STRUCT *pst_wm, spinlock_t nac_knl_wm_lock);


#endif

