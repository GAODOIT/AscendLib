#ifndef	__NAC_KNL_LOG_H__
#define	__NAC_KNL_LOG_H__


#define NAC_KNL_MODULE_SKB 		1
#define NAC_KNL_MODULE_ARP 	    2
#define NAC_KNL_MODULE_UDP 	    4
#define NAC_KNL_MODULE_IOCTL 	8
#define NAC_KNL_MODULE_GROUB 	16
#define NAC_KNL_MODULE_USER     32
#define NAC_KNL_MODULE_POLICY   64
#define NAC_KNL_MODULE_TIMER 	128
#define NAC_KNL_MODULE_DOMAIN 	256
#define NAC_KNL_MODULE_NETLINK 	512
#define NAC_KNL_MODULE_NAT      1024
#define NAC_KNL_MODULE_DHCP     2048




#define NIPQUAD(addr) \
	((unsigned char *)&addr)[0], \
	((unsigned char *)&addr)[1], \
	((unsigned char *)&addr)[2], \
	((unsigned char *)&addr)[3]

#define IP_FORMAT_EX  "%u.%u.%u.%u"
#define MAC_FORMAT_EX "%02X-%02X-%02X-%02X-%02X-%02X"


#define MAC_FORMAT(addr) \
        ((unsigned char *)&addr)[0], \
        ((unsigned char *)&addr)[1], \
        ((unsigned char *)&addr)[2], \
        ((unsigned char *)&addr)[3], \
        ((unsigned char *)&addr)[4], \
        ((unsigned char *)&addr)[5]


#define nac_knl_debug(flags, format, args...) \
	if (unlikely((flags)&nac_knl_debug_modules))\
		printk(KERN_DEBUG""format, ##args)


#endif

