#ifndef	__NAC_KNL_PBR_H__
#define	__NAC_KNL_PBR_H__

int nac_knl_pbr(struct sk_buff *skb);
int nac_knl_pbr_init(void);

#endif

