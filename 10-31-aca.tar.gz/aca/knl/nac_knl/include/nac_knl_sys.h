#ifndef	__NAC_KNL_SYS_H__
#define	__NAC_KNL_SYS_H__


#define NAC_TYPE_NETAPP             1
#define NAC_TYPE_NAT_ENABLE         2
#define NAC_TYPE_ISOLATION_IP       4
#define NAC_TYPE_NETAPP_FORWARD     8
#define NAC_TYPE_HTTP_PROXY_SERVERD 16
#define NAC_TYPE_POST               32
#define NAC_TYPE_DOMAIN             64
#define NAC_TYPE_LOCAL              128
#define NAC_TYPE_PROXY              256
#define NAC_TYPE_NAT_DISABLE        512
#define NAC_TYPE_NETAPP_EXCEPT      1024


extern int hostStep[];
extern int httpStep[];
extern int user_agent[];

struct nac_knl_arp
{
    unsigned char		ar_sha[ETH_ALEN];	/* sender hardware address	*/
	unsigned char		ar_sip[4];		    /* sender IP address		*/
	unsigned char		ar_tha[ETH_ALEN];	/* target hardware address	*/
	unsigned char		ar_tip[4];		    /* target IP address		*/
};

struct nac_knl_rtc_time
{
	struct rtc_time rt;
	unsigned int dos;
};

typedef enum
{
	NAC_LOCAL_DELIVER = 1,
	NAC_FORWARD       = 2,
	NAC_DROP          = 4,
	NAC_REDIRECT      = 8,
	NAC_NETAPP        = 16,
	NAC_NAT_SERVER_ENABLE  = 32,
	NAC_EXEMPT             = 64,
	NAC_ISOLATION          = 128,
	NAC_HTTP_PROXY_SERVER  = 256,
	NAC_NAT_SERVER_DISABLE = 512,
	NAC_NETAPP_EXCEPT      = 1024,
}NAC_POLICY;

#define NAC_KNL_ERR -1
#define NAC_KNL_OK 0


#define nac_knl_get_u8(X,O)   (*(unsigned char *)((unsigned char)X + O))
#define nac_knl_get_u16(X,O)  (*(unsigned short *)((unsigned short)X + O))
#define nac_knl_get_u32(X,O)  (*(unsigned int *)((unsigned int)X + O))

extern spinlock_t nac_knl_vlan_map;
extern struct net_device *pst_in_interface[];
extern struct net_device *pst_out_interface[];


extern char *pc_eth0_mac;

extern int nac_knl_flag;

#define NAC_KNL_PBR_TWO_ETH 1


int nac_mvg_pbr_check(struct sk_buff *skb, unsigned short vlan_id);

#endif

