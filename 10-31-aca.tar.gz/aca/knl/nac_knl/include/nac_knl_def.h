#ifndef	__NAC_KNL_DEF_H__
#define	__NAC_KNL_DEF_H__


///////////////////////////////////////////////////avoid app compiler fail
#define ETH_ALEN 6

struct sock
{
    void *null;
};

struct sk_buff {
	void *null;
};

struct udphdr {
    void *null;
};


typedef struct { int counter; } atomic_t;
struct hlist_node
{
	void *null0;
	void *null1;
};

struct list_head
{
	struct list_head *next, *prev;
};

struct rcu_head
{
	void *null0;
	void *null1;
};

#define member_offsetof(TYPE, MEMBER) ((unsigned long) &((TYPE *)0)->MEMBER)

#define container_of(ptr, type, member) ({			\
	const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
	(type *)( (char *)__mptr - member_offsetof(type,member) );})
/////////////////////////////////////////////////

#include "nac_knl_ioctl.h"
#include "nac_knl_netlink.h"
#include "nac_knl_user.h"
#include "nac_knl_policy.h"
#include "nac_knl_rbtree.h"
#include "nac_knl_domain.h"
#include "nac_knl_nat.h"
#include "nac_knl_protocol.h"
#endif

