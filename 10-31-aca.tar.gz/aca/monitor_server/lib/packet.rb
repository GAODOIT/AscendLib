require 'json'
require 'date'
require 'redis'
require 'digest'
require 'wrap_redis'
module Message
    def set_head(heads)
        MsgTransfer::MSG_HEAD.each do |key|
            @head[key] = heads[key] if heads.has_key?(key)
        end
    end

    def get_head
        msg_head = ''
        MsgTransfer::MSG_HEAD.each do |key|
            if @head[key] != nil
                msg_head += key + ": #{@head[key]}" + "\r\n"
            end
        end
        "#{msg_head}"
    end

    def init_head
        @head = {}
    end

    def msg_package(msg, msg_info)
        init_head
        MsgTransfer::Log.debug "msg_package msg_info = #{msg_info}"
        set_head "MessageMethod" => msg_info["method"]
        set_head "MessageType" => "json"
        set_head "CompressType" => "nil"
        set_head "DateTime" => DateTime.now.httpdate.gsub(/:/, '.')
        set_head "ClientCode" => msg_info["client_id"]
        set_head "MessageLength" => "0"
        set_head "MessageLength" => msg.bytesize if msg != nil
        package = get_head
        if msg != nil
            package += msg += "\r\n"
        end
        MsgTransfer::Log.debug "msg_package return #{package}"
        package
    end
end
module MsgTransfer
    $keys = ['port_list', 'switch_list', 'nac_mode', 'iface_status', 'vlan_map', 'nac_info', \
            'escape_status', 'ha_status', 'net_info', 'traffic_status']
    MSG_HEAD = ["MessageMethod", "MessageType", "CompressType", \
				 "DateTime", "ClientCode", "Address", "StatusCode", "MessageLength"]
    METHOD_MAP = {"ShowNacMode" => "nac_mode", "ShowInterfaceStatus" => "iface_status", \
                  "ShowProcessStatus" => "process_info", "ShowVlanMaping" => "vlan_map", \
                  "ShowSwitchList" => "switch_list", "ShowSwitchPort" => "port_list",  \
                  "ShowEscapeStatus" => "escape_status", "ShowHaStatus" => "ha_status", \
                  "ShowTrafficStatus" => "traffic_status"}
    PROCESS_DIC = {"tomcat" => 80, "mysql" => 3306, "nac_system" => 6001, "main_switch" => 6800}
    class MsgHandle
        REDIS_IP = "127.0.0.1"
        # REDIS_IP = "10.10.2.227"
        REDIS_POT = 6999

        def initialize(server)
            @server = server
            # @redis = Redis.new(host: REDIS_IP, port: REDIS_POT, db: 6)
            # @cache_client = Redis.new(host: REDIS_IP, port: REDIS_POT, db: 6)
            @net_toplist = []
            @max_traffic = 0
            @traffic_escape_status = false
            @moniter_iface = "0"
            @redis = RedisCache.new(REDIS_IP, REDIS_POT, 6)
            @cache_client = RedisCache.new(REDIS_IP, REDIS_POT, 6)
        end

        def do_handle(data, stream)
            # puts "receive data: #{data}"
            # stream.send_msg("server receive: #{data}")
            msg_dispatch(data, stream)
        end

        def msg_dispatch(msgs, stream)
            msgs.each do |msg|
                stream.client_id =  msg["head"]["ClientCode"] if stream.client_id == "0"
                if msg["head"]["MessageMethod"] == "HeartBeat"
                    stream.heart_timer = 3
                    # if !stream.client_id
                    #     stream.client_id =  msg["head"]["ClientId"]
                    # end
                    next
                end
                dispatch_process msg, stream
            end
        end

        def dispatch_process(msg, stream)
            msg_txt = ''
            key = METHOD_MAP[msg["head"]["MessageMethod"]]
            redis_keys = @cache_client.keys("*")
            if redis_keys.include?(key)
                stream.send_msg msg_assemble(key), msg["head"]["MessageMethod"]
            elsif $keys.include? key
                asyn_notify key
            else
                Log.error "method #{msg["head"]["MessageMethod"]} error key = #{key} error"
            end
        end

        def msg_assemble(key)
            paceket = nil
            msg_txt = nil
            if key == "port_list"
                msg_txt = @cache_client.hvals(key)
                msg_port_dic = {}
                Log.debug "msg type = #{msg_txt.class}"
                msg_port_dic["list"] = msg_txt
                # puts "msg_txt = #{JSON.generate(msg_txt)}"
                msg_txt = JSON.generate(msg_port_dic)
            else
                msg_txt = @cache_client.get(key)
            end
            msg_txt
        end

        def asyn_notify(key = "")
            if /port_list|switch_list/ =~ key
                @cache_client.publish("control.switch", "switch_info")
            else
                @cache_client.publish("nac.app", "nac_info")
            end
        end

        def subscribe
            @redis.subscribe(["monitor.switch", "monitor.nacapp"]) do |on|
                on.message do |channel, message|
                    Log.info "receive redis channel= #{channel}, message = #{message}"
                    msg_obj = JSON.parse(message)
                    key = "#{msg_obj["msg_type"]}"
                    msg_obj.delete("msg_type")
                    if key == "escape_status"
                        @max_traffic = msg_obj["max_flowspeed"].to_i
                        msg_obj.delete("max_flowspeed")
                    elsif key == "iface_name"
                        @moniter_iface = "#{msg_obj["untrust"]}"
                    elsif  key == "reset_traffic"
                        init_traffic
                        next
                    end
                    case "#{channel}"
                        when "monitor.switch", "monitor.nacapp"
                            if key == "port_list"
                                @cache_client.hset(key, msg_obj["ip"], JSON.generate(msg_obj)) if $keys.include?(key)
                            else
                                @cache_client.set(key, JSON.generate(msg_obj)) if $keys.include?(key)
                            end
                            @server.server_send msg_assemble(key), get_key_method(key)
                        else
                            Log.error "receiv unknow channel = #{channel} message"
                    end
                end
            end
        end
        def get_key_method(cache_key)
            Log.debug "get_key_method key = #{cache_key}"
            METHOD_MAP.each do |method, key|
                Log.debug "method = #{method}"
                return method if cache_key == key
            end
            Log.error "key = #{cache_key} error in get_key_method"
            "ErrorMethod"
        end
        def notify_get_info
            @cache_client.publish("nac.app", "nac_info")
            @cache_client.publish("control.switch", "switch_info")
        end
        def push_msg(key)
            @server.server_send  msg_assemble(key), get_key_method(key)
        end

        def course_check
            cmd_port = ""
            cmd_process = ""
            process_arry = []
            PROCESS_DIC.each do |name, port|
                if name == "tomcat"
                    cmd_port = `netstat -anpt| grep ":#{port}\s" | grep LISTEN`
                    cmd_process = `pgrep java`
                elsif name == "main_switch"
                    cmd_port = `netstat -anp| grep ":#{port}\s"`
                    cmd_process = `pgrep #{name}`
                else
                    cmd_port = `netstat -anp| grep ":#{port}\s" | grep LISTEN`
                    cmd_process = `pgrep #{name}`
                end
                procs_dic = {}
                procs_dic["name"] = "#{name}"
                procs_dic["status"] = "true"
                procs_dic["port"]   = "true"
                if cmd_port == ""
                    procs_dic["port"]   = "false"
                end
                if cmd_process == ""
                    procs_dic["status"] = "false"
                end
                process_arry << procs_dic
            end
            course_dic = {}
            course_dic["list"] = process_arry
            redis_keys = @cache_client.keys("*")
            if redis_keys.include?("process_info")
                md5_1 = Digest::MD5.hexdigest(JSON.generate(course_dic))
                md5_2 = Digest::MD5.hexdigest(@cache_client.get("process_info"))
                @cache_client.set("process_info", JSON.generate(course_dic))
                if md5_1 != md5_2
                    push_msg "process_info"
                end
            end
            @cache_client.set("process_info", JSON.generate(course_dic))
        end
        def check_traffic
            if_name = "eth0"
            if @moniter_iface == "0"
                asyn_notify
            else
                if_name = @moniter_iface
            end
            Log.debug "untrust iface name = #{if_name}"
            speed_dic = {}
            uptime = `cat /proc/uptime`
            speed_dic[:uptime] = uptime.split[0].to_i.to_s
            traffic = `ifconfig #{if_name}`
            rx_data = /RX bytes:\d+/.match(traffic).to_s.split(":")[1]
            rx_data = rx_data.to_i/1024
            speed_dic[:rx_data] = rx_data.to_s
            tx_data = /TX bytes:\d+/.match(traffic).to_s.split(":")[1]
            tx_data = tx_data.to_i/1024
            speed_dic[:tx_data] = tx_data.to_s
            netspeed = `vnstat -i #{if_name} -tr 2 -ru`
            # Log.debug "netspeed_cmd = #{netspeed}"
            speed_arry = netspeed.split("\n")
            speed_arry.each do |txt|
                txt_arry = txt.split
                if /\A\s+rx/ =~ txt
                    speed_dic[:rx] = txt_arry[1]
                    speed_dic[:rx_unit] = txt_arry[2]
                elsif /\A\s+tx/ =~ txt
                    speed_dic[:tx] = txt_arry[1]
                    speed_dic[:tx_unit] = txt_arry[2]
                end
            end
            Log.debug "origin speed_dic = #{speed_dic}"
            if speed_dic[:tx_unit] == "MiB/s"
                speed_dic[:tx] =  speed_dic[:tx].to_f * 1024
                speed_dic[:tx] = speed_dic[:tx].to_s
                speed_dic[:tx_unit] = "KiB/s"
            end
            if speed_dic[:rx_unit] == "MiB/s"
                speed_dic[:rx] =  speed_dic[:rx].to_f * 1024
                speed_dic[:rx] =  speed_dic[:rx].to_s
                speed_dic[:rx_unit] = "KiB/s"
            end
            speed_dic[:tx] = speed_dic[:tx].to_i.to_s
            speed_dic[:rx] = speed_dic[:rx].to_i.to_s
            speed_dic[:time] = Time.now.to_i.to_s
            # Log.debug "speed_dic = #{speed_dic.to_json}"
            speed_dic
        end

        def handle_traffic
            net_info = check_traffic
            net_info.each do |key, value|
                @cache_client.hset("net_info", key, value)
            end
            rx_dic = {}
            rx_dic[net_info[:time]] = net_info[:rx].to_i
            # Log.debug "rx_dic = #{rx_dic}"
            set_toptraffic = Proc.new do |top_list|
                top_txt = ""
                top_list.each do |dic_top|
                    dic_top.each do |time, speed|
                        if top_txt == ""
                            top_txt = "#{speed}:#{time}"
                        else
                            top_txt +=  ";#{speed}:#{time}"
                        end
                    end
                end
                @cache_client.set("trafficTop", top_txt)
            end
            sort_toplist = Proc.new do
                @net_toplist = @net_toplist.sort_by {|top_dic| top_dic[top_dic.keys[0]]}
                @net_toplist = @net_toplist.reverse
                # Log.debug "sort top list = #{@net_toplist}"

            end
            if @net_toplist.size < 4
                @net_toplist << rx_dic
                if @net_toplist.size == 4
                    set_toptraffic.call(@net_toplist)
                end
            else
                @net_toplist.each do |top_dic|
                    speed = top_dic.values[0]
                    if speed == net_info[:rx].to_i
                        @net_toplist[@net_toplist.index(top_dic)] = rx_dic
                        set_toptraffic.call(@net_toplist)
                        break
                    elsif speed < net_info[:rx].to_i
                        @net_toplist[@net_toplist.index(top_dic)] = rx_dic
                        sort_toplist.call()
                        set_toptraffic.call(@net_toplist)
                        break
                    end
                end
            end
            handle_traffic_escape rx_dic
            # Log.debug "top_list = #{@net_toplist}"
        end
        def handle_traffic_escape(rx_dic = {})
            push_traffic = {}
            push_traffic["status"]   = "true"
            push_traffic["maxSpeed"] = @max_traffic.to_s
            push_traffic["Speed"]    =  rx_dic.values[0].to_s
            if @max_traffic != 0
                traffic_status = rx_dic.values[0] < @max_traffic? true:false
                if traffic_status != @traffic_escape_status
                    push_traffic["msg_type"] = "traffic_status"
                    push_traffic["status"]   = traffic_status.to_s
                    push_traffic["maxSpeed"] = @max_traffic.to_s
                    push_traffic["Speed"]    =  rx_dic.values[0].to_s
                    @traffic_escape_status = traffic_status
                    @cache_client.publish("monitor.nacapp", JSON.generate(push_traffic))
                end
            else
                @cache_client.set("traffic_status", JSON.generate(push_traffic))
            end
        end
        def init_traffic
            reset_traffic = []
            key = Time.now.to_i
            4.times do
                key += 1
                init_top = {}
                init_top[key.to_s] = 0
                reset_traffic << init_top
            end
            @net_toplist = reset_traffic
        end

    end
    class ParseMsg
        def initialize
            # @msg_head = ["MessageMethod", "MessageType", "CompressType" , \
            # 	"DateTime", "ClientCode", "Address", "StatusCode", "MessageLength" ]
            @rev_msg = ""
        end

        def parse(json_data)
            @rev_msg += json_data if json_data != nil
            msgs = []
            head = {}
            body = {}
            msg_mark = 0
            rev_data = @rev_msg.split("\r\n")
            len_arry = Array(0..rev_data.length-1)
            len_arry.each do |j|
                #puts "#########rev_data = #{rev_data[j]}ength = #{rev_data[j].size}"
                arry_msg = rev_data[j].split(":")
                if arry_msg.length >= 2 && MSG_HEAD.include?(arry_msg[0].strip)
                    head[arry_msg[0].strip] = arry_msg[1].strip
                    msg_mark = 1
                    next unless (head.has_key?("MessageLength") && head["MessageLength"].to_i == 0)
                end
                if head.has_key?("MessageLength") && (head["MessageLength"].to_i == 0) && (msg_mark == 1)
                    msg = {}
                    msg["head"] = head
                    msg["body"] = nil
                    head = {}
                    msgs << msg
                    @rev_msg = "" if j == len_arry.length - 1
                    next
                elsif head.has_key?("MessageLength") && (head["MessageLength"].to_i == rev_data[j].length) && (msg_mark == 1)
                    msg = {}
                    msg["head"] = head
                    msg["body"] = JSON.parse(rev_data[j])
                    msgs << msg
                    head = {}
                    msg_mark = 0
                    @rev_msg = "" if j == len_arry.length - 1
                elsif Log.info "message not complete"
                    if j == len_arry.length - 1
                        @rev_msg = rev_data[j]
                    end
                    if j < len_arry.length - 1
                        @rev_msg = ""
                        rev_data[j..-1].each { |last_msg| @rev_msg += "\r\n"+last_msg }
                    end

                end

            end
            msgs
        end
    end
end
