require 'redis'
module MsgTransfer

    class RedisCache
        def initialize(host, port, db)
            @host = host
            @port = port
            @db = db
            @redis = Redis.new(host: @host, port: @port, db: @db)
        end
        def reinitialize
            begin
                @redis = Redis.new(host: @host, port: @port, db: @db)
            rescue => err_msg
                Log.error "#{err_msg}"
            end
        end

        def get(key)
            begin
               return @redis.get(key)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end

        end
        def set(key, value, options = {})
            begin
               return @redis.set(key, value, options)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end
        end
        def publish(channel, message)
            begin
                return @redis.publish(channel, message)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end
        end
        def subscribe(*channels, &block)
            begin
                return @redis.subscribe(*channels, &block)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end

        end

        def hset(key, field, value)
            begin
                return @redis.hset(key, field, value)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end

        end

        def keys(pattern = "*")
            begin
                return @redis.keys(pattern)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end

        end
        def method_missing(method_call, *args)
            begin
                return @redis.send(method_call, *args)
            rescue => err_msg
                Log.error "method missing method error #{method_call}, #{err_msg}"
                reinitialize
                retry
            end

        end

    end

end