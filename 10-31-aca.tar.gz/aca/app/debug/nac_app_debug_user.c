#include "nac_app_debug_main.h"
#include "nac_app_debug_user.h"


const char *xml_msg_model = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> \
                            <nac> \
                            <commandID>%d</commandID> \
                            <actionType>%d</actionType> \
                            %s \
                            </nac>";


static int print_user_debug_result(P_DEBUG_USER debug, unsigned short flag)
{
    char ret_buffer[256] = "";
    switch(debug->action)
    {
    case USER_ADD:
        sprintf(ret_buffer, "add %s %s ", debug->ac_mac, debug->ip_addr);
        break;
    case USER_DEL:
        sprintf(ret_buffer, "del %s %s ", debug->ac_mac, debug->ip_addr);
        break;
    case USER_FLUSH:
        memcpy(ret_buffer, "flush all user ", strlen("flush all user "));
        break;
    default:
        break;
    };
    strcat(ret_buffer, (flag == 1)?("success!"):("failure!"));
    printf("%s\n", ret_buffer);
    return 0;
}


int nac_app_debug_user_deal(P_DEBUG_USER debug)
{
    char user_item[120] = "";
    char msg_buffer[1024*2] = "";
    switch(debug->action)
    {
    case USER_ADD:
        sprintf(user_item, USER_ADD_FORMAT, NAC_KNL_USR_TMP, debug->ac_mac, debug->ip_addr);
        break;
    case USER_DEL:
        sprintf(user_item, USER_DEL_FORMAT, NAC_KNL_USR_TMP, debug->ac_mac, debug->ip_addr);
        break;
    case USER_FLUSH:
        break;
    default:
        printf("user_debug action is nonexist!\n");
        goto FUNC_EXIT;
    }

    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "type=%d--mac=%s--ip=%s\n", debug->action, debug->ac_mac, debug->ip_addr);
    sprintf(msg_buffer, XML_MSG_FORMAT, SYS_WEBUI_USER_AUTH, debug->action, user_item);
    int xml_msg_len = strlen(msg_buffer);
    NAC_WEB_MSG *pst_xml_msg;

    pst_xml_msg = (NAC_WEB_MSG*)malloc((xml_msg_len+sizeof(NAC_WEB_MSG)+1));
    if (pst_xml_msg == NULL)
    {
        printf("%s-->malloc fail\n", __FUNCTION__);
        goto FUNC_EXIT;
    }
    memset(pst_xml_msg, '\0', sizeof(NAC_WEB_MSG));

    pst_xml_msg->us_cmd  = SYS_WEBUI_USER_AUTH;
    pst_xml_msg->reserve = 0;
    pst_xml_msg->ui_len  = xml_msg_len;
    memcpy(pst_xml_msg->ac_buf, msg_buffer, xml_msg_len);


    int dst_address = inet_network("127.0.0.1");
    unsigned short flag = 0;
    nac_app_short_tcp_msg_send(pst_xml_msg, dst_address, &flag);
    free(pst_xml_msg);
    print_user_debug_result(debug, flag);

FUNC_EXIT:
    return 0;
}

