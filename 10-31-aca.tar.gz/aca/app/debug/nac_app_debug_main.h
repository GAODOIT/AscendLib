#ifndef NAC_APP_DEBUG_MAIN_H
#define NAC_APP_DEBUG_MAIN_H

#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_common_lib.h"
#include "nac_system_xml.h"

HUPU_INT32 nac_app_short_tcp_msg_send(NAC_WEB_MSG* pst_msg, unsigned int dst_addr, unsigned short *status);
#endif
