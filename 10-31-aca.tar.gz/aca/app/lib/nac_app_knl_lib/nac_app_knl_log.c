#include "nac_app_knl_lib.h"

HUPU_UINT8 nac_app_debug_log_switch = 1;	  //for write debug_log or not.
HUPU_UINT8 nac_app_advanced_debug_switch = 0; //basic or advanced debug;

HUPU_INT32 nac_lib_debug_file(HUPU_CHAR *filename, HUPU_CHAR *buffer)
{
	FILE			*fp = HUPU_NULL;
	time_t 			timep;
	struct tm 		st_tm;
	HUPU_UINT32 	ui_size = 0;
	HUPU_CHAR 	ac_time[30] = { 0 };
	HUPU_CHAR 	ac_file_path[50] = { 0 };

	if(!filename || !buffer || strlen(buffer) >= NAC_MAX_DEBUG_BUFFER_LEN)
    {
		printf("nac_LIB:invalid point\n");
		return HUPU_ERR;
	}

	fp = fopen(filename, "a+");
	if(HUPU_NULL == fp)
    {
		printf("nac_LIB:open debug file failed<%s>", filename);
		return HUPU_ERR;
	}

	fseek(fp, 0, SEEK_END);
	ui_size = ftell(fp);
	if(NAC_MAX_APP_FILE_SIZE <= ui_size)
	{
		fclose(fp);
		/*������־�ļ���׺��*/
		strcat(ac_file_path, filename);
		strcat(ac_file_path, ".bak");
		rename(filename, ac_file_path);
		fp = fopen(filename, "a+");
		if(!fp)
        {
			return HUPU_ERR;
		}
	}

	time(&timep);
	localtime_r(&timep, &st_tm);
	sprintf(ac_time, "%02d-%02d-%02d %02d:%02d:%02d ",
    		(1900 + st_tm.tm_year),
    		(1 + st_tm.tm_mon),
    		st_tm.tm_mday,
    		st_tm.tm_hour,
    		st_tm.tm_min,
    		st_tm.tm_sec);

	// д�뵽�ļ���
	fwrite(ac_time, strlen(ac_time), 1, fp) ;
	fwrite(buffer, strlen(buffer), 1, fp) ;

	fclose(fp);
	return HUPU_OK;
}

HUPU_INT32 nac_lib_debug(HUPU_INT32 flags,	const HUPU_CHAR *fmt, ...)
{
	HUPU_CHAR 	buf[NAC_MAX_DEBUG_BUFFER_LEN];
   	HUPU_INT32 	size;
	va_list 	args;
	HUPU_CHAR	filename[128] = {0};
    //printf("nac_lib_debug0\n");
	memset(buf, '\0', NAC_MAX_DEBUG_BUFFER_LEN);

	va_start(args, fmt);
	size = vsnprintf(buf, NAC_MAX_DEBUG_BUFFER_LEN-1, fmt, args);
	va_end (args);

	if(size <= 0)
    {
        return HUPU_ERR;
	}

	if (nac_app_debug_log_switch == 0)
	{
		return HUPU_ERR;
	}
	
    //printf("nac_lib_debug1-->flags = %d\n", flags);
	switch(flags)
    {
    case DEBUG_LOG_FOR_NAC_SYS:
		if (nac_app_advanced_debug_switch == 0)
		{
			sprintf(filename, "%s%s", NAC_DEBUG_LOG_FILE_PATH, NAC_ERROR_LOG_FILE_FOR_NAC_SYS);
		}
		
		if (nac_app_advanced_debug_switch == 1)
		{
			sprintf(filename, "%s%s", NAC_DEBUG_LOG_FILE_PATH, NAC_DEBUG_LOG_FILE_FOR_NAC_SYS);
		}
		break;
    case DEBUG_LOG_FOR_NAC_USER:
    	sprintf(filename, "%s%s", NAC_DEBUG_LOG_FILE_PATH, NAC_DEBUG_LOG_FILE_FOR_NAC_USER);
    	break;
    case DEBUG_LOG_FOR_NAC_DB:
    	sprintf(filename, "%s%s", NAC_DEBUG_LOG_FILE_PATH, NAC_DEBUG_LOG_FILE_FOR_NAC_DB);
    	break;
	case DEBUG_LOG_FOR_NAC_SOCKET:
    	sprintf(filename, "%s%s", NAC_DEBUG_LOG_FILE_PATH, NAC_DEBUG_LOG_FILE_FOR_NAC_SOCKET);
    	break;
	case DEBUG_LOG_FOR_NAC_DB_TRANSIT:
        sprintf(filename, "%s%s", NAC_DEBUG_LOG_FILE_PATH, NAC_DEBUG_LOG_FILE_FOR_NAC_DB_TRANSIT);
    	break;
    case DEBUG_LOG_FOR_AUDIT:
        sprintf(filename, "%s%s", NAC_DEBUG_LOG_FILE_PATH, NAC_DEBUG_LOG_FILE_FOR_NAC_AUDIT);
    	break;
    case DEBUG_LOG_FOR_DDNS:
        sprintf(filename, "%s%s", NAC_DEBUG_LOG_FILE_PATH, NAC_DEBUG_LOG_FILE_FOR_NAC_DDNS);
    	break;
    default:
    	printf("invalid debug log type = %d", flags);
    	break;
	}

    //printf("nac_lib_debug2-->filename = %s, buf = %s\n", filename, buf);
	nac_lib_debug_file(filename, buf);
	
	return HUPU_OK;
}

HUPU_VOID nac_lib_create_pid_file(HUPU_CHAR *pc_pid_file_path)
{
    FILE *pidfile      = fopen(pc_pid_file_path, "w");
    HUPU_UINT32 ui_pid = getpid();
	if(!pidfile)
    {
		return;
	}
	fprintf(pidfile, "%d\n", ui_pid);
	fclose(pidfile);
}







