#include "nac_app_knl_lib.h"

HUPU_INT32 nac_tcp_crt_svr(HUPU_UINT16 port)
{
	struct sockaddr_in svr_addr;
	HUPU_INT32			sock_fd;
	HUPU_INT32			iRet;
	HUPU_INT32			reuse = 1;

	// ����socket�����׽���
	if((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SOCKET,
					"%s-->create socket error = %d\n",
					__FUNCTION__, sock_fd);
		return HUPU_ERR;
	}

	//���õ�ַ����
	iRet = setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(HUPU_INT32));
    if(iRet < 0)
    {
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SOCKET,
					"%s-->nac AGENT: setsockopt SO_REUSEADDR failed<%d,%d,%s>\n",
					__FUNCTION__, iRet, errno, strerror(errno));
		return HUPU_ERR;
	}

	// ��ʼ������˵�ַ
	memset(&svr_addr, 0, sizeof(struct sockaddr_in));
	svr_addr.sin_family = AF_INET;
	svr_addr.sin_port = htons(port);
	svr_addr.sin_addr.s_addr = INADDR_ANY;

	// ��local socket������˵�ַ
	iRet = bind(sock_fd,
				(struct sockaddr *)&svr_addr,
				sizeof(struct sockaddr));
	if(iRet < 0)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SOCKET,
					"%s-->bind local socket error = %d, desc = %s/%d\n",
					__FUNCTION__, iRet, strerror(errno), errno);

		return HUPU_ERR;
	}
	return sock_fd;
}


HUPU_INT32 nac_tcp_crt_cli(HUPU_VOID)
{
	HUPU_INT32 sock_fd;

	// ����socket�����׽���
	if((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SOCKET,
					"%s-->create socket error = %d\n",
					__FUNCTION__, sock_fd);
		return HUPU_ERR;
	}
	return sock_fd;
}

HUPU_INT32 nac_tcp_destroy(const HUPU_INT32 sock_fd)
{
	close( sock_fd );
	return HUPU_OK;
}


HUPU_INT32 nac_tcp_listen(const HUPU_INT32 sock_fd,	const HUPU_INT32 lst_num)
{
	// ���ȼ�����
	if(sock_fd < 0)
	{
		return HUPU_ERR;
	}

	return listen(sock_fd, lst_num);
}


HUPU_INT32 nac_tcp_accept(const HUPU_INT32	sock_fd,
            		       HUPU_ULONG32 *dst_ip,
            		       HUPU_UINT16	*dst_port)
{
	struct sockaddr_in 	cli_addr;
	socklen_t 			sin_size;
	HUPU_INT32					iret;

	// ���ȼ�����
	if(sock_fd < 0)
    {
		return HUPU_ERR;
	}
	sin_size = sizeof(struct sockaddr_in);

	// ��ʼ���ͻ��˵�ַ����
	memset(&cli_addr, 0, sizeof(struct sockaddr_in));
	iret = accept(sock_fd, (struct sockaddr *)&cli_addr, &sin_size);

	*dst_ip		= ntohl(cli_addr.sin_addr.s_addr);
	*dst_port	= ntohs(cli_addr.sin_port);

	return iret;
}

HUPU_INT32 nac_tcp_connect(const HUPU_INT32 sock_fd, HUPU_ULONG32 dst_ip, HUPU_UINT16 dst_port)
{
	struct sockaddr_in	svr_addr;

	// ���ȼ�����
	if(sock_fd < 0)
    {
		return HUPU_ERR;
	}

	// ��ʼ������˵�ַ
	memset(&svr_addr, 0, sizeof(struct sockaddr_in));
	svr_addr.sin_family = AF_INET;
	svr_addr.sin_port = htons(dst_port);
	svr_addr.sin_addr.s_addr = htonl(dst_ip);

	return connect(sock_fd, (struct sockaddr *)&svr_addr, sizeof(struct sockaddr));
}


HUPU_INT32 nac_tcp_sendto(const HUPU_INT32	sock_fd,
                	       HUPU_VOID *msgbuf,
                	       const HUPU_INT32	msglen)
{
	// ���ȼ�����
	if( NULL == msgbuf || 0 == msglen)
	{
		return HUPU_ERR;
	}

	return send(sock_fd, msgbuf, msglen, 0);
}

HUPU_INT32 nac_tcp_recvfrom(const HUPU_INT32 sock_fd,
                	         HUPU_VOID *msgbuf,
                	         const HUPU_INT32 msglen)
{
	// ���ȼ�����
	if(NULL == msgbuf || 0 == msglen)
    {
		return HUPU_ERR;
	}

	// ��������
	return recv(sock_fd, msgbuf, msglen, 0);
}



