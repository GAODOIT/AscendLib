#include "nac_precomp.h" //nac_list.h
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_netapp_check.h"
#include "nac_system_netapp_user.h"
#include "nac_system_ha_backup.h"
#include "nac_system_user.h"

//NAC_LIST_HEAD(offline_user_list_head);
struct nac_list_head offline_user_list_head;

HUPU_INT32 nac_system_init_offline_user_list(HUPU_VOID)
{
	NAC_INIT_LIST_HEAD(&offline_user_list_head);
	return HUPU_OK;
}

static HUPU_INT32 nac_system_insert_offline_user_list(NAC_SYS_USER *user_tmp)

{
	NAC_SYS_USER *pst_user = NULL;
    pst_user = (NAC_SYS_USER *)malloc(sizeof(NAC_SYS_USER));
	if (pst_user == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->malloc NAC_SYS_USER error\n", __FUNCTION__);
		return HUPU_ERR;
	}

	memset(pst_user, '\0', sizeof(NAC_SYS_USER));
	pst_user->userid = user_tmp->userid;
	pst_user->depid  = user_tmp->depid;
	pst_user->ip     = user_tmp->ip;
	pst_user->user_type = user_tmp->user_type;
    pst_user->cmd = user_tmp->cmd;
	memcpy(pst_user->mac, user_tmp->mac, ETH_ALEN);

	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->user_id=%d-->group_id=%d-->mac=%02x-%02x-%02x-%02x-%02x-%02x-->ip=%u.%u.%u.%u\n",
			__FUNCTION__, pst_user->userid, pst_user->depid, MAC_FORMAT(pst_user->mac), LIPQUAD(pst_user->ip));

	NAC_INIT_LIST_HEAD(&(pst_user->lnode));
	nac_list_add_tail(&(pst_user->lnode), &offline_user_list_head);

	return HUPU_OK;
}

// show all offline_user_list offline_user
HUPU_INT32 __nac_system_show_offline_user_list(HUPU_VOID)
{
	int iRet, user_count;
	struct NAC_SYS_USER_STRU *pst_user = HUPU_NULL;

	//yes == 1;
	iRet = nac_list_empty(&offline_user_list_head);
	if (iRet == HUPU_TRUE)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->offline_user_list_head is empty\n", __FUNCTION__);
		return HUPU_ERR;
	}

	user_count = 0;

	nac_list_for_each_entry(pst_user, &offline_user_list_head, lnode)
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->%d-->user_id=%d-->group_id=%d-->mac=%02x-%02x-%02x-%02x-%02x-%02x-->ip=%u.%u.%u.%u\n",
					__FUNCTION__, user_count, pst_user->userid, pst_user->depid, MAC_FORMAT(pst_user->mac), LIPQUAD(pst_user->ip));
		user_count = user_count + 1;
	}

	return HUPU_OK;
}

//destroy offline_user_list
HUPU_INT32 nac_system_destory_offline_user_list(HUPU_VOID)
{
	HUPU_INT32 iRet;
    HUPU_UINT16 user_sum = 0;
	struct NAC_SYS_USER_STRU *pst_user = HUPU_NULL;
	struct nac_list_head *pos, *ent;

	//yes == 1;
	iRet = nac_list_empty(&offline_user_list_head);
	if (iRet == HUPU_TRUE)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->offline_user_list_head is empty\n", __FUNCTION__);
		return HUPU_OK;
	}

	nac_list_for_each_safe(pos, ent, &offline_user_list_head)
	{
		pst_user = nac_list_entry(pos, NAC_SYS_USER, lnode);
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->user_id=%d-->group_id=%d-->mac=%02x-%02x-%02x-%02x-%02x-%02x-->ip=%u.%u.%u.%u\n",
				__FUNCTION__, pst_user->userid, pst_user->depid, MAC_FORMAT(pst_user->mac), LIPQUAD(pst_user->ip));

		user_sum = user_sum + 1;
		nac_list_del(pos);
		free(pst_user);
		pst_user = HUPU_NULL;
	}
	NAC_INIT_LIST_HEAD(&offline_user_list_head);

	return HUPU_OK;
}

/*
 * //控制器断开期间下线用户发送至server.
 * <?xml version="1.0" encoding="UTF-8"?>
 * <nac>
 * <commandID>203</commandID>
 * <actionType>0</actionType>
 * //userId:depId:mac,ip(结尾无逗号)
 * <onlineUser>1:10:64-31-50-7e-84-47,10.10.2.163</onlineUser>
 * </nac>
*/

/*return xmlDoc, if(user_sum > 0) send; else free(xmlDoc)*/
/*tmp_node = xmlNewChild(root_node, HUPU_NULL, BAD_CAST "onlineUser", BAD_CAST xml_max_cnt);*/
static xmlDocPtr nac_system_get_knl_offline_user(HUPU_UINT16 cmd_id, HUPU_UINT8 action, HUPU_UINT16 *user_sum)
{
	HUPU_INT32 iRet;
	struct NAC_SYS_USER_STRU *pst_user = HUPU_NULL;
	xmlDocPtr xdoc;
	xmlNodePtr root_node, tmp_node;
    HUPU_CHAR xml_max_cnt[MID_BUFF_LEN];

	// yes == 1;
	iRet = nac_list_empty(&offline_user_list_head);
	if (iRet == HUPU_TRUE)
	{
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "offline_user_list_head is empty\n");
		return HUPU_NULL;
	}

    HUPU_INT32 user_count = 0;
	//offline_user_list_head is unempty, user_count must >= 1;
	xdoc = xmlNewDoc(BAD_CAST "1.0");
	root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
	xmlDocSetRootElement(xdoc, root_node);

    insert_number_xml_new_child(root_node, "commandID", (cmd_id+Ret_cmd_offset));
    insert_number_xml_new_child(root_node, "actionType", action);

	nac_list_for_each_entry(pst_user, &offline_user_list_head, lnode)
	{
		memset(xml_max_cnt, 0, sizeof(xml_max_cnt));
		sprintf(xml_max_cnt, "%d:%d:%02x-%02x-%02x-%02x-%02x-%02x,%u.%u.%u.%u",
                pst_user->userid, pst_user->depid, MAC_FORMAT(pst_user->mac),LIPQUAD(pst_user->ip));
        tmp_node = insert_string_xml_new_child(root_node, "onlineUser", xml_max_cnt);
        insert_number_xml_new_prop(tmp_node, "type", pst_user->user_type);
        user_count ++;
		SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS,
            "user_id=%d-->group_id=%d-->mac=%02x-%02x-%02x-%02x-%02x-%02x-->ip=%u.%u.%u.%u\n",
            pst_user->userid, pst_user->depid, MAC_FORMAT(pst_user->mac), LIPQUAD(pst_user->ip));
	}
    *user_sum = user_count;

	return xdoc;
}

HUPU_INT32 nac_system_send_offline_user_to_server(HUPU_UINT32 ui_sockfd)
{
	HUPU_UINT16 user_sum;
	xmlDocPtr nac_doc = HUPU_NULL;

	nac_doc = nac_system_get_knl_offline_user(SYS_WEBUI_USER_AUTH, NAC_SHOW, &user_sum);
	if (nac_doc != HUPU_NULL)
	{
		if (user_sum > 0)
		{
			nac_sys_send_xmldoc_to_webserver(ui_sockfd, nac_doc, SYS_WEBUI_USER_AUTH);
		}
		else
		{
			nac_free_xmlDoc(nac_doc);
		}
	}

	return HUPU_OK;
}

/*nac_sys_rmv_user
<?xml version="1.0" encoding="UTF-8"?>
<nac>
<commandID>103</commandID>
<actionType>2</actionType>
//userType, userId:depId:mac,ip
<onlineUser type="0">0:0:88-32-9B-3D-53-EB,10.10.5.3</onlineUser>
<onlineUser type="0">0:0:88-32-9B-3D-53-EB,10.10.5.3</onlineUser>
</nac>
*/
static HUPU_INT32 nac_sys_rmv_user(HUPU_CHAR **user_str)
{
    HUPU_INT32 iRet = 0;
    HUPU_CHAR ip_str[IP_STR_LEN];
    HUPU_CHAR mac_str[MAC_STR_LEN];
    NAC_SYS_USER user_tmp;
	NAC_KNL_USER_OBJECT st_knl_user_obj;

    memset(ip_str, '\0', IP_STR_LEN);
    memset(mac_str, '\0', MAC_STR_LEN);
	memset(&user_tmp, 0, sizeof(NAC_SYS_USER));
	memset(&st_knl_user_obj, 0, sizeof(NAC_KNL_USER_OBJECT));

    if (sscanf(user_str[0], "%hd:%hd:%[^,],%[^,]", &(user_tmp.userid), &(user_tmp.depid), mac_str, ip_str) != 4)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->sscanf-->offline_user xml format error\n", __FUNCTION__);
        return NAC_SYS_ERROR_USER_FORMAT_ERR;
    }

	if (user_str[1] != HUPU_NULL)
	{
    	user_tmp.user_type = atoi(user_str[1])==0?NAC_KNL_USR_TMP:(atoi(user_str[1])==1?NAC_KNL_USR_WEB:NAC_KNL_USR_GUEST);
	}

    if (sscanf(mac_str, MAC_MYFMT, &(user_tmp.mac[0]), &(user_tmp.mac[1]), &(user_tmp.mac[2]),
        &(user_tmp.mac[3]), &(user_tmp.mac[4]), &(user_tmp.mac[5])) != 6)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->sscanf-->offline_user mac format error\n", __FUNCTION__);
        return NAC_SYS_ERROR_USER_FORMAT_ERR;
    }

	//network byte inet_addr (const char* ip_str);
	//host byte inet_addr (const char* ip_str);
	user_tmp.ip = inet_network(ip_str);
    SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
				"%s-->uid=%d-->gid=%d-->%u.%u.%u.%u-->%02x-%02x-%02x-%02x-%02x-%02x\n",
                __FUNCTION__, user_tmp.userid, user_tmp.depid,
                LIPQUAD(user_tmp.ip), MAC_FORMAT(user_tmp.mac));

	st_knl_user_obj.id  = user_tmp.userid;
	st_knl_user_obj.gid = user_tmp.depid;
	st_knl_user_obj.ip  = user_tmp.ip;
    st_knl_user_obj.user_type = user_tmp.user_type;
	memcpy(st_knl_user_obj.mac, user_tmp.mac, ETH_ALEN);

    iRet = nac_set_data_to_knl(NAC_CMD_USER_RMV, 0, &st_knl_user_obj, sizeof(NAC_KNL_USER_OBJECT));
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_USER_RMV-->del knl user fail\n", __FUNCTION__);
        return NAC_KNL_ERROR_DEL_USER_FAIL;
    }
    else
    {
        nac_system_delete_netapp_user(st_knl_user_obj.ip, st_knl_user_obj.mac);
    }
    return HUPU_OK;
}


/*
 * //nac_sys_add_user
 * <?xml version="1.0" encoding="UTF-8"?>
 * <nac>
 *	<commandID>103</commandID>
 *	<actionType>1</actionType>
 *	//userId:depId:mac,ip,need_check(0:no need;1:need check),auth_status(0:auth_success, 1:auth_failure)
 *  <onlineUser type="0">1:30:1A-2B-3C-4D-5E-6F,10.10.2.251,1,0</onlineUser>
 *  <isolateZone sum="5">1;2;3;4;5</isolateZone>
 * </nac>
 <?xml version="1.0" encoding="UTF-8"?>
 <nac>
 <commandID>103</commandID>
 <actionType>1</actionType>
 <onlineUser type="0">0:0:88-32-9B-3D-53-EB,10.10.5.3,1,0</onlineUser>
 </nac>
*/

static HUPU_INT32 nac_sys_add_user(HUPU_CHAR **user_str, HUPU_VOID *zoneid_str, HUPU_UINT16 zone_sum)
{
    HUPU_INT32 i,iRet;
    HUPU_CHAR ip_str[IP_STR_LEN];
    HUPU_CHAR mac_str[MAC_STR_LEN];
    NAC_SYS_USER user_tmp;
    NAC_KNL_USER_OBJECT	st_knl_obj;
	HUPU_CHAR zone_str[BUFF_LEN];

	HUPU_CHAR *token, *running;
	HUPU_UINT32 token_id;

    memset(ip_str, '\0', IP_STR_LEN);
    memset(mac_str, '\0', MAC_STR_LEN);
    memset(&user_tmp, 0, sizeof(NAC_SYS_USER));

    if (sscanf(user_str[0], "%hd:%hd:%[^,],%[^,],%hhd,%hhd",
		&(user_tmp.userid), &(user_tmp.depid), mac_str, ip_str, &(user_tmp.need_check), &(user_tmp.auth_status)) != 6)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->sscanf-->online_user xml format error\n", __FUNCTION__);
        return NAC_SYS_ERROR_USER_FORMAT_ERR;
    }
    user_tmp.user_type = atoi(user_str[1])==0?NAC_KNL_USR_TMP:(atoi(user_str[1])==1?NAC_KNL_USR_WEB:NAC_KNL_USR_GUEST);

    /*inet_network return host byte*/
    user_tmp.ip = inet_network(ip_str);
    if (sscanf(mac_str, MAC_MYFMT, &(user_tmp.mac[0]), &(user_tmp.mac[1]), &(user_tmp.mac[2]),
        &(user_tmp.mac[3]), &(user_tmp.mac[4]), &(user_tmp.mac[5])) != 6)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->sscanf-->online_user mac format error\n", __FUNCTION__);
        return NAC_SYS_ERROR_USER_FORMAT_ERR;
    }

    SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
				"%s-->uid=%d-->gid=%d-->%u.%u.%u.%u-->%02x-%02x-%02x-%02x-%02x-%02x--%d--%s-->user_type=%d\n",
                __FUNCTION__, user_tmp.userid, user_tmp.depid, LIPQUAD(user_tmp.ip), MAC_FORMAT(user_tmp.mac),
				zone_sum, (zone_sum > 0)? ((HUPU_CHAR*)zoneid_str):("no_zone"), user_tmp.user_type);


	memset(&st_knl_obj, 0, sizeof(NAC_KNL_USER_OBJECT));
	st_knl_obj.isolation_num = zone_sum;
    st_knl_obj.ip = user_tmp.ip;
    memcpy(st_knl_obj.mac, user_tmp.mac, ETH_ALEN);
    st_knl_obj.id  = user_tmp.userid;
    st_knl_obj.gid = user_tmp.depid;
    st_knl_obj.user_type = user_tmp.user_type;

	//need netapp_check
	if (user_tmp.need_check == 1)
	{
		st_knl_obj.state |= USER_STATE_NETAPP_CHECK;
	}

    if (user_tmp.auth_status == 1)
    {
       st_knl_obj.state |= USER_STATE_IS_ISOLATION_AUTH_FAIL;
    }

	if (zone_sum > 0)
	{
		memset(zone_str, '\0', BUFF_LEN);
		if (strlen(zoneid_str) >= BUFF_LEN)
		{
			memcpy(zone_str, zoneid_str, BUFF_LEN);
		}
		else
		{
			memcpy(zone_str, zoneid_str, strlen(zoneid_str));
		}

		running = zone_str;

		for(i = 0; i < zone_sum; i++)
		{
			token = strsep(&running, ";");
			token_id = atoi(token);
			if (token_id)
			{
				st_knl_obj.isolation_zone[i] = token_id;
			}

		}
	}

	iRet = nac_set_data_to_knl(NAC_CMD_USER_INS, 0, &st_knl_obj, sizeof(NAC_KNL_USER_OBJECT));
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_USER_INS-->add knl user fail\n", __FUNCTION__);
        return NAC_KNL_ERROR_ADD_USER_FAIL;
    }
	else
	{	//remove the auth_success_user of netapp_hlist
        nac_system_delete_netapp_user(st_knl_obj.ip, st_knl_obj.mac);
	}

    return HUPU_OK;
}

/*
<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>203</commandID>
  <actionType>3</actionType>
  //NAC_NETLINK_NETAPP_TIMEOUT or NAC_NETLINK_USER_TIMEOUT
  <offType>2/3</offType>
  //userType:userId:depId:mac,ip
  <onlineUser type="0">0:0:88-32-9B-3D-53-EB,10.10.5.3</onlineUser>
  <netappName>net_app_name</netappName>
</nac>
*/
HUPU_INT32 nac_sys_netlink_user_timeout(NAC_KNL_USER_MSG *nlk_usr_msg, HUPU_INT32 sock_fd)
{
    HUPU_INT32 iRet;
    xmlDocPtr doc;
    xmlNodePtr root_node, tmp_node;
    HUPU_UINT16 command_id = SYS_WEBUI_USER_AUTH;
	HUPU_CHAR xml_max_cnt[MID_BUFF_LEN];

    NAC_KNL_USER_OBJECT st_knl_user;
	struct NAC_SYS_USER_STRU st_offline_user;

	memset(&st_offline_user, 0, sizeof(struct NAC_SYS_USER_STRU));
	memset(&st_knl_user, 0, sizeof(NAC_KNL_USER_OBJECT));

	st_offline_user.userid   = nlk_usr_msg->tmp_id;
    st_offline_user.depid	 = nlk_usr_msg->dept_id;
    st_offline_user.ip		 = nlk_usr_msg->src_ip;
    st_offline_user.user_type= nlk_usr_msg->user_type;
    memcpy(st_offline_user.mac, nlk_usr_msg->src_mac, ETH_ALEN);
    st_offline_user.cmd      = nlk_usr_msg->cmd;
    ha_backup_sync_knl_timeout_user(&st_offline_user);

	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
		"type=%d-->uid=%d-->gid=%d-->mac=%02x-%02x-%02x-%02x-%02x-%02x-->ip=%u.%u.%u.%u-->timeout_type=%d\n",
		st_offline_user.user_type, st_offline_user.userid,
		st_offline_user.depid,	MAC_FORMAT(st_offline_user.mac),
		LIPQUAD(st_offline_user.ip), st_offline_user.cmd);

    // delete knl time_out user
    st_knl_user.id   = st_offline_user.userid;
	st_knl_user.gid  = st_offline_user.depid;
	st_knl_user.ip   = st_offline_user.ip;
    st_knl_user.user_type = st_offline_user.user_type;
	memcpy(st_knl_user.mac, st_offline_user.mac, ETH_ALEN);
	iRet = nac_set_data_to_knl(NAC_CMD_USER_RMV, 0, &st_knl_user, sizeof(NAC_KNL_USER_OBJECT));
   	if (iRet != HUPU_OK)
    {
    	SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl-->NAC_CMD_USER_RMV-->del knl user fail\n");
		return HUPU_ERR;
	}

	if (sock_fd <= 0)
	{
		//save off_line user
        nac_system_insert_offline_user_list(&st_offline_user);
		return HUPU_OK;
	}

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    insert_number_xml_new_child(root_node, "commandID", (command_id+Ret_cmd_offset));
    insert_number_xml_new_child(root_node, "actionType", NAC_MODIFY);
    insert_number_xml_new_child(root_node, "offType", st_offline_user.cmd);

    memset(xml_max_cnt, '\0', strlen(xml_max_cnt));
	sprintf(xml_max_cnt, "%d:%d:%02x-%02x-%02x-%02x-%02x-%02x,%u.%u.%u.%u",
	        st_offline_user.userid, st_offline_user.depid,
			MAC_FORMAT(st_offline_user.mac), LIPQUAD(st_offline_user.ip));
    tmp_node = insert_string_xml_new_child(root_node, "onlineUser", xml_max_cnt);
    insert_number_xml_new_prop(tmp_node, "type",  st_offline_user.user_type);
    if (st_offline_user.cmd == NAC_NETLINK_NETAPP_TIMEOUT)
    {
        memset(xml_max_cnt, '\0', sizeof(xml_max_cnt));
        nac_app_get_netapp_name_by_id(g_netapp_enable_id, xml_max_cnt);
        insert_string_xml_new_child(root_node, "netappName", xml_max_cnt);
    }
    nac_sys_send_xmldoc_to_webserver(sock_fd, doc, command_id);

    return HUPU_OK;
}

HUPU_INT32 nac_sys_netlink_add_tmp_user(NAC_KNL_USER_MSG *netlink_usr_msg)
{
    HUPU_INT32 iRet;
    NAC_KNL_USER_OBJECT	st_knl_obj;

    memset(&st_knl_obj, 0, sizeof(NAC_KNL_USER_OBJECT));


    st_knl_obj.ip    = netlink_usr_msg->src_ip;
    st_knl_obj.other = netlink_usr_msg->tmp_id;
    memcpy(st_knl_obj.mac, netlink_usr_msg->src_mac, 6);


	iRet = nac_set_data_to_knl(NAC_CMD_USER_INS, 0, &st_knl_obj, sizeof(NAC_KNL_USER_OBJECT));
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_USER_INS-->add knl user fail\n", __FUNCTION__);
    }
    return iRet;
}

HUPU_INT32 nac_sys_netlink_add_tmp_domain(NAC_KNL_USER_MSG *netlink_usr_msg)
{
    HUPU_INT32 iRet;
    NAC_KNL_DOMAIN_OBJECT	st_knl_obj;

    memset(&st_knl_obj, 0, sizeof(NAC_KNL_DOMAIN_OBJECT));


    st_knl_obj.src_ip   = netlink_usr_msg->src_ip;
    st_knl_obj.src_port = netlink_usr_msg->result;

	iRet = nac_set_data_to_knl(NAC_CMD_DOMAIN_INS, 0, &st_knl_obj, sizeof(NAC_KNL_DOMAIN_OBJECT));
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_DOMAIN_INS-->add knl domain fail\n", __FUNCTION__);
    }
    return iRet;
}

HUPU_INT32 nac_sys_netlink_del_tmp_domain(NAC_KNL_USER_MSG *netlink_usr_msg)
{
    HUPU_INT32 iRet;
    NAC_KNL_DOMAIN_OBJECT st_knl_obj;

    memset(&st_knl_obj, 0, sizeof(NAC_KNL_DOMAIN_OBJECT));


    st_knl_obj.src_ip   = netlink_usr_msg->src_ip;
    st_knl_obj.src_port = netlink_usr_msg->result;

	iRet = nac_set_data_to_knl(NAC_CMD_DOMAIN_RMV, 0, &st_knl_obj, sizeof(NAC_KNL_DOMAIN_OBJECT));
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_DOMAIN_RMV-->del knl domain fail\n", __FUNCTION__);
    }
    return iRet;
}

HUPU_INT32 nac_sys_netlink_add_tmp_nat(NAC_KNL_USER_MSG *netlink_usr_msg)
{
    HUPU_INT32 iRet;
    NAC_KNL_NAT	st_knl_obj;

    memset(&st_knl_obj, 0, sizeof(NAC_KNL_NAT));

    st_knl_obj.src_ip    = netlink_usr_msg->src_ip;
    //st_knl_obj.id        = netlink_usr_msg->result;
    st_knl_obj.ttl       = netlink_usr_msg->vlan_id;
    st_knl_obj.last_time = netlink_usr_msg->dept_id;
    st_knl_obj.time_count = netlink_usr_msg->user_type;

	iRet = nac_set_data_to_knl(NAC_CMD_NAT_INS, 0, &st_knl_obj, sizeof(NAC_KNL_NAT));
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_NAT_INS-->add knl nat fail\n", __FUNCTION__);
    }
    return iRet;
}

HUPU_INT32 nac_sys_netlink_del_tmp_nat(NAC_KNL_USER_MSG *netlink_usr_msg)
{
    HUPU_INT32 iRet;
    NAC_KNL_NAT st_knl_obj;

    memset(&st_knl_obj, 0, sizeof(NAC_KNL_NAT));

    st_knl_obj.src_ip   = netlink_usr_msg->src_ip;

	iRet = nac_set_data_to_knl(NAC_CMD_NAT_RMV, 0, &st_knl_obj, sizeof(NAC_KNL_NAT));
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_NAT_RMV-->del knl nat fail\n", __FUNCTION__);
    }
    return iRet;
}

xmlDocPtr nac_sys_parse_user_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_INT32 iRet, error_id;
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    xmlChar *user_szKey[2], *zone_szKey, *szAttr;
    HUPU_UINT8 action_type;
	HUPU_UINT16 iso_zone_sum;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
	iso_zone_sum = 0;
    switch (action_type)
    {
	case NAC_FLUSH:
		nac_free_xmlDoc(doc);
		iRet = nac_set_data_to_knl(NAC_CMD_USER_FLUSH, 0, NULL, 0);
    	if (iRet != HUPU_OK)
    	{
       		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,"%s-->nac_set_data_to_knl-->NAC_CMD_USER_FLUSH is error.\n",__FUNCTION__);
        	error_id = NAC_SYS_ERROR_FLUSH_USER_FAIL;
    	}

		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

    case NAC_ADD: //Dowell attention: one xml only deal with a one user check result
        while(cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "onlineUser")) && (xmlHasProp(cur_node, BAD_CAST "type")))
            {
                user_szKey[0] = xmlNodeGetContent(cur_node);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->onlineUser-->%s\n", __FUNCTION__, (HUPU_CHAR*)user_szKey[0]);
                user_szKey[1] =  xmlGetProp(cur_node, BAD_CAST "type");
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->onlineUserType-->%s\n", __FUNCTION__, (HUPU_CHAR*)user_szKey[1]);
			}
			else if (!(xmlStrcmp(cur_node->name, BAD_CAST "isolateZone"))
				&& (xmlHasProp(cur_node, BAD_CAST "sum")))
			{
				zone_szKey = xmlNodeGetContent(cur_node);
				szAttr = xmlGetProp(cur_node, BAD_CAST "sum");
                iso_zone_sum = atoi((HUPU_CHAR*)szAttr);
				xmlFree(szAttr);

				//<isolateZone sum="5"></isolateZone>
				if (!strlen((HUPU_CHAR*)zone_szKey))//!0
				{
					iso_zone_sum = 0;
				}
				break;
			}
			cur_node = cur_node->next;
        }

		if (iso_zone_sum)
		{
			if (iso_zone_sum <= 16)
			{
				iRet = nac_sys_add_user((HUPU_CHAR**)user_szKey, (HUPU_CHAR*)zone_szKey, iso_zone_sum);
			}
			else
			{
				nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->zoneid_sum beyond the max_limits max_sum=16 error\n", __FUNCTION__);
				iRet = NAC_SYS_ERROR_ZONEID_SUM_BEYOND_LIMIT;
			}
		}
		else
		{
			iRet = nac_sys_add_user((HUPU_CHAR**)user_szKey, NULL, iso_zone_sum);
		}

		if (!user_szKey[0])//!HUPU_NULL
		{
			xmlFree(user_szKey);
		}
        if (!user_szKey[1])//!HUPU_NULL
		{
			xmlFree(user_szKey[1]);
		}

		if (!zone_szKey)//!HUPU_NULL
		{
			xmlFree(zone_szKey);
		}

        nac_free_xmlDoc(doc);
		if (iRet != HUPU_OK)
        {
          	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_add_user error\n", __FUNCTION__);
			if (iRet == HUPU_ERR)
			{
				error_id = NAC_SYS_ERROR_ADD_USER_FAIL;
			}
			else
			{
				error_id = iRet;
			}
       	}
        nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    case NAC_DEL:
        while(cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "onlineUser")))
            {
                user_szKey[0] = xmlNodeGetContent(cur_node);
                user_szKey[1] = xmlGetProp(cur_node, BAD_CAST "type");
                iRet = nac_sys_rmv_user((HUPU_CHAR**)user_szKey);
                xmlFree(user_szKey[0]);

				if (user_szKey[1] != HUPU_NULL)
				{
                	xmlFree(user_szKey[1]);
				}

				if (iRet != HUPU_OK)
        		{
          			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_rmv_user error\n", __FUNCTION__);
					if (iRet == HUPU_ERR)
					{
						error_id = NAC_SYS_ERROR_DEL_USER_FAIL;
					}
					else
					{
						error_id = iRet;
					}
					break;
       			}

            }

            cur_node = cur_node->next;
        }
		nac_free_xmlDoc(doc);
        nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    case NAC_SHOW:
    case NAC_MODIFY:
    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}
