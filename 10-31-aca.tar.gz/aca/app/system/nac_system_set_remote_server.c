#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_common_lib.h"
#include "nac_system_errorlog.h"
#include "nac_system_net.h"
#include "nac_system_deal_license.h"
#include "nac_system_deal_sysconfig.h"
#include "nac_system_set_remote_server.h"

//create_sock address(ip(host_bytes),port)
HUPU_UINT32 gi_link_server_ip;
HUPU_CHAR   gi_link_company_code[10];
HUPU_UINT32 last_link_remote_ip; //last time connect serverip.
HUPU_CHAR   last_link_company_code[10];

static HUPU_INT32 nac_system_modify_serverip_companycode(HUPU_UINT32 ui_ip,
				HUPU_CHAR *company_code)
{
	FILE* nac_fp;
	HUPU_CHAR szLine[BUFF_LEN] = "";
	
	HUPU_CHAR *nac_license_name = "/nac/config/nac_license";
	HUPU_CHAR *modify_server_ip = "sed -i '/^companyId/d' %s";
	HUPU_CHAR *modify_company_code = "sed -i '/^serverIp/d' %s";

	/*/nac/config/nac_license is existed or not!*/
	if (access(nac_license_name, F_OK) == -1)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->%s is non_existed\n",
					__FUNCTION__, nac_license_name);

		return HUPU_ERR;
	}

	memset(szLine, '\0', sizeof(szLine));
	sprintf(szLine, modify_server_ip, nac_license_name);
	nac_exec_system(szLine);

	memset(szLine, '\0', sizeof(szLine));
	sprintf(szLine, modify_company_code, nac_license_name);
	nac_exec_system(szLine);

	if ((nac_fp = fopen(nac_license_name, "a+")) == NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n",
					__FUNCTION__, nac_license_name);
		
		return HUPU_ERR;
	}
	
	fprintf(nac_fp, "companyId=%s\n", company_code);
	fprintf(nac_fp, "serverIp=%u.%u.%u.%u\n", LIPQUAD(ui_ip));
	
	fclose(nac_fp);
	
	return HUPU_OK;
}

HUPU_VOID nac_system_destroy_tcp_long_sockfd(HUPU_VOID)
{
	if (new_link_fd)
    {
        nac_tcp_destroy(new_link_fd);
    }
    new_link_fd = 0;
    gi_link_fd  = 0;

	return;
}

/*
 * <?xml version="1.0" encoding="UTF-8"?>
 * <nac>
 *	 <commandID>217</commandID>
 *   <actionType>1</actionType>
 *   <serverIp>127.0.0.1<serverIp>
 *   <companyId>10000000</companyId>
 * </nac>
 */

xmlDocPtr nac_sys_parse_set_remote_server_info(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_INT32 iRet, error_id;
	xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;	
    HUPU_UINT8 action_type;

	xmlChar* ip_szkey;
	xmlChar* code_szkey;

	HUPU_UINT32 server_ip_tmp;
	HUPU_CHAR   company_code_tmp[10] = "";
		
	
	cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }
	
	error_id = 0;	
	switch (action_type)
    {
    case NAC_SHOW:
        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_ret_show_result(cmd_id, "get_link_status");
        break;

    case NAC_ADD:
		while(cur_node != HUPU_NULL)
		{
			if(!(xmlStrcmp(cur_node->name, BAD_CAST "serverIp")))
			{
				ip_szkey = xmlNodeGetContent(cur_node);
				server_ip_tmp = inet_network((HUPU_CHAR*)ip_szkey);
				xmlFree(ip_szkey);	
			}
			else if(!(xmlStrcmp(cur_node->name, BAD_CAST "companyId")))
			{
				code_szkey = xmlNodeGetContent(cur_node);
				memcpy(company_code_tmp, (HUPU_CHAR*)code_szkey, strlen((HUPU_CHAR*)code_szkey));
				xmlFree(code_szkey);
				break;
			}
			cur_node = cur_node->next;
		}

		nac_free_xmlDoc(doc);
		iRet = nac_system_modify_serverip_companycode(server_ip_tmp, company_code_tmp);
		if (iRet != HUPU_OK)
		{
			error_id = NAC_SYS_ERROR_SET_REMOTE_SERVER_INFO_FAIL;
		}
		else
		{
			nac_system_destroy_tcp_long_sockfd();
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
						"%s-->%d-->control modify remote_server close long_connect for reconnect!\n",
						__FUNCTION__, __LINE__);
		}

		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

    case NAC_DEL:
		nac_free_xmlDoc(doc);
		nac_system_destroy_tcp_long_sockfd();
        nac_system_check_license_file("/nac/config/nac_license");
        //imform ruby to reconnect;
        nac_sys_send_ruby_switch_usr1();
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->%d-->control active close long_connect!\n",
					__FUNCTION__, __LINE__);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
	}

	return nac_doc;
}

xmlDocPtr nac_sys_parse_get_controller_link_status(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    HUPU_UINT8 action_type;


    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

    switch (action_type)
    {
    case NAC_SHOW:
        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_ret_show_result(cmd_id, "get_link_status");
        break;

	default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

