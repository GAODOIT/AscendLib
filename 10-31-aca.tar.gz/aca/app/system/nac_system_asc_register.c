#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_net.h"
#include "nac_system_escape_deal.h"
#include "nac_system_asc_register.h"


static HUPU_INT32 nac_app_get_company_id(const HUPU_CHAR* filename, HUPU_CHAR *company_id)
{
    FILE *nac_fp;
    HUPU_UINT16 get_flag = 0;
    HUPU_CHAR buffer[BUFF_LEN] = "";
    HUPU_CHAR* get_content = HUPU_NULL;

    if ((nac_fp = fopen(filename, "r")) == HUPU_NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(buffer, BUFF_LEN, nac_fp)) != HUPU_NULL)
    {
        if ((get_content = strstr(buffer, "companyId=")) != HUPU_NULL)
        {
            get_content = get_content + 10;
            clean_newline_character(get_content);
            memcpy(company_id, get_content, strlen(get_content));
            SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ASC--%s-->nac_license company_id=%s=%d\n", __FUNCTION__, get_content, strlen(get_content));
            get_flag = 1;
            break;
        }

        memset(buffer, '\0', BUFF_LEN);
    }
    fclose(nac_fp);

    if (get_flag == 1)
    {
        return HUPU_OK;

    }
	else
	{
        return HUPU_ERR;
    }

}

//optimize(for xml_string);ASC_CLIENT_REGISTER = 150.
HUPU_INT32 nac_system_send_asc_register_msg_to_server(HUPU_INT32 ui_sock_fd)
{
	HUPU_UINT32 iRet;
    xmlDocPtr nac_doc;
    xmlNodePtr root_node;
    HUPU_CHAR cmd_str[10];
    HUPU_CHAR controller_mac[18] = "";
    HUPU_CHAR cpu_id_str[35] = "";
	HUPU_UINT16 asc_link_action_tmp = ASC_FIRST_LINK;
	HUPU_CHAR asc_link_port_name[BUFF_LEN];

    nac_doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(nac_doc, root_node);

    memset(cmd_str, '\0', sizeof(cmd_str));
    sprintf(cmd_str, "%d", ASC_CLIENT_REGISTER);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_str);

    memset(cmd_str, '\0', sizeof(cmd_str));
    //sprintf(cmd_str, "%d", ASC_LINK);
	sprintf(cmd_str, "%d", asc_link_action_tmp);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST cmd_str);

    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "controllerType", BAD_CAST "app");

    /*
	HUPU_INT16 manager_ifindex;
	manager_ifindex = nac_app_get_eth0_ifindex();
    nac_get_netdev_mac(nac_sys_ifname[manager_ifindex], controller_mac, sizeof(controller_mac));
    */
    sprintf(controller_mac, "%02x-%02x-%02x-%02x-%02x-%02x", MAC_FORMAT(g_manager_mac_addr));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "controllerId", BAD_CAST controller_mac);

    get_cpu_id_str(cpu_id_str);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "cpuId", BAD_CAST cpu_id_str);

    memset(cmd_str, '\0', sizeof(cmd_str));
    nac_app_get_company_id("/nac/config/nac_license", cmd_str);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "companyId", BAD_CAST cmd_str);
    memset(cmd_str, '\0', sizeof(cmd_str));

	switch (app_nacmode)
	{
	case NAC_MVG_MODE:
		memcpy(cmd_str, "mvg", strlen("mvg"));
		break;
	case NAC_PBR_MODE:
		memcpy(cmd_str, "pbr", strlen("pbr"));
		break;
	case NAC_BRIDGE_MODE:
		memcpy(cmd_str, "bridge", strlen("bridge"));
		break;
	default:
		memcpy(cmd_str, "NULL", strlen("NULL"));
		break;
	}

    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "nacMode", BAD_CAST cmd_str);

	if (g_nac_asc_enable_flag == ASC_ENABLE)
    {
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "ascEnable", BAD_CAST "1");
    }else if (g_nac_asc_enable_flag == ASC_DISABLE)
    {
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "ascEnable", BAD_CAST "0");
    }

	if (g_asc_running_mode == ASC_NORMAL_MODE)
	{
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "ascMode", BAD_CAST "1");
	}
	else if (g_asc_running_mode == ASC_ESCAPE_MODE)
	{
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "ascMode", BAD_CAST "0");
	}

	memset(asc_link_port_name, '\0', sizeof(asc_link_port_name));
	nac_app_get_asc_link_port_name(asc_link_port_name);
	xmlNewChild(root_node, HUPU_NULL, BAD_CAST "linkPorts", BAD_CAST asc_link_port_name);

	iRet = nac_sys_send_xmldoc_to_webserver(ui_sock_fd, nac_doc, ASC_CLIENT_REGISTER);
	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_send_xmldoc_to_webserver error\n", __FUNCTION__);
		return HUPU_ERR;
	}

    return HUPU_OK;
}

