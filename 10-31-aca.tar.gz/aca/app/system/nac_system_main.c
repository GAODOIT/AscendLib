#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <errno.h>
#include <poll.h>
#include <time.h>
#include <signal.h>
#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_common_lib.h"
#include "nac_system_xml.h"
#include "nac_system_net.h"
#include "nac_system_user.h"
#include "nac_system_save_sysconfig.h"
#include "nac_system_asc_register.h"
#include "nac_system_get_hardwareId.h"
#include "nac_system_app_knl_port.h"
#include "nac_system_vlanmap.h"
#include "nac_system_redirect_manager_ip.h"
#include "nac_system_set_remote_server.h"
#include "nac_system_debug_sysconfig.h"
#include "nac_system_netapp_check.h"
#include "nac_system_netapp_user.h"
#include "nac_system_switch_main.h"
#include "nac_system_switch_snmp.h"
#include "nac_system_arp_monitor.h"
#include "nac_system_time.h"
#include "nac_system_deal_sysconfig.h"
#include "nac_system_deal_license.h"
#include "nac_system_domain_policy.h"
#include "nac_system_iprange_policy.h"
#include "nac_system_debug_switch.h"
#include "nac_system_escape_deal.h"
#include "nac_system_nat_manage.h"
#include "nac_system_ha_backup.h"
#include "nac_system_redis_subscribe.h"


//debug switch SYSTEM_PRINT();
HUPU_UINT16 g_debug_switch = 0;

//asc_connect_server_timestamp;
HUPU_CHAR long_tcp_connect_success_timestamp[32];

//long_connect_timeout,then destory sockfd;
HUPU_INT32 nac_app_long_connect_timeout;

//sock_fd
static HUPU_UINT32 ui_max_fd = 0;
static HUPU_INT32 nac_web_fd = 0;
static HUPU_INT32 gi_xml_sock_fd = 0;
HUPU_INT32 new_link_fd = 0;
HUPU_INT32 gi_link_fd = 0;
static HUPU_INT32 gi_netlink_fd = 0;
static HUPU_UINT32 gi_cli_connect_index = 0;

/*default app nacmode <nac_knl_policy.h>*/
NAC_MODE app_nacmode = NAC_PBR_MODE;

//pbr advance setup
HUPU_INT32 nac_pbr_onein_oneout_flag = 0;//default close
NAC_PBR_ADVANCE_SETUP pbr_advance_setup;

//Ascend_dowell nac_app_controller_socket_link_flag
HUPU_UINT8  nac_app_link_flag; //controller_client_link flag


HUPU_INT32 nac_system_init_all_config(HUPU_VOID)
{
	HUPU_INT32 iRet;
	//ifconfig, gateway, dns;
	nac_sys_init_warn_config_status();
    nac_system_init_network_ifconfig();
	/*************************init memory config hash***********************************/
	nac_sys_init_redirect_manager_ip_info();
	nac_system_init_vlanmap();
	nac_app_init_netapp_hlist();
	nac_system_init_netapp_user_hlist();
    nac_app_init_nat_manage();
    nac_system_init_device_info_hlist();//nac_system_arp_monitor.c
	nac_system_init_domain_policy();//nac_system_domain_policy.c
	nac_system_init_iprange_policy();//nac_system_iprange_policy.c
	nac_system_init_offline_user_list();//nac_system_user.c
	nac_system_init_switch();
	nac_app_init_delay_msg_list();
	nac_sys_get_knl_pass_switch(&g_nac_asc_enable_flag);
    nac_system_init_ha_backup();
	/**************************init flush knl config*****************************/
	//iRet = nac_app_init_flush_knl_config();
    iRet = nac_app_flush_all_system_config();
	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_system_init_flush_knl_config error, iRet = %d\n", __FUNCTION__, iRet);
		return HUPU_ERR;
	}
    nac_lib_create_pid_file(NAC_SYSTEM_PID_FILE);

    /***********************init send nac_sys_config to knl***********************/
	//one: no nac_sys.conf use default setting; two: have nac_sys.conf read nac_sys.conf init system_config
	if (access(nac_sys_cfg_file, F_OK) == HUPU_OK) //nac_sys.conf is existed!
    {
        nac_app_read_sys_config_from_file(nac_sys_cfg_file, 0);
    }
    else if (access(nac_factory_cfg_file, F_OK) == HUPU_OK)
    {
        nac_app_read_sys_config_from_file(nac_factory_cfg_file, 0);
    }
	else
	{
		iRet = nac_system_set_nac_mode(app_nacmode);
		if (iRet != HUPU_OK)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_system_set_nac_mode-->%d\n", __FUNCTION__, app_nacmode);
			return HUPU_ERR;
		}
	}

	// set eth0_mac to knl
	iRet = nac_app_get_eth0_ifindex();
	memset(g_manager_mac_addr, 0, ETH_ALEN);
	nac_get_netdev_mac(nac_sys_ifname[iRet], g_manager_mac_addr, ETH_ALEN);
	iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_ETH0_MAC, 0, g_manager_mac_addr, ETH_ALEN);
    if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->set manager_eth0_macaddr to knl error\n", __FUNCTION__);
		return HUPU_ERR;
	}

    /*******************create /nac/config/nac_controller_device_id.conf file**************************/
    iRet = nac_sys_save_controller_id("/nac/config/nac_device_id.conf");
    if (iRet == HUPU_ERR)
    {
       	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s--> nac_sys_save_controller_id error, iRet = %d\n", __FUNCTION__, iRet);
	    return HUPU_ERR;
    }

    /***********nac app create 6001 listen port for controller_web to get config******************/
	nac_web_fd = nac_tcp_crt_svr(NAC_APP_SERVER_LISTEN_PORT);
	if(nac_web_fd < 0)
	{
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_tcp_crt_svr error, nac_web_fd = %d\n", __FUNCTION__, nac_web_fd);
		return HUPU_ERR;
	}
    iRet = nac_tcp_listen(nac_web_fd, NAC_SYS_TCP_MAX_LISTEN_NUM);
	if(iRet < 0)
	{
	    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_tcp_listen error, iRet = %d\n", __FUNCTION__, iRet);
		return HUPU_ERR;
	}

	/**************create app netlink sockfd for receive kernel msg ******************/
	gi_netlink_fd = nac_app_netlink_create(NAC_NETLINK_USER_OPEN);
	if(HUPU_ERR == gi_netlink_fd)
	{
	  return HUPU_ERR;
	}

	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_web_fd=%d-->new_link_fd=%d-->gi_netlink_fd=%d--end.\n",
				__FUNCTION__, nac_web_fd, new_link_fd, gi_netlink_fd);

    nac_system_check_license_file("/nac/config/nac_license");
    //imform ruby to connect server;
    nac_sys_send_ruby_switch_usr1();

	return HUPU_OK;
}

HUPU_INT32 nac_system_asc_connect_register_server(HUPU_INT32 link_fd)
{
    HUPU_INT32	iRet, manager_if_index;
	HUPU_UINT32 manager_eth_ip_tmp, now_server_ip; //host_bytes
	HUPU_CHAR escape_buffer[BUFF_LEN];

    // get device_license is ok.
    iRet = nac_system_check_license_file("/nac/config/nac_license");
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "--%s--nac_license is not ok\n", __FUNCTION__);
        return HUPU_ERR-1;
    }


	manager_if_index	= nac_app_get_manager_ifindex();
	manager_eth_ip_tmp	= nac_app_get_netdev_ipaddr(nac_sys_ifname[manager_if_index]);

	iRet = nac_system_check_device_type(manager_eth_ip_tmp);
	if (iRet != HUPU_OK)
	{
		return HUPU_ERR-1;
	}

	if (127 == ((unsigned char *)&gi_link_server_ip)[3] || manager_eth_ip_tmp == gi_link_server_ip)
	{
		now_server_ip = inet_network("127.0.0.1");
	}
	else
	{
		now_server_ip = gi_link_server_ip;
	}

	//set tcp connect keepalive
	iRet = nac_system_set_tcp_connect_keepalive(link_fd);
	if (iRet == HUPU_ERR)
	{
		return HUPU_ERR;
	}
	//connect_time_out = 6s;
	nac_system_set_tcp_connect_timeout(link_fd, 6);

	//tcp_client try connect remote_server;
    iRet = nac_tcp_connect(link_fd, now_server_ip, NAC_APP_CLIENT_LINK_PORT);
    if (iRet < 0)
    {
		if (errno == EINPROGRESS)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s--tcp client create connect timeout\n", __FUNCTION__);
		}

        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,
					"ERROR--%d--%s-->nac_tcp_connect error, gi_link_server_ip = %08x, iRet = %d\n",
                    __LINE__, __FUNCTION__, now_server_ip, iRet);

		return HUPU_ERR;
    }
	//the real remote_server_ip;
	gi_link_server_ip = now_server_ip;
    //imform ruby to reconnect;
    //nac_sys_send_ruby_switch_usr1();
	memset(escape_buffer, '\0', sizeof(escape_buffer));
	if (g_asc_escape_enable_flag == HUPU_ENABLE)
	{
		nac_system_pack_escape_reason(HUPU_FALSE, escape_buffer, &g_asc_running_mode);
	}
	else
	{
		g_asc_running_mode = ASC_NORMAL_MODE;
	}

	//get current tcp_sock create timestamp;
	memset(long_tcp_connect_success_timestamp, '\0', strlen(long_tcp_connect_success_timestamp));
	get_current_time(long_tcp_connect_success_timestamp);

	if (strcmp(last_link_company_code, gi_link_company_code) == HUPU_OK
		&& last_link_remote_ip == now_server_ip)
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
				"reconnect no flush config--%s-->last--%s--%08x-->now--%s--%08x-->manage_ip--%08x;\n",
				__FUNCTION__, last_link_company_code, last_link_remote_ip, gi_link_company_code,
				gi_link_server_ip, manager_eth_ip_tmp);
	}
	else
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
				"reconnect flush config--%s-->last--%s--%08x-->now--%s--%08x-->manage_ip--%08x;\n",
				__FUNCTION__, last_link_company_code, last_link_remote_ip, gi_link_company_code,
				gi_link_server_ip, manager_eth_ip_tmp);

		if (gi_cli_connect_index >= 1)
		{
			//flush all system config
			SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->flush system config, company_code or server_ip have change!\n", __FUNCTION__);
			nac_app_flush_all_system_config();
			//set system default nac_mode = nac_pbr_mode;
			app_nacmode = NAC_PBR_MODE;
		}

	}

	//update the in or out dev_eth
	iRet = nac_system_set_nac_mode(app_nacmode);
	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_system_set_nac_mode-->%d\n",
					__FUNCTION__, app_nacmode);
		return HUPU_ERR;
	}

	/*if gi_link_server_ip == 127.*.*.* or gi_link_server_ip == manager_eth_ip_tmp;
	so device_type == controller+server;
	set ac_redirect_ip = ac_server_manager_ip = manager_eth_ip_tmp;
	update the server_manager_ip
	*/

	if (now_server_ip == inet_network("127.0.0.1"))
	{
		now_server_ip = manager_eth_ip_tmp;
	}

	iRet = nac_sys_set_server_manager_ip(now_server_ip);
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->now_server_ip=%u.%u.%u.%u.\n",
				__FUNCTION__, LIPQUAD(now_server_ip));

	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->nac_sys_set_server_manager_ip-->NAC_CMD_SYS_SET_IP_INFO-->error!\n",
					__FUNCTION__);
		return HUPU_ERR;
	}

	//socket_connect ok; save current remote_ip and company_code;
	gi_cli_connect_index = gi_cli_connect_index + 1; //connect_num ++
	last_link_remote_ip = gi_link_server_ip;
	memset(last_link_company_code, '\0', sizeof(last_link_company_code));
	memcpy(last_link_company_code, gi_link_company_code, strlen(gi_link_company_code));

	iRet = nac_system_send_asc_register_msg_to_server(link_fd);
	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->nac_system_send_asc_register_msg_to_server:error!\n",
					__FUNCTION__);
		return HUPU_ERR;
	}

    return HUPU_OK;
}


HUPU_INT32 nac_control_client_handling_from_web_msg(HUPU_INT32 link_fd)
{
	HUPU_INT32 iRet;
    HUPU_CHAR ac_buff[NAC_WEB_MSG_BUFFER_LEN] = "";
    NAC_WEB_MSG *pst_web_msg = (NAC_WEB_MSG *)ac_buff;
    xmlDocPtr doc = HUPU_NULL;

	memset(ac_buff, '\0', NAC_WEB_MSG_BUFFER_LEN);
    iRet = nac_tcp_recvfrom(link_fd, ac_buff, NAC_WEB_MSG_BUFFER_LEN);
    /*
     recv fault because tcp server point is close,
     must nac_tcp_destroy(link_fd),
     otherwise cannot reconnect server.
     */
	if(iRet <= HUPU_OK)
    {
    	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
			"%d--%s-->recvfrom error.link_fd = %d, iRet = %d, errno = %d, error info = %s\n",
			__LINE__, __FUNCTION__, link_fd, iRet, errno, strerror(errno));
        return HUPU_ERR;
    }
	else
	{
		nac_app_long_connect_timeout = 80;
	}

    SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->iRet = %d-->link_fd = %d, us_cmd = %d, ui_len = %d, ac_buf = %s\n",
				__FUNCTION__, iRet, link_fd, pst_web_msg->us_cmd, pst_web_msg->ui_len, pst_web_msg->ac_buf);

	//receive:1;1;1 return 1;1;0
	if (pst_web_msg->us_cmd == 1 && pst_web_msg->ui_len == 1
		&& memcmp(pst_web_msg->ac_buf, "1", pst_web_msg->ui_len) == HUPU_OK)
	{
		iRet = nac_sys_return_heart_beat_to_webserver(link_fd, ac_buff);
		if (iRet != HUPU_OK)
		{
    		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "error:%s-->control return heart_beat\n", __FUNCTION__);
		}

		return HUPU_OK;
	}

	if ((pst_web_msg->us_cmd + 100) == ASC_CLIENT_REGISTER)
    {
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "Register_Result:%s-->register_result=%s\n",
        			__FUNCTION__, pst_web_msg->ac_buf);

		nac_system_send_offline_user_to_server(link_fd);
		nac_system_destory_offline_user_list();
		nac_app_resend_delay_msg_list(link_fd);
		//nac_app_show_all_delay_msg();
		return HUPU_OK;
    }

	/*Parse transfer xml_buffer */
	if (pst_web_msg->ui_len == strlen(pst_web_msg->ac_buf))
    {
        doc = xmlParseMemory(pst_web_msg->ac_buf, pst_web_msg->ui_len);
        if (HUPU_NULL == doc)
        {
            nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,  "Error:%s-->Fail to parse web_msg buffer!\n", __FUNCTION__);
            return HUPU_OK;
        }

        if (pst_web_msg->us_cmd != SYS_WEBUI_SET_IFCONFIG
            || pst_web_msg->us_cmd != SYS_WEBUI_SET_GATEWAY
            || pst_web_msg->us_cmd != SYS_WEBUI_SET_DNS
            || pst_web_msg->us_cmd != SYS_WEBUI_SHUT_OR_BOOT)
        {
            nac_system_ha_sync_dynamic_config(doc, pst_web_msg);
        }
        nac_sys_parse_web_xmlmsg(link_fd, doc, pst_web_msg->us_cmd);
    }
    /*End parse transfer xml_buffer*/

	return HUPU_OK;
}

HUPU_INT32 nac_control_server_handling_from_web_msg(HUPU_INT32 xml_sock_fd)
{
    HUPU_INT32 iRet;
    HUPU_CHAR ac_buff[NAC_WEB_MSG_BUFFER_LEN] = "";
    NAC_WEB_MSG *pst_web_msg = (NAC_WEB_MSG *)ac_buff;
    xmlDocPtr doc = HUPU_NULL;
    memset(ac_buff, '\0', NAC_WEB_MSG_BUFFER_LEN);
    iRet = nac_tcp_recvfrom(xml_sock_fd, ac_buff, NAC_WEB_MSG_BUFFER_LEN);
    if(iRet <= 0)
    {
		//iRet = 0; opposite end is normal shutdown!
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "recvfrom error xml_sock_fd = %d, iRet = %d, errno = %d, error info = %s\n",
			            xml_sock_fd, iRet, errno, strerror(errno));
        //nac_tcp_destroy(xml_sock_fd);
		return HUPU_ERR;
    }

	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->iRet = %d-->xml_sock_fd = %d, us_cmd = %d, ui_len = %d, ac_buf = %s\n",
				__FUNCTION__, iRet, xml_sock_fd, pst_web_msg->us_cmd, pst_web_msg->ui_len, pst_web_msg->ac_buf);

    if (pst_web_msg->us_cmd == SYS_WEBUI_HA_BACKUP_SYNC + 1)
    {
       nac_system_ha_deal_sync_msg(pst_web_msg, xml_sock_fd);
       return HUPU_OK;
    }

#if 0
	if (pst_web_msg->us_cmd == SYS_WEBUI_IDM_CONNECT_ASC_REQUEST
        && pst_web_msg->ui_len == strlen("GetASCMac")
        && memcmp(pst_web_msg->ac_buf, "GetASCMac", pst_web_msg->ui_len) == HUPU_OK)
    {
		iRet = nac_sys_return_idm_connect_asc_requset(xml_sock_fd);
		if (iRet != HUPU_OK)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "error:%s-->ASC response IDM\n", __FUNCTION__);
		}
        return HUPU_OK;
	}
#endif

	//Parse transfer xml_buffer
	if (pst_web_msg->ui_len == strlen(pst_web_msg->ac_buf))
    {
        doc = xmlParseMemory(pst_web_msg->ac_buf, pst_web_msg->ui_len);
        if (HUPU_NULL == doc)
        {
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "Error:%s-->Fail to parse web_msg buffer!\n",
							__FUNCTION__);
			return HUPU_OK;
		}

		nac_sys_parse_web_xmlmsg(xml_sock_fd, doc, pst_web_msg->us_cmd);
	}
    /*End parse transfer xml_buffer*/

	return HUPU_OK;
}

HUPU_INT32 nac_system_handling_from_kernel_msg(HUPU_INT32 gi_netlink_fd, HUPU_INT32 xml_sock_fd)
{
    HUPU_INT32 iRet;
    struct nlmsghdr  *pst_netlink_head     = HUPU_NULL;
    NAC_KNL_USER_MSG *pst_netlink_user_msg  = HUPU_NULL;
    HUPU_CHAR buffer[1024] = {0};
    iRet = nac_app_netlink_recv(gi_netlink_fd, buffer, sizeof(buffer));
    if(iRet <= 0)
    {
      return HUPU_ERR;
    }
    pst_netlink_head    = (struct nlmsghdr *)buffer;
    pst_netlink_user_msg = (NAC_KNL_USER_MSG *)(buffer + NLMSG_HDRLEN);
	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nlmsg_type=%d\n", pst_netlink_head->nlmsg_type);
	switch(pst_netlink_head->nlmsg_type)
    {
	case NAC_NETLINK_USER_TIMEOUT:
    case NAC_NETLINK_NETAPP_TIMEOUT:
        pst_netlink_user_msg->cmd = pst_netlink_head->nlmsg_type;
        iRet = nac_sys_netlink_user_timeout(pst_netlink_user_msg, xml_sock_fd);
        if (iRet == HUPU_ERR)
        {
            return HUPU_ERR;
        }
      	break;
	case NAC_NETLINK_NETAPP_FOUND:
	case NAC_NETLINK_NETAPP_EXCEPT:
        pst_netlink_user_msg->cmd = pst_netlink_head->nlmsg_type;
		iRet = nac_sys_netlink_netapp_found(pst_netlink_user_msg, xml_sock_fd);
		if (iRet == HUPU_ERR)
		{
			return HUPU_ERR;
		}
		break;
	case NAC_NETLINK_NEW_USR:
        iRet = nac_sys_netlink_add_tmp_user(pst_netlink_user_msg);
		if (iRet == HUPU_ERR)
		{
			return HUPU_ERR;
		}
		break;
    case NAC_NETLINK_DOMAIN_NEW:
        iRet = nac_sys_netlink_add_tmp_domain(pst_netlink_user_msg);
		if (iRet == HUPU_ERR)
		{
			return HUPU_ERR;
		}
        break;
    case NAC_NETLINK_DOMAIN_TIMEOUT:
        iRet = nac_sys_netlink_del_tmp_domain(pst_netlink_user_msg);
		if (iRet == HUPU_ERR)
		{
			return HUPU_ERR;
		}
        break;
    case NAC_NETLINK_NAT_NEW:
        iRet = nac_sys_netlink_add_tmp_nat(pst_netlink_user_msg);
		if (iRet == HUPU_ERR)
		{
			return HUPU_ERR;
		}
        break;
    case NAC_NETLINK_NAT_TIMEOUT:
        iRet = nac_sys_netlink_del_tmp_nat(pst_netlink_user_msg);
		if (iRet == HUPU_ERR)
		{
			return HUPU_ERR;
		}
        break;
    case NAC_NETLINK_NAT_FOUND:
        iRet = nac_sys_netlink_found_nat(pst_netlink_user_msg);
        if (iRet == HUPU_ERR)
        {
            return HUPU_ERR;
        }
        break;
    default:
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "knl netlink nlmsg_type fail!\n");
		break;
    }

    return HUPU_OK;
}

/*
//enable kill -USR1 29150 or kill -s SIGUSR1 29150
HUPU_VOID nac_system_catch_SigUser1(HUPU_INT32 sig)
{
	g_debug_switch = (g_debug_switch + 1)%2;
}
*/

HUPU_VOID *nac_system_asc_connect_server_thread(HUPU_VOID *arg)
{
	HUPU_INT32  iRet;
	while (1)
	{
		if (new_link_fd == 0)
		{
			gi_link_fd = 0;
			new_link_fd = nac_tcp_crt_cli();
			if (new_link_fd < HUPU_OK)
			{
				nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->nac_tcp_crt_cli error, new_link_fd = %d\n",
					__FUNCTION__, new_link_fd);
				new_link_fd = 0;
			}
		}
		else if (new_link_fd > 0 && gi_link_fd == 0)
		{
			SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->(0x%x)-->reconnect %s\n",
						__FUNCTION__, (HUPU_UINT32)pthread_self(), (HUPU_CHAR*)arg);

			iRet = nac_system_asc_connect_register_server(new_link_fd);
			if(iRet == HUPU_OK)
			{

       			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->%d-->asc: nac_system_asc_connect_register_server ok!\n",
					__FUNCTION__, __LINE__);
				gi_link_fd = new_link_fd;
			}
			else if (iRet == HUPU_ERR-1)
			{
				nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,"%s-->%d-->asc:license check error!\n",
							__FUNCTION__, __LINE__);
			}
			else
			{
       			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
						"%s-->%d-->asc:nac_system_asc_connect_register_server error!\n",
						__FUNCTION__, __LINE__);
				nac_tcp_destroy(new_link_fd);
				new_link_fd = 0;
			}

			ui_max_fd = MAX_4(nac_web_fd, gi_netlink_fd, gi_xml_sock_fd, gi_link_fd);
		}
		sleep(5);
	}

	pthread_detach(pthread_self());
	return NULL;
}

#define NAC_SYS_SYNC_NTP_SERVER_TIMEPOINT	24*60*60
HUPU_VOID *nac_system_main_time_out_thread(HUPU_VOID *arg)
{
	HUPU_INT32 iRet;
	time_t	timep;
	struct tm st_tm;
	HUPU_ULONG32 nac_crond_day_time_sec = 0;
	struct timeval st_timeout;
	HUPU_UINT32	snmp_send_time_out_count = 0;
	HUPU_UINT32 arp_send_time_out_count  = 0;
	HUPU_UINT32 hlist_ageing_time_count  = 0;
    HUPU_UINT32 hlist_traverse_cycle     = 0;
	HUPU_UINT32 nac_license_last_hour_count = 0;
	HUPU_UINT32 system_run_status_check_cycle = 0;
    HUPU_UINT32 auto_nat_list_time_count = 0;

	time(&timep);
	localtime_r(&timep, &st_tm);
	nac_crond_day_time_sec = (st_tm.tm_hour * 3600)+ (st_tm.tm_min * 60) + st_tm.tm_sec;

	while(1)
	{
		st_timeout.tv_sec	= 5;
    	st_timeout.tv_usec	= 0;

		iRet = select(1, HUPU_NULL, HUPU_NULL, HUPU_NULL, &st_timeout);
		if (HUPU_ERR == iRet)
        {
            if(errno == EINTR)
            {
                continue;
            }
            break;
        }
		else if (HUPU_OK == iRet) //time_out_scan
		{
			hlist_ageing_time_count	+= 5;
            hlist_traverse_cycle += 5;
			snmp_send_time_out_count += 5;
			arp_send_time_out_count += 5;
			nac_crond_day_time_sec += 5;
			nac_license_last_hour_count += 5;
			system_run_status_check_cycle +=5;
            auto_nat_list_time_count +=5;

			/*
			if (nac_app_long_connect_timeout <= 0)
			{
				nac_system_destroy_tcp_long_sockfd();
			}
			else
			{
				nac_app_long_connect_timeout -= 5;
			}
			*/

            if (auto_nat_list_time_count == 5*12)
            {
                time(&timep);
                nac_app_auto_nat_list_timeout(timep);
                auto_nat_list_time_count = 0;
            }

            if (hlist_traverse_cycle == 5*60)
            {
                hlist_traverse_cycle = 0;
                //netapp_user
		        nac_system_free_time_out_netapp_user(5*60);
            }

			if (hlist_ageing_time_count == 10*60)
			{
				hlist_ageing_time_count = 0;

				if (gst_arp_monitor_config.enable == HUPU_TRUE)
				{
					nac_system_free_device_info_hlist_time_out_node(15*60);
				}

				if (gst_nac_ntp_server.self_sync_enable == HUPU_TRUE)
				{
					nac_ntpdate_time_server(gst_nac_ntp_server.ntp_server);
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->every 10 min auto sync time_server\n", __FUNCTION__);
				}
			}

			if (nac_license_last_hour_count == 60*60)
			{
				nac_license_last_hour_count = 0;
				if (g_ui_license_total_htime != 0 && g_ui_license_remain_htime > 0)
				{
					g_ui_license_remain_htime = g_ui_license_remain_htime - 1;
					nac_system_update_license_remain_htime(nac_remain_htime_file);
				}
			}

			//when utc time come across NAC_SYS_SYNC_NTP_SERVER_TIMEPOINT, excute the auto ntpdate
			if (NAC_SYS_SYNC_NTP_SERVER_TIMEPOINT - nac_crond_day_time_sec <= 5)
			{
				time(&timep);
    			localtime_r(&timep, &st_tm);
   		 		nac_crond_day_time_sec = (st_tm.tm_hour * 3600)+ (st_tm.tm_min * 60) + st_tm.tm_sec;

				// ntpdate -u -t 1 ntp.fudan.edu.cn
				if (gst_nac_ntp_server.self_sync_enable == HUPU_TRUE)
				{
					nac_ntpdate_time_server(gst_nac_ntp_server.ntp_server);
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->every day 00:00 auto sync time_server\n", __FUNCTION__);
				}
			}

			//every g_nac_switch_time_out send snmp_arp_device_info
			if (snmp_send_time_out_count == g_nac_switch_time_out)
			{
				snmp_send_time_out_count = 0;
				//SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_switch_time_out is come!\n",__FUNCTION__);
				nac_system_scan_switch_hlist_for_each_snmp(gi_link_fd);
			}

			//every gst_arp_monitor_config.cycle_time send arp_monitor_device_info
			if (arp_send_time_out_count == (gst_arp_monitor_config.cycle_time*60))
			{
				arp_send_time_out_count = 0;
				if (gst_arp_monitor_config.enable == HUPU_TRUE)
				{
					nac_system_arp_monitor_arp_table_to_server(gi_link_fd);
				}
			}

			if (system_run_status_check_cycle == 3*60)
			{
				system_run_status_check_cycle = 0;
                nac_system_check_sys_run_status(gi_link_fd);
				//check the sys_status
			}

		}
	}

	pthread_detach(pthread_self());
	return NULL;
}

HUPU_INT32 main(HUPU_INT32 argc, HUPU_CHAR *argv[])
{
    HUPU_INT32  iRet;
    fd_set readfd;
    struct timeval	st_timeout;
    HUPU_INT32		i_new_xml_fd = 0;
	HUPU_ULONG32	xml_addr;
	HUPU_UINT16		xml_port;

	pthread_t	connect_pthread = 0;
	pthread_t 	timeout_pthread = 0;
	pthread_t 	arp_monitor_pthread = 0;
    pthread_t   redis_monitor_pthread_id = 0;
	pthread_t   escape_pthread_id = 0;
	SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_system start\n");

	if (argc >= 2)
	{
		if (strcmp(argv[1], "-v") == HUPU_OK
			|| strcmp(argv[1], "-V") == HUPU_OK
			|| strcmp(argv[1], "version") == HUPU_OK)
			{
				printf("nac_system current svn_version: %d\n",
						NAC_APP_DEVELOP_VERSION);

				return -1;
			}

			printf("-v|-V|version\tTo get the nac_system version.\n");
			return -1;
	}

	iRet = nac_system_check_app_repeat_start();
	if (iRet == HUPU_ERR)
	{
		return HUPU_ERR;
	}

	//do library initialization at the beginning of the program
	xmlInitParser();
    signal(SIGPIPE, SIG_IGN);
    signal(SIGCHLD, SIG_IGN);
	signal(SIGTERM, SIG_IGN);
    signal(SIGUSR1, nac_system_catch_siguser1);
    signal(SIGUSR2, nac_system_catch_siguser2);
    signal(SIGRTMIN, nac_system_catch_sigrtmin);


	nac_sys_enable_or_disable_asc(ASC_DISABLE);
    iRet = nac_system_init_all_config();
    if(HUPU_ERR == iRet)
    {
        return HUPU_ERR;
    }

	nac_system_get_license_remain_htime(nac_remain_htime_file);

	nac_app_link_flag = 1; //tcp client connect server success flag.
	iRet = pthread_create(&connect_pthread, NULL,
						nac_system_asc_connect_server_thread, "connect_server");
	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,
					"%s-->can't create control connect server thread: %s\n",
					__FUNCTION__, strerror(iRet));
		return HUPU_ERR;
	}

	iRet = pthread_create(&timeout_pthread, NULL,
						nac_system_main_time_out_thread, "time_out");
	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->can't create time_out thread: %s\n",
					__FUNCTION__, strerror(iRet));
		return HUPU_ERR;
	}

	iRet = pthread_create(&arp_monitor_pthread,	NULL,
						nac_system_arp_monitor_thread_enter, "arp_monitor");
	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->can't create arp_monitor thread: %s\n",
					__FUNCTION__, strerror(iRet));
		return HUPU_ERR;
	}

    iRet = pthread_create(&redis_monitor_pthread_id, NULL,
           nac_sys_monitor_redis_sub_pthread, "redis_subscribe_monitor");

    if (iRet != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "can't create redis_subscribe_monitor thread: %s\n", strerror(iRet));
        return HUPU_ERR;
    }

	iRet = pthread_create(&escape_pthread_id, HUPU_NULL, nac_system_escape_check_thread_enter, "escape_check");
	if (iRet != HUPU_OK)
	{
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"can't create escape_check thread:%s\n", strerror(iRet));
		return HUPU_ERR;
	}

    ui_max_fd = MAX_4(nac_web_fd, gi_netlink_fd, gi_xml_sock_fd, gi_link_fd);
    while (1)
    {
    	st_timeout.tv_sec	= 5;
    	st_timeout.tv_usec	= 0;

		//no matter server or client first close, client socket_fd must nac_tcp_destroy(new_link_fd);

        FD_ZERO(&readfd);

        if(gi_link_fd > 0)
		{
		    FD_SET(gi_link_fd, &readfd);
		}

		if(nac_web_fd > 0)
		{
		    FD_SET(nac_web_fd, &readfd);
		}

		if(gi_xml_sock_fd > 0)
		{
		    FD_SET(gi_xml_sock_fd, &readfd);
		}

        if(gi_netlink_fd > 0)
        {
            FD_SET(gi_netlink_fd, &readfd);
        }

		/*
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
		"%s-->nac_web_fd=%d-->new_link_fd=%d-->gi_netlink_fd=%d-->gi_xml_sock_fd=%d-->gi_link_fd=%d\n",
		__FUNCTION__, nac_web_fd, new_link_fd, gi_netlink_fd, gi_xml_sock_fd, gi_link_fd);
		*/

        iRet = select(ui_max_fd + 1,
                      &readfd,
                      HUPU_NULL,
                      HUPU_NULL,
                      &st_timeout);

        //if (HUPU_ERR == iRet)
        if (iRet < HUPU_OK)
        {
            if(errno == EINTR)
            {
                continue;
            }
            goto HUPU_EXIT_FUNC;
        }

	    if (FD_ISSET(gi_link_fd, &readfd) > 0)
		{
			/*
			recv fault because tcp server point is close, must nac_tcp_destroy(link_fd),
			otherwise cannot automatic  reconnect server.
			*/
            iRet = nac_control_client_handling_from_web_msg(gi_link_fd);
            if(iRet == HUPU_ERR)
            {
            	/*
				if (gi_link_fd)
				{
					nac_tcp_destroy(gi_link_fd);
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SOCKET,
								"%s-->%d-->opposite end close-->nac_tcp_recvfrom error close long connect\n",
								__FUNCTION__, __LINE__);

				}
				*/

				nac_tcp_destroy(gi_link_fd);
                gi_link_fd  = 0;
				new_link_fd = 0;

                ui_max_fd = MAX_4(nac_web_fd, gi_netlink_fd, gi_xml_sock_fd, gi_link_fd);
            }
        }

        if(FD_ISSET(nac_web_fd, &readfd) > 0)
	    {
            i_new_xml_fd = nac_tcp_accept(nac_web_fd, &xml_addr, &xml_port);

            if(i_new_xml_fd < 0)
			{
				nac_tcp_destroy(i_new_xml_fd);
				gi_xml_sock_fd = 0;
				i_new_xml_fd   = 0;
			    continue;
			}

            if(gi_xml_sock_fd <= 0)
			{
                gi_xml_sock_fd = i_new_xml_fd;
			}
			else
			{
			    nac_tcp_destroy(gi_xml_sock_fd);
				gi_xml_sock_fd = i_new_xml_fd;
			}

			st_timeout.tv_sec = 2;
			st_timeout.tv_usec = 0;

			iRet = setsockopt(gi_xml_sock_fd, SOL_SOCKET, SO_RCVTIMEO, &st_timeout, sizeof(struct timeval));
			if(iRet < 0)
			{
			    continue;
			}
            ui_max_fd = MAX_4(nac_web_fd, gi_netlink_fd, gi_xml_sock_fd, gi_link_fd);
        }

	    if(FD_ISSET(gi_xml_sock_fd, &readfd) > 0)
		{
			iRet = nac_control_server_handling_from_web_msg(gi_xml_sock_fd);
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "gi_xml_sock_fd=%d--\n", gi_xml_sock_fd);
            nac_tcp_destroy(gi_xml_sock_fd);
            gi_xml_sock_fd = 0;
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "gi_xml_sock_fd=%d--\n", gi_xml_sock_fd);
            ui_max_fd = MAX_4(nac_web_fd, gi_netlink_fd, gi_xml_sock_fd, gi_link_fd);
		}

		/*netlink_sock_fd is readable*/
        if(FD_ISSET(gi_netlink_fd, &readfd) > 0)
        {
            nac_system_handling_from_kernel_msg(gi_netlink_fd, gi_link_fd);
        }
    }

	//do library cleanup when the program ends up
	xmlCleanupParser();
    return iRet;

HUPU_EXIT_FUNC:
	//do library cleanup when the program ends up
	xmlCleanupParser();
    return HUPU_ERR;
}

