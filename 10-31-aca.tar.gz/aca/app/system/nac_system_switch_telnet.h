#ifndef NAC_SYSTEM_SWITCH_TELNET_H
#define NAC_SYSTEM_SWITCH_TELNET_H

xmlDocPtr nac_system_test_switch_telnet_control(NAC_SYSTEM_SWITCH* pst_switch);
HUPU_INT32 nac_system_add_switch_telnet_control(NAC_SYSTEM_SWITCH* pst_switch);
HUPU_INT32 nac_system_modify_switch_telnet_control(NAC_SYSTEM_SWITCH* pst_switch);

HUPU_INT32 nac_system_switch_send(HUPU_UINT32 ui_fd, HUPU_CHAR *pc_buffer_cmd);
HUPU_INT32 nac_system_switch_recv(HUPU_UINT16 switch_id, HUPU_UINT32 ui_fd, 
										HUPU_CHAR *pc_buffer, HUPU_UINT32 ui_len);
HUPU_VOID nac_system_switch_tcp_connect_thread_enter(HUPU_CHAR *pc_buf);
HUPU_VOID test_switch();


/*
HUPU_INT32 nac_system_scan_switch_hlist_for_each_telnet(HUPU_UINT32 ui_sock_fd);//for nac_system_main.c
HUPU_VOID nac_system_switch_telnet_connect_thread_enter(HUPU_CHAR *pc_buf);
*/

#endif // end of NAC_SYSTEM_SWITCH_TELNET_H



