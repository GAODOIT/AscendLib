#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_set_remote_server.h"
#include "nac_system_deal_sysconfig.h" //nac_app_flush_all_system_config
#include "nac_system_deal_license.h"

HUPU_UINT32 g_ui_license_total_htime	= 0;
HUPU_UINT32 g_ui_license_remain_htime	= 0;
HUPU_CHAR  *nac_remain_htime_file   = "/nac/config/remain_htime";

//product_type: controller=0;server=1;server+controller=2
HUPU_UINT8  g_nac_device_type;

//2015-01-08-need optimize;read /nac/config/license---ok:success; error:error
HUPU_INT32 nac_system_check_license_file(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet;
    FILE *nac_fp = HUPU_NULL;
    HUPU_CHAR buffer[BUFF_LEN] = "";
    HUPU_INT16 error_flag = 0;
    HUPU_CHAR* get_content = HUPU_NULL;

    gi_link_server_ip = 0;
	memset(gi_link_company_code, '\0', strlen(gi_link_company_code));

	if ((nac_fp = fopen(filename, "r")) == HUPU_NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error-->maybe no license file\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while ((fgets(buffer, BUFF_LEN, nac_fp)) != HUPU_NULL)
    {
		if (strstr(buffer, "error") != HUPU_NULL)
        {
            error_flag = -2;
            break;
        }
        else if ((get_content = strstr(buffer, "type=")) != HUPU_NULL)
        {
            get_content = get_content + 5;
            clean_newline_character(get_content);
            g_nac_device_type = atoi(get_content);

			//control:0;	server:1; control+sever:2;
			if (!(g_nac_device_type == 0 || g_nac_device_type == 1
				|| g_nac_device_type == 2))
			{
				error_flag = -2;
				break;
			}
        }
        else if ((get_content = strstr(buffer, "serverIp=")) != HUPU_NULL)
        {
            get_content = get_content + 9;
            clean_newline_character(get_content);
            iRet = nac_preg_match_ip(get_content);
            if (iRet == HUPU_OK)
            {
                gi_link_server_ip = inet_network(get_content);
            }
			else
			{
				gi_link_server_ip = 0;
			}

        }
		else if ((get_content = strstr(buffer, "companyId=")) != HUPU_NULL)
		{
			get_content = get_content + 10;
			clean_newline_character(get_content);
			memset(gi_link_company_code, '\0', strlen(gi_link_company_code));
			memcpy(gi_link_company_code, get_content, strlen(get_content));
		}

        memset(buffer, '\0', BUFF_LEN);
    }
    fclose(nac_fp);

    if (error_flag == -2)
    {
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->Device_Type=%d-->Device license is not ok error!\n",
					__FUNCTION__, g_nac_device_type);

        return HUPU_ERR;
    }

	return HUPU_OK;
}

//ass= server; asc = control;
HUPU_INT32 nac_system_check_device_type(HUPU_UINT32 eth_ip_tmp)
{
	HUPU_INT32 iRet;

	if (g_nac_device_type == 0)//only asc
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
					"%s--license ok-->Control Mode-->companyId=%s-->serverIp=%u.%u.%u.%u end.\n",
					__FUNCTION__, gi_link_company_code, LIPQUAD(gi_link_server_ip));
		if (127 == ((unsigned char *)&gi_link_server_ip)[3]
			|| gi_link_server_ip == eth_ip_tmp)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->asc cannot connect itself sever error!\n",
						__FUNCTION__);
			return HUPU_ERR;
		}

	}
	else if (g_nac_device_type == 1)//only ass can't create long link;
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
					"%s--license ok-->Server Mode-->companyId=%s-->serverIp=%u.%u.%u.%u end.\n",
					__FUNCTION__, gi_link_company_code, LIPQUAD(gi_link_server_ip));

        app_nacmode = NAC_NULL_MODE;
        iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_MODE, app_nacmode, NULL, 0);
        if (iRet != HUPU_OK)
        {
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
						"%s-->nac_set_data_to_knl-->NAC_CMD_SYS_SET_MODE error, iRet = %d\n",
						__FUNCTION__, iRet);
			return HUPU_ERR;
        }

		nac_app_flush_all_system_config();

		return HUPU_ERR;
	}
	else if (g_nac_device_type == 2)//ass+asc
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
					"%s--license ok-->Control+Server Mode-->companyId=%s-->serverIp=%u.%u.%u.%u end.\n",
					__FUNCTION__, gi_link_company_code, LIPQUAD(gi_link_server_ip));
	}
	else
	{
		return HUPU_ERR;
	}


	if (gi_link_server_ip && strlen(gi_link_company_code))
	{
		return HUPU_OK;
	}

	return HUPU_ERR;
}

HUPU_INT32 nac_system_update_license_remain_htime(const HUPU_CHAR* filename)
{
	HUPU_CHAR  exec_cmd[BUFF_LEN];

	memset(exec_cmd, '\0', sizeof(exec_cmd));
	sprintf(exec_cmd, "echo %d > %s", g_ui_license_total_htime, filename);
	nac_exec_system(exec_cmd);

	memset(exec_cmd, '\0', sizeof(exec_cmd));
	sprintf(exec_cmd, "echo %d >> %s", g_ui_license_remain_htime, filename);
	nac_exec_system(exec_cmd);

	return HUPU_OK;
}

HUPU_INT32 nac_system_get_license_remain_htime(const HUPU_CHAR* filename)
{
	FILE *nac_fp = HUPU_NULL;
	HUPU_CHAR szLine[BUFF_LEN] = "";
	HUPU_UINT16 Line_sum;

	/*
	HUPU_CHAR* pst_cnt_data;
	HUPU_INT32 iRet;
	*/

	if ((nac_fp = fopen(filename, "r")) == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->open %s error!\n", __FUNCTION__, filename);
        return HUPU_ERR;
	}

	Line_sum = 0;
	while (fgets(szLine, BUFF_LEN, nac_fp) != HUPU_NULL)
	{
		Line_sum = Line_sum + 1;
		clean_newline_character(szLine);
		if (Line_sum == 1)
		{
			g_ui_license_total_htime  = atoi(szLine);
		}
		else if (Line_sum == 2)
		{
			g_ui_license_remain_htime  = atoi(szLine);
		}
		else
		{
			break;
		}
		memset(szLine, '\0', BUFF_LEN);
	}
	fclose(nac_fp);

	return HUPU_OK;
}

static xmlDocPtr nac_sys_get_license_info(HUPU_VOID)
{
	HUPU_UINT32 iRet = 0;
	xmlDocPtr   doc = HUPU_NULL;
    xmlNodePtr root_node;
	HUPU_UINT16 command_id = SYS_WEBUI_DEAL_LICENSE_INFO;
	HUPU_CHAR cmd_buffer[10] = "";
	HUPU_CHAR xml_cnt_buffer[SEND_BUFFER_LEN] = "";

	HUPU_CHAR* nac_license_file = "/nac/config/web_license/license_plain";
	HUPU_CHAR* nac_version_file = "/nac/config/nac.version";

	FILE *nac_license_fp, *nac_version_fp;
	HUPU_CHAR szLine[BUFF_LEN] = "";
	HUPU_CHAR* pst_content;

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    sprintf(cmd_buffer, "%d", (command_id + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_buffer);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");

	memset(xml_cnt_buffer, '\0', SEND_BUFFER_LEN);
	sprintf(xml_cnt_buffer, "%d;%d", g_ui_license_total_htime, g_ui_license_remain_htime);
	xmlNewChild(root_node, HUPU_NULL, BAD_CAST "authorizeTime", BAD_CAST xml_cnt_buffer);

	memset(xml_cnt_buffer, '\0', SEND_BUFFER_LEN);
	//read /nac/config/nac.version
	if ((nac_version_fp = fopen(nac_version_file, "r")) == HUPU_NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n",
					__FUNCTION__, nac_version_file);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "deviceLicense", BAD_CAST xml_cnt_buffer);
		return doc;
    }

	while((fgets(szLine, BUFF_LEN, nac_version_fp)) != HUPU_NULL)
	{
		iRet = iRet + 1;
		clean_newline_character(szLine);
		strcat(xml_cnt_buffer, szLine);
		strcat(xml_cnt_buffer, ";");
		memset(szLine, '\0', sizeof(szLine));
		if (iRet == 2)
		{
			break;
		}
	}
	fclose(nac_version_fp);

	//read /nac/config/web_license/license_plain
	if ((nac_license_fp = fopen(nac_license_file, "r")) == HUPU_NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n",
						__FUNCTION__, nac_license_file);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "deviceLicense", BAD_CAST xml_cnt_buffer);
		return doc;
    }

	memset(szLine, '\0', BUFF_LEN);
	while((fgets(szLine, BUFF_LEN, nac_license_fp)) != HUPU_NULL)
    {
		clean_newline_character(szLine);
        if ((pst_content = strstr(szLine, "deviceType=")) != HUPU_NULL)
		{
			strcat(xml_cnt_buffer, pst_content+strlen("deviceType="));
			strcat(xml_cnt_buffer, ";");
			pst_content = HUPU_NULL;
		}
		else if ((pst_content = strstr(szLine, "modules=")) != HUPU_NULL)
		{
			strcat(xml_cnt_buffer, pst_content+strlen("modules="));
			strcat(xml_cnt_buffer, ";");
			pst_content = HUPU_NULL;
		}
		else if ((pst_content = strstr(szLine, "maxDeviceCount=")) != HUPU_NULL)
		{
			strcat(xml_cnt_buffer, pst_content+strlen("maxDeviceCount="));
			strcat(xml_cnt_buffer, ";");
			pst_content = HUPU_NULL;
		}
		else if ((pst_content = strstr(szLine, "startTime=")) != HUPU_NULL)
		{
			strcat(xml_cnt_buffer, pst_content+strlen("startTime="));
			strcat(xml_cnt_buffer, ";");
			pst_content = HUPU_NULL;
		}
		else if ((pst_content = strstr(szLine, "endTime=")) != HUPU_NULL)
		{
			strcat(xml_cnt_buffer, pst_content+strlen("endTime="));
			strcat(xml_cnt_buffer, ";");
			pst_content = HUPU_NULL;
		}
		else if ((pst_content = strstr(szLine, "mac=")) != HUPU_NULL)
		{
			strcat(xml_cnt_buffer, pst_content+strlen("mac="));
			strcat(xml_cnt_buffer, ";");
			pst_content = HUPU_NULL;
		}
		else if ((pst_content = strstr(szLine, "productCode=")) != HUPU_NULL)
		{
			strcat(xml_cnt_buffer, pst_content+strlen("productCode="));
			strcat(xml_cnt_buffer, ";");
			pst_content = HUPU_NULL;
		}
		else if((pst_content = strstr(szLine, "cpuId=")) != HUPU_NULL)
		{
			strcat(xml_cnt_buffer, pst_content+strlen("cpuId="));
			strcat(xml_cnt_buffer, ";");
			pst_content = HUPU_NULL;
		}
		else
		{
			pst_content = HUPU_NULL;
		}
        memset(szLine, '\0', BUFF_LEN);
    }

	fclose(nac_license_fp);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "deviceLicense", BAD_CAST xml_cnt_buffer);
	return doc;
}

xmlDocPtr nac_sys_parse_deal_license_info(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_INT32 error_id;
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
	xmlChar		*szKey;
	HUPU_UINT8 action_type, match_tag_flag;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
	match_tag_flag = HUPU_FALSE;
    switch (action_type)
    {
	case NAC_SHOW:
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_get_license_info();
		break;

	case NAC_ADD:
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "authorizeTime")))
			{
				szKey = xmlNodeGetContent(cur_node);
				g_ui_license_total_htime = atoi((HUPU_CHAR*)szKey);
				g_ui_license_remain_htime = g_ui_license_total_htime;
				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s--hello1-->%d;%d\n", __FUNCTION__,
							g_ui_license_total_htime, g_ui_license_remain_htime);
				match_tag_flag = HUPU_TRUE;
				xmlFree(szKey);
				break;
			}
			cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);

		if (match_tag_flag == HUPU_FALSE)
		{
			error_id = NAC_SYS_ERROR_SET_LICENSE_USABLE_TIME_ERROR;
		}

		nac_system_update_license_remain_htime(nac_remain_htime_file);
		//SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s--hello3--nac_sys_update_license_remain_htime\n", __FUNCTION__);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

	default:
		nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

///////////////////////////////////////////////////////////////
HUPU_INT32 nac_system_set_tcp_connect_timeout(HUPU_UINT32 ui_sockfd, HUPU_UINT32 time_out)
{
	/*
	Ascend gaodong_dowell testing ping remote_ip and telnet port(6002) is ok!
	or set connect timeout,like below:
	In unix: SO_RCVTIMEO and SO_SNDTIMEO are only use for socket read(recv)
			and write(send) time_out;
	But in Linux kernel, socket accept and connect time_out also can use by
		SO_RCVTIMEO and SO_SNDTIMEO.
	*/
	HUPU_INT32 iRet;
 	struct timeval  st_connect_timeout;
	st_connect_timeout.tv_sec = time_out;
	st_connect_timeout.tv_usec = 0;

	iRet = setsockopt(ui_sockfd, SOL_SOCKET, SO_SNDTIMEO, &st_connect_timeout, sizeof(struct timeval));
	if (iRet < 0)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s--iRet=%d-->errno=%d, error info=%s-->Fail to set connect SO_SNDTIMEO.\n",
					__FUNCTION__, iRet, errno, strerror(errno));
		//perror("fail to set connect SO_SNDTIMEO");
		return HUPU_ERR;
	}

	return HUPU_OK;
}

HUPU_INT32 nac_system_set_tcp_connect_keepalive(HUPU_UINT32 ui_sockfd)
{
	HUPU_INT32 keepalive = 1;
	HUPU_INT32 keepidle  = 10;
	HUPU_INT32 keepintvl = 5;
	HUPU_INT32 keepcnt   = 3;

	if (setsockopt(ui_sockfd, SOL_SOCKET, SO_KEEPALIVE,
				(void *)&keepalive, sizeof(keepalive)) < 0)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->Fail to set SO_KEEPALIVE",
					__FUNCTION__);
		//perror("fail to set SO_KEEPALIVE");
		return HUPU_ERR;
	}

	if (setsockopt(ui_sockfd, SOL_TCP, TCP_KEEPIDLE,
				(void *)&keepidle, sizeof(keepidle)) < 0)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->Fail to set SO_KEEPIDLE",
					__FUNCTION__);
		//perror("fail to set SO_KEEPIDLE");
		return HUPU_ERR;
	}

	if (setsockopt(ui_sockfd, SOL_TCP, TCP_KEEPINTVL,
					(void *)&keepintvl, sizeof(keepintvl)) < 0)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->Fail to set SO_KEEPINTVL",
					__FUNCTION__);
		//perror("fail to set SO_KEEPINTVL");
		return HUPU_ERR;
	}

	if (setsockopt(ui_sockfd, SOL_TCP, TCP_KEEPCNT,
					(void *)&keepcnt, sizeof(keepcnt)) < 0)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->Fail to set SO_KEEPCNT",
					__FUNCTION__);
		//perror("fail to set SO_KEEPCNT");
		return HUPU_ERR;
	}

	return HUPU_OK;
}



