#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_save_sysconfig.h"      //call nac_sys_save_vlanmap();
#include "nac_system_redirect_manager_ip.h" //call gst_redirect_manager_ip;
#include "nac_system_set_remote_server.h"
#include "nac_system_netapp_check.h"
#include "nac_system_arp_monitor.h"
#include "nac_system_time.h"
#include "nac_system_net.h"
#include "nac_system_deal_license.h"
#include "nac_system_debug_switch.h"
#include "nac_system_debug_sysconfig.h"
#include "nac_system_escape_deal.h"
#include "nac_system_nat_manage.h"
#include "nac_system_netapp_user.h"
#include "nac_system_ha_backup.h"

extern HUPU_UINT16	g_debug_switch;
extern HUPU_UINT8	g_nac_device_type;
extern HUPU_CHAR	long_tcp_connect_success_timestamp[];

HUPU_INT32 nac_app_save_device_info_hlist_for_show(const HUPU_CHAR* config_file)
{
	FILE* nac_fp;
	HUPU_UINT32 hash, count;
    struct nac_hlist_node *pos, *n;
    NAC_SYS_DEVICE_INFO_ST *u = HUPU_NULL;

    if ((nac_fp = fopen(config_file, "a+")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->save open %s error\n", __FUNCTION__, config_file);
        return HUPU_ERR;
    }

	count = 0;
	fputs("device_info_list----------------------\n", nac_fp);
	nac_system_device_info_lock();
    for(hash = 0; hash < NAC_DEVICE_MAC_HASH_SIZE; hash++)
    {
        nac_hlist_for_each_entry_safe(u, pos, n, &nac_device_hlist_by_mac[hash], mac_node)
        {
			fprintf(nac_fp, "%u.%u.%u.%u	%02X-%02X-%02X-%02X-%02X-%02X	%d	%d	%ld\n",
					LIPQUAD(u->ip), MAC_FORMAT(u->mac), u->vlan_tag, u->send_status, u->last_time);

			count = count + 1;
        }
    }
    nac_system_device_info_unlock();
	fprintf(nac_fp, "end-----------------------------sum=%d\n", count);

	fclose(nac_fp);
	return HUPU_OK;
}

HUPU_INT32 nac_app_debug_netapp_hlist(FILE* fp)
{
 	HUPU_INT16 hash;
	HUPU_INT16 i;
	HUPU_UINT16 count = 0;
	struct nac_hlist_node *pos, *n;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;
	HUPU_CHAR xml_buffer[128] = "";
	HUPU_CHAR ip_str[16] = "";
	for(hash = 0; hash < NETAPP_HASH_MAP_SIZE; hash++)
	{
		nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
    	{
    		count ++;
    		fprintf(fp, "netapp--------id=%d\n", pst_netapp_tmp->id);
			//check_config list
			fputs("--exceptconfig-----------\n", fp);
    		fprintf(fp, "name= %s\n", pst_netapp_tmp->netapp_st.name);
			fprintf(fp, "cycle= %d\n", pst_netapp_tmp->netapp_st.cycle);

			memset(ip_str, '\0', sizeof(ip_str));
			switch(pst_netapp_tmp->netapp_st.cycle_unit)
			{
			case CYCLE_UINT_SECOND:
				strcpy(ip_str, "sec");
				break;
			case CYCLE_UINT_MINUTE:
				strcpy(ip_str, "min");
				break;
			case CYCLE_UINT_HOUR:
				strcpy(ip_str, "hour");
				break;
			}

			fprintf(fp, "uint= %s\n", ip_str);
			fprintf(fp, "times= %d\n", pst_netapp_tmp->netapp_st.times);

			memset(ip_str, '\0', sizeof(ip_str));
			switch(pst_netapp_tmp->netapp_st.protocol)
			{
			case IPPROTO_TCP_UDP:
				strcpy(ip_str, "any");
				break;
			case IPPROTO_TCP:
				strcpy(ip_str, "tcp");
				break;
			case IPPROTO_UDP:
				strcpy(ip_str, "udp");
				break;
			}
			fprintf(fp, "protocol= %s\n", ip_str);
			fprintf(fp, "port= %d\n", pst_netapp_tmp->netapp_st.port);

			fprintf(fp, "enable= %s\n",
				(pst_netapp_tmp->enable == HUPU_ENABLE)?("enable"):("disable"));

			memset(xml_buffer, '\0', sizeof(xml_buffer));
			for(i = 0; i < 5; i++)
			{
				if(pst_netapp_tmp->netapp_st.server_group[i] > 0)
				{
					memset(ip_str, '\0', sizeof(ip_str));
					if (i)
					{
						strcat(xml_buffer,";");
					}
					sprintf(ip_str, "%u.%u.%u.%u",
						LIPQUAD(pst_netapp_tmp->netapp_st.server_group[i]));
					strcat(xml_buffer, ip_str);
				}

			}
			fprintf(fp, "serverGroup= %s\n", xml_buffer);
			fprintf(fp, "fixPath= %s\n", pst_netapp_tmp->netapp_st.fix_path);
			fputs("--exceptconfig--------end\n", fp);

			//except_device list
			fprintf(fp, "--exceptDevice--------sum=%d\n", pst_netapp_tmp->sum);
			for (i = 0; i < pst_netapp_tmp->sum; i++)
			{
                fprintf(fp, "iprange= %s-%s\n", pst_netapp_tmp->except_list[i].min, pst_netapp_tmp->except_list[i].max);
			}
			fputs("--exceptDevice--------end\n",fp);

		}
	}
	return count;
}

HUPU_INT32 nac_app_debug_save_sys_config(const HUPU_CHAR* config_file)
{
	HUPU_INT32 iRet = 0;
	FILE *nac_fp, *nac_version_fp;
    HUPU_CHAR  current_time_str[50];
	HUPU_CHAR* nac_version_file = "/nac/config/nac.version";
	HUPU_CHAR szLine[BUFF_LEN] = "";
	HUPU_CHAR nac_version_content[128] = "";
	//HUPU_UINT32 ui_pid = getpid();


	if ((nac_version_fp = fopen(nac_version_file, "r")) == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->save open %s error\n",
					__FUNCTION__, nac_version_file);
        return HUPU_ERR;
	}

	while((fgets(szLine, BUFF_LEN, nac_version_fp)) != HUPU_NULL)
    {
        iRet = iRet + 1;
        clean_newline_character(szLine);
        strcat(nac_version_content, szLine);
        strcat(nac_version_content, ";");
        memset(szLine, '\0', sizeof(szLine));
        if (iRet == 2)
        {
			break;
        }
    }
    fclose(nac_version_fp);
	if(strlen(nac_version_content) == 0)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->get nac_version error\n",
					__FUNCTION__);
        return HUPU_ERR;
	}


    if ((nac_fp = fopen(config_file, "w+")) == HUPU_NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->save open %s error\n", __FUNCTION__, config_file);
        return HUPU_ERR;
    }

	memset(current_time_str, '\0', strlen(current_time_str));
	get_current_time(current_time_str);
	fprintf(nac_fp, "current time:%s\n", current_time_str);
	fprintf(nac_fp, "nac_version = %s\n", nac_version_content);

	fputs("network config start-----------------\n", nac_fp);
	nac_sys_save_ifconfig_status(nac_fp);
	fprintf(nac_fp, "gateway = %s\n", g_default_gateway);
	fprintf(nac_fp, "dns1 = %s\n", gst_dns_server.nameserver1);
    fprintf(nac_fp, "dns2 = %s\n", gst_dns_server.nameserver2);
	fprintf(nac_fp, "asc_manager_eth = %s\n", g_manager_eth_name);
	fprintf(nac_fp, "asc_manager_mac = %02hhX-%02hhX-%02hhX-%02hhX-%02hhX-%02hhX\n", MAC_FORMAT(g_manager_mac_addr));
	fputs("end----------------------------------\n", nac_fp);

	if (app_nacmode == NAC_MVG_MODE)
    {
        fputs("nac_mode = mvg\n", nac_fp);
    }
    else if (app_nacmode == NAC_PBR_MODE)
    {
        fputs("nacmode = pbr\n", nac_fp);
		if (nac_pbr_onein_oneout_flag == HUPU_TRUE)
		{
			fputs("pbr_one_in_one_out_flag = open\n", nac_fp);
			fprintf(nac_fp, "nexthop_sw_ip=%u.%u.%u.%u\n", LIPQUAD(pbr_advance_setup.nexthop_ip));
			fprintf(nac_fp, "nexthop_sw_mac=%02hhX-%02hhX-%02hhX-%02hhX-%02hhX-%02hhX\n",
					MAC_FORMAT(pbr_advance_setup.nexthop_mac));
		}
		else
		{
			fputs("pbr_one_in_one_out_flag = close\n", nac_fp);
		}

    }
    else if (app_nacmode == NAC_BRIDGE_MODE)
    {
        fputs("nacmode = bridge\n", nac_fp);
    }
	else if (app_nacmode == NAC_NULL_MODE)
    {
        fputs("nacmode = NULL\n", nac_fp);
    }
    fprintf(nac_fp, "redirect_flag = %s\n", ((gst_redirect_manager_ip.en_redirect_flag == 1)?("redirect"):("drop")));
	fprintf(nac_fp, "redirect_ip   = %s\n", gst_redirect_manager_ip.ac_redirect_ip);
	fprintf(nac_fp, "control_manager_ip = %s\n", gst_redirect_manager_ip.ac_control_manager_ip);
	fprintf(nac_fp, "server_manager_ip = %s\n", gst_redirect_manager_ip.ac_server_manager_ip);
	fprintf(nac_fp, "in-->out = %s-->%s\n", gst_in_out_eth.ac_in_eth, gst_in_out_eth.ac_out_eth);

	fputs("vlanmap start------------------------\n", nac_fp);
	if (app_nacmode == NAC_MVG_MODE)
	{
		nac_sys_save_vlanmap(nac_fp);
	}
	fputs("end----------------------------------\n", nac_fp);

	fputs("netapp config start------------------\n", nac_fp);
	iRet = nac_app_debug_netapp_hlist(nac_fp);
	fprintf(nac_fp, "end-----------------------------sum=%d\n", iRet);

	fputs("nat start----------------------------\n", nac_fp);
	HUPU_CHAR little_buffer[MIN_BUFF_LEN];
    fprintf(nac_fp, "nat_switch = %s\n", (g_nat_config_st.enable == 1)?("enable"):("disable"));
	fprintf(nac_fp, "auto_found = %s\n", (g_nat_config_st.auto_found == 1)?("on"):("off"));
    memset(little_buffer, '\0', sizeof(little_buffer));
    switch(g_nat_config_st.default_action)
    {
    case NAT_IGNORE:
        strcpy(little_buffer, "ignore(0)");
        break;
    case NAT_ALLOW:
        strcpy(little_buffer, "allow(1)");
        break;
    case NAT_FORBID:
        strcpy(little_buffer, "forbid(2)");
        break;
    default:
        break;
    }
	fprintf(nac_fp, "auto_action= %s\n", little_buffer);
	fputs("nac_manage list----------------------\n", nac_fp);
    nac_app_debug_show_nat_manage_list(nac_fp);
	fputs("end----------------------------------\n", nac_fp);

	fputs("safe_ipzone start--------------------\n", nac_fp);
    nac_system_show_iprange_policy_hlist(nac_fp, NAC_APP_SAFE_IPZONE);
	fputs("end----------------------------------\n", nac_fp);

	fputs("isolate_ipzone start-----------------\n", nac_fp);
    nac_system_show_iprange_policy_hlist(nac_fp, NAC_APP_ISOLATE_IPZONE);
    fputs("end----------------------------------\n", nac_fp);

	fputs("isolate_domain start-----------------\n", nac_fp);
	nac_system_show_domain_policy_hlist(nac_fp, NAC_APP_ISOLATE_DOMAIN);
	fputs("end----------------------------------\n", nac_fp);

	fputs("except terminal start----------------\n", nac_fp);
    nac_system_show_iprange_policy_hlist(nac_fp, NAC_APP_EXCEPT_TERMINAL);
	fputs("end----------------------------------\n", nac_fp);

	fputs("except server start------------------\n", nac_fp);
    nac_system_show_iprange_policy_hlist(nac_fp, NAC_APP_EXCEPT_SERVER);
	fputs("end----------------------------------\n", nac_fp);

	fputs("except domain start------------------\n", nac_fp);
	nac_system_show_domain_policy_hlist(nac_fp, NAC_APP_EXCEPT_DOMAIN);
	fputs("end----------------------------------\n", nac_fp);

	fputs("arp monitor start--------------------\n", nac_fp);
	fprintf(nac_fp, "arp_monitor  = %s\n",
			(gst_arp_monitor_config.enable == HUPU_TRUE)?("open"):("close"));
	fprintf(nac_fp, "cycle_time   = %d\n",	gst_arp_monitor_config.cycle_time);
	fprintf(nac_fp, "monitor_port = %s\n",	gst_arp_monitor_config.monitor_port);
	fprintf(nac_fp, "port_attr    = %s\n",	gst_arp_monitor_config.port_attr);
	fputs("end----------------------------------\n", nac_fp);

	fputs("time_server sync start---------------\n", nac_fp);
	fprintf(nac_fp, "self_sync = %s\n",
			(gst_nac_ntp_server.self_sync_enable == HUPU_TRUE)?("open"):("close"));
	fprintf(nac_fp, "ntp_server = %s\n",	gst_nac_ntp_server.ntp_server);
	fputs("end----------------------------------\n", nac_fp);

	fputs("license authorize_time(h)------------\n", nac_fp);
	fprintf(nac_fp, "authorize_time = %d\n", g_ui_license_total_htime);
	fprintf(nac_fp, "remain_time    = %d\n", g_ui_license_remain_htime);
	fputs("end----------------------------------\n", nac_fp);

	fputs("asc_enable_flag(enable/disable)------\n", nac_fp);
	nac_sys_get_knl_pass_switch(&g_nac_asc_enable_flag);
	fprintf(nac_fp, "asc_enable_flag = %s\n",
			(g_nac_asc_enable_flag == 1)?("enable"):("disable"));
	fprintf(nac_fp, "knl_forward_switch = %s\n",
			(g_nac_asc_enable_flag == 1)?("close"):("open"));
	fputs("end----------------------------------\n", nac_fp);

	fputs("escape_enable_flag(enable/disable)-\n", nac_fp);
	fprintf(nac_fp, "escape_enable_flag = %s\n",
			(g_asc_escape_enable_flag == 1)?("enable"):("disable"));
	fprintf(nac_fp, "asc_running_mode   = %s\n",
			(g_asc_running_mode == 1)?("normal"):("escape"));
    fprintf(nac_fp, "max_untrust_flow_speed = %s kiB/s\n", g_untrust_max_flow_speed);
	fprintf(nac_fp, "manager=%s\tlink=%d\tmust=%d\n",
			manager_eth_event.name,
			manager_eth_event.link,
			manager_eth_event.must);
	fprintf(nac_fp, "untrust=%s\tlink=%d\tmust=%d\n",
			untrust_eth_event.name,
			untrust_eth_event.link,
			untrust_eth_event.must);
	fprintf(nac_fp, "trust  =%s\tlink=%d\tmust=%d\n",
			trust_eth_event.name,
			trust_eth_event.link,
			trust_eth_event.must);

	fputs("end----------------------------------\n", nac_fp);
	fputs("advanced debug swith(enable/diable)--\n", nac_fp);
	fprintf(nac_fp, "advanced_debug_switch = %s\n",
			(nac_app_advanced_debug_switch == 1)?("enable"):("disable"));
	fprintf(nac_fp, "nac_debug_switch      = %s\n",
			(g_debug_switch == 1)?("enable"):("disable"));
	fputs("end----------------------------------\n", nac_fp);

	fputs("warn_config list---------------------\n", nac_fp);
	fprintf(nac_fp, "cpu_warn_rate = %0.2f\n",
			gst_nac_warn_value.cpu/100.0);

	fprintf(nac_fp, "mem_warn_rate = %0.2f\n",
			gst_nac_warn_value.mem/100.0);

	fprintf(nac_fp, "disk_warn_rate = %0.2f\n",
			gst_nac_warn_value.disk/100.0);

	fprintf(nac_fp, "cpu_warn = %s\n",
		   (gst_nac_warn_config_status.cpu == 1)?("enable"):("disable"));

	fprintf(nac_fp, "mem_warn = %s\n",
		   (gst_nac_warn_config_status.mem == 1)?("enable"):("disable"));

	fprintf(nac_fp, "disk_warn = %s\n",
		   (gst_nac_warn_config_status.disk == 1)?("enable"):("disable"));

	fprintf(nac_fp, "reboot_warn = %s\n",
		   (gst_nac_warn_config_status.reboot == 1)?("enable"):("disable"));

	fprintf(nac_fp, "shutdown_warn = %s\n",
		   (gst_nac_warn_config_status.shutdown == 1)?("enable"):("disable"));

	fprintf(nac_fp, "factory_warn = %s\n",
		   (gst_nac_warn_config_status.factory == 1)?("enable"):("disable"));
	fputs("end----------------------------------\n", nac_fp);
    nac_app_debug_ha_backup_config(&gst_ha_backup_config, nac_fp);

    //nac_system_debug_netapp_user(nac_fp);

	fprintf(nac_fp, "long_connect_ok_timestamp=%s\n",
			long_tcp_connect_success_timestamp);
	//line == 11
	fputs("control link_status start------------\n", nac_fp);
	fprintf(nac_fp, "nac_version = %s\n", nac_version_content);
	fprintf(nac_fp, "nac_system_pid = %d\n", getpid());
	if (g_nac_device_type == 0)
	{
		fputs("nac_type = control\n", nac_fp);
	}
	else if (g_nac_device_type == 1)
	{
		fputs("nac_type = server\n", nac_fp);
	}
	else if (g_nac_device_type == 2)
	{
		fputs("nac_type = control+server\n", nac_fp);
	}

	fprintf(nac_fp, "current_link_status = %s(%d)\n",
			(gi_link_fd > 0)?("ok"): ("error"), gi_link_fd);

	fprintf(nac_fp, "nac_debug_switch = %s(%d)\n",
			(g_debug_switch == 1)?("enable"):("disable"), g_debug_switch);

	fprintf(nac_fp, "link_server_ip = %u.%u.%u.%u\n", LIPQUAD(gi_link_server_ip));
	fprintf(nac_fp, "link_company_id = %s\n",gi_link_company_code);
	fprintf(nac_fp, "last_link_server_ip = %u.%u.%u.%u\n", LIPQUAD(last_link_remote_ip));
	fprintf(nac_fp, "last_link_company_id = %s\n",last_link_company_code);
	fputs("end----------------------------------\n", nac_fp);

	fclose(nac_fp);
	return HUPU_OK;
}
