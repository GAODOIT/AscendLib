#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_app_knl_port.h"


//NAC_KNL_RBTREE_ISOLATION_ZONE, NAC_CMD_RBTREE_INS
/*operate knl isolate_zone rbtree: input min_addr and max_addr is int_host_byte*/
HUPU_INT32 nac_app_set_isolate_iprange_to_knl_rbtree(NAC_KNL_RBTREE_TYPE rbtree_type, HUPU_UINT16 rbtree_opt_type,
                                                    HUPU_UINT32 min_addr, HUPU_UINT32 max_addr, HUPU_UINT16 zone_id)
{
    HUPU_INT32 iRet;
    struct nac_knl_rbtree_entry nac_ety;
    memset(&nac_ety, 0, sizeof(struct nac_knl_rbtree_entry));

    SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->%02x->%02x\n", __FUNCTION__, min_addr, max_addr);
    nac_ety.type = rbtree_type;
    nac_ety.union_rbtree.ip.ip_min = min_addr;
    nac_ety.union_rbtree.ip.ip_max = max_addr;
    nac_ety.union_rbtree.ip.isolation_id = zone_id;

    iRet = nac_set_data_to_knl(rbtree_opt_type, 0, &nac_ety, sizeof(struct nac_knl_rbtree_entry));
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->nac_knl_rbtree_entry-->error:iRet=%d\n", __FUNCTION__, iRet);
        return HUPU_ERR;
    }

    return HUPU_OK;
}

/*operate knl rbtree: input min_addr and max_addr is int_host_byte*/
HUPU_INT32 nac_sys_set_iprange_to_knl_rbtree(HUPU_UINT32 min_addr, HUPU_UINT32 max_addr, NAC_KNL_RBTREE_TYPE rbtree_type,
                                            HUPU_UINT16 rbtree_opt_type)
{
    HUPU_INT32 iRet;
    struct nac_knl_rbtree_entry nac_ety;
    memset(&nac_ety, 0, sizeof(struct nac_knl_rbtree_entry));

    SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->%02x->%02x\n", __FUNCTION__, min_addr, max_addr);
    nac_ety.type = rbtree_type;
    nac_ety.union_rbtree.ip.ip_min = min_addr;
    nac_ety.union_rbtree.ip.ip_max = max_addr;

    iRet = nac_set_data_to_knl(rbtree_opt_type, 0, &nac_ety, sizeof(struct nac_knl_rbtree_entry));
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->nac_knl_rbtree_entry-->error:iRet=%d\n", __FUNCTION__, iRet);
        return HUPU_ERR;
    }

    return HUPU_OK;
}

/*operate knl rbtree: input min and max is string*/
HUPU_INT32 nac_sys_set_iprange_str_to_knl_rbtree(NAC_KNL_RBTREE_TYPE rbtree_type, HUPU_UINT16 rbtree_opt_type, HUPU_VOID *min, HUPU_VOID *max)
{
    HUPU_INT32 iRet;
    struct nac_knl_rbtree_entry nac_ety;

    HUPU_UINT32 min_addr;
    HUPU_UINT32 max_addr;

    memset(&nac_ety, 0, sizeof(struct nac_knl_rbtree_entry));
    min_addr = inet_network(min);
    max_addr = inet_network(max);
   	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%u.%u.%u.%u->%u.%u.%u.%u\n", LIPQUAD(min_addr), LIPQUAD(max_addr));
    nac_ety.type = rbtree_type;
    nac_ety.union_rbtree.ip.ip_min = min_addr;
    nac_ety.union_rbtree.ip.ip_max = max_addr;

    iRet = nac_set_data_to_knl(rbtree_opt_type, 0, &nac_ety, sizeof(struct nac_knl_rbtree_entry));
    if (iRet != HUPU_OK)
    {
        return HUPU_ERR;
    }

    return HUPU_OK;
}

/*return have HUPU_OK, HUPU_ERR, NAC_SYS_ERROR_ILLEGAL_DOMAIN; return != HUPU_OK is fault*/
HUPU_INT32 nac_app_set_domain_host_ipaddr_to_knl(NAC_KNL_RBTREE_TYPE rbtree_type,
		HUPU_UINT16 rbtree_opt_type, HUPU_CHAR* domain_tmp, HUPU_UINT16 domain_id)
{
    int iRet;
	int ret_flag;
    FILE* popen_fp;
    char get_mac_cmd[100] = "";
	char line_buffer[512] = "";
    unsigned int ip_addr;
	int host_sum; //the host_ip sum for domain name resolution;

    ret_flag = HUPU_OK;
    sprintf(get_mac_cmd, get_dns_host_ipaddr, domain_tmp);

    popen_fp = popen (get_mac_cmd, "r");
    if (popen_fp == NULL )
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nslookup domain %s error\n",
					  __FUNCTION__, domain_tmp);
        return NAC_SYS_ERROR_ILLEGAL_DOMAIN;
    }

	host_sum = 0;
    while(fgets(line_buffer, sizeof(line_buffer), popen_fp) != NULL)//2014-04-04-line_buffer size not enough
    {
        //SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->len=%d-->line_buffer=%s\n", __FUNCTION__, strlen(line_buffer), line_buffer);
		clean_newline_character(line_buffer);
        ip_addr = inet_network(line_buffer);

        if (rbtree_opt_type == NAC_CMD_RBTREE_INS)
        {
            iRet = nac_app_set_isolate_iprange_to_knl_rbtree(rbtree_type, rbtree_opt_type,
															ip_addr, ip_addr, domain_id);
            if (iRet != HUPU_OK)
            {
				nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
							"%s-->nac_app_set_isolate_iprange_to_knl_rbtree-->add error, iRet = %d\n",
							__FUNCTION__, iRet);

                ret_flag = HUPU_ERR;
                break;
            }
			host_sum = host_sum + 1;
        }
        else if (rbtree_opt_type == NAC_CMD_RBTREE_RMV)
        {
            iRet = nac_sys_set_iprange_to_knl_rbtree(ip_addr, ip_addr, rbtree_type, rbtree_opt_type);
            if (iRet != HUPU_OK)
            {
                nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_set_iprange_to_knl_rbtree-->error, iRet = %d\n", __FUNCTION__, iRet);
                ret_flag = HUPU_ERR;
                break;
            }
			host_sum = host_sum + 1;
        }
        memset(line_buffer, '\0', sizeof(line_buffer));
    }

	fclose(popen_fp);

	if (host_sum == 0)
	{
		return HUPU_ERR;
	}
	else
	{
    	return ret_flag;
	}

}

/*operate knl rbtree: input is ipgroup*/
HUPU_INT32 nac_sys_set_knl_rebtree_ipgroup(NAC_KNL_RBTREE_TYPE rbtree_type, HUPU_UINT16 rbtree_opt_type, HUPU_CHAR *ip_group)
{
    HUPU_INT32 iRet;
    HUPU_CHAR *token, *running;
    HUPU_CHAR min_str[16];
    HUPU_CHAR max_str[16];
    HUPU_CHAR ip_str[IP_GROUP_LEN] = "";
    HUPU_UINT32 min_addr;
    HUPU_UINT32 max_addr;

    /*this step is must*/
    if (strlen(ip_group) >= IP_GROUP_LEN)
    {
        memcpy(ip_str, ip_group, IP_GROUP_LEN);
    }
    else
    {
        memcpy(ip_str, ip_group, strlen(ip_group));
    }


    //SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->ip_group:%s-->ip_str:%s\n", __FUNCTION__, ip_group, ip_str);
    running = ip_str;
    while((token = strsep(&running, ";")) != NULL)
    {
        memset(min_str, '\0', 16);
        memset(max_str, '\0', 16);

        /*ip_str end have ";", while must have one more time,
 		*but this time token is NULL, so we can use strlen to advoid it*/
        if (strlen(token))
        {
            if (strstr(token, "-"))
            {
                if ((sscanf(token, "%[^-]-%s", min_str, max_str)) != 2)
                {
                    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%d--%s-->token:%s-->min_str: %s-->max_str: %s---->error\n",
                             __LINE__, __FUNCTION__, token, min_str, max_str);

                    return HUPU_ERR;
                    break;
                }
            }
            else
            {
				//Ascend strseq 16
                memcpy(min_str, token, 16);
                memcpy(max_str, token, 16);
            }

            min_addr = inet_network(min_str);
            max_addr = inet_network(max_str);

            iRet = nac_sys_set_iprange_to_knl_rbtree(min_addr, max_addr, rbtree_type, rbtree_opt_type);
            if (iRet != HUPU_OK)
            {
                return HUPU_ERR;
                break;
            }
        }
    }
    return HUPU_OK;
}

