#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"

unsigned short nac_system_language_type = LG_schinese;

NAC_ERROR_LOG_STRU nac_sys_error_log[NAC_ERROR_ARR_LEN] =
{
	{NAC_SYS_ERROR_UNEXIST_OPERATE, "this operate cmd unexist", "操作命令不存在"},
    {NAC_SYS_ERROR_ILLEGAL_IP,  "illegal ip", "非法IP"},
    {NAC_SYS_ERROR_ILLEGAL_MAC, "illegal mac", "非法MAC"},
    {NAC_SYS_ERROR_ILLEGAL_IPRANGE, "illegal iprange", "无效IP段"},
	{NAC_SYS_ERROR_REPEAT_IPRANGE,	"repeat iprange", "IP段重复"},
    {NAC_SYS_ERROR_ILLEGAL_DOMAIN, "illegal domain", "非法域名"},
    {NAC_SYS_ERROR_NONEXECUTE_FILE, "nonexecute or noexist exefile", "可执行命令不存在"},
    {NAC_SYS_ERROR_NONCHANGE_NACMODE, "nonchange nacmode", "准入技术切换失败"},
    {NAC_KNL_ERROR_CHANGE_NACMODE_FAIL, "knl change nacmode fail", "切换准入技术失败"},    
    {NAC_SYS_ERROR_GET_NEXTHOP_MAC,  "nexthop_ip is unreach", "下一跳IP不可达"},
    {NAC_KNL_ERROR_SET_PBR_ONEIN_ONEOUT, "set pbr_advance to knl fail", "设置PBR一进一出"},
    {NAC_SYS_ERROR_ADD_IPRANGE_FAIL, "add iprange fail", "添加IP段失败"},
    {NAC_SYS_ERROR_DEL_IPRANGE_FAIL, "del iprange fail", "删除IP段失败"},
    {NAC_SYS_ERROR_MODIFY_IPRANGE_FAIL, "modify iprange fail", "修改IP段失败"},
    
	{NAC_SYS_ERROR_DOMAIN_RESOLVE_FAIL, "domain reslove fail", "域名解析失败"},
    {NAC_SYS_ERROR_ADD_DOMAIN_FAIL,  "add domain fail", "添加域名失败"},
    {NAC_SYS_ERROR_DEL_DOMAIN_FAIL,  "del domain fail", "删除域名失败"},
    {NAC_SYS_ERROR_MODIFY_DOMAIN_FAIL,  "modify domain fail", "修改域名失败"},
    
	{NAC_SYS_ERROR_ADD_USER_FAIL,  "add sys user fail", "添加认证用户失败"},
    {NAC_SYS_ERROR_DEL_USER_FAIL,  "del sys user fail", "删除认证用户失败"},
    {NAC_SYS_ERROR_USER_FORMAT_ERR,  "user_info format error", "认证用户格式错误"},
    {NAC_SYS_ERROR_ZONEID_SUM_BEYOND_LIMIT, "zoneid sum beyond max_limit", "隔离区ID数目超过上限"},
    {NAC_KNL_ERROR_ADD_USER_FAIL,  "add knl user fail", "添加认证用户失败"},
    {NAC_KNL_ERROR_DEL_USER_FAIL,  "del knl user fail", "删除认证用户失败"},

	{NAC_KNL_USER_TIME_OUT_USER, "del knl time_out user", "在线用户超时"},
    {NAC_KNL_USER_NETAPP_CHECK_FAIL, "del knl netapp check fail user", "网络应用检测失败"},
	
	{NAC_SYS_ERROR_SET_SYSTIME_FAIL, "set systime fail", "设置系统时间失败"},
	{NAC_SYS_ERROR_NTPDATE_TIMEOUT, "ntpdate server timeout", "同步时间服务器失败"},	
	{NAC_SYS_ERROR_DELETE_NTPSERVER_UNEXIST, "delete ntpdate server unexist", "删除时间服务器不存在"},

	{NAC_SYS_ERROR_ILLEGAL_VLANTAG, "illegal vlantag", "无效VLANID"},
	{NAC_SYS_ERROR_REPEAT_VLANMAP, "repeat vlanmap", "添加VLAN映射重复"},
	{NAC_SYS_ERROR_ADD_VCONFIG_FAIL, "vconfig add vlantag fail", "VLAN映射添加失败"},
	{NAC_SYS_ERROR_REM_VCONFIG_FAIL, "vconfig rem vlantag fail", "VLAN映射删除失败"},
	{NAC_SYS_ERROR_DELETE_VLANMAP_UNEXIST, "delete vlanmap unexist", "VLAN映射删除失败"},
	{NAC_SYS_ERROR_MODIFY_VLANMAP_UNEXIST, "modify vlanmap unexist", "修改VLAN映射失败"},
	{NAC_KNL_ERROR_INSERT_VLANMAP_FAIL, "knl insert vlanmap fail", "VLAN映射添加失败"},
	{NAC_KNL_ERROR_REMOVE_VLANMAP_FAIL, "knl remove vlanmap fail", "VLAN映射删除失败"},
	{NAC_SYS_ERROR_ADD_VLANMAP_FAIL, "add vlanmap fail", "VLAN映射添加失败"},
	{NAC_SYS_ERROR_MODIFY_VLANMAP_FAIL, "modify vlanmap fail", "修改VLAN映射失败"},

	{NAC_KNL_ERROR_INSERT_ISOLATE_ZONE_FAIL, "knl insert isolate_zone fail", "添加IP段策略失败"},
	{NAC_KNL_ERROR_INSERT_SAFE_ZONE_FAIL, "knl insert safe_zone fail", "添加IP段策略失败"},
	{NAC_KNL_ERROR_REMOVE_IPRANGE_ZONE_FAIL, "knl remove iprange_zone fail", "删除IP段策略失败"},
	{NAC_SYS_ERROR_ADD_IPRANGE_HLIST_FAIL, "app add iprange hlist fail", "添加IP段策略失败"},
	{NAC_SYS_ERROR_DEL_IPRANGE_POLICY_UNEXIST, "app del iprange policy unexist", "删除IP段策略失败"},
	{NAC_SYS_ERROR_MODIFY_IPRANGE_POLICY_UNEXIST, "app modify iprange policy unexist", "修改IP段策略失败"},
	{NAC_SYS_ERROR_SET_REDIRECT_URL_FAIL, "set redirect_url fail", "重定向URL设置失败"},
	{NAC_SYS_ERROR_SET_REMOTE_SERVER_INFO_FAIL, "set remote_server info fail", "远程服务器地址设置失败"},
	{NAC_SYS_ERROR_SET_IFCONFIG_FAIL, "set ifconfig fail", "配置网络参数失败"},
    {NAC_SYS_ERROR_SET_GATEWAY_FAIL, "set gateway fail", "配置网关失败"},
    {NAC_SYS_ERROR_SET_NAMESERVER_FAIL, "set nameserver fail", "设置域名失败"},
    {NAC_SYS_ERROR_ADD_NETAPP_CHECK_FAIL, "add netapp check fail", "添加应用检测失败"},
    {NAC_SYS_ERROR_DEL_NETAPP_CHECK_FAIL, "del netapp check fail", "删除应用检测失败"},
    {NAC_SYS_ERROR_MODIFY_NETAPP_CHECK_FAIL, "modify netapp check fail", "修改应用检测失败"},
    {NAC_SYS_ERROR_ENABLE_NETAPP_CHECK_FAIL, "enable/disable netapp check fail", "启用或者关闭应用检测失败"},
    {NAC_SYS_ERROR_EXECUTE_SNMP_CMD_FAIL,	"snmpwalk cmd execute fail", "SNMP命令执行失败"},
	{NAC_SYS_ERROR_SNMP_TEST_SWITCH_FAIL,	"test snmp switch fail", "测试交换机失败"},
	{NAC_SYS_ERROR_SNMP_ADD_SWITCH_FAIL,	"add  snmp switch fail", "添加交换机失败"},
	{NAC_SYS_ERROR_SNMP_MODIFY_SWITCH_FAIL,	"modify snmp switch fail", "修改交换机失败"},	
	{NAC_SYS_ERROR_MONITOR_PORT_UNABLE,		"monitor port unable or unlink", "监听端口没启用或者没连接"},	
	{NAC_SYS_ERROR_SAVE_SYS_CONFIG_FAIL,	"save current system config fail", "保存当前系统配置失败"},	
	{NAC_SYS_ERROR_FACTORY_CONFIG_UNEXIST,	"factory_sys_config unexist", "出厂配置不存在"},
	{NAC_SYS_ERROR_INPUT_CONFIG_UNEXIST,	"input_sys_config unexist", "导入配置不成功"},	
	{NAC_SYS_ERROR_SET_LICENSE_USABLE_TIME_ERROR,	"set license authorize_time error", "授权时间设置失败"},	
	{NAC_SYS_ERROR_ENABLE_OR_DISABLE_ASC_FAIL,	"enable or disable asc fail", "启用或禁用控制失败"},
    {NAC_SYS_ERROR_FTP_UPLOAD_CMD_UNEXIST, "upload debug_log cmd unexist", "上传调试日志命令不存在"},
	{NAC_SYS_ERROR_SET_WARN_CONF_FAIL, "set warn_conf_policy fail", "设置系统运行告警策略失败"},
    {NAC_SYS_ERROR_FLUSH_USER_FAIL, "flush online user list fail", "清空上线用户列表失败"},
    {NAC_SYS_ERROR_ADD_NAT_FAIL, "add nat_list fail", "添加NAT失败"},
    {NAC_SYS_ERROR_DEL_NAT_FAIL, "del nat_list fail", "删除NAT失败"},
    {NAC_SYS_ERROR_MODIFY_NAT_FAIL, "modify nat_list fail", "修改NAT失败"},
    {NAC_SYS_ERROR_ADD_EXCEPTMAC_FAIL, "add except_mac fail", "添加例外mac失败"}, 
    {NAC_SYS_ERROR_DEL_EXCEPTMAC_FAIL, "del except_mac fail", "删除例外mac失败"},
    {NAC_SYS_ERROR_MODIFY_EXCEPTMAC_FAIL, "modify except_mac fail", "修改例外mac失败"},
};

char* nac_sys_get_error_log(NAC_ERROR_LOG_TYPE error_id)
{
    unsigned int i;
	char *default_error_msg = "配置错误，请重新操作";
    char *sRet_error = NULL;

    for (i = 0; i < NAC_ERROR_ARR_LEN; i++)
    {
        if (nac_sys_error_log[i].type == error_id)
        {
			switch(nac_system_language_type)
			{
			case LG_english:
				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->index=%d-->error_type=%d-->en_error_log=%s\n", 
							__FUNCTION__, i, error_id, nac_sys_error_log[i].en_error_log);
				sRet_error = nac_sys_error_log[i].en_error_log;
				break;

			case LG_schinese:
				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->index=%d-->error_type=%d-->sch_error_log=%s\n", 
							__FUNCTION__, i, error_id, nac_sys_error_log[i].sch_error_log);
				sRet_error = nac_sys_error_log[i].sch_error_log;
				break;

			case LG_tchinese:
				//break;
			default:
				sRet_error = default_error_msg;
				break;
			}
        }
    }
    return sRet_error;
};

/*
SYS_WEBUI_SET_SYS_LANG,//123
//获取当前系统错误提示信息语言类型
<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>123</commandID>
  <actionType>0</actionType>
</nac>
1=English;2=Simplified Chinese;3=Tradition_chinese;
<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>123+100</commandID>
  <actionType>0</actionType>
  <result>0</result>
  <systemLanguage>1/2/3<systemLanguage>
</nac>

//设置当前系统错误提示信息语言类型
<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>123</commandID>
  <actionType>1</actionType>
  <systemLanguage>1/2/3<systemLanguage>
</nac>
*/

xmlDocPtr nac_sys_parse_set_system_language(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_INT32 error_id;
	xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;	
	xmlChar *lang_szkey;
    HUPU_UINT8 action_type;	

	cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
	switch (action_type)
    {
	case NAC_SHOW:
		 nac_free_xmlDoc(doc);
		 nac_doc = nac_sys_ret_show_result(cmd_id, "set_system_lang");
		 break;

	case NAC_ADD:
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "systemLanguage")))
			{
				lang_szkey = xmlNodeGetContent(cur_node);
				nac_system_language_type = atoi((HUPU_CHAR*)lang_szkey);
				xmlFree(lang_szkey);
				break;
			}
			cur_node = cur_node->next;
		}

		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
	}
	
	return nac_doc;
}
