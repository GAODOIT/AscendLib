#ifndef NAC_SYSTEM_NAT_MANAGE_H
#define NAC_SYSTEM_NAT_MANAGE_H

typedef enum
{
    NAT_IGNORE = 0,
    NAT_ALLOW = 1,
	NAT_FORBID = 2,
}NAC_APP_NAT_ACTION_ENUM;

typedef enum
{
	NAT_AUTO_ADD = 0,//auto_add
	NAT_MANUAL_ADD,	//manual_add
	NAT_NULL_ADD,
}NAC_APP_NAT_ADD_ENUM;

typedef struct NAC_APP_NAT_CONFIG_STRU
{
	HUPU_UINT8  enable;
	HUPU_UINT8  auto_found;//auto_found_enable;
	HUPU_UINT16 default_action;//auto_default_action;
}NAC_APP_NAT_CONFIG;

typedef struct NAC_APP_NAT_STRU
{
	struct nac_hlist_node nat_id;
	struct nac_list_head  nat_list;
	HUPU_UINT16 id;
	HUPU_UINT8  type;
	HUPU_UINT8  action;
	HUPU_UINT32	ip;
	HUPU_ULONG32 up_time;
	HUPU_CHAR	describe[MAX_COMMENT_LEN];
}NAC_APP_NAT;

extern HUPU_UINT16 g_nat_policy_index;
extern NAC_APP_NAT_CONFIG g_nat_config_st;
//extern struct nac_list_head g_nac_app_nat_list_head;

HUPU_INT32 nac_app_init_nat_manage(HUPU_VOID);
HUPU_INT32 nac_app_knl_nat_manage_flush(HUPU_VOID);
HUPU_INT32 nac_app_nat_manage_flush(HUPU_VOID);
HUPU_INT32 nac_app_auto_nat_list_timeout(HUPU_ULONG32 now);
HUPU_INT32 nac_app_debug_show_nat_manage_list(FILE* fp);
HUPU_INT32 nac_app_nat_add(NAC_APP_NAT* pst_nat);
HUPU_INT32 nac_app_save_nat_manage_list(FILE* fp);
HUPU_INT32 nac_app_set_auto_nat_found(HUPU_UINT8 flag);
HUPU_INT32 nac_system_deal_nat_manage_switch(HUPU_CHAR flag);
HUPU_INT32 nac_sys_netlink_found_nat(NAC_KNL_USER_MSG *netlink_usr_msg);
xmlDocPtr nac_system_parse_nat_manage_config(xmlDocPtr doc, HUPU_UINT16 cmd_id);
xmlDocPtr nac_system_parse_nat_manage_list(xmlDocPtr doc, HUPU_UINT16 cmd_id);
#endif //NAC_SYSTEM_NAT_MANAGE_H
