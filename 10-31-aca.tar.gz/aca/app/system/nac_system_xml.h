#ifndef NAC_SYSTEM_XML_H
#define NAC_SYSTEM_XML_H

#include <libxml/parser.h>
#include <libxml/tree.h>
#include "nac_precomp.h"

typedef enum
{
	ASC_DISABLE=0,
	ASC_ENABLE,
}NAC_ASC_ENABLE_FLAG;

typedef enum
{
    SYS_NOBOOT,
    SYS_REBOOT,
    SYS_SHUTDOWN,
} NAC_SYS_OPT;

typedef enum
{
   NAC_SHOW,
   NAC_ADD,
   NAC_DEL,
   NAC_MODIFY, //NAC_UPDATE
   NAC_SAVE_SYS_CONFIG,
   NAC_OUTPUT_SYS_CONFIG,
   NAC_INPUT_SYS_CONFIG,
   NAC_RESET_SYS_CONFIG,
   ASC_FIRST_LINK,
   NAC_FLUSH,
} NAC_SET_ACTION;

extern HUPU_UINT16 g_nac_asc_enable_flag;
extern HUPU_INT16  Ret_cmd_offset;

extern nac_knl_in_out_eth gst_in_out_eth;

extern NAC_MODE app_nacmode;

extern HUPU_INT32 nac_pbr_onein_oneout_flag; //default close
extern NAC_PBR_ADVANCE_SETUP pbr_advance_setup;

extern HUPU_UINT16 gi_netdev_count;
extern HUPU_CHAR nac_sys_ifname[IFMAXNUM][IFNAMSIZE];
extern NAC_NET_DEVICE g_nac_net_device[];
extern HUPU_CHAR   g_default_gateway[];
extern NAC_DNS_SERVER gst_dns_server;

extern HUPU_CHAR	g_manager_mac_addr[];
extern HUPU_CHAR	g_manager_eth_name[];

//except_terminal except_server safe_iprangezone and isolate_iprangezone
extern HUPU_UINT16 g_policy_index;

//////////////////////////////////////////////////////////////////////
HUPU_INT32 nac_sys_get_knl_pass_switch(HUPU_UINT16 *flag);
HUPU_INT32 nac_sys_enable_or_disable_asc(HUPU_UINT16 flag);
xmlDocPtr nac_sys_return_web_action_result(HUPU_UINT16 cmd_id, HUPU_UINT8 action, HUPU_UINT16 error_id);
HUPU_INT32 nac_sys_parse_web_xmlmsg(HUPU_INT32 xml_sock_fd, xmlDocPtr tmpdoc, HUPU_UINT16 command_id);
xmlNodePtr nac_xml_parse_get_action(xmlDocPtr doc, HUPU_UINT8 *action);
xmlDocPtr nac_sys_ret_show_result(HUPU_UINT16 cmd_id, HUPU_VOID *show_msg);
xmlDocPtr nac_sys_ret_action_result(HUPU_UINT16 cmd_id, HUPU_UINT8 action, HUPU_INT16 ret_status, HUPU_VOID *ret_msg);

HUPU_VOID nac_free_xmlDoc(xmlDocPtr doc);
HUPU_INT32 nac_sys_return_heart_beat_to_webserver(HUPU_INT32 sock_fd, HUPU_CHAR* rev_heart);
HUPU_INT32 nac_sys_return_idm_connect_asc_requset(HUPU_INT32 sock_fd);
HUPU_INT32 nac_sys_send_xmldoc_to_webserver(HUPU_INT32 sock_fd, xmlDocPtr doc, HUPU_UINT16 cmd_id);
HUPU_INT32 nac_sys_send_xmlstr_to_webserver(HUPU_INT32 sock_fd, HUPU_UINT32 length,
													HUPU_UINT16 cmd, HUPU_CHAR* xml_msg_tmp);

#endif // end of NAC_SYSTEM_XML_H

