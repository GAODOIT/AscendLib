/*
# Note:2015-03-17
# echo "kern.* @127.0.0.1" >> /etc/rsyslog.conf
# /etc/init.d/rsyslog restart
*/
#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_errorlog.h"
#include "nac_system_xml.h"
#include "nac_system_net.h"
#include "nac_system_set_remote_server.h"
#include "nac_system_redis_subscribe.h"
#include "nac_system_escape_deal.h"

//default close
HUPU_UINT16 g_asc_escape_enable_flag = HUPU_DISABLE;
HUPU_CHAR   g_untrust_max_flow_speed[32] = "500";
HUPU_UINT16 g_asc_running_mode		 = ASC_NORMAL_MODE;

struct eth_detect_struct trust_eth_event;
struct eth_detect_struct manager_eth_event;
struct eth_detect_struct untrust_eth_event;

//static NAC_LIST_HEAD(delay_msg_list_head);
struct nac_list_head delay_msg_list_head;
pthread_mutex_t system_msg_list_mutex = PTHREAD_MUTEX_INITIALIZER;

HUPU_INT32 nac_app_init_delay_msg_list(HUPU_VOID)
{
	NAC_INIT_LIST_HEAD(&delay_msg_list_head);
	pthread_mutex_init(&system_msg_list_mutex, HUPU_NULL);
	return HUPU_OK;
}

HUPU_INT32 nac_app_add_delay_msg_list(HUPU_UINT16 length, HUPU_UINT16 cmd, HUPU_CHAR* xml_msg)
{
	DELAY_MSG_STRU* pst_msg = HUPU_NULL;
	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->length=%d-->cmd=%d-->xml_msg=%s\n",
				__FUNCTION__, length, cmd, xml_msg);
	pst_msg = (DELAY_MSG_STRU*)malloc(sizeof(DELAY_MSG_STRU) + strlen(xml_msg) + 1);
	if (pst_msg == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->malloc DELAY_MSG_STRU error\n", __FUNCTION__);
		return HUPU_ERR;
	}

	memset((HUPU_CHAR*)pst_msg, '\0', sizeof(DELAY_MSG_STRU) + strlen(xml_msg) + 1);
	pst_msg->length = length;//strlen(xml_msg)
	pst_msg->type   = cmd;
	strcpy(pst_msg->msg_body, xml_msg);
	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->length=%d-->type=%d-->msg_body=%s\n",
				__FUNCTION__, pst_msg->length, pst_msg->type, pst_msg->msg_body);

	pthread_mutex_lock(&system_msg_list_mutex);
	NAC_INIT_LIST_HEAD(&(pst_msg->msg_list));
	nac_list_add_tail(&(pst_msg->msg_list), &delay_msg_list_head);
	pthread_mutex_unlock(&system_msg_list_mutex);

	return HUPU_OK;
}

HUPU_INT32 nac_app_show_all_delay_msg(HUPU_VOID)
{
	HUPU_INT32 iRet, sum;
	DELAY_MSG_STRU* pst_msg_tmp;

	pthread_mutex_lock(&system_msg_list_mutex);
	iRet = nac_list_empty(&delay_msg_list_head);
	if (iRet == HUPU_TRUE)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->delay_msg_list is empty\n", __FUNCTION__);
		pthread_mutex_unlock(&system_msg_list_mutex);
		return HUPU_ERR;
	}

	sum = 0;
	nac_list_for_each_entry(pst_msg_tmp, &delay_msg_list_head, msg_list)
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,"%s--delay_msg:length=%d-->type=%d-->body=%s\n",
					__FUNCTION__, pst_msg_tmp->length,pst_msg_tmp->type, pst_msg_tmp->msg_body);
		sum = sum + 1;
	}
	pthread_mutex_unlock(&system_msg_list_mutex);
	return HUPU_OK;
}

HUPU_INT32 nac_app_resend_delay_msg_list(HUPU_INT32	sock_fd)
{
	HUPU_INT32 iRet, sum;
	DELAY_MSG_STRU *dying, *tmp;
	HUPU_CHAR	xml_str_buffer[512] = "";
	NAC_WEB_MSG *ret_xml_msg = (NAC_WEB_MSG*)xml_str_buffer;

	pthread_mutex_lock(&system_msg_list_mutex);

	iRet = nac_list_empty(&delay_msg_list_head);
	if (iRet == HUPU_TRUE)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->delay_msg_list is empty\n", __FUNCTION__);
		pthread_mutex_unlock(&system_msg_list_mutex);
		return HUPU_ERR;
	}

	sum = 0;
	nac_list_for_each_entry_safe(dying, tmp, &delay_msg_list_head, msg_list)
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,"%s--delay_msg:length=%d-->type=%d-->body=%s\n",
					__FUNCTION__,  dying->length, dying->type, dying->msg_body);
		sum = sum + 1;

		ret_xml_msg->us_cmd  = dying->type;
        ret_xml_msg->reserve = 0;
		ret_xml_msg->ui_len = dying->length;
		memcpy(ret_xml_msg->ac_buf, dying->msg_body, dying->length);
		iRet = nac_tcp_sendto(sock_fd, xml_str_buffer, (dying->length+4));
		if (iRet != (dying->length + 4))
		{
        	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
						"%s-->nac_tcp_sendto error-->iRet = %d\n", __FUNCTION__,iRet);
    	}
		nac_list_del(&dying->msg_list);
		free(dying);
	}
	pthread_mutex_unlock(&system_msg_list_mutex);

	return HUPU_OK;
}

HUPU_INT32 nac_system_pack_escape_xml_msg(HUPU_CHAR* escape_info)
{
	HUPU_CHAR	xml_str_buffer[512];
	HUPU_UINT16	xml_str_len;
	HUPU_CHAR   *xml_escape_msg_format =
	"<?xml version=\"1.0\" encoding=\"UTF-8\"?><nac>"
	"<commandID>%d</commandID>"
	"<actionType>%d</actionType>"
	"<ascMode>%d</ascMode>"
	"<escapeReason>%s</escapeReason></nac>";
	memset(xml_str_buffer, '\0', strlen(xml_str_buffer));
	sprintf(xml_str_buffer, xml_escape_msg_format,\
			SYS_WEBUI_UPLOAD_ESCAPE_MODE+100, NAC_ADD,\
			g_asc_running_mode, escape_info);

	xml_str_len= strlen(xml_str_buffer);

	nac_app_add_delay_msg_list(xml_str_len,
								SYS_WEBUI_UPLOAD_ESCAPE_MODE+100,
								xml_str_buffer);
	return HUPU_OK;

}

HUPU_INT32 nac_system_upload_escape_msg(HUPU_INT32 ui_sock_fd, HUPU_CHAR* escape_info)
{
	HUPU_CHAR	xml_str_buffer[512];
	HUPU_UINT16	xml_str_len;
	HUPU_CHAR *xml_escape_msg_format =
	"<?xml version=\"1.0\" encoding=\"UTF-8\"?><nac>"
	"<commandID>%d</commandID>"
	"<actionType>%d</actionType>"
	"<ascMode>%d</ascMode>"
	"<escapeReason>%s</escapeReason></nac>";

	memset(xml_str_buffer, '\0', strlen(xml_str_buffer));
	sprintf(xml_str_buffer, xml_escape_msg_format,\
			SYS_WEBUI_UPLOAD_ESCAPE_MODE+100, NAC_ADD,\
			g_asc_running_mode, escape_info);
	xml_str_len= strlen(xml_str_buffer);
	nac_sys_send_xmlstr_to_webserver(ui_sock_fd, xml_str_len,
									SYS_WEBUI_UPLOAD_ESCAPE_MODE,
									xml_str_buffer);
	return HUPU_OK;

}

HUPU_INT32 nac_update_escape_check_event(HUPU_VOID)
{
	HUPU_INT16 i;
	for(i = 0; i < IFMAXNUM; i++)
	{
		if (strcmp(g_nac_net_device[i].if_label, "manager") == HUPU_OK)
		{
			memset(&manager_eth_event, '\0', sizeof(struct eth_detect_struct));
			strcpy(manager_eth_event.name, nac_sys_ifname[i]);
			sprintf(manager_eth_event.up_msg, "%s NIC Link is Up", nac_sys_ifname[i]);
			sprintf(manager_eth_event.down_msg, "%s NIC Link is Down", nac_sys_ifname[i]);
		}
		else if (strcmp(g_nac_net_device[i].if_label,"trust") == HUPU_OK)
		{
			memset(&trust_eth_event, '\0', sizeof(struct eth_detect_struct));
			strcpy(trust_eth_event.name, nac_sys_ifname[i]);
			sprintf(trust_eth_event.up_msg, "%s NIC Link is Up", nac_sys_ifname[i]);
			sprintf(trust_eth_event.down_msg, "%s NIC Link is Down", nac_sys_ifname[i]);
		}
		else if (strcmp(g_nac_net_device[i].if_label,"untrust") == HUPU_OK)
		{
			memset(&untrust_eth_event, '\0', sizeof(struct eth_detect_struct));
			strcpy(untrust_eth_event.name, nac_sys_ifname[i]);
			sprintf(untrust_eth_event.up_msg, "%s NIC Link is Up", nac_sys_ifname[i]);
			sprintf(untrust_eth_event.down_msg, "%s NIC Link is Down", nac_sys_ifname[i]);
		}
	}

	return HUPU_OK;
}

HUPU_INT32 nac_system_pack_escape_reason(HUPU_UINT16 detect_flag, HUPU_CHAR* escape_msg, HUPU_UINT16* run_status)
{
	HUPU_UINT16 mode = 1; //ASC_NORMAL_MODE
	HUPU_CHAR msg_buffer[BUFF_LEN];

    manager_eth_event.must = 1;
	nac_app_get_netdev_link_and_enable_status(manager_eth_event.name,
				&manager_eth_event.link, &manager_eth_event.enable);
	if (detect_flag == HUPU_TRUE)
	{
		if (manager_eth_event.link == HUPU_DISABLE)
		{
			nac_sys_enable_or_disable_asc(ASC_DISABLE);
			nac_system_destroy_tcp_long_sockfd();
		}
		else if (manager_eth_event.link == HUPU_ENABLE)
		{
			nac_sys_enable_or_disable_asc(ASC_ENABLE);
		}
	}
	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
					"manager:%s--link:%d--enable:%d--must:%d\n",
					manager_eth_event.name,	manager_eth_event.link,
					manager_eth_event.enable, manager_eth_event.must);


    untrust_eth_event.must = 1;
	nac_app_get_netdev_link_and_enable_status(untrust_eth_event.name,
				&untrust_eth_event.link, &untrust_eth_event.enable);
	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
					"untrust:%s--link:%d--enable:%d--must:%d\n",
					untrust_eth_event.name, untrust_eth_event.link,
					untrust_eth_event.enable, untrust_eth_event.must);

    trust_eth_event.must = 1;
	nac_app_get_netdev_link_and_enable_status(trust_eth_event.name,
				&trust_eth_event.link, &trust_eth_event.enable);
	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
					"trust:%s--link:%d--enable:%d--must:%d\n",
					trust_eth_event.name, trust_eth_event.link,
					trust_eth_event.enable, trust_eth_event.must);

	switch(app_nacmode)
	{
	case NAC_MVG_MODE:
		strcat(escape_msg, "mvg;");
		if (manager_eth_event.link && untrust_eth_event.link
			&& trust_eth_event.link)
		{
			mode = ASC_NORMAL_MODE;
		}
		else
		{
			mode = ASC_ESCAPE_MODE;
		}
		break;
	case NAC_PBR_MODE:
		if (nac_pbr_onein_oneout_flag == 1)
		{
			strcat(escape_msg, "pbr_two;");
			if (manager_eth_event.link && untrust_eth_event.link
				&& trust_eth_event.link)
			{
				mode = ASC_NORMAL_MODE;
			}
			else
			{
				mode = ASC_ESCAPE_MODE;
			}
		}
		else
		{
			strcat(escape_msg, "pbr_one;");
			trust_eth_event.must = 0;
			if (manager_eth_event.link && untrust_eth_event.link)
			{
				mode = ASC_NORMAL_MODE;
			}
			else
			{
				mode = ASC_ESCAPE_MODE;
			}
		}
		break;
	case NAC_BRIDGE_MODE:
		strcat(escape_msg, "bridge;");
		break;
	default:
		break;
	}

	*run_status = mode;//get the asc_mode(normal or escape)

	memset(msg_buffer, '\0', BUFF_LEN);
	sprintf(msg_buffer, "%s(%s):%s;", manager_eth_event.name,
			"manager",(manager_eth_event.link == 1)? ("up"):("down"));
	strcat(escape_msg, msg_buffer);

	memset(msg_buffer, '\0', BUFF_LEN);
	sprintf(msg_buffer, "%s(%s):%s;", untrust_eth_event.name,
			"untrust",(untrust_eth_event.link == 1)? ("up"):("down"));
	strcat(escape_msg, msg_buffer);

	if (trust_eth_event.must == 1)
	{
		memset(msg_buffer, '\0', BUFF_LEN);
		sprintf(msg_buffer, "%s(%s):%s;", trust_eth_event.name,
			"trust",(trust_eth_event.link == 1)? ("up"):("down"));
		strcat(escape_msg, msg_buffer);
	}

	return HUPU_OK;
}

HUPU_INT32 nac_app_parse_iface_event_syslog(HUPU_CHAR *p_log, HUPU_UINT16 *type)
{
    HUPU_UINT16 flag = 0;
    if (strstr(p_log, manager_eth_event.down_msg) != HUPU_NULL)
    {
        flag = 1;
    }
    else if (strstr(p_log, manager_eth_event.up_msg) != HUPU_NULL)
    {
        flag = 1;
    }
    else if (strstr(p_log, untrust_eth_event.up_msg) != HUPU_NULL)
    {
        flag = 2;
    }
    else if (strstr(p_log, untrust_eth_event.down_msg) != HUPU_NULL)
    {
        flag = 2;
    }
    else if (strstr(p_log, trust_eth_event.up_msg) != HUPU_NULL)
    {
        flag = 2;
    }
    else if (strstr(p_log, trust_eth_event.down_msg) != HUPU_NULL)
    {
        flag = 2;
    }

    *type = flag;

    return 0;
}



//there will have an another pthread to monitor all this Daemon Thread every 10s.
//check this pthread_self() shuzu;
HUPU_VOID *nac_system_escape_check_thread_enter(HUPU_VOID *arg)
{
	HUPU_INT32		iRet;
	HUPU_INT32		nac_syslog_fd = 0;
	HUPU_ULONG32	cli_addr_tmp = 0;
	HUPU_UINT16		cli_port_tmp = 0;
	HUPU_CHAR		recv_buffer[MSG_BUFFER_LEN];
	HUPU_CHAR		escape_buffer[BUFF_LEN];
	HUPU_UINT16		event_flag ;//manager=1;data_trust=2;other=0;

	nac_syslog_fd = nac_udp_crt_svr(NAC_RSYSLOG_UDP_PORT);
	if (nac_syslog_fd < 0)
	{
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_udp_crt_svr error=%d\n", nac_syslog_fd);
		goto ESCAPE_EXIT_FUNC;
	}

	while(1)
	{
        event_flag = 0;
		memset(recv_buffer, '\0', MSG_BUFFER_LEN);
		iRet = nac_udp_recvfrom(nac_syslog_fd, &cli_addr_tmp, &cli_port_tmp, recv_buffer, MSG_BUFFER_LEN);
		if (iRet <= HUPU_OK)
		{
			SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_udp_recvfrom error %d\n", iRet);
			continue;
		}
		else
		{
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%u.%u.%u.%u:%d----payload=%s\n",
							LIPQUAD(cli_addr_tmp), cli_port_tmp, recv_buffer);
            if (g_asc_escape_enable_flag == HUPU_DISABLE)
			{
				continue;
			}

            nac_app_parse_iface_event_syslog(recv_buffer, &event_flag);
			if (event_flag > 0)
			{
				memset(escape_buffer, 0, sizeof(escape_buffer));
				sleep(3);
                //for monitor platform
				send_redis_pub_command("iface_status");
				nac_system_pack_escape_reason(event_flag, escape_buffer, &g_asc_running_mode);
				if (gi_link_fd > 0)
				{
					nac_system_upload_escape_msg(gi_link_fd, escape_buffer);
				}
				else
				{
					nac_system_pack_escape_xml_msg(escape_buffer);
				}
			}

		}
	}
	nac_udp_destroy(nac_syslog_fd);
	nac_syslog_fd = 0;
ESCAPE_EXIT_FUNC:
	pthread_detach(pthread_self());
	return HUPU_NULL;
}

/*
static HUPU_INT32 nac_system_escape_check_create_thread(HUPU_VOID)
{

	pthread_t escape_pthread_id = 0;
	HUPU_INT32 iRet;
	iRet = pthread_create(&escape_pthread_id, HUPU_NULL, nac_system_escape_check_thread_enter, "escape_check");
	if (iRet != HUPU_OK)
	{
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"can't create escape_check thread:%s\n", strerror(iRet));
		return HUPU_ERR;
	}

	return HUPU_OK;
}
*/

HUPU_INT32 nac_sys_escape_config_deal(HUPU_UINT16 flag)
{
	if (g_asc_escape_enable_flag == flag)
	{
		return HUPU_OK;
	}

	if (flag >= HUPU_ENABLE)
	{
		g_asc_escape_enable_flag = HUPU_ENABLE;
	}
	else
	{
		g_asc_escape_enable_flag = HUPU_DISABLE;
	}

    //for monitor platform
    send_redis_pub_command("escape_status");

	/*
	HUPU_CHAR escape_buffer[BUFF_LEN];
	memset(escape_buffer, '\0', sizeof(escape_buffer));
	if (g_asc_escape_enable_flag == HUPU_ENABLE)
	{
		nac_system_pack_escape_reason(HUPU_FALSE, escape_buffer, &g_asc_running_mode);
	}
	*/

	return HUPU_OK;
}

/*
<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>132</commandID>
  <actionType>1</actionType>
  <escapeEnable>0/1<escapeEnable>
  <maxFlowSpeed>0/1024<maxFlowSpeed>
</nac>
*/
xmlDocPtr nac_sys_parse_escape_enable_flag(xmlDocPtr doc, HUPU_UINT16 cmd_id, HUPU_UINT8 *action)
{
    xmlDocPtr	nac_doc = HUPU_NULL;
    xmlNodePtr	cur_node;
	xmlChar		*xml_cnt;
    HUPU_UINT8	action_type;
    HUPU_INT32	error_id;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_xml_parse_get_action\n");
        return HUPU_NULL;
    }

	*action = action_type;
	error_id = 0;
    switch (action_type)
    {
    case NAC_SHOW:
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_ret_show_result(cmd_id, "escapeEnable");
		break;

	case NAC_ADD:
		while(cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "escapeEnable")))
			{
				xml_cnt = xmlNodeGetContent(cur_node);
				g_asc_escape_enable_flag = atoi((HUPU_CHAR*)xml_cnt);
				xmlFree(xml_cnt);
				SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS, "escapeEnable=%d\n", g_asc_escape_enable_flag);

			}
            else if(!(xmlStrcmp(cur_node->name, BAD_CAST "maxFlowSpeed")))
            {
                xml_cnt = xmlNodeGetContent(cur_node);
                memset(g_untrust_max_flow_speed, 0, sizeof(g_untrust_max_flow_speed));
                memcpy(g_untrust_max_flow_speed, xml_cnt, strlen((HUPU_CHAR*)xml_cnt));
				xmlFree(xml_cnt);
                SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS, "maxFlowSpeed=%s\n", g_untrust_max_flow_speed);
                break;
            }
			cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

HUPU_INT32 nac_app_get_asc_link_port_name(HUPU_CHAR* ports_name)
{
	HUPU_CHAR tmp_buffer[32];

	memset(tmp_buffer, '\0', sizeof(tmp_buffer));
	sprintf(tmp_buffer, "manager:%s;", manager_eth_event.name);
	strcat(ports_name, tmp_buffer);

	memset(tmp_buffer, '\0', sizeof(tmp_buffer));
	sprintf(tmp_buffer, "untrust:%s;", untrust_eth_event.name);
	strcat(ports_name, tmp_buffer);

	if (app_nacmode == NAC_PBR_MODE && nac_pbr_onein_oneout_flag == 0)
	{
		return HUPU_OK;
	}
	memset(tmp_buffer, '\0', sizeof(tmp_buffer));
	sprintf(tmp_buffer, "trust:%s;", trust_eth_event.name);
	strcat(ports_name, tmp_buffer);
	return HUPU_OK;
}

//write escape_config to config file
HUPU_INT32 nac_sys_write_escape_config_to_configure(FILE* fp)
{
    HUPU_CHAR content[1024*10] = {0};
    HUPU_CHAR buffer[512]={0};
    strcat(content, "escape_config\n{\n");
    sprintf(buffer,"    escape_switch=%d\n", g_asc_escape_enable_flag);
    strcat(content, buffer);
    sprintf(buffer,"    max_flowspeed=%s\n", g_untrust_max_flow_speed);
    strcat(content, buffer);
    strcat(content, "}\n\n");
    fprintf(fp, "%s", content);
    return 0;
}

HUPU_INT32 nac_sys_get_escape_config_from_configure(const HUPU_CHAR *file_path)
{
    HUPU_INT32 iRet;
    HUPU_CHAR buffer[1024*1024] = {0};
    HUPU_CHAR content[1024*10] = {0};
    HUPU_INT32 fd = 0;
    HUPU_CHAR  *p_value = NULL;

    fd = open(file_path, O_RDONLY);
    read(fd, buffer, 1024*1024);
    close(fd);

    memset(content, 0, sizeof(content));
    if(get_content(buffer, content, "escape_config") < 0)
    {
        goto GO_EXIT;
    }

    p_value = each_line_search(content, "escape_switch");
    iRet = atoi(p_value);
    if (iRet > 0)
    {
       g_asc_escape_enable_flag = HUPU_TRUE;
    }
    else
    {
        g_asc_escape_enable_flag = HUPU_FALSE;
    }

    p_value = each_line_search(content, "max_flowspeed");
    if (strlen(p_value))
    {
        memset(g_untrust_max_flow_speed, 0, sizeof(g_untrust_max_flow_speed));
        memcpy(g_untrust_max_flow_speed, p_value, strlen(p_value));
    }
    send_redis_pub_command("escape_status");
    return 0;
    GO_EXIT:
        return -1;
}


