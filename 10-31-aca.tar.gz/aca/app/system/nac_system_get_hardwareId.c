#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_net.h"
#include "nac_system_get_hardwareId.h"

//save /nac/config/nac_eth_sum.conf
static HUPU_INT32 nac_sys_get_eth_sum(HUPU_VOID)
{
	HUPU_UINT16 eth_sum_tmp;
	HUPU_CHAR	cmd_buffer[64]= "";
	HUPU_CHAR	nac_eth_sum_file[] = "/nac/config/nac_eth_sum.conf";

	eth_sum_tmp = nac_get_netdev_count();
	sprintf(cmd_buffer, "echo %d > %s", eth_sum_tmp, nac_eth_sum_file);
	nac_exec_system(cmd_buffer);

	return eth_sum_tmp;
}

// save /nac/config/nac_device_id.conf
HUPU_INT32 nac_sys_save_controller_id(const HUPU_CHAR* filename)
{
	HUPU_INT16 manager_ifindex;
    FILE *nac_fp = HUPU_NULL;
    HUPU_CHAR controller_mac[18] = "";//eth0
    HUPU_CHAR cpu_id_str[35] = "";

    if ((nac_fp = fopen(filename, "w+")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

	manager_ifindex = nac_app_get_eth0_ifindex();
    nac_get_netdev_mac(nac_sys_ifname[manager_ifindex], controller_mac, sizeof(controller_mac));
    get_cpu_id_str(cpu_id_str);

    fputs(controller_mac, nac_fp);
    fputc('\n', nac_fp);
    fputs(cpu_id_str, nac_fp);
    fputc('\n', nac_fp);

    fclose(nac_fp);
    return HUPU_OK;
}

static xmlDocPtr nac_sys_get_hardware_id(HUPU_UINT16 command_id)
{
	HUPU_INT16 manager_ifindex;
    xmlDocPtr doc;
    xmlNodePtr root_node;

    HUPU_CHAR get_buffer[10] ="";
    HUPU_CHAR controller_mac[18] = "";
    HUPU_CHAR cpu_id_str[35] = "";

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    sprintf(get_buffer, "%d", (command_id + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST get_buffer);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");

	//manager_port
    manager_ifindex = nac_app_get_eth0_ifindex();
    nac_get_netdev_mac(nac_sys_ifname[manager_ifindex], controller_mac, sizeof(controller_mac));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "controllerId", BAD_CAST controller_mac);

    get_cpu_id_str(cpu_id_str);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "cpuId", BAD_CAST cpu_id_str);

    return doc;
}


xmlDocPtr nac_sys_parse_get_hardwareId_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    HUPU_UINT8 action_type;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

    switch (action_type)
    {
    case NAC_SHOW:
        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_get_hardware_id(cmd_id);
        break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}
