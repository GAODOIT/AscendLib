#ifndef NAC_SYSTEM_DEAL_SYSCONFIG_H
#define NAC_SYSTEM_DEAL_SYSCONFIG_H
#include "nac_system_common_lib.h"
extern HUPU_CHAR  *nac_factory_cfg_file;
extern HUPU_CHAR  *nac_input_cfg_file;

HUPU_INT32 nac_sys_send_ruby_switch_usr1(HUPU_VOID);
HUPU_INT32 nac_app_flush_all_system_config(HUPU_VOID);
HUPU_INT32 nac_app_init_flush_knl_config(HUPU_VOID);
HUPU_INT32 nac_sys_reset_to_factory_config(HUPU_VOID);
HUPU_INT32 nac_sys_update_current_system_config(HUPU_VOID);
xmlDocPtr nac_sys_parse_deal_sys_config_xml(xmlDocPtr doc,
						HUPU_UINT16 cmd_id, HUPU_UINT8 *cmd_action);

#endif
