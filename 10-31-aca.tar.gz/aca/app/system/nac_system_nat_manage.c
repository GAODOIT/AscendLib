#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_app_knl_port.h"
#include "nac_system_errorlog.h"
#include "nac_system_nat_manage.h"
#include "nac_system_set_remote_server.h"

/*
add Mutex_lock
*/

static struct nac_hlist_head nat_hash_by_id[NAT_HASH_MAP_SIZE];
NAC_LIST_HEAD(g_nac_app_nat_list_head);
unsigned long g_auto_nat_timeout = 10*60; //10min

NAC_APP_NAT_CONFIG g_nat_config_st;
HUPU_UINT16 g_nat_policy_index = 0;


HUPU_INT32 __nac_app_nat_del(HUPU_UINT16 id, NAC_APP_NAT *pst_nat);

static HUPU_INT32 nac_app_nat_get_hash_by_id(HUPU_UINT16 id)
{
	return id&(NAT_HASH_MAP_SIZE - 1);
}

HUPU_INT32 nac_app_init_nat_manage(HUPU_VOID)
{
	HUPU_UINT32 i;
	memset(&g_nat_config_st, 0, sizeof(NAC_APP_NAT_CONFIG));
	
	for(i = 0; i < NAT_HASH_MAP_SIZE; i++)
	{
		NAC_INIT_HLIST_HEAD(&nat_hash_by_id[i]);
	}
	
	return HUPU_OK;
}

HUPU_INT32 nac_app_set_auto_nat_found(HUPU_UINT8 flag)
{
	HUPU_UINT32 err = 0;
	//flag: NAC_DISABLE, NAC_ENABLE.
	err = nac_set_data_to_knl(NAC_CMD_SYS_SET_NAT_SWIT, flag, NULL, 0);	
    if (err != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "set auto_nat found %s--err=%d\n",
                        ((flag == 1)?("enable"):("disable")), err);
    }

	return err;
}

static HUPU_INT32 nac_app_knl_nat_rmv(HUPU_UINT32 ip)
{
	HUPU_INT32 err = 0;
	struct nac_knl_rbtree_entry nat_ety;
    memset(&nat_ety, 0, sizeof(struct nac_knl_rbtree_entry));
	
    nat_ety.type = NAC_KNL_RBTREE_NAT_SERVER;
    nat_ety.union_rbtree.ip.ip_min = ip;
    nat_ety.union_rbtree.ip.ip_max = ip;

    err = nac_set_data_to_knl(NAC_CMD_RBTREE_RMV, 0, 
							&nat_ety, sizeof(struct nac_knl_rbtree_entry));
    if (err != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "knl_nat rmv--ip=%u.%u.%u.%u--err=%d\n", LIPQUAD(ip), err);
    }
	return err;
}

static HUPU_INT32 nac_app_knl_nat_flush(HUPU_VOID)
{
	HUPU_INT32 err = 0;
    err = nac_set_data_to_knl(NAC_CMD_RBTREE_FLUSH, NAC_KNL_RBTREE_NAT_SERVER, NULL, 0);	
    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "knl_nat flush--err=%d\n", err);
    return err;
}

static HUPU_INT32 nac_app_knl_nat_add(HUPU_VOID *var, HUPU_UINT8 type)
{
	HUPU_INT32 err = 0;
	NAC_APP_NAT *pst_nat;
	HUPU_UINT32 ip;
	struct nac_knl_rbtree_entry nat_ety;

	memset(&nat_ety, 0, sizeof(struct nac_knl_rbtree_entry));
	if (g_nat_config_st.enable == HUPU_DISABLE)
	{
        goto OUT;
	}

    nat_ety.type = NAC_KNL_RBTREE_NAT_SERVER;
	if (type == NAT_MANUAL_ADD)
	{
		pst_nat = (NAC_APP_NAT*)var;
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ip=%u.%u.%u.%u--action=%d\n",
                        LIPQUAD(pst_nat->ip), pst_nat->action);
		if (pst_nat->action == NAT_ALLOW 
			|| pst_nat->action == NAT_FORBID)
		{
			nat_ety.union_rbtree.ip.ip_min = pst_nat->ip;
			nat_ety.union_rbtree.ip.ip_max = pst_nat->ip;
			nat_ety.union_rbtree.ip.isolation_id = pst_nat->action;
        }
	}
	else if (type == NAT_AUTO_ADD)
	{
		ip = *((HUPU_UINT32*)var);
		if (g_nat_config_st.default_action == NAT_ALLOW
			|| g_nat_config_st.default_action == NAT_FORBID)
		{ 
			nat_ety.union_rbtree.ip.ip_min = ip;
			nat_ety.union_rbtree.ip.ip_max = ip;
			nat_ety.union_rbtree.ip.isolation_id = g_nat_config_st.default_action;
		}
	}
	else if (type == NAT_NULL_ADD)
	{
		//note!
	}

    if (nat_ety.union_rbtree.ip.ip_min == 0)
    {    
        goto OUT;
    }

    err = nac_set_data_to_knl(NAC_CMD_RBTREE_INS, 0, &nat_ety, sizeof(struct nac_knl_rbtree_entry));
    if (err != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s knl add nat ip=%u.%u.%u.%u--action=%d----err=%d\n",
                        ((type == NAT_AUTO_ADD)? ("auto"):("manual")), LIPQUAD(nat_ety.union_rbtree.ip.ip_min),
                        nat_ety.union_rbtree.ip.isolation_id, err);
    }
OUT:
	return err;
}

HUPU_INT32 nac_app_knl_nat_manage_flush(HUPU_VOID)
{
	HUPU_UINT32 err = 0;

    //flag: NAC_DISABLE, NAC_ENABLE.
    err = nac_set_data_to_knl(NAC_CMD_SYS_SET_NAT_SWIT, HUPU_DISABLE, NULL, 0);	
    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "set auto_nat found %s--err=%d\n", "disable", err);

    err = nac_set_data_to_knl(NAC_CMD_RBTREE_FLUSH, NAC_KNL_RBTREE_NAT_SERVER, NULL, 0);	
    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "knl_nat flush--err=%d\n", err);

    return HUPU_OK;
}

HUPU_INT32 nac_app_nat_manage_flush(HUPU_VOID)
{
	HUPU_INT32	 err = 0;
	NAC_APP_NAT *pos = HUPU_NULL;
	NAC_APP_NAT *next_pos = HUPU_NULL;

	nac_list_for_each_entry_safe(pos, next_pos, &g_nac_app_nat_list_head, nat_list)
	{
        /*
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%d;%u.%u.%u.%u;%d;%d;%ld;%s",
				pst_nat_tmp->id, LIPQUAD(pst_nat_tmp->ip), pst_nat_tmp->type,
				pst_nat_tmp->action, pst_nat_tmp->up_time, pst_nat_tmp->describe);
		*/
        nac_app_knl_nat_rmv(pos->ip);
		__nac_app_nat_del(0, pos);
	}

    g_nat_config_st.enable = HUPU_DISABLE;
    g_nat_config_st.auto_found = HUPU_DISABLE;
    g_nat_config_st.default_action = NAT_IGNORE;
    g_nat_policy_index = 0;

	return err;
}


static HUPU_INT32 nac_system_upload_log_msg(HUPU_INT32 ui_sock_fd, HUPU_UINT16 cmd,
                                    HUPU_UINT32 ip, HUPU_UINT8 flag)
{
    HUPU_CHAR   xml_cnt_buffer[KB_BUFF_LEN];
    HUPU_UINT16 xml_cnt_len;

    HUPU_CHAR *xml_auto_found_nat_format =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?><nac>"
        "<commandID>%d</commandID>"
        "<actionType>0</actionType>"
        "<warnInfo>auto_nat:%u.%u.%u.%u;%hhd</warnInfo></nac>";

    memset(xml_cnt_buffer, '\0', strlen(xml_cnt_buffer));
    sprintf(xml_cnt_buffer, xml_auto_found_nat_format,
            cmd+100, LIPQUAD(ip), flag);
    xml_cnt_len = strlen(xml_cnt_buffer);
    nac_sys_send_xmlstr_to_webserver(ui_sock_fd, xml_cnt_len,
                                    cmd, xml_cnt_buffer);
    return HUPU_OK;
}

HUPU_INT32 nac_app_nat_add(NAC_APP_NAT* pst_nat)
{
	HUPU_UINT16 hash;
	NAC_APP_NAT *pst_nat_tmp;
	HUPU_INT32  err = 0;

	pst_nat_tmp = (NAC_APP_NAT*)malloc(sizeof(NAC_APP_NAT));
	if (!pst_nat_tmp)
	{
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "malloc error!\n");
		err = HUPU_ERR;
		goto DONE;
	}

	memcpy(pst_nat_tmp, pst_nat, sizeof(NAC_APP_NAT));
	nac_list_add_tail(&pst_nat_tmp->nat_list, &g_nac_app_nat_list_head);

	hash = nac_app_nat_get_hash_by_id(pst_nat_tmp->id);
	nac_hlist_add_head(&pst_nat_tmp->nat_id, &nat_hash_by_id[hash]);

DONE:
	return err;
}

HUPU_INT32 nac_app_auto_nat_list_timeout(HUPU_ULONG32 now)
{
	//time_t timep; time(&timep);
	HUPU_INT32 err = 0;
	NAC_APP_NAT *pos = HUPU_NULL;
	NAC_APP_NAT *next_pos = HUPU_NULL;

	nac_list_for_each_entry_safe(pos, next_pos, &g_nac_app_nat_list_head, nat_list)
	{
		if (pos->type == NAT_AUTO_ADD 
			&& now - pos->up_time >= g_auto_nat_timeout)
		{
		    nac_list_del(&pos->nat_list);
			nac_hlist_del(&pos->nat_id);
            if (pos->action == NAT_ALLOW || pos->action == NAT_FORBID)
            {
                nac_app_knl_nat_rmv(pos->ip);
            }
            //upload the timeout del nat_ip
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "upload del-->ip=%u.%u.%u.%u\n", LIPQUAD(pos->ip));
            nac_system_upload_log_msg(gi_link_fd, SYS_WEBUI_UPLOAD_WARN_INFO, pos->ip, 0);
            free(pos);	
		}
	}

	return err;
}

static HUPU_INT32 __nac_app_auto_nat_add(HUPU_UINT32 ip, HUPU_UINT8 *flag)
{
	HUPU_INT32	err = 0;
	NAC_APP_NAT *pos = HUPU_NULL;
	NAC_APP_NAT *next_pos = HUPU_NULL;
	NAC_APP_NAT nat_st_tmp;
    HUPU_UINT8  flag_tmp = 0;//0:add; 1:unchange; 2:change;

	time_t timep;
	nac_list_for_each_entry_safe(pos, next_pos, &g_nac_app_nat_list_head, nat_list)
	{
		if (pos->ip == ip)
		{
			time(&timep);
			pos->up_time = timep;
			flag_tmp = 1;
			if (pos->type == NAT_AUTO_ADD)
			{
				//auto_find default action have change
                if (pos->action != g_nat_config_st.default_action)
                { 
                    pos->action  = g_nat_config_st.default_action;
					flag_tmp = 2;
                }
			}
			err = HUPU_OK;
			goto DONE;
		}
	}

	g_nat_policy_index = g_nat_policy_index + 1;
	nat_st_tmp.id	= g_nat_policy_index;
	nat_st_tmp.type	= NAT_AUTO_ADD;
	nat_st_tmp.action = g_nat_config_st.default_action;
	nat_st_tmp.ip = ip;

	time(&timep);
	nat_st_tmp.up_time = timep;

	err = nac_app_nat_add(&nat_st_tmp);
	if (err == HUPU_ERR)
	{
		g_nat_policy_index = g_nat_policy_index - 1;
        goto DONE;
	}

    //upload auto_find  nat_ip
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "upload_add-->ip=%u.%u.%u.%u\n", LIPQUAD(ip));
    nac_system_upload_log_msg(gi_link_fd, SYS_WEBUI_UPLOAD_WARN_INFO, ip, 1);
DONE:
    *flag = flag_tmp;
	return err;
}

HUPU_INT32 nac_app_debug_show_nat_manage_list(FILE* fp)
{
	HUPU_CHAR max_cnt[MID_BUFF_LEN];
	NAC_APP_NAT *pos = HUPU_NULL, *next_pos = HUPU_NULL;
    fputs("#id ip type(auto=0/manual=1) action(ignore=0/allow=1/forbid=2) up_time describe\n", fp);
	nac_list_for_each_entry_safe(pos, next_pos, &g_nac_app_nat_list_head, nat_list)
	{
		memset(max_cnt, '\0', sizeof(MID_BUFF_LEN));
        sprintf(max_cnt, "%d;%u.%u.%u.%u;%d;%d;%ld;%s\n",
                pos->id, LIPQUAD(pos->ip), pos->type,
                pos->action, pos->up_time, pos->describe);
        fputs(max_cnt, fp);
        //SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s\n", max_cnt);
	}
	return HUPU_OK;
}

HUPU_INT32 nac_app_save_nat_manage_list(FILE* fp)
{
    HUPU_UINT16 hash;
    struct nac_hlist_node *pos, *n;
    NAC_APP_NAT *pst_nat_tmp = HUPU_NULL;

    for (hash = 0; hash < NAT_HASH_MAP_SIZE; hash++)
    {
        nac_hlist_for_each_entry_safe(pst_nat_tmp, pos, n, &nat_hash_by_id[hash], nat_id)
        {
            if (pst_nat_tmp->type == NAT_MANUAL_ADD)
            {
                fprintf(fp, "%d %u.%u.%u.%u %d %s\n", pst_nat_tmp->id,
                        LIPQUAD(pst_nat_tmp->ip), pst_nat_tmp->action,
                        pst_nat_tmp->describe);
            }
        }
    }

    return HUPU_OK;
}

NAC_APP_NAT* __nac_app_nat_find_by_id(HUPU_UINT16 id)
{
	HUPU_UINT16 hash;
	struct nac_hlist_node *pos, *n;
	NAC_APP_NAT *pst_nat_tmp = HUPU_NULL;
	
	hash = nac_app_nat_get_hash_by_id(id);
	nac_hlist_for_each_entry_safe(pst_nat_tmp, pos, n, &nat_hash_by_id[hash], nat_id)
    {
        if(pst_nat_tmp->id == id)
        {
            break;
        }
    }
	
	return pst_nat_tmp;
}

NAC_APP_NAT* __nac_app_nat_find_by_ip(HUPU_UINT32 ip)
{
	NAC_APP_NAT *pos = HUPU_NULL;
	NAC_APP_NAT *next_pos = HUPU_NULL;
	NAC_APP_NAT *pst_nat_tmp = HUPU_NULL;

	nac_list_for_each_entry_safe(pos, next_pos, &g_nac_app_nat_list_head, nat_list)
	{
		if (pos->ip == ip && pos->action == g_nat_config_st.default_action)
		{
            pst_nat_tmp = pos;
            break;
		}
	}

    return pst_nat_tmp;
}

HUPU_INT32 nac_sys_netlink_found_nat(NAC_KNL_USER_MSG *netlink_usr_msg)
{
    HUPU_INT32 err = 0;
    HUPU_UINT32 nat_ip = 0;
    nat_ip = netlink_usr_msg->src_ip;
    HUPU_UINT8 find_flag = 0;//0:add; 1:unchange; 2:change;
    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ip=%u.%u.%u.%u\n", LIPQUAD(nat_ip));
    err = __nac_app_auto_nat_add(nat_ip, &find_flag);
    if (err == HUPU_ERR || find_flag == 1)
    {
        err = HUPU_OK;
        goto OUT;
    }

    if (err == HUPU_OK)
    {
        //before update knl_nat, must remove nat_ip;
        nac_app_knl_nat_rmv(nat_ip);
        err = nac_app_knl_nat_add(&nat_ip, NAT_AUTO_ADD);
    }
OUT:
    return err;
}

HUPU_INT32 __nac_app_nat_modify(NAC_APP_NAT* pst_nat)
{
	HUPU_INT32	err = 0;
	NAC_APP_NAT *pst_nat_tmp = HUPU_NULL;
	pst_nat_tmp = __nac_app_nat_find_by_id(pst_nat->id);
	if (pst_nat_tmp == HUPU_NULL)
	{
		err = HUPU_ERR;
		goto DONE;
	}
	
	pst_nat_tmp->ip = pst_nat->ip;
	pst_nat_tmp->action = pst_nat->action;
	memset(pst_nat_tmp->describe, '\0', MAX_COMMENT_LEN);
	memcpy(pst_nat_tmp->describe, pst_nat->describe, MAX_COMMENT_LEN);
DONE:
	return err;
}

HUPU_INT32 nac_app_nat_modify(HUPU_UINT16 id, NAC_APP_NAT* pst_nat)
{
	HUPU_INT32  err = 0;
	NAC_APP_NAT *pst_nat_tmp;
	pst_nat_tmp = __nac_app_nat_find_by_id(id);
	if (!pst_nat_tmp)
	{
		err = HUPU_ERR;
		goto DONE;
	}

	err = nac_app_knl_nat_rmv(pst_nat_tmp->ip);

	pst_nat_tmp->ip = pst_nat->ip;
    pst_nat_tmp->type = NAT_MANUAL_ADD;
	pst_nat_tmp->action = pst_nat->action;
	memset(pst_nat_tmp->describe, '\0', MAX_COMMENT_LEN);
	memcpy(pst_nat_tmp->describe, pst_nat->describe, MAX_COMMENT_LEN);

	if (pst_nat_tmp->action == NAT_ALLOW
		|| pst_nat_tmp->action == NAT_FORBID)
	{
		err = nac_app_knl_nat_add(pst_nat_tmp, NAT_MANUAL_ADD);
	}
	
DONE:
	return err;
}

HUPU_INT32 __nac_app_nat_del(HUPU_UINT16 id, NAC_APP_NAT *pst_nat)
{
	NAC_APP_NAT *pst_nat_tmp;
	if (id)
	{
		pst_nat_tmp = __nac_app_nat_find_by_id(id);
	}
	else
	{
		pst_nat_tmp = pst_nat;
	}
	
	if(!pst_nat_tmp)
	{
		goto OUT;
	}
	nac_list_del(&pst_nat_tmp->nat_list);
	nac_hlist_del(&pst_nat_tmp->nat_id);
	free(pst_nat_tmp);	
OUT:	
	return HUPU_OK;
}

HUPU_INT32 nac_app_nat_del(HUPU_UINT16 id)
{
	HUPU_INT32  err = 0;
	NAC_APP_NAT *pst_nat_tmp;
	pst_nat_tmp = __nac_app_nat_find_by_id(id);
	if (pst_nat_tmp)
	{
	    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%d;%u.%u.%u.%u;%d;%d;%ld;%s\n",
				pst_nat_tmp->id, LIPQUAD(pst_nat_tmp->ip), pst_nat_tmp->type,
				pst_nat_tmp->action, pst_nat_tmp->up_time, pst_nat_tmp->describe);
        err = nac_app_knl_nat_rmv(pst_nat_tmp->ip);
        if (err == HUPU_OK)
        {
            __nac_app_nat_del(0, pst_nat_tmp);
        }
	}
	else
	{
		err = HUPU_ERR;
	}

	return err;
}

static xmlDocPtr nac_sys_get_nat_manage_list(HUPU_UINT16 command_id)
{
    xmlDocPtr  doc;
    xmlNodePtr root_node;
	HUPU_CHAR xml_min_cnt[MIN_BUFF_LEN] = "";
	HUPU_CHAR xml_max_cnt[MID_BUFF_LEN] = "";
	
	NAC_APP_NAT *pos = HUPU_NULL;
	NAC_APP_NAT *next_pos = HUPU_NULL;
    
    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

	
	sprintf(xml_min_cnt, "%d", (command_id + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST xml_min_cnt);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");
	nac_list_for_each_entry_safe(pos, next_pos, &g_nac_app_nat_list_head, nat_list)
	{
		memset(xml_max_cnt, '\0', sizeof(xml_max_cnt));
		sprintf(xml_max_cnt, "%d;%u.%u.%u.%u;%d;%d;%ld;%s",
				pos->id, LIPQUAD(pos->ip), pos->type,
				pos->action, pos->up_time, pos->describe);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "natItem", BAD_CAST xml_max_cnt);
	}
	
    return doc;
}

xmlDocPtr nac_system_parse_nat_manage_list(xmlDocPtr doc, HUPU_UINT16 cmd_id) 
{
	HUPU_INT32	iRet, error_id;
	xmlDocPtr	nac_doc = HUPU_NULL;
	xmlNodePtr	cur_node;
	xmlChar 	*xml_value, *xml_attr;
	HUPU_UINT8	action_type;
    NAC_APP_NAT nat_item_tmp;
	HUPU_CHAR	ip_str[IP_STR_LEN];
	HUPU_UINT16 policy_index = 0;
	
	/*actionType mark is NULL or not!*/
	cur_node = nac_xml_parse_get_action(doc, &action_type);
	if (cur_node == HUPU_NULL)
	{
		nac_free_xmlDoc(doc);
		return HUPU_NULL;
	}
	
	error_id = 0;
	switch (action_type)
	{
	case NAC_SHOW:
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_get_nat_manage_list(cmd_id);
		break;

	case NAC_ADD:
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "natItem")))
			{
				memset(&nat_item_tmp, '\0', sizeof(NAC_APP_NAT));
				xml_value = xmlNodeGetContent(cur_node);
				iRet = sscanf((HUPU_CHAR*)xml_value, "%[^;];%hhd;%s", ip_str,
						&nat_item_tmp.action, nat_item_tmp.describe);
                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "NAC_ADD----%s--%hhd--%s\n",ip_str,
                        nat_item_tmp.action, nat_item_tmp.describe);
				xmlFree(xml_value);
				g_nat_policy_index = g_nat_policy_index + 1;
				nat_item_tmp.id   = g_nat_policy_index;
				nat_item_tmp.type = NAT_MANUAL_ADD;
				nat_item_tmp.ip   = inet_network(ip_str);

		        error_id = nac_app_knl_nat_add(&nat_item_tmp, NAT_MANUAL_ADD);
                if (error_id != HUPU_OK)
                {
                    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "add nat_item %s--%hhd--%s--%d\n",
                        ip_str, nat_item_tmp.action, nat_item_tmp.describe, error_id);
                    error_id = NAC_SYS_ERROR_ADD_NAT_FAIL;
                    break;
                }
    	        nac_app_nat_add(&nat_item_tmp);
			}
			cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;
		
	case NAC_DEL:
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "natItem"))
				&& xmlHasProp(cur_node, BAD_CAST "id"))
			{
				policy_index = 0;
				xml_attr = xmlGetProp(cur_node, BAD_CAST "id");
				policy_index = atoi((HUPU_CHAR*)xml_attr);
				xmlFree(xml_attr);
				if (policy_index)
				{
					error_id = nac_app_nat_del(policy_index);
				}
				
				if (error_id != HUPU_OK)
				{
					SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS,
									"del nat_item id=%d--err=%d", policy_index, error_id);
                    error_id = NAC_SYS_ERROR_DEL_NAT_FAIL;
					break;
				}
				
			}
			cur_node = cur_node->next;	
		}
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;
		
	case NAC_MODIFY:
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "natItem"))
				&& xmlHasProp(cur_node, BAD_CAST "id"))
			{
				memset(&nat_item_tmp, '\0', sizeof(NAC_APP_NAT));
				xml_attr = xmlGetProp(cur_node, BAD_CAST "id");
				policy_index = atoi((HUPU_CHAR*)xml_attr);
				xmlFree(xml_attr);

				xml_value = xmlNodeGetContent(cur_node);
				iRet = sscanf((HUPU_CHAR*)xml_value, "%[^;];%hhd;%s", ip_str,
						&nat_item_tmp.action, nat_item_tmp.describe);
				xmlFree(xml_value);

                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "NAC_MODIFY--index=%d-----%s--%hhd--%s--%d\n",
                                policy_index, ip_str, nat_item_tmp.action, nat_item_tmp.describe, iRet);
				nat_item_tmp.ip = inet_network(ip_str);
                error_id = nac_app_nat_modify(policy_index, &nat_item_tmp);
                if (error_id != HUPU_OK)
                {
                    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "modify nat_item %d--%s--%hhd--%s--err=%d\n",
                                    policy_index, ip_str, nat_item_tmp.action, nat_item_tmp.describe, error_id); 
                    error_id = NAC_SYS_ERROR_MODIFY_NAT_FAIL;
                    break;
                }
			}
			cur_node = cur_node->next;	
		}
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;
		
	default:
		nac_free_xmlDoc(doc);
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
		break;
	}
	return nac_doc;
}

//######################################################################
HUPU_INT32 nac_system_deal_nat_manage_switch(HUPU_CHAR flag)
{
	NAC_APP_NAT *pos = HUPU_NULL;
	NAC_APP_NAT *next_pos = HUPU_NULL;

	if (flag == -1)
	{
		return HUPU_OK;
	}

	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "enable=%d--flag=%d\n", g_nat_config_st.enable, flag); 
	if (g_nat_config_st.enable == HUPU_ENABLE && flag == HUPU_DISABLE)
	{
        //enable-->disable
        nac_app_knl_nat_flush();
        g_nat_config_st.enable = flag;
	}
	else if(g_nat_config_st.enable == HUPU_DISABLE && flag == HUPU_ENABLE)
	{
        //disable--enable
        g_nat_config_st.enable = flag;
        nac_list_for_each_entry_safe(pos, next_pos, &g_nac_app_nat_list_head, nat_list)
		{
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ip=%u.%u.%u.%u--type=%d--action=%d\n",
                LIPQUAD(pos->ip), pos->type, pos->action);
			if (pos->action == NAT_ALLOW
				|| pos->action == NAT_FORBID)
			{
				nac_app_knl_nat_add(pos, NAT_MANUAL_ADD);
			}
		}
	}
	return HUPU_OK;
}

static xmlDocPtr nac_system_get_nat_manage_config(HUPU_UINT16 command_id)
{
    xmlDocPtr  doc;
    xmlNodePtr root_node;
	HUPU_CHAR xml_min_cnt[MIN_BUFF_LEN] = "";
	//HUPU_CHAR xml_max_cnt[SMALL_BUFF_LEN] = "";

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

	sprintf(xml_min_cnt, "%d", (command_id + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST xml_min_cnt);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");

    memset(xml_min_cnt, '\0', sizeof(xml_min_cnt));
    sprintf(xml_min_cnt, "%d", g_nat_config_st.enable);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "natSwitch", BAD_CAST xml_min_cnt);

    memset(xml_min_cnt, '\0', sizeof(xml_min_cnt));
    sprintf(xml_min_cnt, "%d;%d", g_nat_config_st.auto_found, g_nat_config_st.default_action);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "autoFoundConfig", BAD_CAST xml_min_cnt);

    return doc;
}

xmlDocPtr nac_system_parse_nat_manage_config(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_INT32  iRet, error_id;
	xmlDocPtr	nac_doc = HUPU_NULL;
	xmlNodePtr	cur_node;
	xmlChar     *xml_value;
	HUPU_UINT8	action_type;
	HUPU_CHAR   nat_switch_tmp = -1;

	/*actionType mark is NULL or not!*/
	cur_node = nac_xml_parse_get_action(doc, &action_type);
	if (cur_node == HUPU_NULL)
	{
		nac_free_xmlDoc(doc);
		return HUPU_NULL;
	}

	error_id = 0;
	switch (action_type)
	{
	case NAC_SHOW:
		nac_free_xmlDoc(doc);
		nac_doc = nac_system_get_nat_manage_config(cmd_id);
		break;
	case NAC_ADD:
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "natSwitch")))
			{
				xml_value = xmlNodeGetContent(cur_node);
				nat_switch_tmp = atoi((HUPU_CHAR*)xml_value);
                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "natSwitch----%d----\n", nat_switch_tmp);
				xmlFree(xml_value);
			}
			else if (!(xmlStrcmp(cur_node->name, BAD_CAST "autoFoundConfig")))
			{
				xml_value = xmlNodeGetContent(cur_node);
				iRet = sscanf((HUPU_CHAR*)xml_value, "%hhd;%hd",
					&g_nat_config_st.auto_found,
					&g_nat_config_st.default_action);
                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "autoFoundConfig----%d--%d--%d\n", 
                                g_nat_config_st.auto_found, g_nat_config_st.default_action, iRet);
				//open or close knl auto_nat_found switch
				nac_app_set_auto_nat_found(g_nat_config_st.auto_found);
				xmlFree(xml_value);
			}
			cur_node = cur_node->next;
		}	
		nac_system_deal_nat_manage_switch(nat_switch_tmp);
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

	default:
		nac_free_xmlDoc(doc);
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
		break;
	}
	return nac_doc;
}

#if 0
static HUPU_INT32 nac_app_auto_nat_add_knl(HUPU_UINT32 ip)
{
	HUPU_INT32 err;
	err = 0;
	if (g_nat_config_st.enable == HUPU_ENABLE
		//&& g_nat_config_st.auto_found == HUPU_ENABLE
		&&(g_nat_config_st.default_action == NAT_ALLOW
		|| g_nat_config_st.default_action == NAT_FORBID))
	{
		//err = nac_app_send_to_knl();
	}
	
	return err;
}
static HUPU_INT32 nac_app_auto_nat_add(HUPU_UINT32 ip)
{   
    HUPU_INT32 err = 0;
    err = nac_app_knl_nat_add(&ip, NAT_AUTO_ADD);
    if (err != HUPU_OK)
    {
        goto OUT;
    }
    err = __nac_app_auto_nat_add(ip);
OUT:
    return err;
}
#endif
