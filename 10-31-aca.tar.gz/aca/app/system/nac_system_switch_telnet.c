#include "nac_precomp.h" //nac_list.h
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_common_lib.h"
#include "nac_system_errorlog.h"
#include "nac_system_switch_main.h"
#include "nac_system_switch_telnet.h"


xmlDocPtr nac_system_test_switch_telnet_control(NAC_SYSTEM_SWITCH* pst_switch)
{
	xmlDocPtr doc = HUPU_NULL;
	return doc;
}

HUPU_INT32 nac_system_add_switch_telnet_control(NAC_SYSTEM_SWITCH* pst_switch)
{
	return HUPU_OK;
}

HUPU_INT32 nac_system_modify_switch_telnet_control(NAC_SYSTEM_SWITCH* pst_switch)
{
	return HUPU_OK;
}

///////////////////////////////////////////////////////////////////////////////////////////

HUPU_INT32 nac_system_switch_send(HUPU_UINT32 ui_fd, HUPU_CHAR *pc_buffer_cmd)
{
    //HUPU_UINT32 ui_len;
    HUPU_INT32 iRet;
    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "nac_system_switch_send cmd = %s\n", pc_buffer_cmd);
    iRet = write(ui_fd, pc_buffer_cmd, strlen(pc_buffer_cmd));
    if(iRet <= 0)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "--%d--%s--> error, ui_fd = %d\n", __LINE__, __FUNCTION__, ui_fd);
    }

	return HUPU_OK;
}

HUPU_INT32 nac_system_switch_recv(HUPU_UINT16 switch_id, HUPU_UINT32 ui_fd, HUPU_CHAR *pc_buffer, HUPU_UINT32 ui_len)
{
    HUPU_CHAR ac_buff[100];
    memset(ac_buff, '\0', sizeof(ac_buff));
    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"nac_system_switch_recv--->%s, ui_len = %u\n", pc_buffer, ui_len);

	if(strstr(pc_buffer, "Username:"))//login switch
    {
        memcpy(ac_buff, "h3c\r\nh3c\r\nsystem-view\r\n",strlen("h3c\r\nh3c\r\nsystem-view\r\n"));
        nac_system_switch_send(ui_fd, ac_buff);
        nac_system_modify_switch_status(switch_id, 0, NAC_SYSTEM_SWITCH_CONNECT_OK);
    }
    else if(strstr(pc_buffer, "% Login"))
    {
        nac_system_modify_switch_status(switch_id, 0, NAC_SYSTEM_SWITCH_NAME_OR_PASS_ERROR);
        return HUPU_ERR;
        //send xml to web error for uname or pass error
    }
    else if(strstr(pc_buffer, "% aaaaaaaaaaa"))
    {
        //send xml to web error for uname or pass error
    }
    else
    {
        //memcpy(ac_buff, "system-view",strlen("system-view"));
        //nac_system_switch_send_cmd(test_fd, ac_buff);
    }
    return HUPU_OK;
}

static HUPU_INT32 nac_system_switch_connect(NAC_SYSTEM_SWITCH *pst_msg)
{
    HUPU_INT32 iRet, ui_switch_fd, ui_max_fd;
    //HUPU_INT32 recvlen;
    HUPU_CHAR ac_buffer_recv[1024];
    struct timeval st_timeout;
    fd_set readfd;
    fd_set writefd;

    ui_switch_fd = nac_tcp_crt_cli();
    if(ui_switch_fd < 0)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "--%d--%s-->error, ui_switch_fd = %d\n", __LINE__, __FUNCTION__, ui_switch_fd);
        return HUPU_ERR;
    }
    iRet = nac_tcp_connect(ui_switch_fd, pst_msg->switch_ip, pst_msg->connect_port);
    if(iRet != 0)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"error--%d--%s-->error, iRet = %d\n", __LINE__, __FUNCTION__, iRet);
        return HUPU_ERR;
    }

	//default set login fault
	nac_system_modify_switch_status(pst_msg->switch_id, ui_switch_fd, NAC_SYSTEM_SWITCH_NAME_OR_PASS_ERROR);

    ui_max_fd = MAX_3(0, 0, ui_switch_fd);
    while(1)
    {
        // ���ó�ʱʱ��5��
    	st_timeout.tv_sec	= 5;
    	st_timeout.tv_usec	= 0;

        FD_ZERO(&readfd);
        FD_ZERO(&writefd);
        FD_SET(ui_switch_fd, &readfd);
        iRet = select(ui_max_fd + 1,
                      &readfd,
                      &writefd,
                      HUPU_NULL,
                      &st_timeout);

        if(HUPU_ERR == iRet)
        {
            if(errno == EINTR)
            {
                continue;
            }
            return HUPU_ERR;
        }

        if(FD_ISSET(ui_switch_fd, &readfd) > 0)
        {
            memset(ac_buffer_recv, '\0', sizeof(ac_buffer_recv));
            iRet = read(ui_switch_fd, ac_buffer_recv, sizeof(ac_buffer_recv));
            if(iRet <= 0)
            {
                close(ui_switch_fd);
                nac_system_modify_switch_status(pst_msg->switch_id, 0, NAC_SYSTEM_SWITCH_CONNECT_CLOSE);
                nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->close, error = %s\n",
                              __FUNCTION__, strerror(errno));
                return HUPU_ERR;
            }
            else if(iRet == 1)
            {
                continue;
            }
            else
            {
                iRet = nac_system_switch_recv(pst_msg->switch_id, ui_switch_fd, ac_buffer_recv, iRet);
                if(iRet != HUPU_OK)
                {
                    close(ui_switch_fd);
                    return HUPU_ERR;
                }
            }
        }
    }
    return HUPU_ERR;
}


HUPU_VOID nac_system_switch_tcp_connect_thread_enter(HUPU_CHAR *pc_buf)
{
    HUPU_INT32 iRet;

    NAC_SYSTEM_SWITCH *pst_msg = (NAC_SYSTEM_SWITCH *)pc_buf;
    iRet = nac_system_switch_connect(pst_msg);
    if(iRet == HUPU_ERR)
    {
        //send error xml to web
    }

    free(pc_buf);
	//pthread exit--2014-06-11;
    pthread_detach(pthread_self());
    return;
}

/*
HUPU_INT32 nac_system_switch_create_thread(NAC_SYSTEM_SWITCH *pst_switch)
{
    NAC_SYSTEM_SWITCH *pst_switch_tmp;
    HUPU_INT32 iRet;
    pthread_t id;

    pst_switch_tmp = (NAC_SYSTEM_SWITCH *)malloc(sizeof(NAC_SYSTEM_SWITCH));
    if(HUPU_NULL == pst_switch_tmp)
    {
        return HUPU_ERR;
    }
    memcpy(pst_switch_tmp, pst_switch, sizeof(NAC_SYSTEM_SWITCH));

    iRet = pthread_create(&id,
                          HUPU_NULL,
                          (HUPU_VOID *)nac_system_switch_thread_enter,
                          pst_switch_tmp);
    if(HUPU_OK != iRet)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "\nnac_system:nac_system_switch_create_thread->pthread_create error, iRet = %d, errno = %d, error info = %s\n", iRet, errno, strerror(errno));
        free(pst_switch_tmp);
        return iRet;
    }
    return HUPU_OK;
}
*/

HUPU_VOID test_switch()
{
    NAC_SYSTEM_SWITCH st_switch;
    st_switch.switch_ip = 168428232;
    //st_switch.connect_port = 23;
    st_switch.switch_status = NAC_SYSTEM_SWITCH_CONNECT_CLOSE;
    st_switch.switch_id = 8;

    nac_system_add_switch(&st_switch);
    nac_system_switch_create_thread(&st_switch);
}









