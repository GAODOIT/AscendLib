/*******************************************************************************
* Copyright (C) 2013, 上海互普信息安全技术股份有限公司
* All rights reserved.
* 产品号 :
* 所属组件 :
* 模块名称 :
* 文件名称 : appCmdDefine.h
* 概要描述 : 应用层命令码定义。
*
* 历史记录 :
* 版本      日期 2013-11-30       作者 YDH   内容
*
******************************************************************************/
#ifndef NAC_APP_CMD_DEFINE_H
#define NAC_APP_CMD_DEFINE_H

#ifdef __cplusplus
extern "C" {
#endif

/*用户管理模块命令码定义， 命令吗范围0x1000到0x2000*/
typedef enum
{
    /*用户登录消息：包括客户端以及web用户*/
    USER_COMMAND_LOGIN                     =  0x1000,
    /*修改sslvpn用户udp端口*/
    USER_COMMAND_GET_SSLVPN_PORT           =  0x1001,
    /*用户注销消息*/
    USER_COMMAND_LOGOUT                    =  0x1002,
    /*用户修改密码*/
    USER_COMMAND_CHANGE_PASSWD,
    /*用户保活消息*/
    USER_COMMAND_KEEP_ALIVE,
    /*增加虚拟VLAN用户消息*/
    USER_COMMAND_ADD_VLAN,
    /*删除虚拟VLAN用户消息*/
    USER_COMMAND_RMV_VLAN,
    /*更新虚拟VLAN用户*/
    USER_COMMAND_UPDATE_VLAN,              //0x1007
    //通知客户端更新策略
    USER_COMMAND_UPDATE_POLICY,
    //客户端策略检查通过
    USER_COMMAND_CLIENT_CHECK_POLICY_PASS, //0x1009
    //客户端策略检查失败
    USER_COMMAND_CLIENT_CHECK_POLICY_FAIL,//0x100a
    /*禁用用户消息*/
    USER_COMMAND_DISABLE,
    /*解禁用户消息*/
    USER_COMMAND_ENABLE,
    /*客户端全局配置通知消息*/
    USER_COMMAND_CLIENT_CONFIG,
     /*授权的用户数目消息*/
    USER_COMMAND_GET_LICENSE_MAX_NUM,
    /*获取网关配置的客户端相关信息*/
    USER_COMMAND_CLIENT_GET_CONFIG,  //0x100f
    USER_COMMAND_CLIENT_AUTO_AUTH,   //客户端自动认证
    /*更新虚拟VLAN用户(ip vlan策略)*/
    USER_COMMAND_UPDATE_VLAN_REL_IP_EX,  //0x1011



    /*与系统管理模块的消息类型*/

    //获取非IP/MAC用户信息
    USER_CHECK_GET_USER_INFO                =  0x1020,
    //删除配置用户
    USER_CHECK_DEL_CONFIG_USER_INFO         =  0x1021,

    //获取IP/MAC用户信息
    USER_CHECK_GET_IP_MAC_USER_INFO         =  0x1022,
    //获取网段用户信息
    USER_CHECK_GET_NET_USER_INFO            =  0x1023,
    //添加系统模块用户
    USER_CHECK_ADD_SYS_USER                 =  0x1024,
    USER_CHECK_ADD_USER_TC                  =  0x1025,
    USER_CHECK_DEL_USER_TC                  =  0x1026,
    /*系统管理模块策略更新消息*/
    USER_CHECK_POLICY_NOTIFY_USER_INFO      =  0x1027,

    /*强制用户下线*/
    USER_CHECK_FORCE_USER_OFFLINE_INFO      =  0x1028,
    /*修改用户属性*/
    USER_CHECK_MODIFY_USER_ATTRIBUTE        =  0x1029,
    /*通知客户端用户下载客户端程序*/
    USER_CHECK_NOTIFY_USER_DOWN_PROGRAM     =  0x1030,
    /*获取在线用户个数*/
    USER_CHECK_GET_ONLINE_USER_NUM			= 0x1031,

    /*动态vlan信息*/
    USER_CHECK_ADD_DYNAMIC_IP_MAC_INFO   	= 0x1032,
    USER_CHECK_RMV_DYNAMIC_IP_MAC_INFO   	= 0x1033,
    USER_ADD_IP_MAC_INFO   	                = 0x1034,

    /*与内核模块通信的消息类型  待内核确定*/
} USER_CHECK_COMMAND_TYPE;

/*系统管理模块命令码定义，命令吗范围0x2001到0x4000*/
/*内核模块命令码定义，命令吗范围0x4001到0x5000*/

/*
系统管理子系统与WEB UI之间命令码的定义：100-200;
通信返回结果的命令码:请求的命令+100;
*/
typedef enum
{
    SYS_WEBUI_NAC_MODE      = 100,
    SYS_WEBUI_REDIRECT_URL,		//101
    SYS_WEBUI_VLANTAG_MAP,		//102
    SYS_WEBUI_USER_AUTH,		//103
    SYS_WEBUI_NETAPP_CHECK,		//104
    SYS_WEBUI_EXCEPT_TERMINAL,	//105
    SYS_WEBUI_EXCEPT_SERVER,	//106
    SYS_WEBUI_EXCEPT_DOMAIN,	//107
    SYS_WEBUI_NAT_DETECT,		//108
    SYS_WEBUI_DEAL_SYS_CONFIG,	//109
    SYS_WEBUI_GET_HARDWARE_ID,	//110

    SYS_WEBUI_SET_IFCONFIG,		//111
    SYS_WEBUI_SET_GATEWAY,		//112
    SYS_WEBUI_SET_DNS,			//113
    SYS_WEBUI_SHUT_OR_BOOT,		//114
    SYS_WEBUI_PBR_SET_ONEIN_ONEOUT,	//115
    SYS_WEBUI_PBR_GET_NEXTHOP_MAC,	//116
    SYS_WEBUI_GET_CONTROLLER_LINK_STATUS,//117
    SYS_WEBUI_SET_SAFE_ZONE,			//118
    SYS_WEBUI_SET_ISOLATE_IPZONE,		//119
    SYS_WEBUI_SET_ISOLATE_DOMAINZONE,	//120
    SYS_WEBUI_SET_SYS_TIME,				//121
	SYS_WEBUI_GET_SYS_STATUS,			//122
	SYS_WEBUI_SET_SYS_LANG,				//123
	SYS_WEBUI_USER_NETAPP_STATUS,		//124
	SYS_WEBUI_SET_SWITCH_CONTROL,		//125
	SYS_WEBUI_SET_ARP_MONITOR_PORT,		//126
	SYS_WEBUI_DEAL_LICENSE_INFO,  		//127
	SYS_WEBUI_SET_ASC_ENABLE_FLAG,		//128
	SYS_WEBUI_ADVANCED_DEBUG_SWITCH,	//129
    SYS_WEBUI_WARN_LOG_CONFIG,          //130
    SYS_WEBUI_UPLOAD_WARN_INFO,			//131
    SYS_WEBUI_ESCAPE_ENABLE_FLAG,		//132
    SYS_WEBUI_UPLOAD_ESCAPE_MODE,		//133
    SYS_WEBUI_NAT_MANAGE_CONFIG,		//134
    SYS_WEBUI_NAT_MANAGE_LIST,			//135
    SYS_WEBUI_EXCEPTAPP_CONFIG,			//136
    SYS_WEBUI_DHCP_MANAGE_CONFIG,       //137
    SYS_WEBUI_HA_BACKUP_CONFIG,         //138
    SYS_WEBUI_HA_BACKUP_SYNC,           //139 //140
    SYS_WEBUI_EXCEPT_MAC = 141,         //141
    SYS_WEBUI_DEBUG_CONFIG,             //142
    SYS_WEBUI_NET_TRAFFIC,              //143
    SYS_WEBUI_ASC_IMPORT_DEVICE_INFO=999,//999
	SYS_WEBUI_IDM_CONNECT_ASC_REQUEST=1018,//1018
	/*
	SYS_WEBUI_SET_SWITCH_ADD,
	SYS_WEBUI_SET_SWITCH_RMV,
	SYS_WEBUI_SET_SWITCH_CONNECT,
	SYS_WEBUI_SET_SWITCH_CLOSE,
	SYS_WEBUI_SET_SWITCH_VLAN_ADD,
	SYS_WEBUI_SET_SWITCH_VLAN_REM,
	SYS_WEBUI_QUERY_SWITCH,
	SYS_WEBUI_QUERY_SWITCH_ARP,
	SYS_WEBUI_QUERY_SWITCH_VLAN,
	SYS_WEBUI_QUERY_SWITCH_PROT,
	*/
    ASC_CLIENT_REGISTER		=250,
} SYS_WEBUI_COMMAND_ID;


#ifdef __cplusplus
}
#endif

#endif  // end of NAC_APP_CMD_DEFINE_H
