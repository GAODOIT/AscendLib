#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define NAC_UDP_PORT    6002
#define DATA_SIZE   256


int main(void)
{
	int sock_fd, len;
	struct sockaddr_in addr;
	struct sockaddr_in recv_addr;
	int addr_len = sizeof(struct sockaddr_in);
	int recv_addr_len = sizeof(struct sockaddr_in);
	char buffer[DATA_SIZE];

	
	if ((sock_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
	{
		perror("udp socket!");
		return -1;
	}

	bzero(&addr, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(NAC_UDP_PORT);
	addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	
	/*
	if ((bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0)){  
        perror("connect!");  
        return -1;  
    }*/

	while(1)
	{
		bzero (buffer, sizeof(buffer));
		len = read (STDIN_FILENO, buffer, sizeof(buffer));
		printf ("----%s----%d\n", buffer, len);

		fflush(stdin);
		len  = sendto (sock_fd, buffer, len, 0, (struct sockaddr *)&addr, addr_len);
		if (len < 0){
			perror ("send to error!");
		}
		printf ("--sendto--%d--%s--%d\n", len, inet_ntoa(addr.sin_addr), ntohs(addr.sin_port));

		len = recvfrom (sock_fd, buffer, sizeof(buffer), 0, (struct sockaddr *)&addr, &recv_addr_len);
		printf ("--recvfrom--%d--%s--%d\n", len, inet_ntoa(addr.sin_addr), ntohs(addr.sin_port));

		buffer[len] = '\0';
		printf ("receive: %s\n", buffer);
		if (memcmp(buffer, "quit", 4) == 0)
		{
			break;
		}
	}

	close (sock_fd);
	return 0;
}
