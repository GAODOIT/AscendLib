#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define NAC_UDP_PORT	6002
#define DATA_SIZE	256

int main(void)
{
	int sock_fd,len;
	struct sockaddr_in serv_add;
	struct sockaddr_in client_add;
	time_t cur_time;
	char recv_buffer[DATA_SIZE];
	int client_len;
	
	client_len = sizeof(struct sockaddr_in);
	sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (-1 == sock_fd){
		perror("Create udp socket error!");
		return -1;
	}
	printf ("create udp socket %d success!\n", sock_fd);
	
	bzero (&serv_add, sizeof(serv_add));
	serv_add.sin_family = AF_INET;
	serv_add.sin_port = htons(NAC_UDP_PORT);
	serv_add.sin_addr.s_addr = inet_addr("127.0.0.1");
	bzero (&(serv_add.sin_zero), 8);
	
	if (bind(sock_fd, (struct sockaddr *)&serv_add, sizeof(serv_add)) != 0)
	{
		perror ("bind serv_add error!");
		close (sock_fd);
		return -1;
	}
	printf ("bind serv_add success!\n");

	while (1)
	{
		printf ("waiting for connect:\n");
		bzero (recv_buffer, DATA_SIZE);
		len = recvfrom (sock_fd, recv_buffer, DATA_SIZE, 0, (struct sockaddr *)&client_add, &client_len);
		if ( len < 0)
		{
			perror ("recvform error!");
		}
		recv_buffer[len] = '\0';
		printf("receive form %s---recv_buffer[%d] = %s\n", inet_ntoa(client_add.sin_addr), len, recv_buffer);
		
		if (memcmp(recv_buffer, "time", 4) == 0){
			cur_time = time(NULL);
			bzero (recv_buffer, DATA_SIZE);
			strcpy(recv_buffer,	asctime(gmtime(&cur_time)));
		}

		sendto (sock_fd, recv_buffer, sizeof(recv_buffer), 0, (struct sockaddr *)&client_add, client_len);
		if (memcmp(recv_buffer, "quit", 4) == 0)
		{
			break;
		}
	}
	
	close (sock_fd);
	return 0;
}
