#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <libxml/parser.h>
#include <libxml/xmlmemory.h>

#define PORT 1235
#define MAXSOCKFD 10


/*parse XML and show content of 'command_id','url'*/  
int parseXML(xmlDocPtr tmpdoc)  
{  
    /*printf("This is in parseXML\n");*/  
    xmlNodePtr curNode; /*Keep node of the xml tree*/  
    xmlChar *szKey;  
  
    /*Get the root Node from tmpdoc*/  
    curNode = xmlDocGetRootElement(tmpdoc);  
    /*check the content of the document*/  
    if (NULL == curNode)  
    {  
        xmlFreeDoc(tmpdoc);  
        return -3;  
    }  
  
    /*Check the type of the root element*/  
    if(xmlStrcmp(curNode->name,BAD_CAST "nac"))  
    {  
        printf("Document of the wrong type");  
        xmlFreeDoc(tmpdoc);  
        return -4;  
    }  
    curNode = curNode->xmlChildrenNode;  
    xmlNodePtr propNpdePtr =curNode;  
    while (curNode != NULL)  
    {  
        /*compare element nodes,show the content*/  
        if( !(xmlStrcmp(curNode->name,(const xmlChar *) "command_id")))  
        {  
            szKey = xmlNodeGetContent(curNode);  
            printf("command_id: %s\n",szKey);  
            xmlFree(szKey);  
        }  
        else if( !(xmlStrcmp(curNode->name,(const xmlChar *) "url")))  
        {  
            printf("url: %s\n",xmlNodeGetContent(curNode));  
        }  
        /*traverse*/  
        curNode = curNode->next;  
    }  
    xmlFreeDoc(tmpdoc);  
    return 0;  
}

int main (void)
{
	int sockfd, newsockfd, fd;
	int is_connected[MAXSOCKFD];
	struct sockaddr_in addr;
	int addr_len = sizeof(struct sockaddr_in);
	fd_set readfds;
	char buffer[256];
	char msg[] = "Welcome to server!";
	
	xmlDocPtr doc;
	
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("socket");
		return -1;
	}
	printf ("socket--sockfd = %d\n", sockfd);
	
	bzero (&addr, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(PORT);
	//addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	
	if (bind(sockfd, (struct sockaddr *)&addr, sizeof(addr)) < 0)
	{
		perror("connect");
		return -1;
	}
	printf ("bind--sockfd = %d\n", sockfd);

	if (listen(sockfd, 3) < 0)
	{
		perror("listen");
		return -1;
	}
	printf ("listen--sockfd = %d\n", sockfd);
	
	for (fd = 0; fd < MAXSOCKFD; fd++)
	{
		is_connected[fd] = 0;
	}

	while(1)
	{
		FD_ZERO (&readfds);
		FD_SET (sockfd, &readfds);
		printf ("while--sockfd = %d\n", sockfd);
		
		for (fd = 0; fd < MAXSOCKFD; fd++)
		{
			if (is_connected[fd])
			{
				FD_SET (fd, &readfds);
			}
		}
		
		if (!select(MAXSOCKFD, &readfds, NULL, NULL, NULL)){
			continue;
		}
		
		for (fd = 0; fd < MAXSOCKFD; fd++)
		{
			if (FD_ISSET(fd, &readfds))
			{
				if (sockfd == fd)
				{
					if ((newsockfd = accept (sockfd, (struct sockaddr *)&addr, &addr_len)) < 0)
					{
						perror ("accept");
					}
					write (newsockfd, msg, sizeof(msg));
					is_connected[newsockfd] = 1;
					printf ("%d----connect from %s\n",newsockfd, inet_ntoa(addr.sin_addr));
				}
				else{
					bzero (buffer, sizeof(buffer));
					if (read(fd, buffer, sizeof(buffer)) <= 0)
					{
						printf ("connect closed.\n");
						is_connected[fd] = 0;
						close(fd);
					}
					else{
						printf("%s", buffer);
						/*transfer buf to xml*/
						doc = xmlParseMemory((char *)buffer, strlen(buffer)+1);
						if (NULL == doc)
						{
							printf("xmlParseMemory fail\n");
							return -1;
						}
						parseXML(doc);
					}
				}

			}

		}

		
	}

}
