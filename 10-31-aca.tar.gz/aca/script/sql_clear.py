#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# author: cody.guo

import os
import sys
import MySQLdb

# countabok用于表清理成功的计数, countaberror失败的计数
countabok = 0
countaberror = 0

# 需要特殊处理的表
huputables = {
    "我的收藏"             : "tmycollection",
    "来宾管理"             : "tguest",
    "来宾分类"             : "tguestclassify",
    "认证流程"             : "tauthpolicy",
    "策略基础时间段"       : "tperiod",
    "策略基础警示信息"     : "tpromptinfo",
    "策略基础警告级别管理" : "twarnlevel",
    "系统角色"             : "trole",
    "管理员角色"           : "tadminrole",
    "云用户管理"           : "tclouduser",
    "认证流程欢迎界面"     : "tauthrootpolicycfg",
    "认证流程员工"         : "tauthpolicyapprove",
    "用户动态表单"         : "tdynamicform",
    "设备动态表单"         : "tdynamicolumn",
    "认证流程认证周期"     : "tauthpolicycycle",
    "认证流程设备注册"     : "tauthpolicydevice",
    "认证流程系统安检"     : "tauthpolicysecuritycheck",
    "设备类型"             : "tdevicetype",
    "来宾默认表单"         : "tcontrolform",
    }

# 特殊处理的表ID
huputablesid = {
    "认证流程"             : "sauthid",
    "策略基础时间段"       : "iperiodid",
    "策略基础警示信息"     : "ipromptinfoid",
    "策略基础警告级别管理" : "iwarnlevelid",
    "系统角色"             : "iroleid",
    "管理员角色"           : "iadminroleid",
    "云用户管理"           : "id",
    "认证流程欢迎界面"     : "iauthid",
    "认证流程员工"         : "iauthid",
    "用户动态表单"         : "dynamicformid",
    "设备动态表单"         : "iuserid",
    "来宾默认表单"         : "scompany",
    }

# 我的收藏初始化
mycollectionsql = "INSERT INTO " + huputables["我的收藏"] + "(iadminid,spermissioncode) values(%s, %s)"
mycollectionparam = (
    (1, "D0001"),
    (1, "D0002"),
    (1, "B0001"),
    (1, "B0002"),
    (1, "E0001"),
    (1, "E0002"),
    (1, "E0004"),
    (1, "E0007"),
    (2, "H0006"),
   ) 

# 初始化设备类型
tdevicetypesql = "INSERT INTO " + huputables["设备类型"] + "(idevicetypeid, scompanycode, ideviceparentid, \
                 sdevicetypename, sleafnode, sifdeleted) values(%s, %s, %s, %s, %s, %s)"
tdevicetypeparam = (
    ('1', '10000000', '-1', 'PC', '-1', '0'),
    ('2', '10000000', '-1', '智能终端', '-1', '0'),
    )

# 初始化认证流程
tauthpolicysql = "INSERT INTO " + huputables["认证流程"] + \
                 "(scompany, deptid, userid, policyname, smodifyer, ipriority, forcepriority, \
                 dmodifytime, openuserregister, openinterface, offzoneid, clientinstall, deviceregister, \
                 systemsecurity, isolationzone, authcycle) values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
tauthpolicyparam = (
    ('10000000', '-1', '0', '默认认证流程策略', '系统', '1', '0', '2014-06-12 17:42:17', '1', '0', '1;0;1', '1;0;1;', '1;1;1;', '1;0;1;', '1;1;1;', '1;1;1'),
   ) 

# 初始化认证流程欢迎界面
tauthrootpolicycfgsql = "INSERT INTO " + huputables["认证流程欢迎界面"] + \
                        "(iauthid, swebpagestyle, ifenablewelcome, iwelcomeinfoid, ifenableem, semauthway, \
                        ifenableguest, sguestauthway) values(%s, %s, %s, %s, %s, %s, %s, %s)"
tauthrootpolicycfgparam = (
    ('1', '0, 0', '1', '0', '1', '1,2,;1', '1', '1,2,;1'),
   ) 

# 初始化认证流程员工表
tauthpolicyapprovesql = "INSERT INTO " + huputables["认证流程员工"] + \
                 "(iauthid, ifenablemess, iguestvalidityflag, daccountstart, daccountstop, \
                 iguestaccounttime, iguestaccounttimeunit, iuserregistset, iuserregisteraudit, \
                 iuserupdateaudit, ifenableupdatepwd, ifemailorphone, ifnumorletter, ifenableform, \
                 ifsavepwd, ifsaveaccount, ifenablereg, ipwdlen, iauthidentity, ireceptionaudit, \
                 iadminaudit, ifenablelogin, ienableotherlogin, iloginmethod, iloginnum) \
                 values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
tauthpolicyapproveparam = (
    ('1', '0', '0', '2015-02-02 00:00:00', '2020-12-31 23:59:59', '1', '1', '0', '0', '0', '1', '0', '1', '1', '1', '1', '1', '1', '1', '0', '0', '0', '0', '0', '2'),
    ('1', '0', '0', '2015-02-02 00:00:00', '2020-12-31 23:59:59', '1', '1', '0', '0', '0', '1', '0', '1', '1', '1', '1', '1', '1', '2', '0', '0', '0', '0', '0', '2'),
   ) 



# 初始化认证流程认证周期
tauthpolicycyclesql = "INSERT INTO " + huputables["认证流程认证周期"] + \
                 "(iauthid, iauthidentity, iauthcycle, scycleunit) \
                 values(%s, %s, %s, %s)"
tauthpolicycycleparam = (
    ('1', '1', '10', 'h'),
    ('1', '2', '10', 'h'),
    ('1', '0', '10', 'h'),
   ) 

# 初始化认证流程设备注册
tauthpolicydevicesql = "INSERT INTO " + huputables["认证流程设备注册"] + \
                 "(iauthid, iauthidentity, ideviceclassway, ifshowstation, ideviceregistset, ideviceregisteraudit, ideivceupdateaudit) \
                 values(%s, %s, %s, %s, %s, %s, %s)"
tauthpolicydeviceparam = (
    ('1', '1', '1', '1', '0', '0', '0'),
   ) 

# 初始化认证流程系统安检
tauthpolicysecuritychecksql = "INSERT INTO " + huputables["认证流程系统安检"] + \
                 "(iauthid, iauthidentity, ifenableautocheck, isecuritycheckperiods, ifappsecurity, ifnetworksecurity) \
                 values(%s, %s, %s, %s, %s, %s)"
tauthpolicysecuritycheckparam = (
    ('1', '1', '1', '10', '1', '0'),
    ('1', '2', '0', '10', '0', '0'),
    ('1', '0', '1', '10', '1', '1'),
   ) 


   
# 动态列表初始化
tdynamicformsql = "INSERT INTO " + huputables["用户动态表单"] + \
                  "(idynamicformid, iauthidentity, iformtype, sformitemtitle, sformitemname, sformitemdesc, \
                  iformitemshow, iifpublic, ipolicyauthid, ipulldownval) \
                  values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
tdynamicformsqlparam = (
    ('1', '1', '1', '认证账号', '认证账号', '系统默认用户注册表单认证账号', '2', '0', '1', '1'),
    ('2', '1', '1', '密码', '密码', '系统默认用户注册表单用户密码', '2', '0', '1', '1'),
    ('3', '1', '1', '工号', '工号', '系统默认用户注册工号', '2', '0', '1', '0'),
    ('4', '1', '1', '所属部门', ' 所属部门', '系统默认用户注册所属部门', '2', '0', '1', '1'),
    ('5', '1', '1', '姓名', '姓名', '系统默认用户注册姓名', '2', '0', '1', '0'),
    ('6', '1', '1', '手机号', '手机号', '系统默认用户注册手机号', '2', '0', '1', '0'),
    ('7', '1', '1', '电子邮箱', '电子邮箱', '系统默认用户注册电子邮箱', '2', '0', '1', '0'),
    ('8', '2', '3', '来宾账户', '来宾账户', '系统默认来宾注册来宾账户', '2', '0', '1', '1'),
    ('9', '2', '2', '密码', '密码', '系统默认来宾注册来宾密码', '1', '1', '1', '0'),
    ('10', '2', '3', '来宾姓名', '来宾姓名', '系统默认来宾注册来宾姓名', '2', '0', '1', '0'),
    ('11', '2', '3', '手机号', '手机号', '系统默认来宾注册手机号', '2', '0', '1', '0'),
    ('12', '2', '3', '电子邮箱', '电子邮箱', '系统默认来宾注册电子邮箱', '2', '0', '1', '0'),
    ('13', '2', '3', '来宾类型', '来宾类型', '系统默认来宾注册来宾类型', '2', '0', '1', '1'),
    ('14', '2', '3', '接待员工', '接待员工', '系统默认来宾注册接待员工', '2', '0', '1', '0'),
    ('15', '2', '3', '来宾公司', '来宾公司', '系统默认来宾注册来宾公司', '2', '0', '1', '0'),
    ('16', '2', '3', '来宾事由', '来宾事由', '系统默认来宾注册来宾事由', '2', '0', '1', '0'),
    )

# 控制器配置文件初始化
def controlIp():
    ffrom = open("/nac/config/nac_sys.conf", "r+")

    flist = ffrom.readlines()
    for i in flist:
        if "manager" in i:
            tmp = i.split( )
            managerip = os.popen("ifconfig " + tmp[1] + " | grep 'inet addr' | cut -d ':' -f2 | awk '{print $1}'")
            managerip = managerip.read().strip()
            #managerip = tmp[3]
        if 'url=' in i:
            urlist = flist.index(i)
            flist[urlist] = 'url=' + managerip +'\n'

    ffrom = open("/nac/config/nac_sys.conf", "w+")
    ffrom.writelines(flist)
    ffrom.close()
    
# 各程序调试日志的目录位置 
filepath = {
    "asclog"    : "/bak/debug_log/asc_client_log/*",
    "clientlog" : "/bak/debug_log/pc_client_log/*",
    "weblog"    : "/bak/debug_log/web_server_log/*",
    }

# 失败表的记录
huputabfaild = {}

# 支持远程数据库IP的清理,输入nacupdate sql clear 10.10.2.221
if len(sys.argv) < 2:
    hostip = "localhost"
else:
    hostip = sys.argv[1]

try:
    # 连接数据库
    conn = MySQLdb.connect(
        host    = hostip,
        port    = 3306,
        user    = "root",
        passwd  = "hupu12iman!",
        db      = "hupunac",
        charset = "utf8",
        )
    cur = conn.cursor()
    print "#" * 50 + "\n连接数据库服务器 " + hostip + " 成功"
except:
    print "#" * 50 + "\n连接数据库服务器失败,请检查服务器IP: " + hostip +"\n"
    exit(1)

# 读取数据库对照文件,进行数据表的清理
hupunacdb = open("/nac/script/hupunac_clear.db")
try:
    for cleartab in hupunacdb:
        try:
            # 过滤空行,跳过空行
            if cleartab == "\n":
                continue
            else:
                (tnote, tname) = cleartab.strip().split(":") # 分割数据库对照文件
            if len(tname) != 0:
                # 针对部分表进行特殊处理
                if tname == str(huputables["策略基础时间段"]) or \
                   tname == str(huputables["策略基础警示信息"]) or \
                   tname == str(huputables["云用户管理"]):
                    cur.execute("DELETE from " + tname + " WHERE " + huputablesid[tnote] + " <> '1'")
                    cur.execute("ALTER TABLE " + tname + " AUTO_INCREMENT = 2")
                    print "#" * 50 + "\n初始化 " + tnote + " ok."
                elif tname == str(huputables["策略基础警告级别管理"]):
                    cur.execute("DELETE from " + tname + " WHERE " + huputablesid[tnote] + " not in (1,2,3,4)")
                    cur.execute("ALTER TABLE " + tname + " AUTO_INCREMENT = 5")
                    print "#" * 50 + "\n初始化 " + tnote + " ok."
                elif tname == str(huputables["系统角色"]):
                    cur.execute("DELETE from " + tname + " WHERE " + huputablesid[tnote] + " not in (1,2)")
                    cur.execute("ALTER TABLE " + tname + " AUTO_INCREMENT = 3")
                    print "#" * 50 + "\n初始化 " + tnote + " ok."
                elif tname == str(huputables["管理员角色"]):
                    cur.execute("DELETE from " + tname + " WHERE " + huputablesid[tnote] + " <> '1'")
                    cur.execute("ALTER TABLE " + tname + " AUTO_INCREMENT = 2")
                    cur.execute("INSERT INTO "+ tname + "(iadminid,iroleid) VALUES(2,2)")
                    print "#" * 50 + "\n初始化 " + tnote + " ok."
                elif tname == str(huputables["来宾管理"]):
                    cur.execute("TRUNCATE TABLE " + tname)
                    cur.execute("ALTER TABLE " + tname + " AUTO_INCREMENT = 4")
                    print "#" * 50 + "\n初始化 " + tnote + " ok."
                elif tname == str(huputables["来宾分类"]):
                    cur.execute("TRUNCATE TABLE " + tname)
                    cur.execute("ALTER TABLE " + tname + " AUTO_INCREMENT = 4")
                    print "#" * 50 + "\n初始化 " + tnote + " ok."
                elif tname == str(huputables["来宾默认表单"]):
                    cur.execute("DELETE from " + tname + " WHERE " + huputablesid[tnote] + " <> '0'")
                    cur.execute("ALTER TABLE " + tname + " AUTO_INCREMENT = 17")
                    print "#" * 50 + "\n初始化 " + tnote + " ok."
                else:
                    # 无需特殊处理的表执行Truncate
                    n = cur.execute("TRUNCATE TABLE " + tname)
                    print "#" * 50 + "\ntruncat table " + tnote + " ok."
                    countabok += 1
        except:
            # 打印并记录清理失败的表
            print "#" * 50 + "\ntruncat table " + tnote + " faild."
            huputabfaild[tnote] = tname
            countaberror += 1
        finally:
            # 跳过失败的表,继续处理下张表
            pass
            #cur.nextset()
    
    # 初始化管理员表
    cur.execute("INSERT INTO tadmin(sadminzhname,sadminenname,scompanyname,scompanycode,saccount,\
                spassword,sworkemail,snativeplace,dcareerentrytime,semployeetype,ipostid,sifaudited,\
                sifdeleted,siflocked,slanguagetype,sifroot) VALUES ('超级管理员','admin','上海互普信息技术股份有限公司',\
                '10000000','admin','21232F297A57A5A743894A0E4A801FC3','hupu@hupu.net','中国','2013-8-1','1','0','1','0','0','zh','1')")
    cur.execute("INSERT INTO tadmin(sadminzhname,sadminenname,scompanyname,scompanycode,saccount,\
                spassword,sworkemail,snativeplace,dcareerentrytime,semployeetype,ipostid,sifaudited,\
                sifdeleted,siflocked,slanguagetype,sifroot) VALUES ('超级审计员','audit','上海互普信息技术股份有限公司',\
                '10000000','audit','21232F297A57A5A743894A0E4A801FC3','hupu@hupu.net','中国','2013-8-1','1','0','1','0','0','zh','1')")
    # 初始化我的收藏表
    cur.executemany(mycollectionsql, mycollectionparam)    
    print "#" * 50 + "\nSqlClear提示: 我的收藏初始化成功."

    # 初始化认证流程相关
    cur.executemany(tauthpolicysql, tauthpolicyparam) # 初始化认证流程
    cur.executemany(tauthrootpolicycfgsql, tauthrootpolicycfgparam)  # 初始化认证流程欢迎界面
    cur.executemany(tauthpolicyapprovesql, tauthpolicyapproveparam)   # 初始化认证流程员工表
    cur.executemany(tauthpolicycyclesql, tauthpolicycycleparam)   # 初始化认证流程认证周期
    cur.executemany(tauthpolicydevicesql, tauthpolicydeviceparam)    # 初始化认证流程设备注册
    cur.executemany(tauthpolicysecuritychecksql, tauthpolicysecuritycheckparam)    # 初始化认证流程系统安检
    cur.executemany(tdevicetypesql, tdevicetypeparam) # 初始化设备类型表
    print "#" * 50 + "\nSqlClear提示: 认证流程相关初始化成功."

    # 初始化动态表单表
    cur.executemany(tdynamicformsql, tdynamicformsqlparam)    
    print "#" * 50 + "\nSqlClear提示: 动态表单初始化成功."

except ValueError as errorLog:
    # 打印处理失败的日志
    print errorLog

cur.close()
conn.commit()
conn.close()


    
print "#" * 50 + "\nSqlClear提示: 清理成功" + str(countabok) + "张表."

# 清理各程序调试日志
for file in filepath:
    os.system("rm -rf " +  filepath[file])
    print "#" * 50 + "\nLogClear提示: 清理 " + file + " ok."

# 打印数据库清理失败的表
print "#" * 15 + " SqlClear 失败提示: " + "#" * 15  + "\nSqlClear提示: 清理失败" + str(countaberror) + "张表."
for key in huputabfaild:
    print "清理失败的表: " + "\n\t" + key + ": " + huputabfaild[key]

# 控制器配置文件初始化
controlIp()
print "#" * 50 + "\n控制器配置文件初始化成功." 

# 重启app程序,重连服务器
os.system("killall -9 nac_system")
os.system("nac_system &")

# 重启ruby程序,只需要杀死ruby,自动会重启
# os.system("killall -9 ruby")
#os.system("/bin/bash /nac/script/update_switch_control.sh")




