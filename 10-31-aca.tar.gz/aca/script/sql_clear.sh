#!/bin/bash
#set -x
#History:
#		2014-9-26 10:55:36 cody.guo first release
#		2014-9-28 15:29:51 cody.guo two release
#		2014-10-15 08:57:52 cody.guo three release
#		2014-11-10 15:29:48 cody.guo four release
#		2014-11-17 15:53:11 cody.guo five release
#		2014-11-25 15:53:11 cody.guo six release
#增加绑定垃圾数据的清理
#来宾类型表初始化从3开始
#日志管理默认收藏
#		2014-11-26 10:30:11 cody.guo seven release
#修复应用认证出现男女选项bug
#清空短信外发
#		2015-1-14 cody.guo eight release
#增加AD域清空

ASC_LOG="/bak/debug_log/asc_client_log/*"
PC_CLIENT="/bak/debug_log/pc_client_log/*"
WEB_LOG="/bak/debug_log/web_server_log/*"

#清空原始日志
rm -rf $ASC_LOG
rm -rf $PC_CLIENT
rm -rf $WEB_LOG

#登录mysql，执行truncate命令
mysql -u $1 -p$2 <<EOF
USE hupunac;
TRUNCATE TABLE tdevice;
TRUNCATE TABLE tusers;
TRUNCATE TABLE tdeviceauthresult;
TRUNCATE TABLE tswitch;
TRUNCATE TABLE tswitcharp;
TRUNCATE TABLE tswitchport;
TRUNCATE TABLE tswitchmac;
TRUNCATE TABLE tasc;
TRUNCATE TABLE tauthdomain;
TRUNCATE TABLE tcheckfirewall;
TRUNCATE TABLE tcheckguestaccount;
TRUNCATE TABLE tcheckinstallsoftware;
TRUNCATE TABLE tcheckinstallsoftwarecontent;
TRUNCATE TABLE tcheckportcontentpolicy;
TRUNCATE TABLE tcheckportpolicy;
TRUNCATE TABLE tcheckprocesscontentpolicy;
TRUNCATE TABLE tcheckprocesspolicy;
TRUNCATE TABLE tcheckremotedesktop;
TRUNCATE TABLE tcheckscreenset;
TRUNCATE TABLE tcheckservice;
TRUNCATE TABLE tclientexceptionlog;
TRUNCATE TABLE tdepartment;
TRUNCATE TABLE tdevicetype;
TRUNCATE TABLE tdynamicform;
TRUNCATE TABLE tglobalvlanmap;
TRUNCATE TABLE tnetworkping;
TRUNCATE TABLE toperatorlog;
TRUNCATE TABLE tpolicylog;
TRUNCATE TABLE tpolicyresult;
TRUNCATE TABLE tquestionmodel;
TRUNCATE TABLE tquestions;
TRUNCATE TABLE tsoftware;
TRUNCATE TABLE tstation;
TRUNCATE TABLE tuserauthlog;
TRUNCATE TABLE tauthpolicywelcome;
TRUNCATE TABLE tdynamicolumn;
TRUNCATE TABLE tmycollection;
TRUNCATE TABLE tguestauthcode;
TRUNCATE TABLE tguest;
TRUNCATE TABLE tguestauthlog;
TRUNCATE TABLE tclientauthcode;
TRUNCATE TABLE toperatorlog;
TRUNCATE TABLE twarnlog;
TRUNCATE TABLE tsystemrunlog;
TRUNCATE TABLE twarnlogoutward;
TRUNCATE TABLE tanswers;
TRUNCATE TABLE tauthpolicysecuritycheck;
TRUNCATE TABLE tauthpolicydevice;
TRUNCATE TABLE tauthpolicyapprove;
TRUNCATE TABLE tauthpolicyapplication;
TRUNCATE TABLE tapplyauthresults;
TRUNCATE TABLE talarmpolicy;
TRUNCATE TABLE talarmpolicyevent;
TRUNCATE TABLE tlogoutgopolicyemail;
TRUNCATE TABLE tlogoutgopolicyphone;
TRUNCATE TABLE tauthbind;
TRUNCATE TABLE tauthpolicycycle;
TRUNCATE TABLE tguestclassify;
TRUNCATE TABLE tipbindpolicy;
TRUNCATE TABLE tmacbindpolicy;
TRUNCATE TABLE tuserbindpolicy;
TRUNCATE TABLE tuserdevicebind;
TRUNCATE TABLE tzoneisolation;
TRUNCATE TABLE tbindcycle;
TRUNCATE TABLE toptions;
TRUNCATE TABLE tauthaddept;




DELETE from tauthpolicy WHERE sauthid <> '1';
ALTER TABLE tauthpolicy AUTO_INCREMENT = 2;
DELETE from tperiod WHERE iperiodid <> '1';
ALTER TABLE tperiod AUTO_INCREMENT = 2;
DELETE from tpromptinfo WHERE ipromptinfoid <> '1';
ALTER TABLE tpromptinfo AUTO_INCREMENT = 2;
DELETE from twarnlevel WHERE iwarnlevelid not in (1,2,3,4);
ALTER TABLE twarnlevel AUTO_INCREMENT = 5;

TRUNCATE TABLE tadmin;
INSERT INTO tadmin(sadminzhname,sadminenname,scompanyname,scompanycode,saccount,spassword,sworkemail,snativeplace,dcareerentrytime,semployeetype,ipostid,sifaudited,sifdeleted,siflocked,slanguagetype,sifroot) VALUES ('超级管理员','admin','上海互普信息技术有限公司','10000000','admin','21232F297A57A5A743894A0E4A801FC3','hupu@hupu.net','中国','2013-8-1','1','0','1','0','0','zh','1');
INSERT INTO tadmin(sadminzhname,sadminenname,scompanyname,scompanycode,saccount,spassword,sworkemail,snativeplace,dcareerentrytime,semployeetype,ipostid,sifaudited,sifdeleted,siflocked,slanguagetype,sifroot) VALUES ('超级审计员','audit','上海互普信息技术有限公司','10000000','audit','21232F297A57A5A743894A0E4A801FC3','hupu@hupu.net','中国','2013-8-1','1','0','1','0','0','zh','1');


DELETE from trole WHERE iroleid not in (1,2);
ALTER TABLE trole AUTO_INCREMENT = 3;



DELETE from tadminrole WHERE iadminroleid <> 1;
ALTER TABLE tadminrole AUTO_INCREMENT = 2;
INSERT INTO tadminrole(iadminid,iroleid) VALUES(2,2);

DELETE from tclouduser WHERE id <> '1';
ALTER TABLE tclouduser AUTO_INCREMENT = 2;

UPDATE tclouduser SET scompanyname = '上海互普信息技术有限公司', susername = '上海互普', smobile = '18821201646', semail = 'iman@hupu.net', sdesc = '' WHERE id = '1'; 


ALTER TABLE tguest AUTO_INCREMENT = 3;
ALTER TABLE tguestclassify AUTO_INCREMENT = 3;

INSERT INTO tmycollection(iadminid,spermissioncode) VALUES (2,'H0006');

EOF


