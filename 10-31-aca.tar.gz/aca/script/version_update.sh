#!/bin/bash
#History:
#2014-6-18 11:24:57 cody.guo first release
#2014-7-22 09:56:49 cody.guo two release

#start

#nac.version
if [ ! -f /nac/config/nac.version ];then
	echo "iMan X3000 Series">/nac/config/nac.version
	echo "3.6.08">>/nac/config/nac.version
	exit 0
fi


#version
v1=`cat /nac/config/nac.version |sed -n '2p'|cut -d "." -f1`
v2=`cat /nac/config/nac.version |sed -n '2p'|cut -d "." -f2`
v3=`cat /nac/config/nac.version |sed -n '2p'|cut -d "." -f3`

#version update
if [ $v3 -eq 8 -o $v3 -eq 9 ];then
	((v3_old = 10#$v3 + 1))
	v3_update=`printf "%02d\n" $v3_old`
else
	((v3_old = $v3 + 1))
    	v3_update=`printf "%02d\n" $v3_old`
fi

sed -i "2s/$v1.$v2.$v3/$v1.$v2.$v3_update/g" /nac/config/nac.version
chmod 755 /nac/config/nac.version

#end
