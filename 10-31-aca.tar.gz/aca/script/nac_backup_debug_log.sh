#!/bin/bash
# set -x
# History:
# create by gaodong at 2014年 09月 09日 星期二 09:20:32 CST
# update by gaodong at 2014-10-20 14:45:36
# echo -e "Time:`date "+%F %k:%M:%S"`"


TIME_STAMP=`date "+%Y%m%d-%H%M"`
CRONTAB_FILE="/etc/crontab"
LOG_BACKUP_SHELL="/nac/script/nac_backup_debug_log.sh"
ASC_DEBUG_BAK="/bak/debug_log/asc_client_log"
WEB_DEBUG_BAK="/bak/debug_log/web_server_log"
PC_DEBUG_BAK="/bak/debug_log/pc_client_log"

EN_PASSWD="zaq#@!"

function print_usage()
{

cat<<HELP
please input the log type
web:		 backup web debug_log;
query_del:	 query auto del log cycle;
set_auto_del:set auto del log cycle;
off_auto_del:close auto del log switch;
HELP

}

if [ $# -lt 1 ];then
	print_usage
	exit 0
fi

function check_ret()
{
	if [ $? == 0 ];then
		echo "ok"
	else
		echo "error"
		exit 1
	fi
}

function check_auto_ret()
{
	if [ $? == 0 ];then
		echo "error"
		exit 1
	else
		echo "ok"
	fi

}

function crond_restart()
{
	crontab $CRONTAB_FILE
	/etc/init.d/crond restart >>/dev/null 2>&1
}


function nac_backup_web_debug_log()
{
	cd /var/log/tomcat
	if [ ! -d  ./WebLog ];then
		mkdir -p WebLog
	fi

	mv *.bak ./WebLog/ >>/dev/null 2>&1
	if [ $? == 1 ];then
		echo "/var/log/tomcat/*.bak nonexist!"
		exit 0
	fi

	tar -Jcvf - ./WebLog | openssl des3 -salt -e -k $EN_PASSWD -out WebLog-$TIME_STAMP.txz
	#tar -Jcvf WebLog-$TIME_STAMP.txz WebLog >>/dev/null 2>&1
	\cp -f WebLog-$TIME_STAMP.txz /bak/debug_log/web_server_log/
	
	rm -f WebLog-$TIME_STAMP.txz
	rm -rf ./WebLog/*
}

function crond_query_auto_bak()
{
	cat $CRONTAB_FILE|grep "nac_backup_debug_log.sh auto_bak" >/dev/null 2>&1
	if [ $? == 0 ];then
		auto_bak_status="yes,`cat $CRONTAB_FILE | grep "nac_backup_debug_log.sh auto_bak"|awk '{print $10}'`"
	else
		auto_bak_status="no"
	fi
	
	echo "$auto_bak_status"
}

function crond_query_auto_del()
{

	cat $CRONTAB_FILE|grep "nac_backup_debug_log.sh auto_del_log" >/dev/null 2>&1
	if [ $? == 0 ];then
		auto_del_status="yes,`cat $CRONTAB_FILE | grep "nac_backup_debug_log.sh auto_del_log" |awk '{print $10}'`"
	else
		auto_del_status="no"
	fi

	echo "$auto_del_status"
}


function crond_del_cmd()
{
	echo "01 00 * * * root sh $LOG_BACKUP_SHELL auto_del_log $1">>$CRONTAB_FILE
	check_ret
}

function crond_set_auto_del()
{
	cat $CRONTAB_FILE|grep "auto_del_log" >/dev/null 2>&1
	if [ $? == 0 ];then
		sed -i "/auto_del_log/d" $CRONTAB_FILE >/dev/null 2>&1
	fi
		
	case "$1" in
		"week" | "WEEK")
			crond_del_cmd week
			;;
		"half_month" | "HALF_MONTH")
			crond_del_cmd half_month
			;;
		"month" | "MONTH")
			crond_del_cmd month
			;;
		"three_month" | "THREE_MONTH")
			crond_del_cmd three_month
			;;
		"half_year" | "HALF_YEAR")
			crond_del_cmd half_year
			;;
		"full_year" | "FULL_YEAR")
			crond_del_cmd full_year
			;;
		*)
			echo "You input wrong,Please retry!"
			;;
	esac
	crond_restart
}

function auto_del_debug_log()
{
	case "$1" in
		"week" | "WEEK")
			find $WEB_DEBUG_BAK -name "*.txz" -ctime +6 -delete	
			find $ASC_DEBUG_BAK -name "*.txz" -ctime +6 -delete 
			find $PC_DEBUG_BAK  -name "*.zip" -ctime +6 -delete
			;;
		"half_month" | "HALF_MONTH")
			find $WEB_DEBUG_BAK/* -name "*.txz" -ctime +14 -delete	
			find $ASC_DEBUG_BAK/* -name "*.txz" -ctime +14 -delete
			find $PC_DEBUG_BAK/*  -name "*.zip" -ctime +14 -delete
			;;
		"month" | "MONTH") 
			find $WEB_DEBUG_BAK/* -name "*.txz" -ctime +29 -delete
			find $ASC_DEBUG_BAK/* -name "*.txz" -ctime +29 -delete
			find $PC_DEBUG_BAK/*  -name "*.zip" -ctime +29 -delete
			;;
		"three_month" | "THREE_MONTH")
			find $WEB_DEBUG_BAK/* -name "*.txz" -ctime +89 -delete
			find $ASC_DEBUG_BAK/* -name "*.txz" -ctime +89 -delete
            find $PC_DEBUG_BAK/*  -name "*.zip" -ctime +89 -delete
			;;
		"half_year" | "HALF_YEAR")         
			find $WEB_DEBUG_BAK/* -name "*.txz" -ctime +179 -delete
			find $ASC_DEBUG_BAK/* -name "*.txz" -ctime +179 -delete
			find $PC_DEBUG_BAK/*  -name "*.zip" -ctime +179 -delete
			;;
		"full_year" | "FULL_YEAR")
			find $WEB_DEBUG_BAK/* -name "*.txz" -ctime +364 -delete
			find $ASC_DEBUG_BAK/* -name "*.txz" -ctime +364 -delete
			find $PC_DEBUG_BAK/*  -name "*.zip" -ctime +364 -delete
			;;
		*)
			echo "You input wrong,Please retry!"
			;;
	esac
	crond_restart
}

function crond_auto_del_off()
{
	cat $CRONTAB_FILE|grep "auto_del_log" >/dev/null 2>&1

	if [ $? == 0 ];then
		sed -i "/auto_del_log/d" $CRONTAB_FILE >/dev/null 2>&1
	fi

	cat $CRONTAB_FILE|grep "auto_del_log" >/dev/null 2>&1
	check_auto_ret
	crond_restart
}

#main
case "$1" in
	"asc" | "ASC")
		exit 0
		;;
	"pc" | "PC")	
		exit 0
		;;
	"web" | "WEB")
		nac_backup_web_debug_log	
		;;
	"set_auto_del" | "SET_AUTO_DEL")
		crond_set_auto_del $2
		;;
	"off_auto_del" | "OFF_AUTO_DEL")
		crond_auto_del_off
		;;
	"auto_del_log" | "AUTO_DEL_LOG")
		auto_del_debug_log $2
		;;
	"query_bak" | "QUERY_BAK")
		crond_query_auto_bak
		;;
	"query_del" | "QUERY_DEL")
		crond_query_auto_del
		;;
	*)
		echo "You input wrong,Please retry"
		print_usage
		;;
esac

#end
