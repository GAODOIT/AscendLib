#!/bin/bash
SWITCH_BIN="/nac/switch.bin"
ps aux | grep "nac_start.sh"| grep -v grep|awk '{print $2}'|xargs kill -9 1>/dev/null 2>&1
ps aux|grep "main_switch"|grep -v grep|awk '{print $2}'|xargs kill -9 1>/dev/null 2>&1
if [ -f "$SWITCH_BIN" ]; then
	chmod +x "$SWITCH_BIN"
	cd /nac && ./switch.bin
fi
nohup /nac/switch/run_ruby.sh 1>/dev/null 2>&1 &

