#!/bin/bash
# show cpu usage rate
# set -x
# History:
# create by gaodong at 2014-10-20 15:28:54
# echo -e "Time:`date "+%F %k:%M:%S"`"


get_cpu_info()
{
    cat /proc/stat | grep "^cpu" | head -n1 | awk '{used=$2+$3+$4;unused=$5+$6+$7+$8} \
    END{print used,unused}'
}

#cpu status first
time_point_1=`get_cpu_info`
sleep 1

#cpu status two
time_point_2=`get_cpu_info`

usecpu=`echo $time_point_1 $time_point_2 | awk '{used=$3-$1;total=$3+$4-$1-$2; print used*100/total}'`

#show now time
#echo -e "Time:`date "+%F %k:%M:%S"`"

#show cpu status
#printf "%s%0.2f%s\n" "usecpu:" "$usecpu" "%"

printf "%0.2f%s\n" "$usecpu" "%"
