#!/bin/bash
#2015-08-31 14:53:29 create by gaodong!

function print_usage()
{
cat<<HELP
please input the backup address.
for example $0 7.7.7.2
HELP
}

if [ $# -lt 1 ];then
	print_usage
        exit -1
fi

BACKUP_HOST=$1
HOSTNAME="127.0.0.1"
PORT="3306"
USERNAME="root"
PASSWORD="hupu12iman!"
DATABASE_NAME="hupunac"
BAK_DATABASE_PATH="/bak/ha_sync/ha_backup_db.sql"
MYSQL="/usr/local/mysql5.1.72/bin/mysql"
MYSQLDUMP="/usr/local/mysql5.1.72/bin/mysqldump"

function nac_exec_sql()
{
	echo "$1"
	$MYSQL -h$HOSTNAME -P$PORT -u$USERNAME -p$PASSWORD -e "$1"
}

/bin/cp -f /nac/config/my_sync/my_master.cnf /etc/my.cnf
#create user for backup in master mysql
create_grant_user_sql="GRANT REPLICATION SLAVE ON *.* TO 'backup'@'$BACKUP_HOST' IDENTIFIED BY 'iman@hupu.net'"

$MYSQL -h$HOSTNAME -P$PORT -u$USERNAME -p$PASSWORD -e "$create_grant_user_sql"

#export mysql database hupunac
$MYSQLDUMP -h$HOSTNAME -R -u$USERNAME -p$PASSWORD $DATABASE_NAME --lock-all-tables > $BAK_DATABASE_PATH 2>/dev/null

#restart mysql service
service mysqld restart


function show_master_status
{
mysql -uroot -phupu12iman!<<!
show master status;
!
}

mysql_status=`show_master_status`
LOG_BIN=`echo $mysql_status | awk '{print $5}'`
echo $LOG_BIN > /bak/ha_sync/my_log_bin

#LOG_BIN=`/nac/script/show_master_status.sh |awk '{print $1}'| sed '1d'`
