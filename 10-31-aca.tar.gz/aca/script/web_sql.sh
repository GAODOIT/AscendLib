#!/bin/bash
#set -x
#History:
#2014-7-31 10:51:42 cody.guo first release
#2014-8-5 14:04:46 cody.guo two release
#2014-8-6 16:53:41 cody.guo three release
#2014-8-14 14:14:16 cody.guo four release
#2014-11-6 10:53:11 cody.guo five release
#	增加存储过程的备份
#2014-11-27 20:08:05 cody.guo six release
#解决数据库备份失败bug

TIME=`date "+%Y%m%d-%H%M%S"`
bak="/bak/mysql"
passwd="hupu12iman!"
backup_shell="/nac/script/web_sql.sh"
nac_version="/nac/config/nac.version"
cron_file="/etc/crontab"
MYSQL="/usr/local/mysql5.1.72/bin/mysql"
MYSQLDUMP="/usr/local/mysql5.1.72/bin/mysqldump"

function Check() {
	if [ $? == 0 ];then
		echo "ok"
	else
		echo "error"
		exit 1
	fi
}

function Check_auto() {
	if [ $? == 0 ];then
		echo "error"
		exit 1
	else
		echo "ok"
	fi
}

function Check_disk() {
	disk1=`df -h /bak|grep bak|awk '{ print $4 }'|grep -i "m"`
	if [ $? == 0 ];then
		echo "error,No disk space available"
		exit 1
	fi
	disk=`df -h /bak|grep bak|awk '{ print $4 }'|cut -d 'G' -f 1`
	min_disk="1"
	if [ $(expr $min_disk \> $disk) == 1 ];then
		echo "error,No disk space available"
		exit 1
	fi
}

function Version() {
	#nac.version not exsit
	if [ ! -f $nac_version ];then
		echo "iMan X3000">$nac_version
		echo "3.6.08.01">>$nac_version
	fi
	#nac.version
	v1=`cat $nac_version |sed -n '2p'|cut -d "." -f1`
	v2=`cat $nac_version |sed -n '2p'|cut -d "." -f2`
	v3=`cat $nac_version |sed -n '2p'|cut -d "." -f3`
	v4=`cat $nac_version |sed -n '2p'|cut -d "." -f4`
	version=`echo $v1$v2$v3$v4`
}


function Cron_restart() {
	crontab $cron_file
	service crond restart >>/dev/null 2>&1
}


function Backsql() {
	if [ ! -d $bak ];then
		mkdir -p $bak
	fi
	Check_disk
	Version
	$MYSQLDUMP -R -uroot -p$passwd hupunac > $bak/backup-db$1-"$TIME"_$version.sql 2>/dev/null
	Check
}

function Delsqlbak()
{
	if [ -f "$bak/$1" ];then
		rm -rf $bak/"$1"
	else
		return 1
	fi
}

function Recoversql()
{
	if [ -f "$bak/$1" ];then
		$MYSQL -uroot -p$passwd -e "use hupunac;source $bak/$1;" 2>/dev/null
	else
		return 1
	fi
}

function Cron_bak_off()
{
	cat $cron_file|grep "web_sql.sh backup" >/dev/null 2>&1
	if [ $? == 0 ];then
		sed -i "/web_sql.sh backup/d" $cron_file >/dev/null 2>&1
	fi
	cat $cron_file|grep "web_sql.sh backup" >/dev/null 2>&1
	Check_auto
	Cron_restart
}

function Cron_del_off()
{
	cat $cron_file|grep "auto_del_sql" >/dev/null 2>&1
	if [ $? == 0 ];then
		sed -i "/auto_del_sql/d" $cron_file >/dev/null 2>&1
	fi
	cat $cron_file|grep "auto_del_sql" >/dev/null 2>&1
	Check_auto
	Cron_restart
}

function Auto_query()
{
	cat $cron_file|grep "web_sql.sh backup" >/dev/null 2>&1
	if [ $? == 0 ];then
		auto_bak_status="yes,`cat $cron_file | grep "web_sql.sh backup" | awk '{print $11}'`"
	else
		auto_bak_status="no"
	fi
	cat $cron_file|grep "auto_del_sql" >/dev/null 2>&1
	if [ $? == 0 ];then
		auto_del_status="yes,`cat $cron_file |grep auto_del_sql|awk  '{print $10}'`"
	else
		auto_del_status="no"
	fi

	echo "$auto_bak_status;$auto_del_status"
}

function Auto_del_sql()
{
	case "$1" in
		"week" | "WEEK")
			find $bak -name "*.sql" -ctime +6 -delete
			Check
			;;
		"half_month" | "HALF_MONTH")
			find $bak/* -name "*.sql" -ctime +14 -delete
			Check
			;;
		"month" | "MONTH")
			find $bak/* -name "*.sql" -ctime +29 -delete
			Check
			;;
		"three_month" | "THREE_MONTH")
			find $bak/* -name "*.sql" -ctime +89 -delete
			Check
			;;
		"half_year" | "HALF_YEAR")
			find $bak/* -name "*.sql" -ctime +179 -delete
			Check
			;;
		"full_year" | "FULL_YEAR")
			find $bak/* -name "*.sql" -ctime +364 -delete
			Check
			;;
		*)
			echo "You input cron wrong,Please retry!"
			;;
	esac
	Cron_restart
}

function Cron_bak()
{
	echo "01 00 $1 $2 $3 root	sh $backup_shell backup $4 $5" >>$cron_file
	Check
}

function Cron_auto_bak()
{
	cat $cron_file|grep "web_sql.sh backup" >/dev/null 2>&1
	if [ $? == 0 ];then
		sed -i "/web_sql.sh backup/d" $cron_file >/dev/null 2>&1
	fi

	case "$1" in
		"week" | "WEEK")
			Cron_bak "*" "*" 1 -auto week
			;;
		"half_month" | "HALF_MONTH")
			Cron_bak "1,16" "*" "*" -auto half_month
			;;
		"month" | "MONTH")
			Cron_bak 1 "*" "*" -auto month
			;;
		"three_month" | "THREE_MONTH")
			Cron_bak 1 "1,4,7,10" "*" -auto three_month
			;;
		"half_year" | "HALF_YEAR")
			Cron_bak 1 "1,7" "*" -auto half_year
			;;
		"full_year" | "FULL_YEAR")
			Cron_bak 1 1 "*" -auto full_year
			;;
		*)
			echo "You input cron wrong,Please retry!"
			;;
	esac
	Cron_restart
}

function Cron_del()
{
	echo "01 00 * * * root	sh $backup_shell auto_del_sql $1">>$cron_file
	Check
}

function Cron_auto_del()
{
	cat $cron_file|grep "auto_del_sql" >/dev/null 2>&1
	if [ $? == 0 ];then
		sed -i "/auto_del_sql/d" $cron_file >/dev/null 2>&1
	fi

	case "$1" in
		"week" | "WEEK")
			Cron_del week
			;;
		"half_month" | "HALF_MONTH")
			Cron_del half_month
			;;
		"month" | "MONTH")
			Cron_del month
			;;
		"three_month" | "THREE_MONTH")
			Cron_del three_month
			;;
		"half_year" | "HALF_YEAR")
			Cron_del half_year
			;;
		"full_year" | "FULL_YEAR")
			Cron_del full_year
			;;
		*)
			echo "You input cron wrong,Please retry!"
			;;
	esac
	Cron_restart
}

case "$1" in
	"backup" | "BACKUP")
		Backsql $2
		;;
	"del" | "DEL")
		Delsqlbak $2
		Check
		;;
	"rec" | "REC")
		Recoversql $2
		Check
		;;
	"auto_query" | "AUTO_QUERY")
		Auto_query
		;;
	"auto_bak" | "AUTO_BAK")
		Cron_auto_bak $2
		;;
	"auto_bak_off" | "AUTO_BAK_OFF")
		Cron_bak_off $2
		#Check
		;;
	"auto_del" | "AUTO_DEL")
		Cron_auto_del $2
		;;
	"auto_del_off" | "AUTO_DEL_OFF")
		Cron_del_off $2
		#Check
		;;
	"auto_del_sql" | "AUTO_DEL_SQL")
		Auto_del_sql $2
		;;
	*)
		echo "You input wrong,Please retry!"
		;;
esac

#end
