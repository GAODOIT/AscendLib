/* Copyright 2006 The FreeRADIUS server project */

#ifndef _OTHER_H
#define _OTHER_H

#include <freeradius-devel/ident.h>
RCSIDH(other_h, "$Id: c41a72698c188b6a4ba09fe2bcf70404146e6d90 $")

/* define the function */

void other_function(void);

#endif /*_OTHER_H*/
