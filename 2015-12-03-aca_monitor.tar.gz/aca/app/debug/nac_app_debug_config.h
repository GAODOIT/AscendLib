#ifndef NAC_APP_DEBUG_CONFIG_H
#define NAC_APP_DEBUG_CONFIG_H

#define NAC_APP_SHOW_SYS_CONFIG_FILE	"/var/log/nac_asc/tmp/nac_debug_sys_conf.log"
#define NAC_APP_SHOW_NETAPP_USER_FILE   "/var/log/nac_asc/tmp/nac_debug_netapp_user.log"

#define CONFIG_DEBUG_FORMAT "<?xml version=\"1.0\" encoding=\"UTF-8\"?><nac><commandID>%d</commandID><actionType>%d</actionType></nac>"

enum
{
    SHOW_CONFIG=0,
    DEBUG_OPEN=1,
    DEBUG_CLOSE=2,
    DEBUG_NETAPP=3
};

int nac_app_decrypt_tar_log(char* log_path);
int nac_app_debug_config_deal(int show_state);
int nac_app_debug_netapp_user(int show_state);
int nac_app_enable_system_log_switch(int show_state);

#endif
