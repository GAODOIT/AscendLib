#include "nac_app_debug_main.h"
#include "nac_app_debug_config.h"

int nac_app_decrypt_tar_log(char* log_path)
{
    char encrypt_passwd[] = "zaq#@!";
    char decrypt_cmd[] = "openssl des3 -salt -d -k %s -in %s | tar -Jxvf -";
    char exec_cmd[256] = "";

    sprintf(exec_cmd, decrypt_cmd, encrypt_passwd, log_path);
    system(exec_cmd);
    return 0;
}

int nac_app_debug_netapp_user(int show_state)
{
    char msg_buffer[512] = "";
    NAC_WEB_MSG *pst_xml_msg;
    sprintf(msg_buffer, CONFIG_DEBUG_FORMAT, SYS_WEBUI_DEBUG_CONFIG, DEBUG_NETAPP);
    int xml_msg_len = strlen(msg_buffer);

    pst_xml_msg = (NAC_WEB_MSG*)malloc((xml_msg_len+sizeof(NAC_WEB_MSG)+1));
    if (pst_xml_msg == NULL)
    {
        printf("%s-->malloc fail\n", __FUNCTION__);
        goto FUNC_EXIT;
    }
    memset(pst_xml_msg, '\0', sizeof(NAC_WEB_MSG));

    pst_xml_msg->us_cmd  = SYS_WEBUI_DEBUG_CONFIG;
    pst_xml_msg->reserve = 0;
    pst_xml_msg->ui_len  = xml_msg_len;
    memcpy(pst_xml_msg->ac_buf, msg_buffer, xml_msg_len);

    int dst_address = inet_network("127.0.0.1");
    unsigned short flag = 0;
    nac_app_short_tcp_msg_send(pst_xml_msg, dst_address, &flag);
    free(pst_xml_msg);

    if (flag == 1)
    {
        system("cat /var/log/nac_asc/tmp/nac_debug_netapp_user.log");
    }
    else
    {
        printf("get nac_app netapp_user failure\n");
    }

FUNC_EXIT:
    return 0;
}



int nac_app_debug_config_deal(int show_state)
{
    char msg_buffer[512] = "";
    NAC_WEB_MSG *pst_xml_msg;
    sprintf(msg_buffer, CONFIG_DEBUG_FORMAT, SYS_WEBUI_DEBUG_CONFIG, SHOW_CONFIG);
    int xml_msg_len = strlen(msg_buffer);

    pst_xml_msg = (NAC_WEB_MSG*)malloc((xml_msg_len+sizeof(NAC_WEB_MSG)+1));
    if (pst_xml_msg == NULL)
    {
        printf("%s-->malloc fail\n", __FUNCTION__);
        goto FUNC_EXIT;
    }
    memset(pst_xml_msg, '\0', sizeof(NAC_WEB_MSG));

    pst_xml_msg->us_cmd  = SYS_WEBUI_DEBUG_CONFIG;
    pst_xml_msg->reserve = 0;
    pst_xml_msg->ui_len  = xml_msg_len;
    memcpy(pst_xml_msg->ac_buf, msg_buffer, xml_msg_len);

    int dst_address = inet_network("127.0.0.1");
    unsigned short flag = 0;
    nac_app_short_tcp_msg_send(pst_xml_msg, dst_address, &flag);
    free(pst_xml_msg);

    if (flag == 1)
    {
        if (show_state == 2)
        {
            system("cat /var/log/nac_asc/tmp/nac_debug_sys_conf.log");
        }
        else if (show_state == 3)
        {
            system("cat /var/log/nac_asc/tmp/nac_debug_sys_conf.log | tail -n 11");
        }
    }
    else
    {
        if (show_state == 2)
            printf("get nac_system all config failure\n");
        else if (show_state == 3)
            printf("get nac_system socket status failure\n");
    }

FUNC_EXIT:
    return 0;
}


int nac_app_enable_system_log_switch(int show_state)
{
    char msg_buffer[512] = "";
    NAC_WEB_MSG *pst_xml_msg;
    unsigned short switch_state;
    if (show_state == 4)
    {
        switch_state = DEBUG_OPEN;
    }
    else if (show_state == 5)
    {
        switch_state = DEBUG_CLOSE;
    }
    else
    {
        goto FUNC_EXIT;
    }

    sprintf(msg_buffer, CONFIG_DEBUG_FORMAT, SYS_WEBUI_DEBUG_CONFIG, switch_state);

    int xml_msg_len = strlen(msg_buffer);

    pst_xml_msg = (NAC_WEB_MSG*)malloc((xml_msg_len+sizeof(NAC_WEB_MSG)+1));
    if (pst_xml_msg == NULL)
    {
        printf("%s-->malloc fail\n", __FUNCTION__);
        goto FUNC_EXIT;
    }
    memset(pst_xml_msg, '\0', sizeof(NAC_WEB_MSG));

    pst_xml_msg->us_cmd  = SYS_WEBUI_DEBUG_CONFIG;
    pst_xml_msg->reserve = 0;
    pst_xml_msg->ui_len  = xml_msg_len;
    memcpy(pst_xml_msg->ac_buf, msg_buffer, xml_msg_len);

    int dst_address = inet_network("127.0.0.1");
    unsigned short flag = 0;
    nac_app_short_tcp_msg_send(pst_xml_msg, dst_address, &flag);
    free(pst_xml_msg);

    if (switch_state == DEBUG_OPEN)
    {
        printf("open nac_system debug_switch %s!\n", (flag == 1)?("success"):("failure"));
    }
    else
    {
        printf("close nac_system debug_switch %s!\n", (flag == 1)?("success"):("failure"));
    }

FUNC_EXIT:
    return 0;
}

