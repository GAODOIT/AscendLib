#include "nac_app_debug_user.h"
#include "nac_app_debug_config.h"
#include "nac_app_debug_main.h"

HUPU_INT32 nac_app_short_tcp_msg_send(NAC_WEB_MSG* pst_msg, unsigned int dst_addr, unsigned short *status)
{
    HUPU_INT32 iRet;
    fd_set  readfd;
    struct timeval st_timeout;
    HUPU_INT32  recv_len;
    HUPU_CHAR   ac_buffer_recv[1024*10];
    HUPU_UINT32 sock_fd = 0;
    HUPU_UINT32 msg_len;

    sock_fd = nac_tcp_crt_cli();
    if (sock_fd == HUPU_ERR)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "create tcp client error!\n");
        goto FUNC_EXIT;
    }

    iRet = nac_tcp_connect(sock_fd, dst_addr, NAC_APP_SERVER_LISTEN_PORT);
    if (iRet < 0)
    {
        if (errno == EINPROGRESS)
        {
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "tcp connect timeout\n");
        }
        goto FUNC_EXIT_1;
    }

    msg_len = pst_msg->ui_len + sizeof(NAC_WEB_MSG);
    SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS,
                    "send_msg:send_len=%d cmd=%d len=%d msg=%s\n",
                    msg_len, pst_msg->us_cmd,
                    pst_msg->ui_len, pst_msg->ac_buf);
    iRet = nac_tcp_sendto(sock_fd, (HUPU_CHAR*)pst_msg, msg_len);
    if (iRet != msg_len)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_tcp_sendto error!\n");
        goto FUNC_EXIT_1;
    }

    st_timeout.tv_sec  = 5;
    st_timeout.tv_usec = 0;
    FD_ZERO(&readfd);
    FD_SET(sock_fd, &readfd);

    iRet = select(sock_fd + 1,
                &readfd,
                HUPU_NULL,
                HUPU_NULL,
                &st_timeout);
    if (iRet <= HUPU_ERR)
    {
        /*
        if (errno == EINTR)
        {
            continue;
        }
        */
        goto FUNC_EXIT_1;
    }
    else if (iRet == HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "select timeout!\n");
        goto FUNC_EXIT_1;
    }

    if (FD_ISSET(sock_fd, &readfd) > 0)
    {
        memset(ac_buffer_recv, '\0', sizeof(ac_buffer_recv));
        iRet = nac_tcp_recvfrom(sock_fd, ac_buffer_recv, sizeof(ac_buffer_recv));
        if (iRet <= 0)
        {
                SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "sock_fd read error!\n");
        }
        else
        {
            recv_len = iRet;
            NAC_WEB_MSG *pst_recv_msg = (NAC_WEB_MSG*)ac_buffer_recv;
            SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS,
                            "recv_msg:recv_len=%d cmd=%d len=%d msg=%s\n",
                            recv_len, pst_recv_msg->us_cmd,
                            pst_recv_msg->ui_len, pst_recv_msg->ac_buf);

            if (strstr(pst_recv_msg->ac_buf, "<result>0</result>") != NULL)
            {
                *status = 1;
            }
        }
    }

FUNC_EXIT_1:
    nac_tcp_destroy(sock_fd);
FUNC_EXIT:
    return HUPU_OK;
}

void print_usage_help(void)
{
    printf("help usage:\n\
    config \tshow nac_system all config\n\
    netstat\tshow nac_system socket status\n\
    enable \topen nac_system debug switch\n\
    disable\tclose nac_system debug switch\n\
    flush  \tflush all knl online_user\n\
    netapp \tshow nac_app netapp_user\n\
    extract  [tar.log] ... [tar.log]\n\
    add|del  ip[10.10.5.3] mac[88-32-9B-3D-53-EB]\n");
}

HUPU_INT32 main(HUPU_INT32 argc, HUPU_CHAR *argv[])
{
    O_DEBUG_USER user_debug_st;
    int status = 0;

    if (argc < 2)
    {
        print_usage_help();
        goto MAIN_EXIT;
    }

    memset(&user_debug_st, '\0', sizeof(O_DEBUG_USER));
    if ( !memcmp(argv[1], "add", strlen("add")) )
    {
        if (argc < 4)
        {
            print_usage_help();
            goto MAIN_EXIT;
        }
        status = 1;
        user_debug_st.action = USER_ADD;
        memcpy(user_debug_st.ip_addr, argv[2], strlen(argv[2]));
        memcpy(user_debug_st.ac_mac, argv[3], strlen(argv[3]));
    }
    else if ( !memcmp(argv[1], "del", strlen("del")) )
    {
        if (argc < 4)
        {
            print_usage_help();
            goto MAIN_EXIT;
        }
        status = 1;
        user_debug_st.action = USER_DEL;
        memcpy(user_debug_st.ip_addr, argv[2], strlen(argv[2]));
        memcpy(user_debug_st.ac_mac, argv[3], strlen(argv[3]));
    }
    else if ( !memcmp(argv[1], "flush", strlen("flush")) )
    {
        status = 1;
        user_debug_st.action = USER_FLUSH;
    }
    else if ( !memcmp(argv[1], "config", strlen("config")) )
    {
        status = 2;
    }
    else if ( !memcmp(argv[1], "netstat", strlen("netstat")) )
    {
        status = 3;
    }
    else if ( !memcmp(argv[1], "enable", strlen("enable")))
    {
        status = 4;
    }
    else if ( !memcmp(argv[1], "disable", strlen("disable")))
    {
        status = 5;
    }
    else if ( !memcmp(argv[1], "netapp", strlen("netapp")))
    {
        status = 6;
    }
    else if (!memcmp(argv[1], "extract", strlen("extract")))
    {
        if (argc < 3)
        {
            printf("please input the log_tar, one or more!\n");
            goto MAIN_EXIT;
        }

        int i;
        for (i=2; i < argc; i++)
        {
            nac_app_decrypt_tar_log(argv[i]);
            printf("\n");
        }

    }
    else
    {
        print_usage_help();
        goto MAIN_EXIT;
    }

    if (status == 1)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "type=%d--mac=%s--ip=%s\n",
                            user_debug_st.action, user_debug_st.ac_mac, user_debug_st.ip_addr);
        nac_app_debug_user_deal(&user_debug_st);
    }
    else if (status == 2 || status == 3)
    {
        nac_app_debug_config_deal(status);
    }
    else if (status == 4 || status == 5)
    {
        nac_app_enable_system_log_switch(status);
    }
    else if (status == 6)
    {
        nac_app_debug_netapp_user(status);
    }

MAIN_EXIT:
    return HUPU_OK;
}

