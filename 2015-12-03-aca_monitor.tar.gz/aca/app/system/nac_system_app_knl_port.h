#ifndef NAC_SYSTEM_APP_KNL_PORT_H
#define NAC_SYSTEM_APP_KNL_PORT_H
#include "nac_system_common_lib.h"
//NAC_KNL_RBTREE_ISOLATION_ZONE, NAC_CMD_RBTREE_INS
/*operate knl isolate_zone rbtree: input min_addr and max_addr is int_host_byte*/
HUPU_INT32 nac_app_set_isolate_iprange_to_knl_rbtree(NAC_KNL_RBTREE_TYPE rbtree_type,
			HUPU_UINT16 rbtree_opt_type, HUPU_UINT32 min_addr, HUPU_UINT32 max_addr, HUPU_UINT16 zone_id);

/*operate knl rbtree: input min_addr and max_addr is int_host_byte*/
HUPU_INT32 nac_sys_set_iprange_to_knl_rbtree(HUPU_UINT32 min_addr, HUPU_UINT32 max_addr,
			NAC_KNL_RBTREE_TYPE rbtree_type, HUPU_UINT16 rbtree_opt_type);

/*operate knl rbtree: input min and max is string*/
HUPU_INT32 nac_sys_set_iprange_str_to_knl_rbtree(NAC_KNL_RBTREE_TYPE rbtree_type,
			HUPU_UINT16 rbtree_opt_type, HUPU_VOID *min, HUPU_VOID *max);

/*get domain host ipaddr and sent it to knl rebtree*/
HUPU_INT32 nac_app_set_domain_host_ipaddr_to_knl(NAC_KNL_RBTREE_TYPE rbtree_type,
        HUPU_UINT16 rbtree_opt_type, HUPU_CHAR* domain_tmp, HUPU_UINT16 domain_id);

/*operate knl rbtree: input is ipgroup*/
HUPU_INT32 nac_sys_set_knl_rebtree_ipgroup(NAC_KNL_RBTREE_TYPE rbtree_type,
			HUPU_UINT16 rbtree_opt_type, HUPU_CHAR *ip_group);

#endif
