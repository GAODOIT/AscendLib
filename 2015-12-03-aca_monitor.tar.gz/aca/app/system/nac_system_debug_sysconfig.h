#ifndef NAC_SYSTEM_DEBUG_SYSCONFIG_H
#define NAC_SYSTEM_DEBUG_SYSCONFIG_H

#include "nac_system_common_lib.h"

#define NAC_APP_SHOW_SYS_CONFIG_FILE	"/var/log/nac_asc/tmp/nac_debug_sys_conf.log"
#define NAC_APP_SHOW_NETAPP_USER_FILE   "/var/log/nac_asc/tmp/nac_debug_netapp_user.log"

/*save current system config for debug show----success: HUPU_OK, fault: HUPU_ERR*/
HUPU_INT32 nac_app_debug_save_sys_config(const HUPU_CHAR* config_file);

/*save current arp_list for debug show----success: HUPU_OK, fault: HUPU_ERR*/
HUPU_INT32 nac_app_save_device_info_hlist_for_show(const HUPU_CHAR* config_file);

#endif
