#ifndef NAC_SYSTEM_USER_H
#define NAC_SYSTEM_USER_H

#define NAC_SYS_USER_HASH_SIZE      1024*2

typedef struct NAC_SYS_USER_STRU
{
    struct nac_list_head lnode;
    struct nac_hlist_node node;
    HUPU_INT16  os_type;
    HUPU_INT16  user_type;
    HUPU_UINT16 userid;
    HUPU_UINT16 depid;
    HUPU_UINT32 ip;
    HUPU_CHAR mac[ETH_ALEN];
	//0:no need check; 1:need_check;
    HUPU_UINT8 need_check; //check_status
    //0:auth_success, 1:auth_failure;
    HUPU_UINT8 auth_status;//auth_status
    HUPU_UINT32 cmd;//offline_type
    HUPU_UINT32 isolation_num;
    HUPU_UINT32 isolation_zone[16]; //max 16
} NAC_SYS_USER;

extern struct nac_list_head offline_user_list_head;

HUPU_INT32 nac_system_init_offline_user_list(HUPU_VOID);
HUPU_INT32 nac_system_destory_offline_user_list(HUPU_VOID);
HUPU_INT32 __nac_system_show_offline_user_list(HUPU_VOID);

xmlDocPtr nac_sys_parse_user_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id);
HUPU_INT32 nac_sys_netlink_user_timeout(NAC_KNL_USER_MSG *nlk_usr_msg, HUPU_INT32 sock_fd);
HUPU_INT32 nac_sys_netlink_user_os_check(NAC_KNL_USER_MSG *nlk_usr_msg, HUPU_INT32 sock_fd);
HUPU_INT32 nac_system_send_offline_user_to_server(HUPU_UINT32 ui_sockfd);
HUPU_INT32 nac_sys_netlink_add_tmp_user(NAC_KNL_USER_MSG *netlink_usr_msg);
HUPU_INT32 nac_sys_netlink_add_tmp_domain(NAC_KNL_USER_MSG *netlink_usr_msg);
HUPU_INT32 nac_sys_netlink_del_tmp_domain(NAC_KNL_USER_MSG *netlink_usr_msg);
HUPU_INT32 nac_sys_netlink_add_tmp_nat(NAC_KNL_USER_MSG *netlink_usr_msg);
HUPU_INT32 nac_sys_netlink_del_tmp_nat(NAC_KNL_USER_MSG *netlink_usr_msg);
#endif
