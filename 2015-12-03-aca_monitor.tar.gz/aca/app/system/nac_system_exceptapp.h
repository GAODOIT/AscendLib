/*
 *
 * Part:        nac except app.
 *
 * Author:      cxk
 *
 */

#ifndef __EXCEPTAPP_HEAD__
#define __EXCEPTAPP_HEAD__

#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_common_lib.h"
#include "nac_system_errorlog.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>


#define CONFIG_FILE_PATH  "/nac/config/nac_sys.conf"

xmlDocPtr nac_system_parse_exceptapp_config(xmlDocPtr doc, HUPU_UINT16 cmd_id);
//typedef xmlDocPtr (*HANDLE_DATA)(xmlDocPtr doc, void *except_app);
typedef struct __EXCEPT_APP_DATA__
{
    HUPU_INT32 status;
    HUPU_INT32 port;
    HUPU_CHAR ip[32];
    HUPU_CHAR proto[8];
    HUPU_CHAR comment[MAX_LEN];
} O_EXCEPT_APP_DATA, *P_EXCEPT_APP_DATA;
typedef struct __EXCEPT_APP__
{
    HUPU_INT32 flag;
    HUPU_INT32 enable;
    HUPU_INT32 num;
    //HANDLE_DATA handle;
    P_EXCEPT_APP_DATA  pData;

} O_EXCEPT_APP, *P_EXCEPT_APP;
enum ACTION_TYPE
{
    EXCEPT_APP_SHOW,
    EXCEPT_APP_UPDATE,
    EXCEPT_APP_FLUSH
};

#define BULK_SHOW  		EXCEPT_APP_SHOW
#define BULK_UPDATE  	EXCEPT_APP_UPDATE
#define BULK_FLUSH  	EXCEPT_APP_FLUSH


HUPU_INT32 get_list_exceptapp_value(HUPU_CHAR (*p_list)[MAX_LEN], P_EXCEPT_APP_DATA p_data,HUPU_INT32 num);

P_EXCEPT_APP get_expect_struct_point(void);

HUPU_INT32 get_exceptapp_data_form_configure(const HUPU_CHAR *file_path);


HUPU_INT32 write_exceptapp_data_to_configure(FILE* fp);

xmlDocPtr nac_sys_return_exceptapp_result(HUPU_INT32 action_type, P_EXCEPT_APP pData);

HUPU_INT32 nac_sys_parse_exceptapp_result(xmlNodePtr cur_node, P_EXCEPT_APP pData, HUPU_UINT8 action_type);

HUPU_INT32 nac_system_set_exceptapp_data_to_kernel(P_EXCEPT_APP pData);

xmlDocPtr nac_system_parse_exceptapp_config(xmlDocPtr doc, HUPU_UINT16 cmd_id);

HUPU_INT32 nac_sys_flush_except_app_config(void);





#endif
