#ifndef NAC_SYSTEM_SAVE_SYSCONFIG_H
#define NAC_SYSTEM_SAVE_SYSCONFIG_H
#include "nac_system_common_lib.h"
extern HUPU_CHAR* nac_sys_cfg_file;

HUPU_VOID nac_sys_save_vlanmap(FILE* fp);
HUPU_VOID nac_system_show_iprange_policy_hlist(FILE* fp, EM_POLICY_TYPE ip_type);
HUPU_VOID nac_system_show_domain_policy_hlist(FILE* fp, EM_POLICY_TYPE domain_type);

/*save config to file---success: HUPU_OK, fault: HUPU_ERR*/
HUPU_INT32 nac_app_save_sys_config_to_file(const HUPU_CHAR* config_file);

/*read config from file---success: HUPU_OK, fault: HUPU_ERR;*/
//HUPU_INT32 nac_app_read_sys_config_from_file(const HUPU_CHAR* config_file);
HUPU_INT32 nac_app_read_sys_config_from_file(const HUPU_CHAR* config_file, HUPU_UINT8 flag);

HUPU_INT32 nac_sys_init_safe_ipzone_config(const HUPU_CHAR* filename);

#endif
