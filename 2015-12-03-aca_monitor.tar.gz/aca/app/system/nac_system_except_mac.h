#ifndef NAC_SYSTEM_EXCEPT_MAC_H
#define NAC_SYSTEM_EXCEPT_MAC_H
#include "nac_system_common_lib.h"
#include "nac_system_iprange_policy.h"

HUPU_INT32 nac_sys_flush_except_mac_config(HUPU_VOID);
HUPU_INT32 nac_sys_write_except_mac_data_to_configure(FILE* fp);
HUPU_INT32 nac_sys_get_except_mac_data_form_configure(const HUPU_CHAR *file_path);
xmlDocPtr nac_system_parse_except_mac_config(xmlDocPtr doc, HUPU_UINT16 cmd_id, HUPU_UINT16 policy_type, const HUPU_CHAR* xml_tag);

#endif
