#include "nac_precomp.h" //nac_list.h
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_common_lib.h"
#include "nac_system_errorlog.h"
#include "nac_system_switch_main.h"
#include "nac_system_switch_snmp.h"

//commandID  = SYS_WEBUI_SET_SWITCH_CONTROL(125);
//snmpwalk -v 2c -c cisco1 10.10.2.253 1.3.6.1.2.1.1.1

HUPU_CHAR* switch_sysDescr_mib = "1.3.6.1.2.1.1.1";
HUPU_CHAR* switch_sysName0_mib = "1.3.6.1.2.1.1.5";
HUPU_CHAR* switch_arpTable_mib = "1.3.6.1.2.1.4.22.1.2";

HUPU_CHAR* switch_snmp_walk_v1_format = "snmpwalk -O0q -v 1 -c %s %u.%u.%u.%u %s";
HUPU_CHAR* switch_snmp_walk_v2c_format = "snmpwalk -O0q -v 2c -c %s %u.%u.%u.%u %s";

HUPU_INT32 nac_system_snmp_walk_switch(HUPU_CHAR* snmp_cmd, HUPU_CHAR* snmp_result)
{
	FILE* popen_fp;
	HUPU_CHAR szLine[FILE_LINE_SIZE]="";
	HUPU_UINT32 file_size;  
	
	popen_fp = popen(snmp_cmd, "r");
	if (popen_fp == HUPU_NULL)
	{
		return HUPU_ERR;
	}

	file_size = 0;
	while((fgets(szLine, FILE_LINE_SIZE, popen_fp)) != HUPU_NULL)
	{
		clean_newline_character(szLine);
		memcpy(snmp_result+file_size, szLine, strlen(szLine));
		
		file_size += strlen(szLine);
		memset(szLine, '\0', FILE_LINE_SIZE);
	}

	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->snmp_result[%d]=%s\n",
				__FUNCTION__, strlen(snmp_result), snmp_result);
	
	if (file_size == 0) //connect time_out
	{
		pclose(popen_fp);
		return (HUPU_ERR-1);		
	}

	pclose(popen_fp);
	
	return HUPU_OK;
}

HUPU_INT32 __nac_system_scan_switch_arp_table(NAC_SYSTEM_SWITCH *pst_msg)
{
	HUPU_INT32 iRet;	
	HUPU_CHAR get_buffer[SEND_BUFFER_LEN] ="";
	HUPU_CHAR switch_snmp_walk_cmd[BUFF_LEN] = "";

	sprintf(switch_snmp_walk_cmd, switch_snmp_walk_v2c_format, 
			pst_msg->union_passwd.snmp.ro_community,
			LIPQUAD(pst_msg->switch_ip), switch_sysName0_mib);

	iRet = nac_system_snmp_walk_switch(switch_snmp_walk_cmd, get_buffer);
	
	if (iRet == HUPU_ERR-1)//connect time_out
	{
		return HUPU_ERR;
	}
	
	return HUPU_OK;
}

/*
actionType = SWITCH_SHOW(0); 
root@hupu:~#snmpwalk -O0q -v 1 -c public 10.10.2.246 1.3.6.1.2.1.4.22.1.2
IP-MIB::ipNetToMediaPhysAddress.4.10.10.2.1 00:90:7f:84:50:94
IP-MIB::ipNetToMediaPhysAddress.4.10.10.2.76 8c:89:a5:e9:85:ca
IP-MIB::ipNetToMediaPhysAddress.4.10.10.2.138 d4:3d:7e:20:10:9d
IP-MIB::ipNetToMediaPhysAddress.4.10.10.2.222 00:25:11:a7:90:34
IP-MIB::ipNetToMediaPhysAddress.4.10.10.2.252 b0:51:8e:02:08:a9

<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>999</commandID>
  <actionType>1</actionType>
  <switchInfo>10.10.2.253<switchInfo>
  <ascMac>00:00:00:00:00:00<ascMac>
  <arpTable>192.168.10.2;d4:be:d9:db:17:a9;0</arpTable>
  <arpTable>192.168.10.2;d4:be:d9:db:17:a9;1</arpTable>
</nac>
*/

HUPU_INT32 nac_system_scan_switch_arp_table_to_server(NAC_SYSTEM_SWITCH *pst_msg, HUPU_UINT32 ui_sockfd)
{
	HUPU_INT32 iRet, error_id;
	FILE* popen_fp;
	HUPU_UINT32 file_size;
	HUPU_CHAR szLine[FILE_LINE_SIZE]="";
	HUPU_CHAR switch_snmp_walk_cmd[BUFF_LEN] = "";

	xmlDocPtr sw_doc = HUPU_NULL;
	xmlNodePtr root_node;
	HUPU_UINT16 default_null_vlantag = 0;    
	HUPU_CHAR ip_buffer[IP_STR_LEN]   = "";	
	HUPU_CHAR mac_buffer[MAC_STR_LEN] = "";
	HUPU_CHAR cmd_buffer[IP_STR_LEN]  = "";
	HUPU_UINT16 command_id = SYS_WEBUI_ASC_IMPORT_DEVICE_INFO;	
    
	sprintf(switch_snmp_walk_cmd, switch_snmp_walk_v2c_format, 
			pst_msg->union_passwd.snmp.ro_community,
			LIPQUAD(pst_msg->switch_ip), switch_arpTable_mib);
	popen_fp = popen(switch_snmp_walk_cmd, "r");
	if (popen_fp == HUPU_NULL)
	{
		return HUPU_ERR;
	}

	
	file_size = 0;
	memset(switch_snmp_walk_cmd, '\0', BUFF_LEN);
	if(fgets(szLine, FILE_LINE_SIZE, popen_fp) == HUPU_NULL)
	{
		pclose(popen_fp);
		return (HUPU_ERR-1);
	}

	clean_newline_character(szLine);
	file_size += strlen(szLine);
	iRet = sscanf(szLine, "%s %s", switch_snmp_walk_cmd, mac_buffer);
	if (iRet != 2)
	{	
		pclose(popen_fp);
		return HUPU_ERR;
	}

	iRet = sscanf(switch_snmp_walk_cmd, "%*[^.].%*[^.].%s", ip_buffer);
	if (iRet != 1)
	{	
		pclose(popen_fp);
		return HUPU_ERR;
	}


	sw_doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(sw_doc, root_node);

	memset(cmd_buffer, '\0', sizeof(cmd_buffer));
    sprintf(cmd_buffer, "%d", (command_id + Ret_cmd_offset));
    xmlNewChild (root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_buffer);
    xmlNewChild (root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");

	memset(szLine, '\0', FILE_LINE_SIZE);
	sprintf(szLine, "%u.%u.%u.%u", LIPQUAD(pst_msg->switch_ip));
	xmlNewChild (root_node, HUPU_NULL, BAD_CAST "switchInfo", BAD_CAST szLine);	

	memset(szLine, '\0', FILE_LINE_SIZE);
	sprintf(szLine, "%s;%s", ip_buffer, mac_buffer);
	xmlNewChild(root_node, HUPU_NULL, BAD_CAST "arpTable", BAD_CAST szLine);


	error_id  = 0;	
	memset(szLine, '\0', FILE_LINE_SIZE);
	memset(mac_buffer, '\0', sizeof(mac_buffer));
	memset(ip_buffer, '\0', sizeof(ip_buffer));
	memset(switch_snmp_walk_cmd, '\0', BUFF_LEN);	
	while((fgets(szLine, FILE_LINE_SIZE, popen_fp)) != HUPU_NULL)
	{
		clean_newline_character(szLine);
		file_size += strlen(szLine);
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->%s.\n", __FUNCTION__, szLine);
		
		iRet = sscanf(szLine, "%s %s", switch_snmp_walk_cmd, mac_buffer);
		if (iRet != 2)
		{
			error_id = -1;
			break;
		}
		
		iRet = sscanf(switch_snmp_walk_cmd, "%*[^.].%*[^.].%s", ip_buffer);
		if (iRet != 1)
		{
			error_id = -1;
			break;
		}

		memset(szLine, '\0', FILE_LINE_SIZE);
		sprintf(szLine, "%s;%s;%d", ip_buffer, mac_buffer, default_null_vlantag);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "arpTable", BAD_CAST szLine);
		
		memset(szLine, '\0', FILE_LINE_SIZE);
		memset(mac_buffer, '\0', sizeof(mac_buffer));
		memset(ip_buffer, '\0', sizeof(ip_buffer));
		memset(switch_snmp_walk_cmd, '\0', BUFF_LEN);
		
	}
	pclose(popen_fp);

	if (error_id == -1)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, 
					"%s-->snmpwalk get arpTable error!\n", __FUNCTION__);
		nac_free_xmlDoc(sw_doc);
		return HUPU_ERR;
	}
	
	if (ui_sockfd > 0)
	{
		iRet = nac_sys_send_xmldoc_to_webserver(ui_sockfd, sw_doc, command_id);
	}
	else
	{
		nac_free_xmlDoc(sw_doc);
	}

	return HUPU_OK;
}

HUPU_INT32 nac_system_scan_switch_hlist_for_each_snmp(HUPU_UINT32 ui_sock_fd)
{
	HUPU_INT32 iRet, i;
    struct nac_hlist_node *pos, *n;
    NAC_SYSTEM_SWITCH *pst_switch_tmp;
	NAC_SYSTEM_SWITCH  st_switch_tmp;

	for(i = 0; i < NAC_SYSTEM_SWITCH_HASH_SIZE; i++)
    {
    	nac_system_switch_lock();
 		nac_hlist_for_each_entry_safe(pst_switch_tmp, pos, n, &nac_switch_hash_by_id[i], node)
 		{
 			if (pst_switch_tmp->login_type == NAC_SWITCH_SNMP
				&& pst_switch_tmp->switch_status == NAC_SYSTEM_SWITCH_CONNECT_OK)
 			{
 				memcpy(&st_switch_tmp, pst_switch_tmp, sizeof(NAC_SYSTEM_SWITCH));
				iRet = nac_system_scan_switch_arp_table_to_server(&st_switch_tmp, ui_sock_fd);
				if (iRet == HUPU_ERR-1) //connect time_out;
				{
					pst_switch_tmp->switch_status = NAC_SYSTEM_SWITCH_CONNECT_ERROR;
				}
 			}
 		}
		nac_system_switch_unlock();
	}
	return HUPU_OK;
}

HUPU_VOID nac_system_switch_snmp_walk_thread_enter(HUPU_CHAR *pc_buf)
{
    HUPU_INT32 iRet;
    NAC_SYSTEM_SWITCH *pst_msg = (NAC_SYSTEM_SWITCH *)pc_buf;
	
	while (1)
	{
		sleep(3*60);
		iRet = __nac_system_scan_switch_arp_table(pst_msg);
		if (iRet != HUPU_OK)
		{
			break;
			//send error xml to web
		}
	}
	
	nac_system_modify_switch_status(pst_msg->switch_id, 0, 
									NAC_SYSTEM_SWITCH_CONNECT_ERROR);
	
	free(pc_buf);
    pthread_detach(pthread_self());
    return;
}


//actionType = SWITCH_TEST(4); 
xmlDocPtr nac_system_test_switch_snmp_control(NAC_SYSTEM_SWITCH* pst_switch)
{
	HUPU_INT32 iRet, error_id;
	xmlDocPtr doc;
    xmlNodePtr root_node;
    HUPU_CHAR get_buffer[SEND_BUFFER_LEN] ="";
	HUPU_CHAR switch_snmp_walk_cmd[BUFF_LEN] = "";

	error_id = 0;
    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);
    sprintf(get_buffer, "%d", (SYS_WEBUI_SET_SWITCH_CONTROL + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST get_buffer);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "4");
	
	sprintf(switch_snmp_walk_cmd, switch_snmp_walk_v2c_format, 
			pst_switch->union_passwd.snmp.ro_community,
			LIPQUAD(pst_switch->switch_ip), switch_sysDescr_mib);
	
	memset(get_buffer, '\0', sizeof(get_buffer));
	iRet = nac_system_snmp_walk_switch(switch_snmp_walk_cmd, get_buffer);
	if (iRet == HUPU_OK)
	{
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");
	}
	else if (iRet == HUPU_ERR-1)
	{
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "-1");
		sprintf(get_buffer, 
				"Timeout: No Response from %u.%u.%u.%u;\nplease check you setting!\n",
				LIPQUAD(pst_switch->switch_ip));
	}
	else if (iRet == HUPU_ERR)
	{
		error_id = NAC_SYS_ERROR_EXECUTE_SNMP_CMD_FAIL;
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "-1");
		sprintf(get_buffer, "%s", nac_sys_get_error_log(error_id));	
	}

    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "switchResult", BAD_CAST get_buffer);
	return doc;	
}

//actionType = SWITCH_ADD(1); 
HUPU_INT32 nac_system_add_switch_snmp_control(NAC_SYSTEM_SWITCH* pst_switch)
{
	HUPU_INT32 iRet, error_id;
	HUPU_CHAR get_buffer[SEND_BUFFER_LEN] ="";
	HUPU_CHAR switch_snmp_walk_cmd[BUFF_LEN] = "";

	sprintf(switch_snmp_walk_cmd, switch_snmp_walk_v2c_format, 
			pst_switch->union_passwd.snmp.ro_community,
			LIPQUAD(pst_switch->switch_ip), switch_sysName0_mib);

	error_id = 0;
	iRet = nac_system_snmp_walk_switch(switch_snmp_walk_cmd, get_buffer);
	if (iRet == HUPU_ERR)
	{
		return NAC_SYS_ERROR_EXECUTE_SNMP_CMD_FAIL;
	}
	else if (iRet == HUPU_ERR-1) //connect time_out
	{
		return NAC_SYS_ERROR_SNMP_TEST_SWITCH_FAIL;
	}
	pst_switch->switch_status = NAC_SYSTEM_SWITCH_CONNECT_OK;

	/*
	iRet = nac_system_switch_create_thread(pst_switch);
	if (iRet != HUPU_OK)
	{
		return NAC_SYS_ERROR_CREATE_SWITCH_THREAD_FAIL;
	}
	*/
	
	//pst_switch->switch_id;pst_switch->pthread_id;pst_switch->switch_status
	iRet = nac_system_add_switch(pst_switch);
	if (iRet == HUPU_ERR)
	{
		return NAC_SYS_ERROR_SNMP_ADD_SWITCH_FAIL;
	}
	
	return HUPU_OK;
}


//actionType = SWITCH_MODIFY(3); 
HUPU_INT32 nac_system_modify_switch_snmp_control(NAC_SYSTEM_SWITCH* pst_switch)
{
	HUPU_INT32 iRet, error_id;
	HUPU_CHAR get_buffer[SEND_BUFFER_LEN] ="";
	HUPU_CHAR switch_snmp_walk_cmd[BUFF_LEN] = "";

	sprintf(switch_snmp_walk_cmd, switch_snmp_walk_v2c_format, 
			pst_switch->union_passwd.snmp.ro_community,
			LIPQUAD(pst_switch->switch_ip), switch_sysName0_mib);

	error_id = 0;
	iRet = nac_system_snmp_walk_switch(switch_snmp_walk_cmd, get_buffer);
	if (iRet == HUPU_ERR)
	{
		return NAC_SYS_ERROR_EXECUTE_SNMP_CMD_FAIL;
	}
	else if (iRet == HUPU_ERR-1) //connect time_out
	{
		return NAC_SYS_ERROR_SNMP_TEST_SWITCH_FAIL;
	}

	pst_switch->switch_status = NAC_SYSTEM_SWITCH_CONNECT_OK;

	iRet = nac_system_modify_switch_st(pst_switch);
	if (iRet == HUPU_ERR)
	{
		return NAC_SYS_ERROR_SNMP_MODIFY_SWITCH_FAIL;
	}
	
	return HUPU_OK;
}


