#include "nac_system_os_check.h"

unsigned int nac_app_os_check_swit = 0; //0-->disable, 1-->enable;

/*
typedef enum
{
    OTHERS = 0,
    LINUX = 1,
    WINDOWS = 2,
    ANDROID = 3,
    IOS = 4,
    OSX = 5,
    WPHONE = 6,
    TYPE_MAX
} USER_AGENT_TYPE;
*/

struct USER_AGENT_KEY_WORDS_STRU
{
    char *keyword;
	int cls;
} USER_AGENT_KEY_WORDS[] = {
                            { "iPad",             IOS},
                            { "iPhone",           IOS},
                            { "Windows NT ",      WINDOWS},
                        	{ "Windows Phone",    WPHONE},
                            { "(Mobile;",         WPHONE},
                            { " OS X",            OSX},
                            { "Macintosh;",       OSX},
                            { " Android ",        ANDROID},
                            { "(Android ",        ANDROID},
                            { "Linux ",           LINUX},
                            { "HUPUNAC",          WINDOWS},
                            { "HuPuApp",          WINDOWS},
                            { "MacBook",          OSX}//MacBook Pro or MacBook Air
                          };


HUPU_VOID nac_system_init_user_agent(HUPU_VOID)
{
    int i = 0;
    int array_len = ARRAYLEN(USER_AGENT_KEY_WORDS);

    nac_set_data_to_knl(NAC_CMD_USER_AGENT_FLUSH, 0, NULL, 0);

    for(i = 0; i < array_len; i++)
    {
        nac_set_data_to_knl(NAC_CMD_USER_AGENT_INS, USER_AGENT_KEY_WORDS[i].cls,
                            USER_AGENT_KEY_WORDS[i].keyword, strlen(USER_AGENT_KEY_WORDS[i].keyword));
    }
}

HUPU_INT32 nac_system_debug_os_check_status(FILE* fp)
{
	fputs("os_check_swit--------------------------\n", fp);
    fprintf(fp, "os_check_swit=%s\n", (nac_app_os_check_swit == HUPU_ENABLE)?"enable":"disable");
	fputs("end------------------------------------\n", fp);
    return HUPU_OK;
}

static xmlDocPtr nac_sys_return_os_check_result(HUPU_INT32 action_type)
{
	xmlDocPtr doc;
    xmlNodePtr root_node;
    //HUPU_CHAR cmd_str[256] = {0};
    create_xml_doc(&doc, &root_node);
   	if(action_type == APP_SHOW)
	{
        insert_number_xml_new_child(root_node, "commandID", (SYS_WEBUI_OS_CHECK_CONFIG + Ret_cmd_offset));
        insert_number_xml_new_child(root_node, "actionType", action_type);
        insert_number_xml_new_child(root_node, "OSCheckSwit", nac_app_os_check_swit);
	}
	else if (action_type == APP_UPDATE)
	{
        insert_number_xml_new_child(root_node, "commandID", (SYS_WEBUI_OS_CHECK_CONFIG + Ret_cmd_offset));
        insert_number_xml_new_child(root_node, "actionType", action_type);
        insert_number_xml_new_child(root_node, "result", 1); //result=1-->success;result=0-->fault
        insert_number_xml_new_child(root_node, "OSCheckSwit", nac_app_os_check_swit);
	}
	return doc;
}

static HUPU_INT32 nac_sys_parse_os_check_result(xmlNodePtr cur_node, HUPU_UINT32 *pdata, HUPU_UINT8 action_type)
{
    xmlNodePtr node = cur_node;
    xmlChar *xml_value;
    //xmlChar *xml_attr;
    for(;node;)
    {
        if (!(xmlStrcmp(node->name, BAD_CAST "OSCheckSwit")))
        {
            xml_value = xmlNodeGetContent(node);
			*pdata = atoi((HUPU_CHAR*)xml_value);
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "OSCheckSwit----%d-- xml_value=%s\n", pdata, xml_value);
		    xmlFree(xml_value);
            break;
        }
        node = node->next;
    }
    return 0;
}

HUPU_INT32 nac_system_set_os_check_swit_to_kernel(unsigned int swit)
{
    HUPU_INT32 status = 0;
    status = nac_set_data_to_knl(NAC_CMD_SYS_SET_OS_CHECK, swit, NULL, 0);
    if (status != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl--status = %d\n", status);
    }
    return status;
}

xmlDocPtr nac_system_parse_os_check(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_UINT8 action_type;
    xmlNodePtr cur_node = NULL;
    xmlDocPtr re_doc;
    cur_node = nac_xml_parse_get_action(doc, &action_type);
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "into handle cmd_id = %d action type = %d \n", cmd_id, action_type);
    if(action_type == APP_SHOW)
    {
        re_doc = nac_sys_return_os_check_result(action_type);

    }
    else if (action_type == APP_UPDATE)
    {
        nac_sys_parse_os_check_result(cur_node, &nac_app_os_check_swit, action_type);
        nac_system_set_os_check_swit_to_kernel(nac_app_os_check_swit);
        re_doc = nac_sys_return_os_check_result(action_type);
    }
    nac_free_xmlDoc(doc);
    return re_doc;
}

//write os_check_swit to config file
HUPU_INT32 nac_sys_write_os_check_swit_to_configure(FILE* fp)
{
    HUPU_CHAR content[1024*10] = {0};
    HUPU_CHAR buffer[512]={0};
    strcat(content, "os_check_swit_config\n{\n");
    sprintf(buffer,"    os_check_swit=%d\n", nac_app_os_check_swit);
    strcat(content, buffer);
    strcat(content, "}\n\n");
    fprintf(fp, "%s", content);
    return 0;
}

HUPU_INT32 nac_sys_get_os_check_swit_from_configure(const HUPU_CHAR *file_path)
{
    HUPU_INT32 iRet;
    HUPU_CHAR buffer[1024*1024] = {0};
    HUPU_CHAR content[1024*10] = {0};
    HUPU_INT32 fd = 0;
    HUPU_CHAR  *p_value = NULL;

    fd = open(file_path, O_RDONLY);
    read(fd, buffer, 1024*1024);
    close(fd);

    memset(content, 0, sizeof(content));
    if(get_content(buffer, content, "os_check_swit_config") < 0)
    {
        goto GO_EXIT;
    }

    p_value = each_line_search(content, "os_check_swit");
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "os_check_swit=%s\n", p_value);
    iRet = atoi(p_value);
    if (iRet > 0)
    {
        nac_app_os_check_swit = 1;
    }
    else
    {
        nac_app_os_check_swit = 0;
    }
    nac_system_set_os_check_swit_to_kernel(nac_app_os_check_swit);
    return 0;
    GO_EXIT:
        return -1;
}
