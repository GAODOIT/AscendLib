#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_net.h"
#include "nac_system_errorlog.h"
#include "nac_system_redirect_manager_ip.h"

struct nac_knl_ip_info gst_redirect_manager_ip;

HUPU_VOID nac_sys_init_redirect_manager_ip_info(HUPU_VOID)
{
	memset(&gst_redirect_manager_ip, 0, sizeof(struct nac_knl_ip_info));
    gst_redirect_manager_ip.en_redirect_flag = NAC_KNL_POLICY_REDIRECT;
	strcpy(gst_redirect_manager_ip.ac_redirect_ip, "0.0.0.0");
	strcpy(gst_redirect_manager_ip.ac_control_manager_ip, "0.0.0.0");
	strcpy(gst_redirect_manager_ip.ac_server_manager_ip, "0.0.0.0");
	strcpy(gst_redirect_manager_ip.ac_control_untrust_ip, "0.0.0.0");
	strcpy(gst_redirect_manager_ip.ac_control_trust_ip, "0.0.0.0");
	return;
}

HUPU_INT32 nac_sys_set_knl_redirect_manager_ip(struct nac_knl_ip_info* pst_redirect_manager_ip)
{
    HUPU_INT32 iRet;
    iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_IP_INFO, 0, pst_redirect_manager_ip, sizeof(struct nac_knl_ip_info));
    if (iRet != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl-->NAC_CMD_SYS_SET_IP_INFO error\n");
		return HUPU_ERR;
    }

	return HUPU_OK;
}

HUPU_INT32 nac_sys_set_redirect_ip(HUPU_CHAR* pst_redirect_ip)
{
	HUPU_INT32 iRet;
	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
                    "redirect_ip=%s-->control_ip=%s-->server_ip=%s-->untrust_ip=%s-->trust_ip=%s\n",
                    gst_redirect_manager_ip.ac_redirect_ip, gst_redirect_manager_ip.ac_control_manager_ip,
                    gst_redirect_manager_ip.ac_server_manager_ip, gst_redirect_manager_ip.ac_control_untrust_ip,
                    gst_redirect_manager_ip.ac_control_trust_ip);

    memset(gst_redirect_manager_ip.ac_redirect_ip, '\0', 16);
	memcpy(gst_redirect_manager_ip.ac_redirect_ip, pst_redirect_ip, 15);
	iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_IP_INFO, 0, &gst_redirect_manager_ip, sizeof(struct nac_knl_ip_info));
    if (iRet != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl-->NAC_CMD_SYS_SET_IP_INFO error\n");
		return HUPU_ERR;
	}
	return HUPU_OK;
}

HUPU_INT32 nac_sys_set_controller_manager_ip(HUPU_UINT32 ui_controller_manager_ip)
{
	HUPU_INT32 iRet;
	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ui_controller_manager_ip = %u.%u.%u.%u\n", LIPQUAD(ui_controller_manager_ip));
	if (ui_controller_manager_ip && (ui_controller_manager_ip != inet_network(gst_redirect_manager_ip.ac_control_manager_ip)))
	{
		memset(gst_redirect_manager_ip.ac_control_manager_ip, '\0', 16);
		sprintf(gst_redirect_manager_ip.ac_control_manager_ip, "%u.%u.%u.%u", LIPQUAD(ui_controller_manager_ip));

		iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_IP_INFO, 0, &gst_redirect_manager_ip, sizeof(struct nac_knl_ip_info));
    	if (iRet != HUPU_OK)
    	{
       		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_SYS_SET_IP_INFO error\n", __FUNCTION__);
			return HUPU_ERR;
		}
	}

	return HUPU_OK;
}

/*
 when asc connect ser, we will set ac_redirect_ip equal to ac_server_manager_ip if ac_redirect_ip = 0.0.0.0.
*/
HUPU_INT32 nac_sys_set_server_manager_ip(HUPU_UINT32 ui_remote_ip)
{
	HUPU_INT32  iRet;
    HUPU_UINT32 controller_manager_ip;//host_bytes
	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ui_remote_ip = %u.%u.%u.%u\n", LIPQUAD(ui_remote_ip));
	memset(gst_redirect_manager_ip.ac_control_manager_ip, '\0', 16);
	iRet = nac_app_get_manager_ifindex();
	controller_manager_ip = nac_app_get_netdev_ipaddr(nac_sys_ifname[iRet]);
	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "controller_manager_ip = %u.%u.%u.%u\n", LIPQUAD(controller_manager_ip));
	sprintf(gst_redirect_manager_ip.ac_control_manager_ip, "%u.%u.%u.%u",  LIPQUAD(controller_manager_ip));

	if(ui_remote_ip)
	{
		memset(gst_redirect_manager_ip.ac_server_manager_ip, '\0', 16);
		sprintf(gst_redirect_manager_ip.ac_server_manager_ip, "%u.%u.%u.%u", LIPQUAD(ui_remote_ip));

		SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "old_ac_redirect_ip-->%s\n", gst_redirect_manager_ip.ac_redirect_ip);
		if (strcmp(gst_redirect_manager_ip.ac_redirect_ip, "0.0.0.0") == 0)
		{
			SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"gst_redirect_manager_ip.ac_redirect_ip error\n");
			memset(gst_redirect_manager_ip.ac_redirect_ip, '\0', 16);
			sprintf(gst_redirect_manager_ip.ac_redirect_ip, "%u.%u.%u.%u", LIPQUAD(ui_remote_ip));
		}
	}

	iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_IP_INFO, 0, &gst_redirect_manager_ip, sizeof(struct nac_knl_ip_info));
    if (iRet != HUPU_OK)
    {
		SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl-->NAC_CMD_SYS_SET_IP_INFO error\n");
		return HUPU_ERR;
	}

	return HUPU_OK;
}

xmlDocPtr nac_xml_parse_redirect_url(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_INT32 iRet, error_id;
	xmlDocPtr  nac_doc = HUPU_NULL;
	xmlNodePtr cur_node;
	xmlChar *szKey, *szAttr;
	HUPU_UINT8 action_type;
	HUPU_CHAR  addr_str[STR_URL_LEN];
    HUPU_UINT8 flag = 1;

	cur_node = nac_xml_parse_get_action(doc, &action_type);
	if (cur_node == HUPU_NULL)
	{
		nac_free_xmlDoc(doc);
		return HUPU_NULL;
	}

	error_id = 0;
	switch (action_type)
	{
	case NAC_SHOW:
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_ret_show_result(cmd_id, "redirectUrl");
		break;

	case NAC_ADD:
		memset (addr_str, '\0', STR_URL_LEN);
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "redirectUrl"))
                && xmlHasProp(cur_node, BAD_CAST "type"))
			{
				szKey = xmlNodeGetContent(cur_node);
				mymemcpy(addr_str, STR_URL_LEN, (HUPU_CHAR*)szKey, strlen((HUPU_CHAR*)szKey));
				xmlFree(szKey);
                szAttr = xmlGetProp(cur_node, BAD_CAST "type");
                flag = atoi((HUPU_CHAR*)szAttr);
                xmlFree(szAttr);
				break;
			}
			cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);

        if (flag == 1)
        {
            gst_redirect_manager_ip.en_redirect_flag = NAC_KNL_POLICY_REDIRECT;
        }
        else
        {
            gst_redirect_manager_ip.en_redirect_flag = NAC_KNL_POLICY_DROP;
        }
		iRet = nac_sys_set_redirect_ip(addr_str);
		if (iRet != HUPU_OK)
		{
			error_id  = NAC_SYS_ERROR_SET_REDIRECT_URL_FAIL;
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_set_data_to_knl-->NAC_CMD_SYS_SET_IP_INFO-->redirect_ip is error, iRet = %d\n",
						__FUNCTION__, iRet);
		}

		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

	default:
		nac_free_xmlDoc(doc);
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
		break;
	}

	return nac_doc;
}

//write redirect_config to config file
HUPU_INT32 nac_sys_write_redirect_config_to_configure(FILE* fp)
{
    HUPU_CHAR content[1024*10] = {0};
    HUPU_CHAR buffer[512]={0};
    strcat(content, "redirect_config\n{\n");
    sprintf(buffer,"    flag=%d\n", gst_redirect_manager_ip.en_redirect_flag);
    strcat(content, buffer);
    sprintf(buffer,"    address=%s\n", gst_redirect_manager_ip.ac_redirect_ip);
    strcat(content, buffer);
    strcat(content, "}\n\n");
    fprintf(fp, "%s", content);
    return 0;
}

HUPU_INT32 nac_sys_get_redirect_config_from_configure(const HUPU_CHAR *file_path)
{
    HUPU_INT32 iRet;
    HUPU_CHAR buffer[1024*1024] = {0};
    HUPU_CHAR content[1024*10] = {0};
    HUPU_INT32 fd = 0;
    HUPU_CHAR  *p_value = NULL;

    fd = open(file_path, O_RDONLY);
    read(fd, buffer, 1024*1024);
    close(fd);

    memset(content, 0, sizeof(content));
    if(get_content(buffer, content, "redirect_config") < 0)
    {
        goto GO_EXIT;
    }

    p_value = each_line_search(content, "flag");
    iRet = atoi(p_value);
    if (iRet > 0)
    {
        gst_redirect_manager_ip.en_redirect_flag = NAC_KNL_POLICY_REDIRECT;
    }
    else
    {
        gst_redirect_manager_ip.en_redirect_flag = NAC_KNL_POLICY_DROP;
    }

    p_value = each_line_search(content, "address");
    if (strlen(p_value))
    {
        nac_sys_set_redirect_ip(p_value);
    }

    return 0;
    GO_EXIT:
        return -1;
}
