#ifndef NAC_SYSTEM_DEAL_LICENSE_H
#define NAC_SYSTEM_DEAL_LICENSE_H

#include "nac_system_common_lib.h"

extern HUPU_UINT8  g_nac_device_type;
extern HUPU_UINT32 g_ui_license_total_htime;
extern HUPU_UINT32 g_ui_license_remain_htime;
extern HUPU_CHAR  *nac_remain_htime_file;

HUPU_INT32 nac_system_check_device_type(HUPU_UINT32 eth_ip_tmp);
HUPU_INT32 nac_system_check_license_file(const HUPU_CHAR* filename);
HUPU_INT32 nac_system_get_license_remain_htime(const HUPU_CHAR* filename);
HUPU_INT32 nac_system_update_license_remain_htime(const HUPU_CHAR* filename);
xmlDocPtr nac_sys_parse_deal_license_info(xmlDocPtr doc, HUPU_UINT16 cmd_id);

HUPU_INT32 nac_system_set_tcp_connect_keepalive(HUPU_UINT32 ui_sockfd);
HUPU_INT32 nac_system_set_tcp_connect_timeout(HUPU_UINT32 ui_sockfd, HUPU_UINT32 time_out);


#endif
