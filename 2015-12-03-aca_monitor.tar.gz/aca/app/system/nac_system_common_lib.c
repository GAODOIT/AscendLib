#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_common_lib.h"

const char *get_default_gw_cmd = "ip route show |grep \"default via\"";
char *get_dns_host_ipaddr = "host %s|grep \"has address\"|grep -v grep|awk '{print $4}'";

const char *ip_pattern = "^([0-9]|[1-9][0-9]|1[0-9]{1,2}|2[0-4][0-9]|25[0-5]).([0-9]|[1-9][0-9]|1[0-9]{1,2}|2[0-4][0-9]|25[0-5]).([0-9]|[1-9][0-9]|1[0-9]{1,2}|2[0-4][0-9]|25[0-5]).([0-9]|[1-9][0-9]|1[0-9]{1,2}|2[0-4][0-9]|25[0-5])$";

//const char *mac_pattern = "[0-9A-Fa-f][0-9A-Fa-f]-[0-9A-Fa-f][0-9A-Fa-f]-[0-9A-Fa-f][0-9A-Fa-f]-[0-9A-Fa-f][0-9A-Fa-f]-[0-9A-Fa-f][0-9A-Fa-f]-[0-9A-Fa-f][0-9A-Fa-f]";
const char *mac_pattern = "[0-9A-F][0-9A-F]-[0-9A-F][0-9A-F]-[0-9A-F][0-9A-F]-[0-9A-F][0-9A-F]-[0-9A-F][0-9A-F]-[0-9A-F][0-9A-F]";

const char *url_pattern = "[a-zA-z]+://[^s]*";

HUPU_INT32 nac_system_check_app_repeat_start(HUPU_VOID)
{
    FILE *popen_fp;
    HUPU_CHAR szLine[BUFF_LEN] = "";
    //HUPU_CHAR* check_nac_system_restart = "ps aux |grep nac_system|grep -v grep|awk '{print $2}'";
    HUPU_CHAR* check_nac_system_restart = "netstat -anp|grep 6001|grep LISTEN|grep nac_system";

    popen_fp = popen(check_nac_system_restart, "r");
    if (popen_fp == HUPU_NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->check nac_system restart cmd error!\n", __FUNCTION__);
        return HUPU_ERR;
    }

    if (fgets(szLine, BUFF_LEN, popen_fp) == HUPU_NULL)
    {
    	pclose(popen_fp);
		return HUPU_OK;
	}
	pclose(popen_fp);

	printf("%s-->nac_system have starting:exit!\n%s\n", __FUNCTION__, szLine);
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_system have starting:exit!\n%s\n", __FUNCTION__, szLine);

	return HUPU_ERR;
}

/*return dest addr, if dest_size <= src_len,copy_len = dest_len; or copy_len = src_len */
void *mymemcpy(void *dest, size_t dest_size, const void *src, size_t src_len)
{
    char *destaddr = dest;
    char const *srcaddr = src;
    int cp_len;

    assert((dest != NULL)&&(src != NULL)&&(dest_size != 0));
    if (dest == NULL || src == NULL || dest_size == 0)
        return NULL;

    if (src_len >= dest_size)
    {
        cp_len = dest_size;
    }
    else
    {
        cp_len = src_len;
    }

    while (cp_len-- >0)
    {
        *destaddr++ = *srcaddr++;
    }

    return dest;
}

/*char ip_str[15] = "255.255.255.255; get domain's host ipaddress*/
int nac_app_get_domain_host_ip_address(char* domain_url)
{
    FILE* popen_fp;
    char get_mac_cmd[100];
    char ip_str[IP_STR_LEN];

    memset(get_mac_cmd, '\0', sizeof(get_mac_cmd));
    sprintf(get_mac_cmd, get_dns_host_ipaddr, domain_url);

    popen_fp = popen (get_mac_cmd, "r");
    memset(ip_str, '\0', IP_STR_LEN);
    while(fgets(ip_str, IP_STR_LEN, popen_fp) != NULL)
    {
        clean_newline_character(ip_str);
        SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->ip_str=%s\n", __FUNCTION__, ip_str);
        memset(ip_str, '\0', IP_STR_LEN);
    }
    fclose(popen_fp);

    return HUPU_OK;
}

/*success: 0; failure: -1*/
int nac_exec_system(const char *string)
{
    pid_t status;

    if (*string == '\0')
    {
        return -1;
    }

	signal(SIGCHLD, SIG_DFL);
    status = system(string);
	signal(SIGCHLD, SIG_IGN);

	/*
	nac_lib_debug(HUPU_INT32 flags,const HUPU_CHAR * fmt,...)(DEBUG_LOG_FOR_NAC_SYS,
				"%s-->status=%d-->WIFEXITED(status)=%d-->WEXITSTATUS(status)=%d\n",
 				__FUNCTION__, status, WIFEXITED(status), WEXITSTATUS(status));
	*/

    if ((-1 != status) && (WIFEXITED(status)) && (0 == WEXITSTATUS(status)))
    {
        return 0;
    }

    return -1;
}

int get_current_time(char *time_str)
{
	char *weekdays[] = {"Sun", "Mon", "Tue", "Wen", "Thu", "Fri", "Sat"};
    time_t current_secs;
    struct tm *current_hutime;

    time(&current_secs);
    current_hutime = gmtime(&current_secs);
    sprintf(time_str, "%04d-%02d-%02d %s %02d:%02d:%02d", 1900+current_hutime->tm_year,
            1+current_hutime->tm_mon, current_hutime->tm_mday, weekdays[current_hutime->tm_wday],
            8+current_hutime->tm_hour, current_hutime->tm_min, current_hutime->tm_sec);

    return 0;
}

int clean_newline_character(char *strSrc)
{
    if (strSrc == NULL)
    {
        return -1;
    }

    while(*strSrc != '\0')
    {
        if (*strSrc == '\r' || *strSrc == '\n')
        {
            *strSrc = '\0';
            break;
        }

        strSrc ++;
    }

    return 0;
}

int strIp_to_intIp(const char* ip_str, unsigned short order)
{
    int retcomp, retexec;
    regex_t myreg;
    regmatch_t pm[replace_max_num];
    const size_t nmatch = replace_max_num;
    char errbuf[ERRBUF] = "";
    if (*ip_str == '\0')
    {
        return -1;
    }

    if (memcmp(ip_str, "NULL", strlen("NULL")) == 0)
    {
        return -1;
    }

    retcomp = regcomp(&myreg, ip_pattern, REG_EXTENDED | REG_NEWLINE);
    if (retcomp != 0)
    {
        regerror(retcomp, &myreg, errbuf, sizeof(errbuf));
        regfree(&myreg);
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "regcomp-->error: %s\n",errbuf);
        return -1;
    }

    retexec = regexec(&myreg, ip_str, nmatch, pm, 0);
    if (retexec !=0)
    {
        regerror(retexec, &myreg, errbuf, sizeof(errbuf));
        regfree(&myreg);
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "regexec-->error: %s\n", errbuf);
        return -1;
    }
    regfree(&myreg);

    struct in_addr in_ip;
    if(inet_aton(ip_str, &in_ip))
    {
        if (order == 1)
        {
            return in_ip.s_addr;
        }
        return ntohl(in_ip.s_addr);
    }
    else
    {
       SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "inet_aton convert error\n");
       return -1;
    }


}


int nac_preg_match_ip(char *src_str)
{
    int retcomp, retexec;
    regex_t myreg;
    regmatch_t pm[replace_max_num];
    unsigned int ip[4];
    const size_t nmatch = replace_max_num;
    char errbuf[ERRBUF] = "";
    ip[0] = 0,ip[1] = 0,ip[2] = 0,ip[3] = 0;

    //SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->src_str=%s\n", __FUNCTION__, src_str);
    if (*src_str == '\0')
    {
        return -1;
    }

    if (memcmp(src_str, "NULL", strlen("NULL")) == 0)
    {
        return -1;
    }

    clean_newline_character(src_str);
    if (sscanf(src_str, "%u.%u.%u.%u", &ip[0], &ip[1], &ip[2], &ip[3]) != 4)
    {
        return -1;
    }

    if (ip[0] > 255 || ip[1] > 255 || ip[2] > 255 || ip[3] > 255)
    {
        return -1;
    }

    retcomp = regcomp(&myreg, ip_pattern, REG_EXTENDED | REG_NEWLINE);
    if (retcomp != 0)
    {
        regerror(retcomp, &myreg, errbuf, sizeof(errbuf));
        regfree(&myreg);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->regcomp-->error: %s\n", __FUNCTION__, errbuf);
        return -1;
    }

    retexec = regexec(&myreg, src_str, nmatch, pm, 0);
    if (retexec !=0)
    {
        regerror(retexec, &myreg, errbuf, sizeof(errbuf));
        regfree(&myreg);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->regexec-->error: %s\n", __FUNCTION__, errbuf);
        return -1;
    }

    regfree(&myreg);

    return 0;
}

int nac_app_preg_match_iprange(char* min_ipstr, char* max_ipstr)
{
	if (nac_preg_match_ip(min_ipstr) == 0 && nac_preg_match_ip(max_ipstr) == 0)
	{
		return 0;
	}
	else
	{
		return -1;
	}

	return 0;
}


int nac_preg_match_mac(char *src_str)
{
    int retcomp, retexec;
    char errbuf[ERRBUF] = {0};

    regex_t myreg;
    regmatch_t pm[replace_max_num];
    const size_t nmatch = replace_max_num;

    if (*src_str == '\0')
    {
        return -1;
    }


    /*不区分大小REG_ICASE*/
    retcomp = regcomp(&myreg, mac_pattern, REG_EXTENDED | REG_NEWLINE | REG_ICASE);
    if (retcomp != 0)
    {
        regerror(retcomp, &myreg, errbuf, sizeof(errbuf));
        regfree(&myreg);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->regcomp-->error: %s\n", __FUNCTION__, errbuf);
        return -1;
    }

    retexec = regexec(&myreg, src_str, nmatch, pm, 0);
    if (retexec !=0)
    {
        regerror(retexec, &myreg, errbuf, sizeof(errbuf));
        regfree(&myreg);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->regexec-->error: %s\n", __FUNCTION__, errbuf);
        return -1;
    }
    regfree(&myreg);

    return 0;
}

int nac_preg_match_url(char *src_str)
{
    int retcomp, retexec;
    char errbuf[ERRBUF] = {0};

    regex_t myreg;
    regmatch_t pm[replace_max_num];
    const size_t nmatch = replace_max_num;

    if (*src_str == '\0')
    {
        return -1;
    }

    retcomp = regcomp(&myreg, url_pattern, REG_EXTENDED | REG_NEWLINE);
    if (retcomp != 0)
    {
        regerror(retcomp, &myreg, errbuf, sizeof(errbuf));
        regfree(&myreg);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->regcomp-->error: %s\n", __FUNCTION__, errbuf);
        return -1;
    }

    retexec = regexec(&myreg, src_str, nmatch, pm, 0);
    if (retexec !=0)
    {
        regerror(retexec, &myreg, errbuf, sizeof(errbuf));
        regfree(&myreg);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->regexec-->error: %s\n", __FUNCTION__, errbuf);
        return -1;
    }
    regfree(&myreg);

    return 0;
}

/*-1:error; 0: unlink; 1: link*/
int nac_netdev_link_detect(const char* net_name)
{
    int skfd = 0;
    struct ifreq ifr;
    unsigned char link_flag = 0;

    skfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(skfd < 0)
    {
        printf("%s:%d Open socket error!\n", __FILE__, __LINE__);
        return -1;
    }

    strcpy(ifr.ifr_name, net_name);

    if (ioctl(skfd, SIOCGIFFLAGS, &ifr) <0 )
    {
		printf("%s-->SIOCGIFFLAGS IOCTL error, Maybe ethernet inferface %s is not valid!", __FUNCTION__, ifr.ifr_name);
        close(skfd);
        return -1;
    }

    if(ifr.ifr_flags & IFF_RUNNING)
    {
        link_flag = 1;
        //printf("%s is link running :)\n", ifr.ifr_name);
    }
    else
    {
        link_flag = 0;
        //printf("%s is not link running :(\n", ifr.ifr_name);
    }
	close(skfd);

    return link_flag;
}

/*-1:error; 0: down; 1: up*/
int nac_netdev_enable_detect(const char* net_name)
{
    int skfd = 0;
    struct ifreq ifr;
    unsigned char enable_flag = 0;

    skfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(skfd < 0)
    {
        printf("%s:%d Open socket error!\n", __FILE__, __LINE__);
        return -1;
    }

    strcpy(ifr.ifr_name, net_name);

    if(ioctl(skfd, SIOCGIFFLAGS, &ifr) <0 )
    {
		printf("%s-->SIOCGIFFLAGS IOCTL error, Maybe ethernet inferface %s is not valid!", __FUNCTION__, ifr.ifr_name);
        close(skfd);
        return -1;
    }

    if(ifr.ifr_flags & IFF_UP)
    {
        enable_flag = 1;
        //printf("%s is enable up :)\n", ifr.ifr_name);
    }
    else
    {
        enable_flag = 0;
        //printf("%s is enable down :(\n", ifr.ifr_name);
    }
	close(skfd);

    return enable_flag;
}


int nac_get_netdev_count(void)
{
	FILE *nac_fp = NULL;
    char szLine[BUFF_LEN] = "";
	char szName[IFNAMSIZE] = "";
    int nCount = 0;

	if ((nac_fp = fopen("/proc/net/dev", "r")) == NULL)
    {
        printf("open /proc/net/dev failed by %s!\n", strerror(errno));
        return nCount;
    }

    fgets(szLine, sizeof(szLine), nac_fp);
    fgets(szLine, sizeof(szLine), nac_fp);
    memset(szLine, '\0', sizeof(szLine));

    while ((fgets(szLine, sizeof(szLine), nac_fp)) != NULL)
    {
		memset(szName, '\0', sizeof(szName));
		sscanf(szLine, "%s", szName);
		sscanf(szName, "%[^:]", szName);
        if (strstr(szName, "eth") != NULL && strstr(szName, ".") == NULL)
        {
			 nCount++;
        }
        memset(szLine, '\0', sizeof(szLine));
    }
	fclose(nac_fp);
    return nCount;
}

/*return netdev count if return <=0 error
int nac_get_netdev_count(char (*net_dev)[IFNAMSIZE])
{
	FILE *nac_fp = NULL;
    char szLine[BUFF_LEN] = "";
	char szName[IFNAMSIZE] = "";
    int nCount = 0;

	if ((nac_fp = fopen("/proc/net/dev", "r")) == NULL)
    {
        printf("open /proc/net/dev failed by %s!\n", strerror(errno));
        return nCount;
    }

    fgets(szLine, sizeof(szLine), nac_fp);
    fgets(szLine, sizeof(szLine), nac_fp);
	memset(szLine, '\0', sizeof(szLine));

    while ((fgets(szLine, sizeof(szLine), nac_fp)) != NULL)
    {

		memset(szName, '\0', sizeof(szName));
		sscanf(szLine, "%s", szName);
		sscanf(szName, "%[^:]", szName);
		int nLen = strlen(szName);

		if (nLen <= 0)
		{
			memset(szLine, '\0', sizeof(szLine));
			continue;
		}
		else if (strstr(szName, "eth") == NULL)
        {
			//(strcmp(szName, "lo") == 0)
            memset(szLine, '\0', sizeof(szLine));
            continue;
        }
        else if (strstr(szName, ".") != NULL)
        {
            memset(szLine, '\0', sizeof(szLine));
            continue;
        }

		memcpy (net_dev[nCount], szName, strlen(szName));
		memset(szLine, '\0', sizeof(szLine));
        nCount++;
    }

	fclose(nac_fp);
    return nCount;
}
*/

/*return 0: get gateway; return -1: no gateway*/
int nac_app_get_system_default_gateway(char* default_gateway)
{
	FILE* popen_fp;
	char line_buffer[BUFF_LEN];

	popen_fp = popen(get_default_gw_cmd, "r");
	if (popen_fp == NULL)
	{
		printf("popen %s fail!\n", get_default_gw_cmd);
		return -1;
	}

	memset(line_buffer, '\0', BUFF_LEN);
	//default via 10.10.2.1 dev eth0
	if (fgets(line_buffer, BUFF_LEN, popen_fp) != NULL)
	{
		sscanf(line_buffer, "%*s%*s%s", default_gateway);
	}
	else
	{
		pclose(popen_fp);
		return -1;
	}

	pclose(popen_fp);
	return 0;
}

/*return 0: get dns_server; return -1: no dns_server*/
int nac_app_get_system_resolv_conf(const char* filename, NAC_DNS_SERVER* st_dnserver)
{
	int line_count;
	FILE* nac_fp;
	char line_buffer[BUFF_LEN];
	//char* pline_content= NULL;

	if ((nac_fp = fopen(filename, "r")) == NULL)
	{
		printf("open %s fail!\n", filename);
		return -1;
	}

	line_count = 0;
	memset(line_buffer, '\0', BUFF_LEN);

	while((fgets(line_buffer, BUFF_LEN, nac_fp)) != NULL)
	{
		if (strstr(line_buffer, "nameserver") != NULL)
		{
			line_count ++;
			if (line_count == 1)
			{
				sscanf(line_buffer, "%*s%s", st_dnserver->nameserver1);
			}
			else if (line_count == 2)
			{
				sscanf(line_buffer, "%*s%s", st_dnserver->nameserver2);
			}
		}
		memset(line_buffer, '\0', BUFF_LEN);
	}
	fclose(nac_fp);

	if (line_count == 0)
	{
		return -1;
	}
	else
	{
		return 0;
	}
}

int nac_app_get_netdev_ipaddr(const char *szDevName)
{
    int s;
    struct ifreq ifr;
    int ipaddr;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0)
    {
        printf("Create socket failed by %s!\n", strerror(errno));
        return -1;
    }

    //printf("netDevName= %s\n", szDevName);
    strcpy(ifr.ifr_name, szDevName);
    if (ioctl(s, SIOCGIFADDR, &ifr) < 0)
    {
        ipaddr = 0;
    }
    else
    {
        ipaddr = ((struct sockaddr_in *)&(ifr.ifr_addr))->sin_addr.s_addr;//net_bytes
    }
	close(s);

    return ntohl(ipaddr);
}

/*
 * 函数声明：char *inet_ntoa (struct in_addr);
 * 返回点分十进制的字符串在静态内存中的指针。
 * typedef uint32_t in_addr_t;
 * struct sockaddr == struct sockaddr_in->struct in_addr sin_addr->in_addr_t s_addr;
*/
int nac_app_get_system_netcard_info(const char *szDevName, NAC_NET_DEVICE *netcard_info)
{
    struct ifreq ifr;
	struct sockaddr_in *sockaddr_in_ip = NULL;
	struct sockaddr_in *sockaddr_in_netmask = NULL;

	int s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0)
    {
        printf("%s-->Create socket failed by %s!\n", __FUNCTION__, strerror(errno));
        return -1;
    }

	//printf("netDevName=%s\n", szDevName);
	//get if ipaddr
    strcpy(ifr.ifr_name, szDevName);
    if (ioctl(s, SIOCGIFADDR, &ifr) < 0)
	{
        memcpy(netcard_info->if_ip, "NULL", strlen("NULL"));
	}
    else
	{
		sockaddr_in_ip = (struct sockaddr_in *)&(ifr.ifr_addr);
		strcpy(netcard_info->if_ip, inet_ntoa(sockaddr_in_ip->sin_addr));
		//memcpy(netcard_info->if_ip, inet_ntoa(sockaddr_in_ip->sin_addr), strlen(inet_ntoa(sockaddr_in_ip->sin_addr)));
	}
	//printf("ipaddr:%s\n", netcard_info->if_ip);

	//get if netmask
	strcpy(ifr.ifr_name, szDevName);
    if (ioctl(s, SIOCGIFNETMASK, &ifr) < 0)
	{
        memcpy(netcard_info->if_mask, "NULL", strlen("NULL"));
	}
    else
	{
		sockaddr_in_netmask = (struct sockaddr_in *)&(ifr.ifr_netmask);
		strcpy(netcard_info->if_mask, inet_ntoa(sockaddr_in_netmask->sin_addr));
		//memcpy(netcard_info->if_mask, inet_ntoa(sockaddr_in_netmask->sin_addr), strlen(inet_ntoa(sockaddr_in_netmask->sin_addr)));
	}
	//printf("netmask:%s\n", netcard_info->if_mask);

	//get enable and link status
	strcpy(ifr.ifr_name, szDevName);
	if(ioctl(s, SIOCGIFFLAGS, &ifr) < 0)
	{
		printf("%s-->SIOCGIFFLAGS IOCTL error, Maybe ethernet inferface %s is not valid!", __FUNCTION__, ifr.ifr_name);
		close(s);
		return -1;
	}

	if (ifr.ifr_flags & IFF_RUNNING)
	{
		netcard_info->if_link = 1;
		//printf("%s is link running :)\n", ifr.ifr_name);
	}

	if (ifr.ifr_flags & IFF_UP)
	{
		netcard_info->if_enable = 1;
		//printf("%s is enable up :)\n", ifr.ifr_name);
	}
    close(s);

	return 0;
}

int nac_app_get_netdev_enable_link_status(const char *szDevName)
{
    int iRet, s;
    struct ifreq ifr;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->Create socket failed by %s!\n",
					__FUNCTION__, strerror(errno));
        return -1;
    }

    //get enable and link status
    strcpy(ifr.ifr_name, szDevName);
    if(ioctl(s, SIOCGIFFLAGS, &ifr) < 0)
    {
       	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->SIOCGIFFLAGS IOCTL error, Maybe ethernet inferface %s is not valid!",
					__FUNCTION__, ifr.ifr_name);
        close(s);
        return -1;
    }

    iRet = 0;
    //IFF_RUNNING:connect/unconnect:if_connect; IFF_UP:up/down:if_enable;
    if ((ifr.ifr_flags & IFF_RUNNING) && (ifr.ifr_flags & IFF_UP))
    {
        iRet = 1;
    }

	close(s);
	return iRet;
}

int nac_app_get_netdev_link_and_enable_status(const char *szDevName,
									unsigned char* link_flag, unsigned char* enable_flag)
{
    int	s;
    struct ifreq ifr;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->Create socket failed by %s!\n",
					__FUNCTION__, strerror(errno));
        return -1;
    }

    //get enable and link status
    strcpy(ifr.ifr_name, szDevName);
    if(ioctl(s, SIOCGIFFLAGS, &ifr) < 0)
    {
       	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->SIOCGIFFLAGS IOCTL error, Maybe ethernet inferface %s is not valid!",
					__FUNCTION__, ifr.ifr_name);
        close(s);
        return -1;
    }

    //IFF_RUNNING:connect/unconnect=if_connect;
   	if (ifr.ifr_flags & IFF_RUNNING)
   	{
		*link_flag	= 1;
	}
	else
	{
		*link_flag = 0;
	}

    //IFF_UP:up/down=if_enable;
    if (ifr.ifr_flags & IFF_UP)
    {
		*enable_flag = 1;
    }
	else
	{
		*enable_flag = 0;
	}

	close(s);
	return 0;
}

int nac_app_get_netdev_enable_status(const char *szDevName)
{
    int iRet, s;
    struct ifreq ifr;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->Create socket failed by %s!\n",
					__FUNCTION__, strerror(errno));
        return -1;
    }

    //get enable status
    strcpy(ifr.ifr_name, szDevName);
    if(ioctl(s, SIOCGIFFLAGS, &ifr) < 0)
    {
       	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->SIOCGIFFLAGS IOCTL error, Maybe ethernet inferface %s is not valid!",
					__FUNCTION__, ifr.ifr_name);
        close(s);
        return -1;
    }

    iRet = 0;
    //IFF_UP:up/down=if_enable;
    if (ifr.ifr_flags & IFF_UP)
    {
        iRet = 1;
    }

	close(s);
	return iRet;
}

int nac_app_get_netdev_link_status(const char *szDevName)
{
    int iRet, s;
    struct ifreq ifr;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->Create socket failed by %s!\n",
					__FUNCTION__, strerror(errno));
        return -1;
    }

    //get link status
    strcpy(ifr.ifr_name, szDevName);
    if(ioctl(s, SIOCGIFFLAGS, &ifr) < 0)
    {
       	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->SIOCGIFFLAGS IOCTL error, Maybe ethernet inferface %s is not valid!",
					__FUNCTION__, ifr.ifr_name);
        close(s);
        return -1;
    }

    iRet = 0;
    //IFF_RUNNING:connect/unconnect=if_connect;
    if (ifr.ifr_flags & IFF_RUNNING)
    {
        iRet = 1;
    }
	close(s);

	return iRet;
}

int nac_sys_get_netdev_netmask(char *szDevName, char *if_netmask)
{
	int s;
    struct ifreq ifr;
    struct sockaddr_in *sockaddr_in_netmask = NULL;

	s = socket(AF_INET, SOCK_DGRAM, 0);
	if (s < 0)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,"%s-->Create socket failed by %s!\n",
					__FUNCTION__, strerror(errno));
        close(s);
		return -1;
	}
    strcpy(ifr.ifr_name, szDevName);
    if (ioctl(s, SIOCGIFNETMASK, &ifr) < 0)
    {
    	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,"%s-->ioctl-->get if_netmask error!\n",
					__FUNCTION__);
        memcpy(if_netmask, "NULL", strlen("NULL"));
        close(s);
		return -1;
    }
    else
    {
    	sockaddr_in_netmask = (struct sockaddr_in *)&(ifr.ifr_netmask);
		strcpy(if_netmask, inet_ntoa(sockaddr_in_netmask->sin_addr));
    }

    close(s);

    return 0;
}


int create_xml_doc(xmlDocPtr *doc, xmlNodePtr *root)
{
    *doc = xmlNewDoc(BAD_CAST "1.0");
    if (*doc == NULL)
    {
        printf("create xml_doc fault!\n");
        return -1;
    }

    *root = xmlNewNode(NULL, BAD_CAST "nac");
    xmlDocSetRootElement(*doc, *root);
    return 0;
}

xmlNodePtr insert_number_xml_new_child(xmlNodePtr node, const char *tag, int value)
{
    xmlNodePtr ret_node;
    char xml_item[128];
    memset(xml_item, '\0', sizeof(xml_item));
    sprintf(xml_item, "%d", value);
    ret_node = xmlNewChild(node, NULL, BAD_CAST tag, BAD_CAST xml_item);
    return ret_node;
}

xmlNodePtr insert_string_xml_new_child(xmlNodePtr node, const char *tag, char *value)
{
    xmlNodePtr ret_node;
    ret_node = xmlNewChild(node, NULL, BAD_CAST tag, BAD_CAST value);
    return ret_node;
}

xmlAttrPtr insert_number_xml_new_prop(xmlNodePtr node, const char *tag, int value)
{
    xmlAttrPtr ret_attr;
    char prop_str[128];
    memset(prop_str, 0, sizeof(prop_str));
    sprintf(prop_str, "%d", value);
    ret_attr = xmlNewProp(node, BAD_CAST tag, BAD_CAST prop_str);
    return ret_attr;
}

xmlAttrPtr insert_string_xml_new_prop(xmlNodePtr node, const char *tag, char *value)
{
    xmlAttrPtr ret_attr;
    ret_attr = xmlNewProp(node, BAD_CAST tag, BAD_CAST value);
    return ret_attr;
}

int nac_get_popen_cmd_result(char *cmd, char *result)
{
    int len, start, end;
    FILE *popen_fp = NULL;
    char szLine[256] = "";

    popen_fp = popen(cmd, "r");
    if (popen_fp == NULL)
    {
        return -1;
    }

    if (fgets(szLine, 256, popen_fp) != NULL)
    {
        len = strlen(szLine);

        start = 0;
        while((szLine[start] == ' '||szLine[start] == '\t') && start < len)
        {
            start++;
        }

        end = len - 1;
        while((szLine[end] == '\n'||szLine[end] == '\r') && end > 0)
        {
            end--;
        }

        memcpy(result, &szLine[start], ((end+1)-start));
    }

    fclose(popen_fp);
    return 0;
}

//get item content form config file
HUPU_INT32 get_content(HUPU_CHAR *buffer, HUPU_CHAR *out, HUPU_CHAR *item_name)

{
   HUPU_CHAR *p = NULL;
   p = strstr(buffer, item_name);
   if(!p)
       return -1;
   //printf("p = %d\n", p);
   HUPU_INT32 flag = 0;
   p = strchr(p, '{');
   HUPU_CHAR *tp = p;
   p += 2;
   for(;;)
   {
        if(*tp == '{')
        {
            flag++;
        }
        if(*tp == '}')
        {
            flag--;
        }
        if(flag == 0)
        {
            tp--;
            for(;;)
            {
                if(*tp != '\n')
                {
                    tp--;
                    continue;
                }
                break;
            }
            break;
        }
        tp++;

   }
   if(out)
   {
       HUPU_CHAR *sp = NULL;
       for(sp = out;p <= tp; *sp++ = *p++);
   }
   return 0;
}

// search str and get the str value in config buffer
HUPU_CHAR *each_line_search(HUPU_CHAR *buffer, HUPU_CHAR *str)
{
    static HUPU_CHAR u_static[64];
    HUPU_CHAR *pp = strstr(buffer, str);
    if (pp)
    {
        pp = strstr(pp, "=");
        if(pp)
        {
            HUPU_CHAR *p_static = u_static;
            memset(p_static, 0, sizeof(u_static));
            pp++;
            for(;*pp != '\n'; pp++)
            {
                if (*pp != ' ')
                {
                    *p_static++ = *pp;
                }
            }
        }
    }
    if(*u_static != '\0')
        return u_static;
    return NULL;
}

//get list item in config file buffer
HUPU_INT32 get_list(HUPU_CHAR *content, HUPU_CHAR (*out)[MAX_LEN])
{
    HUPU_CHAR *p = content;
    HUPU_CHAR *pe = NULL;
    HUPU_INT32 i = 0;
    HUPU_CHAR *po = NULL;
    for(;;)
    {
        pe = strchr(p, '\n');
        if (pe)
        {
            po = (HUPU_CHAR *)&out[i];
            i++;
            for(;pe >= p; p++)
            {
                if(*p != ' ' && *p != '\n')
                {
                    memcpy(po, p, pe - p);
                    p = pe + 1;
                    break;
                }
            }
        }
        else
        {
            break;
        }
    }
    return i;
}

HUPU_INT32 split_string(HUPU_CHAR *src, HUPU_CHAR*delim, HUPU_INT32 num, HUPU_CHAR **p)
{
	int i;
	HUPU_CHAR *ptr;
	ptr = strtok(src, delim);
	for(i=0; ptr; i++)
	{
		if(i < num)
		{
			strcpy(p[i], ptr);
		}
		else
		{
			strcat(p[num-1], delim);
			strcat(p[num-1], ptr);
		}
		ptr = strtok(NULL, delim);
	}
	return i;
}
