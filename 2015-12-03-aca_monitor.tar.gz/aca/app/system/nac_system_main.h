#ifndef NAC_SYSTEM_MAIN_H
#define NAC_SYSTEM_MAIN_H

#ifdef __cplusplus
extern "C" {
#endif
#define	NAC_APP_DEVELOP_VERSION				1172

#define NAC_APP_SERVER_LISTEN_PORT			6001
#define NAC_APP_CLIENT_LINK_PORT            6002

#define NAC_SYS_TCP_MAX_LISTEN_NUM	20
#define NAC_WEB_MSG_BUFFER_LEN      1024*32
///////////////////////////////////////////////////


#define ETH_ALEN 6
#define STR_URL_LEN 16 //for redirect url/ip
#define IP_STR_LEN  16 //for ipaddr str link: 255.255.255.255
#define MAC_STR_LEN 18
#define MAX_COMMENT_LEN 100 //UTF_8(3),BASE64(4);
#define MAX_DOMAIN_LEN  64

//xml.h
#define PARSE_BUFFER_LEN 1024*4
#define SEND_BUFFER_LEN 1024
#define ERROR_LEN	120
#define IP_GROUP_LEN    512

//for nac_system_save_sysconfig.h
#define BUFF_LEN 512
#define KB_BUFF_LEN 1024
//middle
#define MID_BUFF_LEN 512
//small
#define SMALL_BUFF_LEN 128
#define MIN_BUFF_LEN 16

#define MAC_MYFMT   "%02hhx-%02hhx-%02hhx-%02hhx-%02hhx-%02hhx"
#define MAC_FMT     "%02X-%02X-%02X-%02X-%02X-%02X"

/*Uppercase alphabet, lowercase alphabet*/
#define COLON_LOWER_MACFMT "%02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx"

/*
#define MAC_FMT     %02x-%02x-%02x-%02x-%02x-%02x
#define NIPQUAD_FMT %u.%u.%u.%u
*/


#define NIPQUAD(addr) \
    ((unsigned char *)&addr)[0], \
    ((unsigned char *)&addr)[1], \
    ((unsigned char *)&addr)[2], \
    ((unsigned char *)&addr)[3]

#define LIPQUAD(addr) \
    ((unsigned char *)&addr)[3], \
    ((unsigned char *)&addr)[2], \
    ((unsigned char *)&addr)[1], \
    ((unsigned char *)&addr)[0]

#define MAC_FORMAT(addr) \
    ((unsigned char *)&addr)[0], \
    ((unsigned char *)&addr)[1], \
    ((unsigned char *)&addr)[2], \
    ((unsigned char *)&addr)[3], \
    ((unsigned char *)&addr)[4], \
    ((unsigned char *)&addr)[5]

//for char* mac
#define MAC_FORMAT_2(addr) \
    ((unsigned char *)addr)[0], \
    ((unsigned char *)addr)[1], \
    ((unsigned char *)addr)[2], \
    ((unsigned char *)addr)[3], \
    ((unsigned char *)addr)[4], \
    ((unsigned char *)addr)[5]

typedef struct NAC_WEB_MSG_STRU
{
    HUPU_UINT16 us_cmd; //command_id
    HUPU_UINT16 reserve; //for later use
    HUPU_UINT32	ui_len; //strlen(xml_msg)
    HUPU_CHAR   ac_buf[0];
} NAC_WEB_MSG;

#define IFMAXNUM	16
#define IFNAMSIZE	16
typedef struct NAC_NET_DEVICE_STRU
{
    HUPU_UINT16 if_index;
    HUPU_CHAR   if_label[IFNAMSIZE];
    HUPU_CHAR   if_ip[IP_STR_LEN];
    HUPU_CHAR   if_mask[IP_STR_LEN];
    HUPU_UINT8  if_link;
    HUPU_UINT8  if_enable;
} NAC_NET_DEVICE;
//extern NAC_NET_DEVICE g_nac_net_device[];

typedef struct NAC_DNS_SERVER_STRU
{
    HUPU_CHAR nameserver1[IP_STR_LEN];
    HUPU_CHAR nameserver2[IP_STR_LEN];
} NAC_DNS_SERVER;

//except, exempt, safe_ipzone and isolate_ipzone
/*
typedef enum
{
    NAC_APP_EXCEPT_TERMINAL = 1,
    NAC_APP_EXCEPT_SERVER,	//2
    NAC_APP_SAFE_IPZONE,	//3
    NAC_APP_ISOLATE_IPZONE,	//4
	NAC_APP_EXCEPT_DOMAIN,	//5
	NAC_APP_ISOLATE_DOMAIN,	//6
	NAC_APP_EXEMPT_IP,	//7
    NAC_APP_EXEMPT_MAC,	//8
    NAC_APP_EXEMPT_IP_MAC,	//9
	NAC_APP_ALL_POLICY,
} EM_POLICY_TYPE;
*/

typedef enum
{
    NAC_APP_EXCEPT_TERMINAL = 1,
    NAC_APP_EXCEPT_SERVER   = 2,	//2
    NAC_APP_SAFE_IPZONE,	//3
    NAC_APP_ISOLATE_IPZONE,//4
    NAC_APP_EXCEPT_MAC,//4
	NAC_APP_EXCEPT_DOMAIN,
	NAC_APP_ISOLATE_DOMAIN,
	NAC_APP_ALL_POLICY,
} EM_POLICY_TYPE;

/*
		struct
		{
			HUPU_UINT32 ip_addr;
		}ip_key;

		struct
		{
			HUPU_CHAR mac[ETH_ALEN];
		}mac_key;

		struct
		{
			HUPU_UINT32 ip_addr;
			HUPU_CHAR mac[ETH_ALEN];
		}ipmac_key;
*/

//Ascend iprange struct and domain_struct can maybe combine
//1.2.3.4 7.8.9

typedef struct NAC_PBR_ADVANCE_SETUP_STRU
{
    HUPU_UINT32 nexthop_ip;
    HUPU_CHAR nexthop_mac[ETH_ALEN];
    HUPU_CHAR trust_mac[ETH_ALEN];
} NAC_PBR_ADVANCE_SETUP;


extern HUPU_UINT16 g_debug_switch;

#define SYSTEM_PRINT(flags, format, ...) \
{\
    if(g_debug_switch)\
    {\
        nac_lib_debug(flags, format, ##__VA_ARGS__);\
    }\
}

#define SYSTEM_INFO_PRINT(flags, format, ...) \
do{\
	nac_lib_debug(flags, "%s-->%d-->%s:"format, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__);\
}while(0)

#define SYSTEM_ERR_PRINT(flags, format, ...) \
do{\
	nac_lib_debug(flags, "%s-->%d-->%s:"format, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__);\
}while(0)


#define SYSTEM_DEBUG_PRINT(flags, format, ...) \
do{\
	if(g_debug_switch)\
	{\
		nac_lib_debug(flags, "%s-->%d-->%s:"format, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__);\
	}\
}while(0)

HUPU_INT32 nac_control_server_handling_from_web_msg(HUPU_INT32 xml_sock_fd);

#ifdef __cplusplus
}
#endif

#endif //end of NAC_SYSTEM_MAIN_H

