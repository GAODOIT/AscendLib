#ifndef NAC_SYSTEM_PBR_ADVANCE_SETUP_H
#define NAC_SYSTEM_PBR_ADVANCE_SETUP_H
#include "nac_system_common_lib.h"
HUPU_INT32 nac_sys_add_pbr_advance_setup(HUPU_INT32 pbr_flag, NAC_PBR_ADVANCE_SETUP* pbr_setup);
xmlDocPtr nac_sys_parse_pbr_advance_setup(xmlDocPtr doc, HUPU_UINT16 cmd_id);
xmlDocPtr nac_sys_parse_pbr_get_nexthop_mac(xmlDocPtr doc, HUPU_UINT16 cmd_id);

#endif
