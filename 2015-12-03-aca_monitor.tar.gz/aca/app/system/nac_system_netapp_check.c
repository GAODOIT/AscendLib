#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_app_knl_port.h"
#include "nac_system_netapp_user.h"
#include "nac_system_netapp_check.h"

struct nac_hlist_head netapp_hash_by_id[NETAPP_HASH_MAP_SIZE];
HUPU_UINT16 tmp_netapp_enable_id    = 0;
HUPU_UINT16 g_netapp_enable_id		= 0;

HUPU_UINT16 g_netapp_policy_index	= 0;


static inline HUPU_INT32 nac_app_get_hash_by_id(HUPU_UINT16 id)
{
	return id&(NETAPP_HASH_MAP_SIZE - 1);
}

HUPU_INT32 nac_app_init_netapp_hlist(HUPU_VOID)
{
	HUPU_UINT32 i;

	for(i = 0; i < NETAPP_HASH_MAP_SIZE; i++)
	{
		NAC_INIT_HLIST_HEAD(&netapp_hash_by_id[i]);
	}
	return HUPU_OK;
}

HUPU_INT32 nac_app_add_netapp_hlist(NAC_APP_NETAPP_OBJECT *netapp_tmp)
{
	HUPU_UINT16 hash;
	NAC_APP_NETAPP_OBJECT *netapp_ent = HUPU_NULL;
	hash = nac_app_get_hash_by_id(netapp_tmp->id);
	netapp_ent = (NAC_APP_NETAPP_OBJECT*)malloc(sizeof(NAC_APP_NETAPP_OBJECT));
	if (netapp_ent == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
						"%s-->netapp_struct error\n", __FUNCTION__);
		free(netapp_tmp->except_list);
		return HUPU_ERR;
	}
	memset(netapp_ent, '\0', sizeof(NAC_APP_NETAPP_OBJECT));
	memcpy(&netapp_ent->netapp_st, &netapp_tmp->netapp_st,
		sizeof(struct NETAPP_CONFIG_STRU));
	netapp_ent->id		= netapp_tmp->id;
	netapp_ent->enable	= 0;
	netapp_ent->sum 	= netapp_tmp->sum;
	netapp_ent->except_list = netapp_tmp->except_list;
	nac_hlist_add_head(&netapp_ent->netapp_id, &netapp_hash_by_id[hash]);
	return HUPU_OK;
}

HUPU_INT32 nac_sys_flush_netapp_config_hlist(HUPU_VOID)
{
	HUPU_UINT16 hash;
	struct nac_hlist_node *pos, *n;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;
	for(hash = 0; hash < NETAPP_HASH_MAP_SIZE; hash++)
	{
        nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
        {
            nac_hlist_del(&pst_netapp_tmp->netapp_id);
            free(pst_netapp_tmp->except_list);
            free(pst_netapp_tmp);
        }
    }

    return HUPU_OK;
}


HUPU_INT32 nac_app_delete_netapp_hlist(HUPU_UINT16 id)
{
	HUPU_UINT16 hash;
	hash = nac_app_get_hash_by_id(id);
	struct nac_hlist_node *pos, *n;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;
	nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
    {
        if(pst_netapp_tmp->id == id)
        {
			nac_hlist_del(&pst_netapp_tmp->netapp_id);
			free(pst_netapp_tmp->except_list);
            free(pst_netapp_tmp);
            return HUPU_OK;
        }
    }
	return HUPU_ERR;
}

NAC_APP_NETAPP_OBJECT* nac_app_get_netapp_by_id(HUPU_UINT16 id)
{
	HUPU_UINT16 hash;
	hash = nac_app_get_hash_by_id(id);
	struct nac_hlist_node *pos, *n;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;
	nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
    {
        if(pst_netapp_tmp->id == id)
        {
            break;
        }
    }

	return pst_netapp_tmp;
}

HUPU_INT32 nac_app_get_netapp_name_by_id(HUPU_UINT16 id, HUPU_CHAR* name)
{
	HUPU_UINT16 hash;
	hash = nac_app_get_hash_by_id(id);
	struct nac_hlist_node *pos, *n;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;
	nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
    {
        if(pst_netapp_tmp->id == id)
        {
        	memcpy(name, pst_netapp_tmp->netapp_st.name, MAX_COMMENT_LEN);
            break;
        }
    }

	return HUPU_OK;
}


HUPU_INT32 nac_app_modify_netapp_hlist(NAC_APP_NETAPP_OBJECT *netapp_tmp, HUPU_UINT16 type)
{
	HUPU_UINT16 hash;
	struct nac_hlist_node *pos, *n;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;
	hash = nac_app_get_hash_by_id(netapp_tmp->id);
	nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
    {
        if(pst_netapp_tmp->id == netapp_tmp->id)
        {
        	switch(type)
        	{
			case NETAPP_MODIFY_CONFIG:
				memset(&pst_netapp_tmp->netapp_st, '\0', sizeof(struct NETAPP_CONFIG_STRU));
				memcpy(&pst_netapp_tmp->netapp_st, &netapp_tmp->netapp_st, sizeof(struct NETAPP_CONFIG_STRU));
				break;
			case NETAPP_MODIFY_EXCEPT:
				free(pst_netapp_tmp->except_list);
				pst_netapp_tmp->sum = netapp_tmp->sum;
				pst_netapp_tmp->except_list = netapp_tmp->except_list;
				break;
			default:
				memset(&pst_netapp_tmp->netapp_st, '\0', sizeof(struct NETAPP_CONFIG_STRU));
				memcpy(&pst_netapp_tmp->netapp_st, &netapp_tmp->netapp_st,
						sizeof(struct NETAPP_CONFIG_STRU));
				free(pst_netapp_tmp->except_list);
				pst_netapp_tmp->sum = netapp_tmp->sum;
				pst_netapp_tmp->except_list = netapp_tmp->except_list;
				break;
        	}
            return HUPU_OK;
        }
    }
	return HUPU_ERR;
}

HUPU_INT32 nac_app_update_netapp_hlist_enable_status(HUPU_UINT16 id, HUPU_UINT16 status)
{
	HUPU_UINT16 hash;
	hash = nac_app_get_hash_by_id(id);
	struct nac_hlist_node *pos, *n;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;
	nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
    {
        if(pst_netapp_tmp->id == id)
        {
        	if (status == NETAPP_CONFIG_ENABLE)
        	{
				pst_netapp_tmp->enable = HUPU_ENABLE;
        	}
			else if (status == NETAPP_CONFIG_DISABLE)
			{
				pst_netapp_tmp->enable = HUPU_DISABLE;
			}
            return HUPU_OK;
        }
    }
	return HUPU_ERR;
}

static int pack_netapp_config_item(xmlNodePtr node, NAC_APP_NETAPP_OBJECT* pst_netapp)
{
    HUPU_INT16 i;
    HUPU_CHAR ip_str[16];
	HUPU_CHAR xml_buffer[128];
    xmlNodePtr netapp_node, config_node, except_node;
	netapp_node = HUPU_NULL;
	config_node = HUPU_NULL;
	except_node = HUPU_NULL;

	netapp_node = xmlNewNode(HUPU_NULL, BAD_CAST "netApp");
	xmlAddChild(node, netapp_node);

	memset(ip_str, '\0', sizeof(ip_str));
	sprintf(ip_str, "%d", pst_netapp->id);
	xmlNewProp(netapp_node, BAD_CAST "id", BAD_CAST ip_str);

	//check_config list
	config_node = xmlNewNode(HUPU_NULL, BAD_CAST "checkConfig");
	xmlAddChild(netapp_node, config_node);

	xmlNewChild(config_node, HUPU_NULL, BAD_CAST "name", BAD_CAST pst_netapp->netapp_st.name);
	memset(xml_buffer, '\0', sizeof(xml_buffer));
	sprintf(xml_buffer, "%d", pst_netapp->netapp_st.cycle);
	xmlNewChild(config_node, HUPU_NULL, BAD_CAST "cycle", BAD_CAST xml_buffer);
	memset(xml_buffer, '\0', sizeof(xml_buffer));
	switch(pst_netapp->netapp_st.cycle_unit)
	{
		case CYCLE_UINT_SECOND:
			strcpy(xml_buffer, "sec");
			break;
		case CYCLE_UINT_MINUTE:
			strcpy(xml_buffer, "min");
			break;
		case CYCLE_UINT_HOUR:
			strcpy(xml_buffer, "hour");
			break;
	}
	xmlNewChild(config_node, HUPU_NULL, BAD_CAST "cycleUint", BAD_CAST xml_buffer);

	memset(xml_buffer, '\0', sizeof(xml_buffer));
	sprintf(xml_buffer, "%d", pst_netapp->netapp_st.times);
	xmlNewChild(config_node, HUPU_NULL, BAD_CAST "times", BAD_CAST xml_buffer);

	memset(xml_buffer, '\0', sizeof(xml_buffer));
	switch(pst_netapp->netapp_st.protocol)
	{
		case IPPROTO_TCP_UDP:
			strcpy(xml_buffer, "any");
			break;
		case IPPROTO_TCP:
			strcpy(xml_buffer, "tcp");
			break;
		case IPPROTO_UDP:
			strcpy(xml_buffer, "udp");
			break;
	}
	xmlNewChild(config_node, HUPU_NULL, BAD_CAST "protocol", BAD_CAST xml_buffer);

	memset(xml_buffer, '\0', sizeof(xml_buffer));
	sprintf(xml_buffer, "%d", pst_netapp->netapp_st.port);
	xmlNewChild(config_node, HUPU_NULL, BAD_CAST "port", BAD_CAST xml_buffer);

	memset(xml_buffer, '\0', sizeof(xml_buffer));
	sprintf(xml_buffer, "%d", pst_netapp->enable);
	xmlNewChild(config_node, HUPU_NULL, BAD_CAST "enable", BAD_CAST xml_buffer);

	memset(xml_buffer, '\0', sizeof(xml_buffer));
	for(i = 0; i < 5; i++)
	{
		if (pst_netapp->netapp_st.server_group[i] > 0)
		{
			memset(ip_str, '\0', sizeof(ip_str));
			if (i)
			{
				strcat(xml_buffer, ";");
			}
			sprintf(ip_str, "%u.%u.%u.%u",
					LIPQUAD(pst_netapp->netapp_st.server_group[i]));
			strcat(xml_buffer, ip_str);
		}
	}
	xmlNewChild(config_node, HUPU_NULL, BAD_CAST "serverGroup", BAD_CAST xml_buffer);
	xmlNewChild(config_node, HUPU_NULL, BAD_CAST "fixPath", BAD_CAST pst_netapp->netapp_st.fix_path);
	//except_device list
	except_node = xmlNewNode(HUPU_NULL, BAD_CAST "exceptDevice");
	xmlAddChild(netapp_node, except_node);
    HUPU_INT16 sum = pst_netapp->sum;
	for (i = 0; i < sum; i++)
	{
		memset(xml_buffer, '\0', sizeof(xml_buffer));
		sprintf(xml_buffer, "%s-%s", pst_netapp->except_list[i].min, pst_netapp->except_list[i].max);
		xmlNewChild(except_node, HUPU_NULL, BAD_CAST "ipRange", BAD_CAST xml_buffer);
	}

	return 0;
}

static xmlDocPtr nac_sys_show_specify_netapp_config(HUPU_UINT16 command, HUPU_UINT16 action_type)
{
    xmlDocPtr doc;
    xmlNodePtr nac_node;
    HUPU_INT16 hash;
	struct nac_hlist_node *pos, *n;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;

    create_xml_doc(&doc, &nac_node);
    insert_number_xml_new_child(nac_node, "commandID", (command + Ret_cmd_offset));
    insert_number_xml_new_child(nac_node, "actionType", action_type);
    insert_number_xml_new_child(nac_node, "result", 0);

    if (action_type == NETAPP_SHOW)
    {
	    for(hash = 0; hash < NETAPP_HASH_MAP_SIZE; hash++)
	    {
		    nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
    	    {
                pack_netapp_config_item(nac_node, pst_netapp_tmp);
		    }
	    }
    }
    else if (action_type == NETAPP_ON_GET)
    {
        hash = nac_app_get_hash_by_id(g_netapp_enable_id);
	    nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
        {
    	    if(pst_netapp_tmp->id == g_netapp_enable_id)
    	    {
                pack_netapp_config_item(nac_node, pst_netapp_tmp);
                break;
            }
        }
    }
    return doc;
}

static HUPU_INT32 nac_app_parse_netapp_config(xmlNodePtr curNode, NAC_APP_NETAPP_OBJECT* netapp_tmp)
{
	xmlChar	*szKey;
	HUPU_UINT16 count;
	xmlNodePtr cur_node;
	cur_node = curNode->xmlChildrenNode;
	while (cur_node != HUPU_NULL)
	{
		if(!(xmlStrcmp(cur_node->name, BAD_CAST "name")))
		{
			szKey = xmlNodeGetContent(cur_node);
			strcpy(netapp_tmp->netapp_st.name, (HUPU_CHAR*)szKey);
			xmlFree(szKey);
		}
		else if (!(xmlStrcmp(cur_node->name, BAD_CAST "cycle")))
		{
			szKey = xmlNodeGetContent(cur_node);
			netapp_tmp->netapp_st.cycle = atoi((HUPU_CHAR*)szKey);
			xmlFree(szKey);
		}
		else if (!(xmlStrcmp(cur_node->name, BAD_CAST "cycleUint")))
		{
			count = 0;
			szKey = xmlNodeGetContent(cur_node);
			if (strstr((HUPU_CHAR*)szKey, "sec") != HUPU_NULL)
			{
				count = CYCLE_UINT_SECOND;
			}
			else if (strstr((HUPU_CHAR*)szKey, "min") != HUPU_NULL)
			{
				count = CYCLE_UINT_MINUTE;
			}
			else if (strstr((HUPU_CHAR*)szKey, "hour") != HUPU_NULL)
			{
				count = CYCLE_UINT_HOUR;
			}
			netapp_tmp->netapp_st.cycle_unit = count;
			xmlFree(szKey);
		}
		else if (!(xmlStrcmp(cur_node->name, BAD_CAST "times")))
		{
			szKey = xmlNodeGetContent(cur_node);
			netapp_tmp->netapp_st.times = atoi((HUPU_CHAR*)szKey);
			xmlFree(szKey);
		}
		else if (!(xmlStrcmp(cur_node->name, BAD_CAST "protocol")))
		{//tcp=6,udp=17,any=0;for aligning
			count = 0;
			szKey = xmlNodeGetContent(cur_node);
			if (strstr((HUPU_CHAR*)szKey, "any") != HUPU_NULL)
			{
				count = IPPROTO_TCP_UDP;
			}
			else if (strstr((HUPU_CHAR*)szKey, "tcp") != HUPU_NULL)
			{
				count = IPPROTO_TCP;
			}
			else if (strstr((HUPU_CHAR*)szKey, "udp") != HUPU_NULL)
			{
				count = IPPROTO_UDP;
			}

			netapp_tmp->netapp_st.protocol = count;
			xmlFree(szKey);
		}
		else if (!(xmlStrcmp(cur_node->name, BAD_CAST "port")))
		{
			szKey = xmlNodeGetContent(cur_node);
			netapp_tmp->netapp_st.port = atoi((HUPU_CHAR*)szKey);
			xmlFree(szKey);
		}
		else if (!(xmlStrcmp(cur_node->name, BAD_CAST "fixPath")))
		{
			szKey = xmlNodeGetContent(cur_node);
			strcpy(netapp_tmp->netapp_st.fix_path, (HUPU_CHAR*)szKey);
			xmlFree(szKey);
		}
		else if (!(xmlStrcmp(cur_node->name, BAD_CAST "serverGroup")))
		{
			count = 0;
			HUPU_CHAR *token = HUPU_NULL, *running = HUPU_NULL;
			szKey = xmlNodeGetContent(cur_node);
			running = (HUPU_CHAR*)szKey;
			while((token = strsep(&running, ";")) != HUPU_NULL && count < 5)
			{
				if (strlen(token) > 4)//check token = ip_str
				{
					netapp_tmp->netapp_st.server_group[count] = inet_network(token);
				}
				else
				{
					netapp_tmp->netapp_st.server_group[count] = 0;
				}

				count ++;
			}
			xmlFree(szKey);
		}
		cur_node = cur_node->next;
	}
	return HUPU_OK;
}

static HUPU_INT32 nac_app_parse_netapp_except(xmlNodePtr cur_node, NAC_APP_NETAPP_OBJECT *pst_netapp)
{
    HUPU_INT32 num = 0;
	xmlChar	*xml_value;
	xmlNodePtr node, item_node;
    item_node = cur_node->xmlChildrenNode;
    node = item_node;
    for(;node;)
    {
        if (!(xmlStrcmp(node->name, BAD_CAST "ipRange")))
        {
            num++;
        }
        node = node->next;
    }
    pst_netapp->sum = num;

    if (pst_netapp->sum == 0) //exceptDevice_sum = 0;
    {
        pst_netapp->except_list = HUPU_NULL;
        return HUPU_OK;
    }

    pst_netapp->except_list = (NETAPP_EXCEPT*)malloc(num * (sizeof(NETAPP_EXCEPT)));
	if(pst_netapp->except_list == HUPU_NULL)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->malloc error!\n");
        return HUPU_ERR;
    }
    memset(pst_netapp->except_list, 0, num * (sizeof(NETAPP_EXCEPT)));

    HUPU_INT32 i = 0;
    node = item_node;
    for(i=0; i < num;)
    {
        if (!(xmlStrcmp(node->name, BAD_CAST "ipRange")))
        {
            xml_value = xmlNodeGetContent(node);
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ipRange----%s\n", xml_value);
            if(strlen((HUPU_CHAR*)xml_value) >= MAX_LEN)
            {
                xml_value[MAX_LEN-1] = '\0';
            }
            sscanf((HUPU_CHAR*)xml_value, "%[0-9.]-%[0-9.]", pst_netapp->except_list[i].min, pst_netapp->except_list[i].max);
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "except_netapp=%s-%s\n", pst_netapp->except_list[i].min, pst_netapp->except_list[i].max);
            i++;
            xmlFree(xml_value);
        }
        node = node->next;
    }
	return HUPU_OK;
}





NAC_APP_NETAPP_OBJECT *nac_app_find_netapp(HUPU_UINT16 id)
{
	HUPU_UINT16 hash;
	hash = nac_app_get_hash_by_id(id);
	struct nac_hlist_node *pos, *n;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;
	nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
	{
		if(pst_netapp_tmp->id == id)
		{
			return pst_netapp_tmp;
		}
	}
	return HUPU_NULL;
}

static HUPU_INT32 nac_app_flush_knl_netapp_config(HUPU_VOID)
{
	HUPU_INT32 iRet;
	struct nac_knl_net_app st_netapp_tmp;
	memset(&st_netapp_tmp, '\0', sizeof(struct nac_knl_net_app));
	st_netapp_tmp.switc = HUPU_DISABLE;
	iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_NETAPP, 0, &st_netapp_tmp,
                              sizeof(struct nac_knl_net_app));
	if (iRet != HUPU_OK)
	{
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "disable set knl netapp config fail\n");
		return HUPU_ERR;
	}
    else
    {
        //destroy the old netapp_user_status;
        nac_system_destroy_netapp_user_hlist();
    }

    /*
	iRet = nac_set_data_to_knl(NAC_CMD_RBTREE_FLUSH, NAC_KNL_RBTREE_NETAPP_SERVER, NULL, 0);
	if (iRet != HUPU_OK)
	{
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "flush netapp_server fail\n");
		return HUPU_ERR;
	}

    iRet = nac_set_data_to_knl(NAC_CMD_RBTREE_FLUSH, NAC_KNL_RBTREE_EXCEPT_NET_APP, NULL, 0);
    if (iRet != HUPU_OK)
    {
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "flush except_netapp fail\n");
        return HUPU_ERR;
    }

	iRet = nac_set_data_to_knl(NAC_CMD_USER_MOD, NAC_KNL_NETAPP_CLR_EXCEPT_STATUS, NULL, 0);
	if (iRet != HUPU_OK)
	{
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "flush user netapp_except status fail\n");
		return HUPU_ERR;
	}
	*/

	return HUPU_OK;
}

static HUPU_INT32 nac_app_set_knl_netapp_config(HUPU_UINT16 policy_id)
{
	HUPU_INT32 iRet;
	HUPU_INT32 i, sum;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp;
	struct nac_knl_net_app st_netapp_tmp;

	memset(&st_netapp_tmp, '\0', sizeof(struct nac_knl_net_app));
	pst_netapp_tmp = nac_app_find_netapp(policy_id);

	st_netapp_tmp.switc = HUPU_ENABLE;
	st_netapp_tmp.cycle = (pst_netapp_tmp->netapp_st.cycle_unit)*(pst_netapp_tmp->netapp_st.cycle);
	st_netapp_tmp.times = pst_netapp_tmp->netapp_st.times;
	st_netapp_tmp.dst_port = pst_netapp_tmp->netapp_st.port;
	st_netapp_tmp.protocol = pst_netapp_tmp->netapp_st.protocol;
	iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_NETAPP, 0, &st_netapp_tmp, sizeof(struct nac_knl_net_app));
	if (iRet != HUPU_OK)
	{
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "enable set knl netapp config fail\n");
		return HUPU_ERR;
	}

	sum = 5;
	for(i = 0; i < sum; i++)
	{
		if (pst_netapp_tmp->netapp_st.server_group[i] > 0)
		{
			nac_sys_set_iprange_to_knl_rbtree(pst_netapp_tmp->netapp_st.server_group[i],
                                             pst_netapp_tmp->netapp_st.server_group[i],
											NAC_KNL_RBTREE_NETAPP_SERVER, NAC_CMD_RBTREE_INS);
		}
	}

    sum = pst_netapp_tmp->sum;
    for(i = 0; i < sum; i++)
    {
        nac_sys_set_iprange_str_to_knl_rbtree(NAC_KNL_RBTREE_EXCEPT_NET_APP, NAC_CMD_RBTREE_INS,
                          pst_netapp_tmp->except_list[i].min, pst_netapp_tmp->except_list[i].max);
    }

	return HUPU_OK;
}

HUPU_INT32 nac_sys_knl_flush_enable_netapp_config(HUPU_VOID) //for init start flush
{
	if (g_netapp_enable_id)
	{
		nac_app_flush_knl_netapp_config();
		nac_app_update_netapp_hlist_enable_status(g_netapp_enable_id, NETAPP_CONFIG_DISABLE);
		g_netapp_enable_id = 0;
	}
	return HUPU_OK;
}


HUPU_INT32 nac_sys_delete_netapp_config(HUPU_UINT16 policy_id)
{
	HUPU_INT32 iRet;
    nac_app_delete_netapp_hlist(policy_id);
	if(policy_id == g_netapp_enable_id)
	{
		iRet = nac_app_flush_knl_netapp_config();
		g_netapp_enable_id = 0;
	}

	return HUPU_OK;
}

HUPU_INT32 nac_sys_set_enable_netapp_config(HUPU_UINT16 policy_id)
{
	HUPU_INT32 iRet;
	nac_app_flush_knl_netapp_config();
	if (g_netapp_enable_id == policy_id)//close enable_netapp
	{
		g_netapp_enable_id = 0;
		nac_app_update_netapp_hlist_enable_status(policy_id, NETAPP_CONFIG_DISABLE);

	}
	else
	{
		nac_app_update_netapp_hlist_enable_status(g_netapp_enable_id, NETAPP_CONFIG_DISABLE);
		iRet = nac_app_set_knl_netapp_config(policy_id);
		if (iRet != HUPU_OK)
		{
			return HUPU_ERR;
		}
		g_netapp_enable_id = policy_id;
		nac_app_update_netapp_hlist_enable_status(g_netapp_enable_id, NETAPP_CONFIG_ENABLE);
	}

	return HUPU_OK;
}

HUPU_INT32 nac_sys_modify_enable_netapp_config(HUPU_UINT16 policy_id, HUPU_UINT16 type)
{
	HUPU_INT32 iRet;
	if(g_netapp_enable_id == policy_id)
	{
		iRet = nac_app_flush_knl_netapp_config();
		if (iRet != HUPU_OK)
		{
			return HUPU_ERR;
		}

		iRet = nac_app_set_knl_netapp_config(policy_id);
		if (iRet != HUPU_OK)
		{
			return HUPU_ERR;
		}
	}
	return HUPU_OK;
}

xmlDocPtr nac_sys_parse_netapp_config(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_INT32 iRet, error_id;
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node, netapp_node, config_node, except_node;
    HUPU_UINT8 action_type;
	NAC_APP_NETAPP_OBJECT netapp_object_tmp;
	xmlChar	*szAttr;
	HUPU_UINT16 policy_id;
	HUPU_UINT16 mod_type;
    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
	memset(&netapp_object_tmp, '\0', sizeof(NAC_APP_NETAPP_OBJECT));
    switch (action_type)
    {
    case NETAPP_SHOW:
        nac_free_xmlDoc(doc);
		nac_doc = nac_sys_show_specify_netapp_config(cmd_id, NETAPP_SHOW);
        break;
    case NETAPP_ADD:
        while(cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "netApp")))
            {
                mod_type = 0;
            	netapp_node = cur_node;
				cur_node = cur_node->xmlChildrenNode;
                while(cur_node != HUPU_NULL)
				{
					if (!(xmlStrcmp(cur_node->name, BAD_CAST "checkConfig")))
					{
						config_node = cur_node;
						nac_app_parse_netapp_config(cur_node, &netapp_object_tmp);
						cur_node = config_node;
                        mod_type |= NETAPP_MODIFY_CONFIG;
					}
					else if (!(xmlStrcmp(cur_node->name, BAD_CAST "exceptDevice")))
					{
                        except_node = cur_node;
					    error_id = nac_app_parse_netapp_except(cur_node, &netapp_object_tmp);
						cur_node = except_node;
                        mod_type |= NETAPP_MODIFY_EXCEPT;
                        break;
					}
					cur_node = cur_node->next;
				}
				cur_node = netapp_node;
            }
            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);
        if (error_id == HUPU_OK && mod_type > 0)
        {
		    g_netapp_policy_index = g_netapp_policy_index + 1;
		    netapp_object_tmp.id = g_netapp_policy_index;
		    error_id = nac_app_add_netapp_hlist(&netapp_object_tmp);
		    if (error_id == HUPU_ERR)
		    {
			    error_id = NAC_SYS_ERROR_ADD_NETAPP_CHECK_FAIL;
			    g_netapp_policy_index = g_netapp_policy_index - 1;
		    }
        }
        else
        {
            error_id = NAC_SYS_ERROR_ADD_NETAPP_CHECK_FAIL;
        }
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;
	case NETAPP_DEL: //if delete enable_one, we flush the knl.
		while(cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "netApp"))
				&& xmlHasProp(cur_node, BAD_CAST "id"))
            {
            	policy_id = 0;
            	szAttr = xmlGetProp(cur_node, BAD_CAST "id");
				policy_id = atoi((HUPU_CHAR*)szAttr);
				iRet = nac_sys_delete_netapp_config(policy_id);
				if (iRet != HUPU_OK)
				{
					error_id = NAC_SYS_ERROR_DEL_NETAPP_CHECK_FAIL;
				}
            }
            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;
	case NETAPP_MOD://if mod enable_one, we flush the old_one and add the new_one.
		mod_type = 0;
		while(cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "netApp"))
				&& xmlHasProp(cur_node, BAD_CAST "id"))
            {
            	policy_id = 0;
            	szAttr = xmlGetProp(cur_node, BAD_CAST "id");
				policy_id = atoi((HUPU_CHAR*)szAttr);
				netapp_object_tmp.id = policy_id;
                mod_type = 0;

            	netapp_node = cur_node;
				cur_node = cur_node->xmlChildrenNode;
				while(cur_node != HUPU_NULL)
				{
					if (!(xmlStrcmp(cur_node->name, BAD_CAST "checkConfig")))
					{
						config_node = cur_node;
						nac_app_parse_netapp_config(cur_node, &netapp_object_tmp);
						cur_node  = config_node;
						mod_type |= NETAPP_MODIFY_CONFIG;
					}
					else if (!(xmlStrcmp(cur_node->name, BAD_CAST "exceptDevice")))
					{
                        except_node = cur_node;
					    error_id = nac_app_parse_netapp_except(cur_node, &netapp_object_tmp);
						cur_node = except_node;
					    mod_type |= NETAPP_MODIFY_EXCEPT;
                        break;
					}
					cur_node = cur_node->next;
				}
				cur_node = netapp_node;
            }
            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);
        if (error_id == HUPU_OK && mod_type > 0 )
        {
		    nac_app_modify_netapp_hlist(&netapp_object_tmp, mod_type);
		    iRet = nac_sys_modify_enable_netapp_config(policy_id, mod_type);
		    if (iRet != HUPU_OK)
		    {
			    error_id = NAC_SYS_ERROR_MODIFY_NETAPP_CHECK_FAIL;
		    }
        }
        else
        {
            error_id = NAC_SYS_ERROR_MODIFY_NETAPP_CHECK_FAIL;
        }
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

	case NETAPP_ON_OFF:
		while(cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "netApp"))
				&& xmlHasProp(cur_node, BAD_CAST "id"))
            {
            	policy_id = 0;
            	szAttr = xmlGetProp(cur_node, BAD_CAST "id");
				policy_id = atoi((HUPU_CHAR*)szAttr);
				break;
            }
            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);
		iRet = nac_sys_set_enable_netapp_config(policy_id);
		if (iRet != HUPU_OK)
		{
			error_id = NAC_SYS_ERROR_ENABLE_NETAPP_CHECK_FAIL;;
		}
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;
	case NETAPP_ON_GET:
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_show_specify_netapp_config(cmd_id, NETAPP_ON_GET);
		break;
    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->invalid action_type\n", __FUNCTION__);
        break;
    }
    return nac_doc;
}
