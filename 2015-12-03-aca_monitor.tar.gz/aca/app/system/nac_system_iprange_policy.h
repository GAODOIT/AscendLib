#ifndef NAC_SYSTEM_IPRANGE_POLICY_H
#define NAC_SYSTEM_IPRANGE_POLICY_H

#include "nac_system_common_lib.h"
#define NAC_SYS_POLICY_HASH_SIZE	1024

typedef struct _NAC_APP_POLICY_STRU
{
    struct nac_hlist_node node;
	HUPU_UINT16 type;
	HUPU_UINT32 id;

	union
	{
		struct
		{
			HUPU_UINT32 ip_min;
    		HUPU_UINT32 ip_max;
		}iprange;

		struct
		{
			HUPU_UINT32 ip_addr;
			HUPU_CHAR	ac_mac[ETH_ALEN];
		}ipmac;

		struct
		{
			HUPU_CHAR ac_mac[ETH_ALEN];
		}mac;

	}union_ply;

	HUPU_CHAR plyname[MAX_COMMENT_LEN];
	HUPU_CHAR comment[MAX_COMMENT_LEN];
} NAC_APP_POLICY;

extern struct nac_hlist_head nac_app_policy_hash[];

//now no syscall;

HUPU_INT32 nac_sys_flush_policy_iprange_config(HUPU_INT16 ply_type);
HUPU_INT32 insert_app_policy_hlist(NAC_APP_POLICY* policy_st);
HUPU_INT32 remove_app_policy_hlist(HUPU_UINT32 del_id);
NAC_APP_POLICY* find_app_policy_hlist(HUPU_UINT32 find_id, HUPU_UINT16 policy_type);
HUPU_INT32 modify_app_policy_hlist(NAC_APP_POLICY* mod_stru);

xmlDocPtr nac_sys_get_iprange_policy_hlist(HUPU_UINT16 command_id, const HUPU_CHAR* xml_tag);
HUPU_INT32 search_app_policy_hlist(NAC_APP_POLICY* search_stru);

HUPU_VOID nac_system_init_iprange_policy(HUPU_VOID);

HUPU_INT32 nac_system_destroy_app_policy_pool(HUPU_VOID);

HUPU_INT32 nac_system_add_iprange_policy(NAC_APP_POLICY* policy_st);

xmlDocPtr nac_system_parse_iprange_policy_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id,
						HUPU_UINT16 enum_plytype, const HUPU_CHAR* const_xml_plyname);

#endif
