#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_vlanmap.h"
#include "nac_system_ha_backup.h"
#include "nac_system_escape_deal.h"
#include "nac_system_access_mode.h"
#include "nac_system_redis_subscribe.h"

//redisContext *pub_c = NULL;
//{"msg_type":"nac_mode","mode":"mvg"}
static int package_nac_mode_json(json_t *node)
{
    json_t *value;
    HUPU_CHAR mode_str[16] = "";
    switch (asc_access_mode)
	{
	case NAC_MVG_MODE:
		memcpy(mode_str, "mvg", strlen("mvg"));
		break;
	case NAC_PBR_MODE:
        if (nac_pbr_onein_oneout_flag  == HUPU_TRUE)
        {
		    memcpy(mode_str, "pbr0", strlen("pbr0"));
        }
        else
        {
            memcpy(mode_str, "pbr1", strlen("pbr1"));
        }
		break;
	case NAC_BRIDGE_MODE:
		memcpy(mode_str, "bridge", strlen("bridge"));
		break;
    case NAC_8021X_MODE:
        memcpy(mode_str, "8021x", strlen("8021x"));
        break;
	default:
		memcpy(mode_str, "NULL", strlen("NULL"));
		break;
	}

    value = json_new_string(mode_str);
    json_insert_pair_into_object(node, "mode", value);

    return 0;
}

//{"msg_type":"iface_status", "manager":"true", "untrust":"false", "trust":"true", "ha":"false"}
static int package_iface_status_json(json_t *node)
{
    int i;
    json_t *value;
    HUPU_CHAR value_buffer[16] = "";
    for (i = 0; i < gi_netdev_count; i++)
    {
        if (strcmp(g_nac_net_device[i].if_label, "manager") == 0
            || strcmp(g_nac_net_device[i].if_label, "untrust") == 0
            || strcmp(g_nac_net_device[i].if_label, "trust") == 0
            || strcmp(g_nac_net_device[i].if_label, "ha") == 0)
        {
            nac_app_get_netdev_link_and_enable_status(nac_sys_ifname[i],
                &g_nac_net_device[i].if_link, &g_nac_net_device[i].if_enable);

            memset(value_buffer, 0, sizeof(value_buffer));
            if (g_nac_net_device[i].if_link == HUPU_TRUE)
            {
                memcpy(value_buffer, "true", strlen("true"));
            }
            else
            {
                memcpy(value_buffer, "false", strlen("false"));
            }
            value = json_new_string(value_buffer);
            json_insert_pair_into_object(node, g_nac_net_device[i].if_label, value);
        }

    }

    return 0;
}

//{"msg_type":"vlanmap","vlanMap":[{"isolation":"100","normal":"1"},{"isolation":"102","normal":"2"}]}
static int package_vlan_map_json(json_t *node)
{
    json_t *value, *array, *entry;
    array = json_new_array();
    HUPU_INT16 hash;
    NAC_APP_VLANMAP *ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;
    HUPU_CHAR value_buffer[16];
    for ( hash = 0; hash < NAC_SYS_VLANMAP_HASH_SIZE; hash++)
    {
        nac_hlist_for_each_entry_safe(ent, pos, n, &nac_vlanmap_hash[hash], node)
        {
            entry = json_new_object();

            memset(value_buffer, 0, sizeof(value_buffer));
            sprintf(value_buffer, "%d", ent->isolate_vlantag);
            value = json_new_string(value_buffer);
            json_insert_pair_into_object(entry, "isolation", value);

            memset(value_buffer, 0, sizeof(value_buffer));
            sprintf(value_buffer, "%d", ent->normal_vlantag);
            value = json_new_string(value_buffer);
            json_insert_pair_into_object(entry, "normal", value);

            json_insert_child(array, entry);
        }
    }

    json_insert_pair_into_object(node, "vlanMap", array);

    return 0;
}

//{"msg_type":"escape_status","status":"true", "max_flowspeed":"1024000"}
static int package_escape_status_json(json_t *node)
{
    json_t *value;
    HUPU_CHAR value_buffer[64] = "";
    if (g_asc_escape_enable_flag == HUPU_TRUE)
    {
        strcpy(value_buffer, "true");
    }
    else
    {
        strcpy(value_buffer, "false");
    }
    value = json_new_string(value_buffer);
    json_insert_pair_into_object(node, "status", value);
    value = json_new_string(g_untrust_max_flow_speed);
    json_insert_pair_into_object(node, "max_flowspeed", value);
    return 0;
}

//{"msg_type":"ha_status","status":"true"}
static int package_ha_status_json(json_t *node)
{
    json_t *value;
    HUPU_CHAR value_buffer[64] = "";
    if (gst_ha_backup_config.ha_switch == HUPU_TRUE)
    {
        strcpy(value_buffer, "true");
    }
    else
    {
        strcpy(value_buffer, "false");
    }
    value = json_new_string(value_buffer);
    value = json_new_string(value_buffer);
    json_insert_pair_into_object(node, "status", value);
    return 0;
}

//{"msg_type":"iface_name", "manager":"eth0", "untrust":"eth2", "trust":"eth3", "ha":"eth1"}
static int package_iface_name_json(json_t *node)
{
    int i;
    json_t *value;
    //HUPU_CHAR value_buffer[16] = "";
    for (i = 0; i < gi_netdev_count; i++)
    {
        if (strcmp(g_nac_net_device[i].if_label, "manager") == 0
            || strcmp(g_nac_net_device[i].if_label, "untrust") == 0
            || strcmp(g_nac_net_device[i].if_label, "trust") == 0
            || strcmp(g_nac_net_device[i].if_label, "ha") == 0)
        {
            value = json_new_string(nac_sys_ifname[i]);
            json_insert_pair_into_object(node, g_nac_net_device[i].if_label, value);
        }

    }
    return 0;
}

KEY_FUNC_MAP monitor_methods[7] =
{
    {"nac_mode", package_nac_mode_json},
    {"vlan_map", package_vlan_map_json},
    {"ha_status", package_ha_status_json},
    {"iface_status", package_iface_status_json},
    {"escape_status", package_escape_status_json},
    {"iface_name", package_iface_name_json},
    {"nac_info", NULL},
};

static int package_nacapp_status_json(char *content, const char *type)
{
    json_t *root, *value;
    char *text = NULL;
    setlocale (LC_ALL, "");

    root  = json_new_object();
    value = json_new_string(type);
    json_insert_pair_into_object(root, "msg_type", value);

    short int i, count;
    KEY_FUNC_MAP *p_map = NULL;
    CallBackFun pfun_method;
    count = sizeof(monitor_methods)/sizeof(KEY_FUNC_MAP);
    for (i = 0; i < count; i++)
    {
        p_map = &monitor_methods[i];
        if (memcmp(p_map->key, type, strlen(type)) == 0)
        {
            pfun_method = p_map->method;
            pfun_method(root);
        }

    }
    json_tree_to_string(root, &text);
    memcpy(content, text, strlen(text));
    free(text);
    json_free_value(&root);
    return 0;
}

static int check_redis_sub_command(char *key)
{
    short int err, i, count;
    err = -1;
    count = sizeof(monitor_methods)/sizeof(KEY_FUNC_MAP);
    for (i = 0; i < count;  i++)
    {
        if (strcmp(monitor_methods[i].key, key) == 0)
        {
            err = i;
            break;
        }
    }

    return err;
}

int send_redis_pub_command(char *key)
{
    redisContext *c;
    redisReply *reply;
    char pub_msg[1024*12] = "";
    short int i, count;

    struct timeval timeout = { 1, 500000 }; // 1.5 seconds
    c = redisConnectWithTimeout(HOSTNAME, REDISPORT, timeout);
    if (c == NULL || c->err)
    {
        if (c)
        {
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "Connection error: %s\n", c->errstr);
            redisFree(c);
        }
        else
        {
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "Connection error: can't allocate redis context\n");
        }
        return -1;
    }

    /* PING server */
    reply = redisCommand(c, "PING");
    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS,"PING: %s\n", reply->str);
    freeReplyObject(reply);

    if (strcmp(key, "nac_info") == 0)
    {
        count = sizeof(monitor_methods)/sizeof(KEY_FUNC_MAP);
        for (i = 0; i < count;  i++)
        {
            if (strcmp(monitor_methods[i].key, "nac_info") == 0 )
            {
                continue;
            }
            memset(pub_msg, '\0', sizeof(pub_msg));
            package_nacapp_status_json(pub_msg, monitor_methods[i].key);
            reply = redisCommand(c, "PUBLISH %s %s", "monitor.nacapp", pub_msg);
            if (reply->type == REDIS_REPLY_INTEGER)
            {
                SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "publish: (integer) %lld\n", reply->integer);
            }
            freeReplyObject(reply);
        }
    }
    else
    {
        memset(pub_msg, '\0', sizeof(pub_msg));
        package_nacapp_status_json(pub_msg, key);
        reply = redisCommand(c,"PUBLISH %s %s", "monitor.nacapp", pub_msg);
        if (reply->type == REDIS_REPLY_INTEGER)
        {
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "publish: (integer) %lld\n", reply->integer);
        }
        freeReplyObject(reply);
    }
    /* Disconnects and frees the context */
    redisFree(c);
    return 0;
}


void parse_redis_sub_message(redisReply *reply)
{
    if (reply == NULL)
    {
        return;
    }

    if ( reply->type == REDIS_REPLY_ARRAY && reply->elements == 3 )
    {
        if (strcmp(reply->element[0]->str, "message" ) == 0)
        {
            SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS, "Received channel %s: %s\n", reply->element[1]->str, reply->element[2]->str);
            if ( (check_redis_sub_command(reply->element[2]->str)) > -1)
            {
                send_redis_pub_command(reply->element[2]->str);
            }
            else
            {
                SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "Received channel %s: %s cmd is unexist!\n", reply->element[1]->str, reply->element[2]->str);
            }
        }
    }

    return;
}

void *nac_sys_monitor_redis_sub_pthread(void *data)
{
    redisContext *sub_c = NULL;
    redisReply *reply;
    struct timeval timeout = { 1, 500000 }; // 1.5 seconds

    for(;;)
    {
        sleep(5);
        sub_c= redisConnectWithTimeout(HOSTNAME, REDISPORT, timeout);
        if (sub_c == NULL || sub_c->err)
        {
            if (sub_c)
            {
                printf("Connection error: %s\n", sub_c->errstr);
                redisFree(sub_c);
                sub_c = NULL;
            }
            else
            {
                printf("Connection error: can't allocate redis context\n");
            }
            continue;
        }

        /* PING server */
        reply = redisCommand(sub_c,"PING");
        printf("PING: %s\n", reply->str);
        freeReplyObject(reply);

        reply = redisCommand(sub_c, "SUBSCRIBE nac.app");
        freeReplyObject(reply);

        while (redisGetReply(sub_c, (void*)&reply) == REDIS_OK)
        {
            parse_redis_sub_message(reply);
            freeReplyObject(reply);
        }
        /* Disconnects and frees the context */
        redisFree(sub_c);
        sub_c = NULL;
    }
	pthread_detach(pthread_self());
	return NULL;
}
