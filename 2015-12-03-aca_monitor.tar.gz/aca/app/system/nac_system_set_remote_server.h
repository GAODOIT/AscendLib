#ifndef NAC_SYSTEM_SET_REMOTE_SERVER_H
#define NAC_SYSTEM_SET_REMOTE_SERVER_H

extern HUPU_INT32 new_link_fd;
extern HUPU_INT32 gi_link_fd;

extern HUPU_UINT32 gi_link_server_ip;
extern HUPU_CHAR gi_link_company_code[10];
extern HUPU_UINT32 last_link_remote_ip; //last time connect serverip.
extern HUPU_CHAR   last_link_company_code[10];


HUPU_VOID nac_system_destroy_tcp_long_sockfd(HUPU_VOID);

xmlDocPtr nac_sys_parse_set_remote_server_info(xmlDocPtr doc, HUPU_UINT16 cmd_id);

#endif
