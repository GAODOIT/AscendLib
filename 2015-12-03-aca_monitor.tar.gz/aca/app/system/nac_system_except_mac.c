#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_except_mac.h"

HUPU_INT32 nac_sys_flush_except_mac_config(HUPU_VOID)
{
    nac_set_data_to_knl(NAC_CMD_RBTREE_FLUSH, NAC_KNL_RBTREE_EXCEPT_MAC, NULL, 0);
    return 0;
}


//NAC_CMD_RBTREE_INS, NAC_CMD_RBTREE_RMV
HUPU_INT32 set_except_mac_data_to_kernel(HUPU_CHAR* ac_mac, HUPU_UINT16 flag)
{
    HUPU_INT32 iRet;
    struct nac_knl_rbtree_entry ex_mac_entry;

    if (flag == NAC_CMD_RBTREE_FLUSH)
    {
       iRet = nac_set_data_to_knl(flag, NAC_KNL_RBTREE_EXCEPT_MAC, NULL, 0);
       SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "knl except_mac flush--iRet=%d\n", iRet);
       iRet = HUPU_OK;
       goto EXIT_OUT;
    }

    memset(&ex_mac_entry, 0, sizeof(struct nac_knl_rbtree_entry));
    ex_mac_entry.type = NAC_KNL_RBTREE_EXCEPT_MAC;
    memcpy(ex_mac_entry.union_rbtree.mac.ac_mac, ac_mac, ETH_ALEN);

    iRet = nac_set_data_to_knl(flag, 0, &ex_mac_entry, sizeof(struct nac_knl_rbtree_entry));
    if (iRet != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl--iRet=%d\n", iRet);
        iRet = HUPU_ERR;
    }

EXIT_OUT:
    return iRet;
}


HUPU_INT32 nac_system_add_except_mac(NAC_APP_POLICY* ex_mac)
{
    HUPU_INT32 iRet = 0;
    iRet = set_except_mac_data_to_kernel(ex_mac->union_ply.mac.ac_mac, NAC_CMD_RBTREE_INS);
    if (iRet != HUPU_OK)
    {
        goto FUNC_EXIT;
    }

    iRet = insert_app_policy_hlist(ex_mac);
FUNC_EXIT:
        return iRet;
}

HUPU_INT32 nac_sys_delete_except_mac(HUPU_INT32 id)
{
    NAC_APP_POLICY *pst_policy = HUPU_NULL;
    HUPU_INT32 iRet = 0;

    pst_policy = find_app_policy_hlist(id, NAC_APP_EXCEPT_MAC);
    if (pst_policy == HUPU_NULL)
    {
        iRet = HUPU_ERR;
        goto FUNC_EXIT;
    }

    iRet = set_except_mac_data_to_kernel(pst_policy->union_ply.mac.ac_mac, NAC_CMD_RBTREE_RMV);
    if (iRet != HUPU_OK)
    {
        goto FUNC_EXIT;
    }

    remove_app_policy_hlist(id);

FUNC_EXIT:
    return iRet;
}


HUPU_INT32 nac_sys_modify_except_mac(NAC_APP_POLICY* ex_mac)
{
    HUPU_INT32 iRet = 0;
    NAC_APP_POLICY *pst_policy = HUPU_NULL;

    pst_policy = find_app_policy_hlist(ex_mac->id, NAC_APP_EXCEPT_MAC);
    if (pst_policy == HUPU_NULL)
    {
        iRet = HUPU_ERR;
        goto FUNC_EXIT;
    }

    iRet = set_except_mac_data_to_kernel(pst_policy->union_ply.mac.ac_mac, NAC_CMD_RBTREE_RMV);
    if (iRet != HUPU_OK)
    {
        goto FUNC_EXIT;
    }

    iRet = set_except_mac_data_to_kernel(ex_mac->union_ply.mac.ac_mac, NAC_CMD_RBTREE_INS);
    if (iRet != HUPU_OK)
    {
        goto FUNC_EXIT;
    }

    modify_app_policy_hlist(ex_mac);

FUNC_EXIT:
    return iRet;
}

//get except_mac config data
static HUPU_INT32 get_list_except_mac_value(HUPU_CHAR (*p_list)[MAX_LEN], HUPU_INT32 num)
{
    HUPU_INT32 iRet, i;
    HUPU_CHAR mac_str[18];
    NAC_APP_POLICY except_mac_st;
    HUPU_INT32 max = (num == 0 || num > MAX_ITEM)?MAX_ITEM:num;
    for(i=0; i<max; i++)
    {
        if (!strlen(p_list[i]))
        {
            break;
        }

        HUPU_CHAR *p = (HUPU_CHAR *)&p_list[i];
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "get except_mac list text--value=%s\n", p);

        memset(mac_str, '\0', sizeof(mac_str));
		memset(&except_mac_st, '\0', sizeof(NAC_APP_POLICY));
        iRet = sscanf(p, "%d;%[^;];%[^;];%s", &except_mac_st.id,
                      except_mac_st.plyname, mac_str, except_mac_st.comment);

        iRet = sscanf(mac_str, "%02hhX-%02hhX-%02hhX-%02hhX-%02hhX-%02hhX",
                    &except_mac_st.union_ply.mac.ac_mac[0], &except_mac_st.union_ply.mac.ac_mac[1],
                    &except_mac_st.union_ply.mac.ac_mac[2], &except_mac_st.union_ply.mac.ac_mac[3],
                    &except_mac_st.union_ply.mac.ac_mac[4], &except_mac_st.union_ply.mac.ac_mac[5]);

        except_mac_st.type = NAC_APP_EXCEPT_MAC;

        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
                        "exceptMac_item: iRet=%d--id=%d--name=%s--%02X-%02X-%02X-%02X-%02X-%02X--comment=%s\n",
                        iRet, except_mac_st.id, except_mac_st.plyname, MAC_FORMAT(except_mac_st.union_ply.mac.ac_mac),
                        except_mac_st.comment);

        iRet = nac_system_add_except_mac(&except_mac_st);
        if (iRet != HUPU_OK)
        {
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "add except_mac fail--iRet=%d.\n", iRet);
        }
        else
        {
            g_policy_index = (except_mac_st.id >= g_policy_index)?(except_mac_st.id):(g_policy_index);
        }

    }
    return 0;
}

/*get except_mac config data form config file*/
HUPU_INT32 nac_sys_get_except_mac_data_form_configure(const HUPU_CHAR *file_path)
{
    HUPU_CHAR buffer[1024*1024] = {0};
    HUPU_CHAR content[1024*10] = {0};
    HUPU_UINT16 item_num = 0;
    HUPU_INT32 fd = 0;
    HUPU_CHAR  *p_value = NULL;

    fd = open(file_path, O_RDONLY);
    read(fd, buffer, 1024*1024);
    close(fd);

    memset(content, 0, sizeof(content));
    if(get_content(buffer, content, "except_mac_config") < 0)
    {
        goto GO_EXIT;
    }

    p_value = each_line_search(content,  "item_num");
    item_num = atoi(p_value);

    memset(buffer, 0, sizeof(buffer));
    memcpy(buffer, content, sizeof(content));
    memset(content, 0, sizeof(content));
    get_content(buffer, content, "item_list");

    if (strlen(content) < 5)
    {
        goto GO_EXIT;
    }

    HUPU_CHAR list[MAX_ITEM][MAX_LEN];
    memset(list, 0, sizeof(list));
    get_list(content, list);
    get_list_except_mac_value(list, item_num);
    //nac_system_set_except_mac_data_to_kernel;
    return 0;
    GO_EXIT:
        return -1;
}

//write except_mac data to config file
HUPU_INT32 nac_sys_write_except_mac_data_to_configure(FILE* fp)
{
    HUPU_CHAR content[1024*10] = {0};
    HUPU_CHAR buffer[512]={0};
    HUPU_UINT16 item_num = 0;
    strcat(content, "except_mac_config\n{\n");
    sprintf(buffer,"    item_num=%d\n", item_num);
    strcat(content, buffer);
    strcat(content, "    item_list\n    {\n");
    HUPU_UINT16 key;
    NAC_APP_POLICY *policy_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;
    for (key = 0; key < NAC_SYS_POLICY_HASH_SIZE; key++)
    {
        nac_hlist_for_each_entry_safe(policy_ent, pos, n, &nac_app_policy_hash[key], node)
        {
            if (policy_ent->type == NAC_APP_EXCEPT_MAC)
            {
                    memset(buffer, 0, sizeof(buffer));
                    sprintf(buffer, "        %d;%s;%02X-%02X-%02X-%02X-%02X-%02X;%s\n", policy_ent->id, policy_ent->plyname,
                            MAC_FORMAT(policy_ent->union_ply.mac.ac_mac), policy_ent->comment);
                    strcat(content, buffer);
            }
        }
    }
    strcat(content, "    }\n");
    strcat(content, "}\n\n");
    fprintf(fp, "%s", content);
    return 0;
}



xmlDocPtr nac_system_return_except_mac_result(HUPU_UINT16 cmd_id, HUPU_UINT8 action, HUPU_UINT16 error_id)
{
    xmlDocPtr doc;
    xmlNodePtr root_node;
    HUPU_CHAR xml_item[512] = "";

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    insert_number_xml_new_child(root_node, "commandID", (cmd_id + Ret_cmd_offset));
    insert_number_xml_new_child(root_node, "actionType", action);

    if (error_id == HUPU_OK)
    {
        xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");
    }
	else if (error_id == HUPU_ERR)
	{
        xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "-1:null");
	}
    else
    {
        memset(xml_item, '\0', sizeof(xml_item));
        sprintf(xml_item, "-1:%s", nac_sys_get_error_log(error_id));
        xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST xml_item);
    }

    HUPU_UINT16 key;
    NAC_APP_POLICY *policy_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    for (key = 0; key < NAC_SYS_POLICY_HASH_SIZE; key++)
    {
        nac_hlist_for_each_entry_safe(policy_ent, pos, n, &nac_app_policy_hash[key], node)
        {
                memset(xml_item, '\0', sizeof(xml_item));
                if (policy_ent->type == NAC_APP_EXCEPT_MAC)
                {
                    sprintf(xml_item, "%d;%s;%02X-%02X-%02X-%02X-%02X-%02X;%s", policy_ent->id, policy_ent->plyname,
                            MAC_FORMAT(policy_ent->union_ply.mac.ac_mac), policy_ent->comment);
                    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "exceptMac", BAD_CAST xml_item);
                }
        }
    }

    return doc;
}


xmlDocPtr nac_system_parse_except_mac_config(xmlDocPtr doc, HUPU_UINT16 cmd_id, HUPU_UINT16 policy_type, const HUPU_CHAR* xml_tag)
{
    HUPU_INT32 iRet, error_id;
    HUPU_UINT8 action_type;
    xmlDocPtr ret_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    xmlChar *xml_value;
    NAC_APP_POLICY except_mac_st;
    HUPU_CHAR mac_str[18];
    HUPU_UINT32 tmp_id;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "into handle cmd_id = %d action type = %d \n", cmd_id, action_type);
    error_id = 0;
    switch(action_type)
    {
    case NAC_SHOW:
        ret_doc = nac_sys_get_iprange_policy_hlist(cmd_id, xml_tag);
        break;

    case NAC_ADD: //get a new id.
        while (cur_node != HUPU_NULL)
        {
            if (!xmlStrcmp(cur_node->name, BAD_CAST xml_tag))
            {
                memset(mac_str, '\0', sizeof(mac_str));
				memset(&except_mac_st, '\0', sizeof(NAC_APP_POLICY));
                xml_value = xmlNodeGetContent(cur_node);

				iRet = sscanf((HUPU_CHAR*)xml_value, "%[^;];%[^;];%s",
                        except_mac_st.plyname, mac_str, except_mac_st.comment);
				xmlFree(xml_value);

                iRet = sscanf(mac_str, "%02hhX-%02hhX-%02hhX-%02hhX-%02hhX-%02hhX",
                    &except_mac_st.union_ply.mac.ac_mac[0], &except_mac_st.union_ply.mac.ac_mac[1],
                    &except_mac_st.union_ply.mac.ac_mac[2], &except_mac_st.union_ply.mac.ac_mac[3],
                    &except_mac_st.union_ply.mac.ac_mac[4], &except_mac_st.union_ply.mac.ac_mac[5]);

                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
                                "add exceptMac_item: iRet=%d--name=%s--%02X-%02X-%02X-%02X-%02X-%02X--comment=%s--len=%d\n",
                                iRet, except_mac_st.plyname, MAC_FORMAT(except_mac_st.union_ply.mac.ac_mac),
                                except_mac_st.comment, strlen(except_mac_st.comment));

                g_policy_index		= g_policy_index + 1;
				except_mac_st.id	= g_policy_index;
                except_mac_st.type  = policy_type;

                iRet = nac_system_add_except_mac(&except_mac_st);
                if (iRet != HUPU_OK)
                {
                    g_policy_index = g_policy_index - 1;
                    error_id = NAC_SYS_ERROR_ADD_EXCEPTMAC_FAIL;
                    break;
                }
            }
            cur_node = cur_node->next;
        }
        ret_doc = nac_system_return_except_mac_result(cmd_id, action_type, error_id);
        break;

    case NAC_DEL: //del the data of this id.
        while (cur_node != HUPU_NULL)
        {
            if (!xmlStrcmp(cur_node->name, BAD_CAST xml_tag))
            {
                xml_value = xmlNodeGetContent(cur_node);
                tmp_id = atoi((HUPU_CHAR*)xml_value);
                xmlFree(xml_value);
                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "del exceptMac_item: id=%d\n", tmp_id);
                iRet = nac_sys_delete_except_mac(tmp_id);
                if (iRet != HUPU_OK)
                {
                    error_id = NAC_SYS_ERROR_DEL_EXCEPTMAC_FAIL;
                    break;
                }
            }
           cur_node = cur_node->next;
        }
        ret_doc = nac_system_return_except_mac_result(cmd_id, action_type, error_id);
        break;

    case NAC_MODIFY: //only update the data,id is exist.
        while (cur_node != HUPU_NULL)
        {
            if (!xmlStrcmp(cur_node->name, BAD_CAST xml_tag))
            {
                memset(mac_str, '\0', sizeof(mac_str));
				memset(&except_mac_st, '\0', sizeof(NAC_APP_POLICY));
                xml_value = xmlNodeGetContent(cur_node);

                iRet = sscanf((HUPU_CHAR*)xml_value, "%d;%[^;];%[^;];%s", &except_mac_st.id,
                            except_mac_st.plyname, mac_str, except_mac_st.comment);
				xmlFree(xml_value);

                iRet = sscanf(mac_str, "%02hhX-%02hhX-%02hhX-%02hhX-%02hhX-%02hhX",
                    &except_mac_st.union_ply.mac.ac_mac[0], &except_mac_st.union_ply.mac.ac_mac[1],
                    &except_mac_st.union_ply.mac.ac_mac[2], &except_mac_st.union_ply.mac.ac_mac[3],
                    &except_mac_st.union_ply.mac.ac_mac[4], &except_mac_st.union_ply.mac.ac_mac[5]);

                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
                                "modify exceptMac_item: iRet=%d--id=%d--name=%s--%02X-%02X-%02X-%02X-%02X-%02X--comment=%s--len=%d\n",
                                iRet, except_mac_st.id, except_mac_st.plyname, MAC_FORMAT(except_mac_st.union_ply.mac.ac_mac),
                                except_mac_st.comment, strlen(except_mac_st.comment));

                except_mac_st.type = policy_type;

                iRet = nac_sys_modify_except_mac(&except_mac_st);
                if (iRet != HUPU_OK)
                {
                    error_id = NAC_SYS_ERROR_MODIFY_EXCEPTMAC_FAIL;
                    break;
                }
            }
            cur_node = cur_node->next;
        }
		ret_doc = nac_system_return_except_mac_result(cmd_id, action_type, error_id);
        break;

    default:
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    nac_free_xmlDoc(doc);
    return ret_doc;
}

