#ifndef NAC_SYSTEM_DOMAIN_POLICY_H
#define NAC_SYSTEM_DOMAIN_POLICY_H

#include "nac_system_common_lib.h"
#define NAC_SYS_DOMAIN_HASH_SIZE	256

typedef struct _NAC_APP_DOMAIN_STRU
{
    struct nac_hlist_node   node;
    HUPU_UINT32 id;
	HUPU_UINT16 type;
    HUPU_CHAR domain[MAX_DOMAIN_LEN];
	HUPU_CHAR plyname[MAX_COMMENT_LEN];
	HUPU_CHAR comment[MAX_COMMENT_LEN];
} NAC_APP_DOMAIN;

extern struct nac_hlist_head nac_app_domain_hash[];

HUPU_INT32 nac_sys_flush_knl_domain_policy(HUPU_VOID);

HUPU_VOID nac_system_init_domain_policy(HUPU_VOID);

HUPU_VOID nac_system_destroy_domain_policy_pool(HUPU_VOID);

HUPU_INT32 nac_system_add_domain_policy(NAC_APP_DOMAIN* domain_stru);

xmlDocPtr nac_system_parse_domain_policy_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id,
					HUPU_UINT16 enum_plytype, const HUPU_CHAR* const_xml_plyname);

#endif
