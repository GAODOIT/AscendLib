#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_errorlog.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_netapp_user.h"
#include "nac_system_debug_sysconfig.h"
#include "nac_system_debug_switch.h"
#include "nac_system_set_remote_server.h"
#include "nac_system_netapp_check.h"



HUPU_CHAR nac_upload_debug_log_cmd_path[] = "/nac/script/nac_upload_debug_log.sh";
HUPU_CHAR nac_upload_debug_log_cmd[] = "/nac/script/nac_upload_debug_log.sh debug >/dev/null 2>&1";
//HUPU_CHAR nac_upload_debug_log_cmd[] = "/nac/script/nac_upload_debug_log.sh debug";

HUPU_CHAR WEB_WARN_TYPE_ID[7][5]={"A000", "A001", "A002", "A003", "A004", "A005", "A006"};
NAC_SYS_WARN_CONFIG_ST gst_nac_warn_config_status;
OBJECT_WARN_VALUE_ST   gst_nac_warn_value;
pthread_t test_pthread_id = 0;


static HUPU_VOID *nac_sys_upload_debug_log_thread(HUPU_VOID* arg)
{
	HUPU_INT32 iRet;
	nac_app_debug_save_sys_config("/var/log/nac_asc/nac_debug_sys_conf.log");
	iRet = nac_exec_system((HUPU_CHAR*)(arg));
	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
						"pthread_id=(0x%x)-->exec_cmd=%s-->%d\n",
						(HUPU_UINT32)pthread_self(), (HUPU_CHAR*)arg, iRet);
	pthread_detach(pthread_self());
	return HUPU_NULL;
}

static HUPU_VOID *nac_sys_netlink_report_test(HUPU_VOID* arg)
{
    //HUPU_INT32 iRet;
    xmlDocPtr doc;
    HUPU_UINT16 i, cmd;
    xmlNodePtr root_node;
    time_t cur_time  = 0;
	HUPU_CHAR xml_max_cnt[MID_BUFF_LEN];
    cmd  = SYS_WEBUI_NETAPP_CHECK;
    HUPU_CHAR user_mac[ETH_ALEN] = {0x05, 0x04, 0x03, 0x02, 0x00, 0x00};
    HUPU_UINT32 user_ip = inet_network("10.10.5.1");

	pthread_detach(pthread_self());

    for (i = 1; i < 6; i++)
    {
        if (g_debug_switch == 0)
        {
            break;
        }
        user_ip = user_ip + 1;
        user_mac[5] = user_mac[5] + 1;
        if (user_mac[5] == 250)
        {
            user_mac[4] = user_mac[4] + 1;
            user_mac[5] = 0x00;
        }
        time(&cur_time);
        doc = xmlNewDoc(BAD_CAST "1.0");
        root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
        xmlDocSetRootElement(doc, root_node);
        insert_number_xml_new_child(root_node, "commandID", (cmd+Ret_cmd_offset));
        insert_number_xml_new_child(root_node, "actionType", NETAPP_USER_UPLOAD);
        memset(xml_max_cnt, '\0', strlen(xml_max_cnt));
	    sprintf(xml_max_cnt, "%02X-%02X-%02X-%02X-%02X-%02X;%u.%u.%u.%u;%d",
                MAC_FORMAT(user_mac), LIPQUAD(user_ip), NAC_NETLINK_NETAPP_FOUND);
        insert_string_xml_new_child(root_node, "userItem", xml_max_cnt);
        nac_sys_send_xmldoc_to_webserver(gi_link_fd, doc, cmd);
        sleep(1);
    }
	return HUPU_NULL;
}

/*
<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>142</commandID>
  <actionType>0(show_config)/1(open)/2(close)</actionType>
</nac>
*/
xmlDocPtr nac_system_parse_debug_config(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_INT32  iRet;
    xmlDocPtr	ret_doc = HUPU_NULL;
    xmlNodePtr	cur_node;
    HUPU_UINT8	action_type;
    HUPU_INT32	error_id;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

    error_id = 0;
    if (action_type == NAC_SHOW)
    {
        nac_app_debug_save_sys_config(NAC_APP_SHOW_SYS_CONFIG_FILE);
    }
    else if (action_type == NAC_ADD)
    {
        g_debug_switch = 1;
        if (test_pthread_id > 0)
        {
            iRet = pthread_cancel(test_pthread_id);
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "pthread_cancel, iRet=%d\n", iRet);
        }
	    iRet = pthread_create(&test_pthread_id, NULL, nac_sys_netlink_report_test, NULL);
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "pthread_cancel, iRet=%d\n", iRet);
    }
    else if (action_type == NAC_DEL)
    {
        g_debug_switch = 0;
    }
    else if (action_type == NAC_MODIFY)
    {
        nac_system_debug_save_netapp_user(NAC_APP_SHOW_NETAPP_USER_FILE);
    }
    else
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "invalid action_type\n");
    }

    nac_free_xmlDoc(doc);
    ret_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);

    return ret_doc;
}

/*
//系统高级调试日志开关
<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>129</commandID>
  <actionType>1</actionType>
  <debugSwitch>0/1<debugSwitch>
</nac>
*/

/*
This function will record the sys_debug log from open time_point to close time_point!
*/
xmlDocPtr nac_sys_parse_debug_switch(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_INT32 	iRet = 0;
    xmlDocPtr	nac_doc = HUPU_NULL;
    xmlNodePtr	cur_node;
	xmlChar		*xml_tag_szKey;
    HUPU_UINT8	action_type;
    HUPU_INT32	error_id;
	HUPU_UINT16 debug_switch_tmp;
	pthread_t	ftp_upload_pthread;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
    switch (action_type)
    {
    case NAC_SHOW:
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_ret_show_result(cmd_id, "debugSwitch");
		break;

	case NAC_ADD:
		while(cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "debugSwitch")))
			{
				xml_tag_szKey = xmlNodeGetContent(cur_node);
				debug_switch_tmp = atoi((HUPU_CHAR*)xml_tag_szKey);
				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->enable_flag=%d\n",
							__FUNCTION__, debug_switch_tmp);
				xmlFree(xml_tag_szKey);
				break;
			}
			cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);
		nac_app_advanced_debug_switch = debug_switch_tmp;

		//open advanced debug switch
		if (nac_app_advanced_debug_switch == 1)
		{
			g_debug_switch = 1;
		}//close advanced debug switch
		else if (nac_app_advanced_debug_switch == 0)
		{
			if (access(nac_upload_debug_log_cmd_path, X_OK) == -1)
			{
				error_id = NAC_SYS_ERROR_FTP_UPLOAD_CMD_UNEXIST;
			}
			else
			{
				g_debug_switch = 0;
				iRet = pthread_create(&ftp_upload_pthread, NULL,
									nac_sys_upload_debug_log_thread,
									nac_upload_debug_log_cmd);
			}
		}
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

HUPU_UINT32 nac_sys_init_warn_config_status(HUPU_VOID)
{
	memset(&gst_nac_warn_value, 0, sizeof(OBJECT_WARN_VALUE_ST));
	memset(&gst_nac_warn_config_status, 0, sizeof(NAC_SYS_WARN_CONFIG_ST));
	return HUPU_OK;
}

xmlDocPtr nac_sys_parse_warn_log_config(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_INT32	iRet, error_id;
    xmlDocPtr	nac_doc = HUPU_NULL;
    xmlNodePtr	cur_node;
	xmlChar		*xml_tag_szKey;
    HUPU_UINT8	action_type;

	OBJECT_WARN_VALUE_ST 	st_warn_value_tmp;
	OBJECT_WARN_FLOAT_VALUE_ST st_warn_flt_value_tmp;

	NAC_SYS_WARN_CONFIG_ST  st_warn_config_tmp;


	memset(&st_warn_value_tmp, 0, sizeof(OBJECT_WARN_VALUE_ST));
	memset(&st_warn_flt_value_tmp, 0, sizeof(OBJECT_WARN_FLOAT_VALUE_ST));
	memset(&st_warn_config_tmp, 0, sizeof(NAC_SYS_WARN_CONFIG_ST));

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
    switch (action_type)
    {

	case NAC_ADD:
		while(cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "warnLogConf")))
			{
				xml_tag_szKey = xmlNodeGetContent(cur_node);


				iRet = sscanf((HUPU_CHAR*)xml_tag_szKey, "%f;%f;%f;%d;%d;%d",
					&st_warn_flt_value_tmp.cpu, &st_warn_flt_value_tmp.mem,
					&st_warn_flt_value_tmp.disk, &st_warn_config_tmp.reboot,
					&st_warn_config_tmp.shutdown, &st_warn_config_tmp.factory);

				if (iRet != 6)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
								 "%s-->set warn policy config fault\n", __FUNCTION__);
					error_id = NAC_SYS_ERROR_SET_WARN_CONF_FAIL;
					xmlFree(xml_tag_szKey);
					break;
				}

				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
							"%s-->cpu=%f;mem=%f;disk=%f;shutdown=%d;reboot=%d;factory=%d--end\n",
							__FUNCTION__, st_warn_flt_value_tmp.cpu, st_warn_flt_value_tmp.mem,
							st_warn_flt_value_tmp.disk, st_warn_config_tmp.shutdown,
							st_warn_config_tmp.reboot, st_warn_config_tmp.factory);

				xmlFree(xml_tag_szKey);
				break;
			}
			cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);

		gst_nac_warn_config_status.reboot   = st_warn_config_tmp.reboot;
		gst_nac_warn_config_status.shutdown = st_warn_config_tmp.shutdown;
		gst_nac_warn_config_status.factory  = st_warn_config_tmp.factory;

		//float_value*100 for compare to warnning
		st_warn_value_tmp.cpu  = (HUPU_INT32)(st_warn_flt_value_tmp.cpu*100);
		st_warn_value_tmp.mem  = (HUPU_INT32)(st_warn_flt_value_tmp.mem*100);
		st_warn_value_tmp.disk = (HUPU_INT32)(st_warn_flt_value_tmp.disk*100);

		if (st_warn_value_tmp.cpu > 0)
		{
			gst_nac_warn_config_status.cpu = 1;
			gst_nac_warn_value.cpu = st_warn_value_tmp.cpu;
		}
		else
		{
			gst_nac_warn_config_status.cpu = 0;
			gst_nac_warn_value.cpu = 0;

		}

		if (st_warn_value_tmp.mem > 0)
		{
			gst_nac_warn_config_status.mem = 1;
			gst_nac_warn_value.mem = st_warn_value_tmp.mem;
		}
		else
		{
			gst_nac_warn_config_status.mem = 0;
			gst_nac_warn_value.mem = 0;

		}

		if (st_warn_value_tmp.disk > 0)
		{
			gst_nac_warn_config_status.disk = 1;
			gst_nac_warn_value.disk = st_warn_value_tmp.disk;
		}
		else
		{
			gst_nac_warn_config_status.disk = 0;
			gst_nac_warn_value.disk = 0;
		}

		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

HUPU_INT32 nac_system_send_warn_info_to_server(HUPU_UINT32 ui_sockfd,
									HUPU_BOOL warn_type, HUPU_UINT32 warn_value)
{
	HUPU_INT32 iRet;
	xmlDocPtr  doc_tmp;
    xmlNodePtr root_node;

	HUPU_UINT16 command_id = SYS_WEBUI_UPLOAD_WARN_INFO; //131
	HUPU_CHAR xml_short_buffer[32] = "";
	//HUPU_CHAR xml_long_buffer[SEND_BUFFER_LEN] = "";

	doc_tmp = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc_tmp, root_node);

	sprintf(xml_short_buffer, "%d", (command_id + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST xml_short_buffer);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");

	memset(xml_short_buffer, '\0', 32);
	switch(warn_type)
	{
	case NAC_CPU_WARN:
	case NAC_MEM_WARN:
	case NAC_DISK_WARN:
		if (warn_value > 0)
		{
			//sprintf(xml_short_buffer, "%0.2f\%", warn_value/100.0);
			sprintf(xml_short_buffer, "%s:%0.2f", WEB_WARN_TYPE_ID[warn_type],
					warn_value/100.0);
		}
		break;

	case NAC_REBOOT_WARN:
		sprintf(xml_short_buffer, "%s:reboot", WEB_WARN_TYPE_ID[warn_type]);
		break;

	case NAC_SHUTDOWN_WARN:
		sprintf(xml_short_buffer, "%s:shutdown", WEB_WARN_TYPE_ID[warn_type]);
		break;

	case NAC_FACTORY_WARN:
		sprintf(xml_short_buffer, "%s:factory", WEB_WARN_TYPE_ID[warn_type]);
		break;

	default:
		break;

	}

	xmlNewChild(root_node, HUPU_NULL, BAD_CAST "warnInfo", BAD_CAST xml_short_buffer);

	if (ui_sockfd > 0)
    {
       	iRet = nac_sys_send_xmldoc_to_webserver(ui_sockfd, doc_tmp, command_id);
    }
    else
    {
        nac_free_xmlDoc(doc_tmp);
    }

	return HUPU_OK;
}

HUPU_INT32 nac_system_check_sys_run_status(HUPU_UINT32 ui_sock_fd)
{
	HUPU_INT32 iRet;
	FILE *cmd_fp;
	//get the usage(the real_usage*100);
	char *get_sys_run_status_cmd = "/nac/script/nac_check_sys_used_status.sh rate";
	HUPU_CHAR fgets_line_buffer[BUFF_LEN] = "";

	OBJECT_WARN_VALUE_ST st_rate_tmp;

	cmd_fp = popen(get_sys_run_status_cmd, "r");
	if (cmd_fp == HUPU_NULL)
	{
		goto FUNC_EXIT;
	}

	fgets(fgets_line_buffer, BUFF_LEN, cmd_fp);

	if (strlen(fgets_line_buffer) <= 3)
	{
        goto FUNC_EXIT_1;
	}

	memset(&st_rate_tmp, 0, sizeof(OBJECT_WARN_VALUE_ST));

	iRet = sscanf(fgets_line_buffer, "%d;%d;%d",
				&st_rate_tmp.cpu, &st_rate_tmp.mem,
				&st_rate_tmp.disk);
	if (iRet != 3)
	{
        goto FUNC_EXIT_1;
	}

	if (gst_nac_warn_config_status.cpu == 1)
	{
		if (gst_nac_warn_value.cpu <= st_rate_tmp.cpu)
		{
			nac_system_send_warn_info_to_server(ui_sock_fd,
								NAC_CPU_WARN, st_rate_tmp.cpu);
		}
	}

	if (gst_nac_warn_config_status.mem == 1)
	{
		if (gst_nac_warn_value.mem <= st_rate_tmp.mem)
		{
			nac_system_send_warn_info_to_server(ui_sock_fd,
								NAC_MEM_WARN, st_rate_tmp.mem);
		}
	}

	if (gst_nac_warn_config_status.disk == 1)
	{
		if (gst_nac_warn_value.disk <= st_rate_tmp.disk)
		{
			nac_system_send_warn_info_to_server(ui_sock_fd,
								NAC_DISK_WARN, st_rate_tmp.disk);
		}
	}

FUNC_EXIT_1:
    pclose(cmd_fp);
FUNC_EXIT:
    return HUPU_OK;
}
