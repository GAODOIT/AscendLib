#ifndef __NAC_SYSTEM_ACCESS_MODE__
#define __NAC_SYSTEM_ACCESS_MODE__

#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_net.h"
#include "nac_system_errorlog.h"
#include "nac_system_xml.h"
#include "nac_system_save_sysconfig.h"
#include "nac_system_redirect_manager_ip.h"
#include "nac_system_redis_subscribe.h"
#include "nac_system_deal_sysconfig.h"

extern HUPU_UINT16 asc_access_mode;
HUPU_INT32 convert_access_mode_to_str(char *mode_str);
HUPU_INT32 nac_system_set_asc_access_mode(HUPU_UINT16 access_mode);
HUPU_INT32 nac_sys_write_access_mode_to_configure(FILE* fp);
HUPU_INT32 nac_sys_get_access_mode_from_configure(const HUPU_CHAR *file_path);
xmlDocPtr nac_system_parse_access_mode(xmlDocPtr doc, HUPU_UINT16 cmd_id);

#endif
