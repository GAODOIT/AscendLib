#ifndef NAC_SYSTEM_ARP_MONITOR_H
#define NAC_SYSTEM_ARP_MONITOR_H

#include "nac_system_common_lib.h"

/* ARP protocol opcodes. */
#define NAC_ARPOP_REQUEST   1       /* ARP request          */
#define NAC_ARPOP_REPLY 	2       /* ARP reply            */

#define NAC_VLAN_VID_MASK	0xFFF
#define PCAP_ERRBUF_LEN		128
#define PCAP_PKT_BUF_LEN	1518
#define PCAP_SNAP_TIME_OUT	5

////////////////////////////////////////////////////////////////////
typedef struct nac_ethhdr
{
	unsigned char   h_dest[ETH_ALEN];   /* destination eth addr */
    unsigned char   h_source[ETH_ALEN]; /* source ether addr    */
    unsigned short 	h_proto;			/* packet type ID field */
	char eth_payload[0];
}nac_ethhdr_st;

typedef struct nac_vlan_hdr
{
    unsigned short  h_vlan_TCI;
    unsigned short  h_vlan_encapsulated_proto;
	char vlan_payload[0];
}nac_vlan_hdr_st;

typedef struct nac_vlan_ethhdr
{
    unsigned char   h_dest[ETH_ALEN];
    unsigned char   h_source[ETH_ALEN];
    unsigned short  h_vlan_proto;
    unsigned short  h_vlan_TCI;
    unsigned short  h_vlan_encapsulated_proto;
	char vlan_eth_payload[0];
} nac_vlan_ethhdr_st;

typedef struct nac_arphdr
{
    unsigned short	ar_hrd;     /* format of hardware address   */
    unsigned short 	ar_pro;     /* format of protocol address   */
    unsigned char	ar_hln;     /* length of hardware address   */
    unsigned char   ar_pln;     /* length of protocol address   */
    unsigned short	ar_op;      /* ARP opcode (command)     */

    unsigned char       ar_sha[ETH_ALEN];   /* sender hardware address  */
	//unsigned int arp_sip;
	unsigned char       ar_sip[4];      /* sender IP address        */

	unsigned char       ar_tha[ETH_ALEN];   /* target hardware address */
	//unsigned int	arp_tip;
	unsigned char       ar_tip[4];      /* target IP address        */
	char 				arp_payload[0];
}nac_arphdr_st;


struct nac_iphdr
{
	unsigned char version:4,
					ihl:4; /*iphdr_len = ihl*5;*/
	/*unsigned char	ver_ihl;*/
	unsigned char 	tos;
	unsigned short  tot_len;
	unsigned short	id;
	unsigned short	frag_off;
	unsigned char	ttl;
	unsigned char 	protocol;
	unsigned short	checksum;
	unsigned int	saddr;
	unsigned int	daddr;
	char 			ip_payload[0];
}nac_iphdr_st;
///////////////////////////////////////////////////////////////////////////////////
#define NAC_DEVICE_IP_HASH_SIZE		1024
#define NAC_DEVICE_MAC_HASH_SIZE	1024

typedef struct arp_monitor_config_struct
{
    unsigned char	enable;		//0:close;1:open;
    unsigned char	test_flag;	//0:ok;--1:no;
	unsigned short	cycle_time; //minute;
    char monitor_port[IFNAMSIZE];
    char port_attr[IFNAMSIZE];

} arp_monitor_config_st;
extern struct arp_monitor_config_struct gst_arp_monitor_config;//for extern_file.c use

typedef struct NAC_SYS_DEVICE_INFO_STRU
{
	struct nac_hlist_node ip_node;
	struct nac_hlist_node mac_node;
	HUPU_ULONG32 last_time;
	HUPU_UINT32 ip;
	HUPU_CHAR	mac[ETH_ALEN];
	HUPU_UINT16 send_status; //0:unsend;1:send;
	HUPU_UINT16 vlan_tag;
}NAC_SYS_DEVICE_INFO_ST;
extern struct nac_hlist_head nac_device_hlist_by_mac[NAC_DEVICE_MAC_HASH_SIZE];

HUPU_VOID nac_system_device_info_lock(HUPU_VOID);
HUPU_VOID nac_system_device_info_unlock(HUPU_VOID);
HUPU_UINT32 nac_system_device_get_hash_by_mac(char *mac);
HUPU_VOID nac_system_init_device_info_hlist(HUPU_VOID);
HUPU_VOID nac_system_free_device_info_hlist(HUPU_VOID);
HUPU_VOID *nac_system_arp_monitor_thread_enter(HUPU_VOID *arg);
HUPU_INT32 nac_system_device_info_insert(NAC_SYS_DEVICE_INFO_ST* pst_device_st);
HUPU_INT32 nac_system_arp_monitor_arp_table_to_server(HUPU_UINT32 ui_sockfd);
HUPU_VOID __nac_system_show_device_info_hlist(HUPU_VOID);
HUPU_VOID nac_system_free_device_info_hlist_time_out_node(HUPU_UINT32 ageing_time_interval);

/*return xmlDoc*/
xmlDocPtr nac_sys_parse_set_arp_monitor(xmlDocPtr doc, HUPU_UINT16 cmd_id);

#endif //end of NAC_SYSTEM_ARP_MONITOR_H
