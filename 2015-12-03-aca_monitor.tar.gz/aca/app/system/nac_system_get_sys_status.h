#ifndef NAC_SYSTEM_GET_SYS_STATUS_H
#define NAC_SYSTEM_GET_SYS_STATUS_H
#include "nac_system_common_lib.h"
//0.00, 0.00, 0.00
int nac_get_system_load_average_status(char *status_str);

//4020;1190 --total;used
int nac_get_system_memory_status(char *status_str);

//0.00%
int nac_get_system_cpu_status(char *status_str);

//466388;4119--total;used
int nac_get_system_disk_status(char *status_str);

//419562;237--total;used
int nac_get_system_data_partition_status(char *status_str);

xmlDocPtr nac_sys_parse_get_sys_status_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id);

#endif //NAC_SYSTEM_GET_SYS_STATUS_H
