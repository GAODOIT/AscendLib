#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_vlanmap.h"
#include "nac_system_net.h"
#include "nac_system_pbr_advance_setup.h"
#include "nac_system_redirect_manager_ip.h"
#include "nac_system_netapp_check.h"
#include "nac_system_iprange_policy.h"
#include "nac_system_domain_policy.h"
#include "nac_system_save_sysconfig.h"
#include "nac_system_arp_monitor.h"
#include "nac_system_time.h"
#include "nac_system_escape_deal.h"
#include "nac_system_set_remote_server.h"
#include "nac_system_nat_manage.h"
#include "nac_system_exceptapp.h"
#include "nac_system_dhcp_manage.h"
#include "nac_system_except_mac.h"
#include "nac_system_ha_backup.h"
#include "nac_system_os_check.h"
#include "nac_system_access_mode.h"

//save and recover config
HUPU_CHAR* nac_sys_cfg_file = "/nac/config/nac_sys.conf";

//fputs("# id enable name cycle uint times proto port fixPath serverList", nac_save_fp);
HUPU_INT32 nac_sys_save_netapp_config_list(FILE* fp)
{
 	HUPU_INT16 hash, i;
	struct nac_hlist_node *pos, *n;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;
	HUPU_CHAR uint_str[16], ip_str[16], proto_str[16];
	HUPU_CHAR server_list[128];
	for(hash = 0; hash < NETAPP_HASH_MAP_SIZE; hash++)
	{
		nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
    	{
			memset(uint_str, '\0', sizeof(uint_str));
			switch(pst_netapp_tmp->netapp_st.cycle_unit)
			{
			case CYCLE_UINT_SECOND:
				strcpy(uint_str, "sec");
				break;
			case CYCLE_UINT_MINUTE:
				strcpy(uint_str, "min");
				break;
			case CYCLE_UINT_HOUR:
				strcpy(uint_str, "hour");
				break;
			};

			memset(proto_str, '\0', sizeof(proto_str));
			switch(pst_netapp_tmp->netapp_st.protocol)
			{
			case IPPROTO_TCP_UDP:
				strcpy(proto_str, "any");
				break;
			case IPPROTO_TCP:
				strcpy(proto_str, "tcp");
				break;
			case IPPROTO_UDP:
				strcpy(proto_str, "udp");
				break;
			};

			memset(server_list, '\0', sizeof(server_list));
			for(i = 0; i < 5; i++)
			{
				if(pst_netapp_tmp->netapp_st.server_group[i] > 0)
				{
					memset(ip_str, '\0', sizeof(ip_str));
					if (i)
					{
						strcat(server_list, ";");
					}
					sprintf(ip_str, "%u.%u.%u.%u",
							LIPQUAD(pst_netapp_tmp->netapp_st.server_group[i]));
					strcat(server_list, ip_str);
				}
			}

			fprintf(fp, "%d %d %s %d %s %d %s %d %s %s\n",
					pst_netapp_tmp->id, pst_netapp_tmp->enable,
					pst_netapp_tmp->netapp_st.name,
					pst_netapp_tmp->netapp_st.cycle,
					uint_str, pst_netapp_tmp->netapp_st.times,
					proto_str, pst_netapp_tmp->netapp_st.port,
					server_list,pst_netapp_tmp->netapp_st.fix_path);
		}
	}
	return HUPU_OK;
}

static HUPU_INT32 nac_sys_read_netapp_config(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet;
    FILE *nac_read_fp;
    HUPU_CHAR line_item[BUFF_LEN] = "";
    HUPU_UINT16 match_flag = 0;//0:no match;1:match;
    NAC_APP_NETAPP_OBJECT st_netapp_tmp;
	HUPU_CHAR uint_str[16],proto_str[16];
	HUPU_CHAR server_list[128];
	HUPU_UINT32 item_len, tmp, count;

	//NAC_APP_VLANMAP app_vlanmap_st;

    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(line_item, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if(match_flag == 0)
        {
            if(strstr(line_item, "netapp_config") != NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
        	if (line_item[0] == '#')
			{
				continue;
			}

			item_len = strlen(line_item);
			if (item_len < 2)
            {
                break;
            }
			//line_item[item_len-1] = '\0';
			//fputs("# id enable name cycle uint times proto port serverList fixPath", nac_save_fp)
			memset(&st_netapp_tmp, '\0', sizeof(NAC_APP_NETAPP_OBJECT));
			//iRet = sscanf(line_item, "%hd %hhd %s %hd %s %hd %s %hd %s %s",
			//%[^\n] avoid the fixpath have '\0';
			iRet = sscanf(line_item, "%hd %hhd %s %hd %s %hd %s %hd %s %[^\n]",
						&st_netapp_tmp.id, &st_netapp_tmp.enable,
						st_netapp_tmp.netapp_st.name,
						&st_netapp_tmp.netapp_st.cycle,
						uint_str, &st_netapp_tmp.netapp_st.times,
						proto_str, &st_netapp_tmp.netapp_st.port,
						server_list, st_netapp_tmp.netapp_st.fix_path);
			if (iRet != 10)
			{
				continue;
			}

			tmp = 0;
			if (strstr(uint_str, "sec"))
			{
				tmp = CYCLE_UINT_SECOND;
			}
			else if (strstr(uint_str, "min"))
			{
				tmp = CYCLE_UINT_MINUTE;
			}
			else if (strstr(uint_str, "hour"))
			{
				tmp = CYCLE_UINT_HOUR;
			}
			st_netapp_tmp.netapp_st.cycle_unit = tmp;

			tmp = 0;
			if (strstr(proto_str, "any") != HUPU_NULL)
			{
				tmp = IPPROTO_TCP_UDP;
			}
			else if(strstr(proto_str, "tcp") != HUPU_NULL)
			{
				tmp = IPPROTO_TCP;
			}
			else if(strstr(proto_str, "udp") != HUPU_NULL)
			{
				tmp = IPPROTO_UDP;
			}
			st_netapp_tmp.netapp_st.protocol = tmp;
			HUPU_CHAR *token = HUPU_NULL, *running = HUPU_NULL;
			running = (HUPU_CHAR*)server_list;
			count = 0;
			while((token = strsep(&running, ";")) != HUPU_NULL && count < 5)
			{
				if (strlen(token) > 4)//check token = ip_str
				{
					st_netapp_tmp.netapp_st.server_group[count] = inet_network(token);
				}
				else
				{
					st_netapp_tmp.netapp_st.server_group[count] = 0;
				}
				count ++;
			}

			st_netapp_tmp.sum = 0;
			st_netapp_tmp.except_list = HUPU_NULL;

			iRet = nac_app_add_netapp_hlist(&st_netapp_tmp);
			if (iRet != HUPU_OK)
			{
				continue;
			}

            if (st_netapp_tmp.enable == HUPU_ENABLE)
            {
                g_netapp_enable_id   = 0;
                tmp_netapp_enable_id = st_netapp_tmp.id;
            }

			if (g_netapp_policy_index < st_netapp_tmp.id)
			{
				g_netapp_policy_index = st_netapp_tmp.id;
			}
        }
        memset(line_item, '\0', BUFF_LEN);
    }
	fclose(nac_read_fp);
	return HUPU_OK;
}

//fputs("# netapp_id name except_iprange\n", nac_save_fp);
HUPU_INT32 nac_sys_save_netapp_except_list(FILE* fp)
{
 	HUPU_INT16 hash, i;
	struct nac_hlist_node *pos, *n;
	NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;
	for(hash = 0; hash < NETAPP_HASH_MAP_SIZE; hash++)
	{
		nac_hlist_for_each_entry_safe(pst_netapp_tmp, pos, n, &netapp_hash_by_id[hash], netapp_id)
    	{

			for (i = 0; i < pst_netapp_tmp->sum; i++)
			{
				fprintf(fp, "%d %s %s-%s\n",
					pst_netapp_tmp->id,
					pst_netapp_tmp->netapp_st.name,
					pst_netapp_tmp->except_list[i].min,
					pst_netapp_tmp->except_list[i].max);
			}
		}
	}

	return HUPU_OK;
}

static HUPU_INT32 nac_sys_read_netapp_except_list(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet,item_len;
    FILE *nac_read_fp;
    HUPU_CHAR line_item[BUFF_LEN] = "";
    HUPU_UINT16 match_flag = 0;//0:no match;1:match;
	HUPU_UINT16 netapp_id;
	HUPU_CHAR ip_str[2][32], name[MAX_COMMENT_LEN];
    NAC_APP_NETAPP_OBJECT *pst_netapp_tmp = HUPU_NULL;
	HUPU_UINT16 except_sum = 0;
	struct NETAPP_EXCEPT_STRU* pst_except_list = HUPU_NULL;


    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(line_item, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(line_item, "netapp_except") != NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
        	if (line_item[0] == '#')
			{
				continue;
			}

			item_len = strlen(line_item);
			if (item_len < 2)
            {
                break;
            }

			line_item[item_len-1] = '\0';
			memset(name, '\0', sizeof(name));
			memset(ip_str, '\0', sizeof(ip_str));
			iRet = sscanf(line_item, "%hd %s %[0-9.]-%[0-9.]", &netapp_id, name, ip_str[0], ip_str[1]);
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "netapp id=%d-->name=%s-->ip_min=%s-->ip_max=%s\n",
                                netapp_id, name, ip_str[0], ip_str[1]);
			if (iRet != 4)
			{
				continue;
			}

			pst_netapp_tmp = nac_app_get_netapp_by_id(netapp_id);
			if (pst_netapp_tmp == HUPU_NULL)
			{
				continue;
			}

			if (pst_netapp_tmp->sum == 0)
			{
				except_sum = 1;
			}
			else
			{
				except_sum = pst_netapp_tmp->sum + 1;
			}

			pst_except_list = (struct NETAPP_EXCEPT_STRU*)malloc(except_sum*sizeof(struct NETAPP_EXCEPT_STRU));
			if (pst_except_list == HUPU_NULL)
			{
					SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "malloc fault!\n");
					continue;
			}
            memset(pst_except_list, '\0', except_sum*sizeof(struct NETAPP_EXCEPT_STRU));
			memcpy(pst_except_list, pst_netapp_tmp->except_list, (pst_netapp_tmp->sum)*sizeof(struct NETAPP_EXCEPT_STRU));
            memcpy(pst_except_list[except_sum-1].min, ip_str[0], strlen(ip_str[0]));
            memcpy(pst_except_list[except_sum-1].max, ip_str[1], strlen(ip_str[1]));
			if (pst_netapp_tmp->sum > 0)
			{
				free(pst_netapp_tmp->except_list);
			}
			pst_netapp_tmp->sum = except_sum;
			pst_netapp_tmp->except_list = pst_except_list;
		}
        memset(line_item, '\0', BUFF_LEN);
    }
	fclose(nac_read_fp);
	return HUPU_OK;
}

HUPU_VOID nac_sys_save_vlanmap(FILE* fp)
{
    HUPU_INT16 key;
    NAC_APP_VLANMAP *vlan_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;
    for (key = 0; key < NAC_SYS_VLANMAP_HASH_SIZE; key++)
    {
    	nac_hlist_for_each_entry_safe(vlan_ent, pos, n, &nac_vlanmap_hash[key], node)
		{
			fprintf(fp, "%d %hd %hd %s\n", vlan_ent->id, vlan_ent->isolate_vlantag,
					vlan_ent->normal_vlantag, vlan_ent->comment);
		}
    }
}

static HUPU_VOID nac_sys_save_iprange_policy_hlist(FILE* fp)
{
	HUPU_INT16 key;
	NAC_APP_POLICY *policy_ent = HUPU_NULL;
	struct nac_hlist_node *pos, *n;

	for (key = 0; key < NAC_SYS_POLICY_HASH_SIZE; key++)
	{
		if (!nac_hlist_empty(&nac_app_policy_hash[key]))
        {
            nac_hlist_for_each_entry_safe(policy_ent, pos, n, &nac_app_policy_hash[key], node)
			{
				if ((policy_ent->type == NAC_APP_EXCEPT_TERMINAL) || (policy_ent->type == NAC_APP_EXCEPT_SERVER)
					|| (policy_ent->type == NAC_APP_SAFE_IPZONE)  || (policy_ent->type == NAC_APP_ISOLATE_IPZONE)
					)
				{
					fprintf(fp,	"%d %d %s %u.%u.%u.%u-%u.%u.%u.%u %s\n", policy_ent->id, policy_ent->type,
							policy_ent->plyname, LIPQUAD(policy_ent->union_ply.iprange.ip_min),
							LIPQUAD(policy_ent->union_ply.iprange.ip_max), policy_ent->comment);
				}
			}
		}
	}
}

//for debug_sysconfig call
HUPU_VOID nac_system_show_iprange_policy_hlist(FILE* fp, EM_POLICY_TYPE ip_type)
{
	HUPU_INT16 key;
	NAC_APP_POLICY *policy_ent = HUPU_NULL;
	struct nac_hlist_node *pos, *n;

	for (key = 0; key < NAC_SYS_POLICY_HASH_SIZE; key++)
	{
		if (!nac_hlist_empty(&nac_app_policy_hash[key]))
        {
            nac_hlist_for_each_entry_safe(policy_ent, pos, n, &nac_app_policy_hash[key], node)
			{
				if (ip_type == policy_ent->type)
				{
					fprintf(fp,	"%d %d %s %u.%u.%u.%u-%u.%u.%u.%u %s\n", policy_ent->id, policy_ent->type,
							policy_ent->plyname, LIPQUAD(policy_ent->union_ply.iprange.ip_min),
							LIPQUAD(policy_ent->union_ply.iprange.ip_max), policy_ent->comment);
				}
			}
		}
	}
}

//policy_type = 5; except_domain;  NAC_APP_EXCEPT_DOMAIN = 5;
//policy_type = 6; isolate_domain; NAC_APP_ISOLATE_DOMAIN = 6;
static HUPU_VOID nac_sys_save_domain_policy_hlist(FILE* fp)
{
	HUPU_INT16 key;
	NAC_APP_DOMAIN *domain_ent = HUPU_NULL;
	struct nac_hlist_node *pos, *n;

    for (key = 0; key < NAC_SYS_DOMAIN_HASH_SIZE; key++)
    {
        if (!nac_hlist_empty(&nac_app_domain_hash[key]))
        {
            nac_hlist_for_each_entry_safe(domain_ent, pos, n, &nac_app_domain_hash[key], node)
            {
				if ((domain_ent->type == NAC_APP_EXCEPT_DOMAIN) || (domain_ent->type == NAC_APP_ISOLATE_DOMAIN))
				{
					fprintf(fp, "%d %d %s %s %s\n", domain_ent->id, domain_ent->type,
							domain_ent->plyname, domain_ent->domain, domain_ent->comment);
				}
            }
        }
    }
}

//for debug_sysconfig call
HUPU_VOID nac_system_show_domain_policy_hlist(FILE* fp, EM_POLICY_TYPE domain_type)
{
	HUPU_INT16 key;
	NAC_APP_DOMAIN *domain_ent = HUPU_NULL;
	struct nac_hlist_node *pos, *n;

    for (key = 0; key < NAC_SYS_DOMAIN_HASH_SIZE; key++)
    {
        if (!nac_hlist_empty(&nac_app_domain_hash[key]))
        {
            nac_hlist_for_each_entry_safe(domain_ent, pos, n, &nac_app_domain_hash[key], node)
            {
				if (domain_type == domain_ent->type)
				{
					fprintf(fp, "%d %d %s %s %s\n", domain_ent->id, domain_ent->type,
							domain_ent->plyname, domain_ent->domain, domain_ent->comment);
				}
            }
        }
    }
}

HUPU_INT32 nac_app_save_sys_config_to_file(const HUPU_CHAR* config_file)
{
    FILE *nac_save_fp;
    HUPU_CHAR current_time_str[50];

    if ((nac_save_fp = fopen(config_file, "w+")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->save open %s error\n", __FUNCTION__, config_file);
        return HUPU_ERR;
    }

    fputs("# HUPU_NAC configuration file\n", nac_save_fp);
    fputs("# Version: 2.01.01\n", nac_save_fp);

	memset(current_time_str, '\0', strlen(current_time_str));
    get_current_time(current_time_str);
    fprintf(nac_save_fp, "# setup time:%s\n", current_time_str);
    fputs("\n\n\n", nac_save_fp);

    //ifconfig
    fputs("# ifconfig configuration\n", nac_save_fp);
    fputs("# id ifname ifattr ip netmask enable\n", nac_save_fp);
    nac_sys_save_ifconfig(nac_save_fp);
    fputs("\n\n", nac_save_fp);

    fputs("# nameserver configuration\n", nac_save_fp);
    fprintf(nac_save_fp, "dns1=%s\n", gst_dns_server.nameserver1);
    fprintf(nac_save_fp, "dns2=%s\n", gst_dns_server.nameserver2);
    fputs("\n\n", nac_save_fp);

    //default_gateway
    fputs("# default_gateway configuration\n", nac_save_fp);
    //fputs("# gateway\n", nac_save_fp);
    fprintf(nac_save_fp, "gateway=%s\n", g_default_gateway);
    fputs("\n\n", nac_save_fp);


    //access_mode
    nac_sys_write_access_mode_to_configure(nac_save_fp);

	//pbr_advance_setup
	fputs("# pbr_advance_setup configuration\n", nac_save_fp);
	fprintf(nac_save_fp, "onein_oneout_switch=%d\n", nac_pbr_onein_oneout_flag);
	if (nac_pbr_onein_oneout_flag == HUPU_TRUE)
	{
		fprintf(nac_save_fp, "nexthop_sw_ip=%u.%u.%u.%u\n", LIPQUAD(pbr_advance_setup.nexthop_ip));
		fprintf(nac_save_fp, "nexthop_sw_mac=%02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx\n",
				MAC_FORMAT(pbr_advance_setup.nexthop_mac));
	}
	fputs("\n\n", nac_save_fp);

    //redirect_addr
    nac_sys_write_redirect_config_to_configure(nac_save_fp);

    //os_check_swit
    nac_sys_write_os_check_swit_to_configure(nac_save_fp);

    /*
    fputs("# redirect_url configuration\n", nac_save_fp);
    fprintf(nac_save_fp, "url=%s\n", gst_redirect_manager_ip.ac_redirect_ip);
    fputs("\n\n", nac_save_fp);
    */

    //vlanmap
    fputs("# vlanmap configuration\n", nac_save_fp);
    fputs("# id isolate_vlan normal_vlan comment\n", nac_save_fp);
    nac_sys_save_vlanmap(nac_save_fp);
    fputs("\n\n", nac_save_fp);

    //arp_monitor config
	fputs("# arp_monitor configuration\n",	nac_save_fp);
	fprintf(nac_save_fp, "arp_enable=%d\n", gst_arp_monitor_config.enable);
	fprintf(nac_save_fp, "cycle_time=%d\n", gst_arp_monitor_config.cycle_time);
	fprintf(nac_save_fp, "monitor_port=%s;%s\n",
			gst_arp_monitor_config.monitor_port, gst_arp_monitor_config.port_attr);
	fputs("\n\n", nac_save_fp);

	//ntpdate_server config
	fputs("# ntpdate_server configuration\n",	nac_save_fp);
	fprintf(nac_save_fp, "auto_sync=%d\n",	gst_nac_ntp_server.self_sync_enable);
	fprintf(nac_save_fp, "ntp_server=%s\n",	gst_nac_ntp_server.ntp_server);
	fputs("\n\n", nac_save_fp);

	//asc_enable_flag config
	fputs("# asc_enable_flag configuration(enable/disable)\n",	nac_save_fp);
	fprintf(nac_save_fp, "asc_enable_flag=%s\n",
			(g_nac_asc_enable_flag == 1)?("enable"):("disable"));
	fputs("\n\n", nac_save_fp);

	//asc escape_config
    nac_sys_write_escape_config_to_configure(nac_save_fp);

	/*
	//except_policy(except_terminal; except_server)
	fputs("# except_policy configuration\n", nac_save_fp);
	fputs("# id type ip_range\n", nac_save_fp);
	nac_sys_save_except_policy(nac_save_fp);
	fputs("\n\n", nac_save_fp);

	//except_domain
	fputs("# except_domain configuration(id++)\n", nac_save_fp);
	fputs("# id type domain\n", nac_save_fp);
	nac_sys_save_except_domain(nac_save_fp);
	fputs("\n\n", nac_save_fp);
	*/

	//except_terminal=1; except_server=2; safe_ipzone=3 and isolate_ipzone=4;
	fputs("# iprange_policy configuration(id++)\n", nac_save_fp);
	fputs("# id type plyname iprange comment\n", nac_save_fp);
	nac_sys_save_iprange_policy_hlist(nac_save_fp);
	fputs("\n\n", nac_save_fp);

	//except_domain=5 and isolate_domain=6;
	fputs("# domain_policy configuration\n", nac_save_fp);
	fputs("# id type plyname domain comment\n", nac_save_fp);
	nac_sys_save_domain_policy_hlist(nac_save_fp);
	fputs("\n\n", nac_save_fp);

	//netapp_config_list
    fputs("# netapp_config configuration\n", nac_save_fp);
	fputs("# id enable name cycle uint(sec,min,hour) times proto(any,tcp,udp) port serverList fixPath\n", nac_save_fp);
	nac_sys_save_netapp_config_list(nac_save_fp);
	fputs("\n\n", nac_save_fp);

	//netapp_except_list
	fputs("# netapp_except configuration\n", nac_save_fp);
	fputs("# netapp_id name except_iprange\n", nac_save_fp);
	nac_sys_save_netapp_except_list(nac_save_fp);
	fputs("\n\n", nac_save_fp);

    //nat_manage switch
    fputs("# nat_manage configuration\n", nac_save_fp);
    fputs("# natSwitch(off=0/on=1) autoFound(off=0/on=1) defaultAction(ignore=0/allow=1/forbid=2)\n", nac_save_fp);
    fprintf(nac_save_fp, "%d %d %d\n", g_nat_config_st.enable,
        g_nat_config_st.auto_found,
        g_nat_config_st.default_action);
    fputs("\n\n", nac_save_fp);

    //nat_manage_list
    fputs("# nat_list configuration\n", nac_save_fp);
    fputs("# id ip action(ignore=0/allow=1/forbid=2) describe\n", nac_save_fp);
    nac_app_save_nat_manage_list(nac_save_fp);
    fputs("\n\n", nac_save_fp);

    //write except app data to config
    write_exceptapp_data_to_configure(nac_save_fp);

    //write dhcp manage data to config
    nac_sys_write_dhcp_manage_data_to_configure(nac_save_fp);

    //write except mac data to config
    nac_sys_write_except_mac_data_to_configure(nac_save_fp);

    //write ha_backup config to config
    nac_sys_write_ha_backup_config_to_configure(nac_save_fp);

    fclose(nac_save_fp);
    return HUPU_OK;
}

static HUPU_INT32 nac_sys_init_vlanmap_config(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet;
    FILE *nac_read_fp;
    HUPU_CHAR buffer[BUFF_LEN] = "";
    HUPU_UINT16 match_flag = 0, enter_flag = 0;//0:no match;1:match;
	NAC_APP_VLANMAP app_vlanmap_st;

    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(buffer, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(buffer, "vlanmap") != NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
            if (enter_flag == 0)
            {
				enter_flag = 1;
                continue;
            }

            //id isolate_vlan normal_vlan comment
            if (strlen(buffer) < 2)
            {
                break;
            }

			memset(&app_vlanmap_st, '\0', sizeof(NAC_APP_VLANMAP));
            sscanf(buffer, "%d %hd %hd %s", &app_vlanmap_st.id, &app_vlanmap_st.isolate_vlantag,
				&app_vlanmap_st.normal_vlantag, app_vlanmap_st.comment);

			if (app_vlanmap_st.isolate_vlantag <= 0 && app_vlanmap_st.normal_vlantag <= 0)
			{
				continue;
			}

			SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->id=%d--isolate_vlan=%d--normal_vlan=%d\n", __FUNCTION__,
						app_vlanmap_st.id, app_vlanmap_st.isolate_vlantag, app_vlanmap_st.normal_vlantag);

			iRet = nac_sys_add_vlanmap(&app_vlanmap_st);
			if (iRet != HUPU_OK)
			{
				nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_add_vlanmap error,iRet = %d\n",__FUNCTION__, iRet);
				//continue;
			}
			else
			{
				g_vlanmap_index = app_vlanmap_st.id;
			}
        }
        memset(buffer, '\0', BUFF_LEN);
    }
    fclose(nac_read_fp);
	return HUPU_OK;
}

static HUPU_INT32 nac_sys_init_ifconfig_config(const HUPU_CHAR* filename)
{
    FILE *nac_read_fp;
    HUPU_CHAR buffer[BUFF_LEN] = "";
	HUPU_UINT16 match_flag = 0, enter_flag = 0;//0:no match;1:match;
    NAC_NET_DEVICE app_netdev_st;
    HUPU_CHAR netdev_name[IFNAMSIZE] = "";
	HUPU_UINT16 netdev_count = 0;
    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(buffer, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(buffer, "ifconfig") != NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
            //id ifname ifattr ip netmask enable
			if (enter_flag == 0)
            {
                enter_flag = 1;
                continue;
            }

            if (strlen(buffer) < 2)
            {
                break;
            }

			memset(&app_netdev_st, '\0', sizeof(NAC_NET_DEVICE));
			sscanf(buffer, "%hd %s %s %s %s %hhd", &app_netdev_st.if_index, netdev_name,
				app_netdev_st.if_label, app_netdev_st.if_ip, app_netdev_st.if_mask,
				&app_netdev_st.if_enable);

			if (strcmp(app_netdev_st.if_label, "manager") == HUPU_OK)
			{
				memset(g_manager_eth_name, '\0', IFNAMSIZE);
				memcpy(g_manager_eth_name, netdev_name, sizeof(netdev_name));
			}

            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ifconfig-->%d-%s-%s-%s-%s-%d\n",
                            app_netdev_st.if_index, netdev_name, app_netdev_st.if_label,
				            app_netdev_st.if_ip, app_netdev_st.if_mask, app_netdev_st.if_enable);

			app_netdev_st.if_enable = 1;

			// config_eth_count != real_eth_count;
			if (gi_netdev_count == netdev_count)
			{
				break;
			}
            nac_sys_net_set_ifconfig(&app_netdev_st);
			netdev_count = netdev_count + 1;

        }
        memset(buffer, '\0', BUFF_LEN);
    }
    nac_sys_set_knl_redirect_manager_ip(&gst_redirect_manager_ip);
    fclose(nac_read_fp);
	return HUPU_OK;
}

static HUPU_INT32 nac_sys_init_nameserver_config(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet;
    FILE *nac_read_fp;
    HUPU_CHAR buffer[BUFF_LEN] = "";
    HUPU_UINT16 match_flag = 0;//0:no match;1:match;
    HUPU_CHAR* cfg_content = HUPU_NULL;
    NAC_DNS_SERVER dnserver_st;

    memset(&dnserver_st, '\0', sizeof(NAC_DNS_SERVER));

    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(buffer, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(buffer, "nameserver") != NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
            //url=10.10.2.251
            if (strlen(buffer) < 2)
            {
                break;
            }

			cfg_content = HUPU_NULL;
            if ((cfg_content = strstr(buffer, "dns1=")) != NULL)
            {
                cfg_content = cfg_content + 5;
                clean_newline_character(cfg_content);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->DNS1=%s\n", __FUNCTION__, cfg_content);
                memcpy(dnserver_st.nameserver1, cfg_content, strlen(cfg_content));
            }
            else if((cfg_content = strstr(buffer, "dns2=")) != NULL)
            {
                cfg_content = cfg_content + 5;
                clean_newline_character(cfg_content);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->DNS2=%s\n", __FUNCTION__, cfg_content);
                memcpy(dnserver_st.nameserver2, cfg_content, strlen(cfg_content));
                break;
            }

        }
        memset(buffer, '\0', BUFF_LEN);
    }
    fclose(nac_read_fp);

    /*youhua failure return HUPU_ERR*/
    iRet = nac_sys_net_set_dnserver(&dnserver_st);
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_net_set_dnserver error, iRet = %d\n", __FUNCTION__, iRet);
        return HUPU_ERR;
    }
    return HUPU_OK;
}

static HUPU_INT32 nac_sys_init_default_gateway_config(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet;
    FILE *nac_read_fp;
    HUPU_CHAR buffer[BUFF_LEN] = "";
    HUPU_UINT16 match_flag = 0;//0:no match;1:match;
    HUPU_CHAR* cfg_content = HUPU_NULL;
	HUPU_CHAR gateway_tmp[IP_STR_LEN] = "";

    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(buffer, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(buffer, "default_gateway") != NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
            //gateway=10.10.2.1
            if (strlen(buffer) < 2)
            {
                break;
            }

			cfg_content = HUPU_NULL;
            if ((cfg_content = strstr(buffer, "gateway=")) != NULL)
            {
                cfg_content = cfg_content + strlen("gateway=");
                clean_newline_character(cfg_content);
				mymemcpy(gateway_tmp, sizeof(gateway_tmp), cfg_content, strlen(cfg_content));
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->default_gateway=%s\n", __FUNCTION__, gateway_tmp);
                break;
            }
        }
        memset(buffer, '\0', BUFF_LEN);
    }
    fclose(nac_read_fp);

	if (match_flag == 1)
	{
		memset(g_default_gateway, '\0', IP_STR_LEN);
		if (strlen(gateway_tmp) > HUPU_OK)
		{
			mymemcpy(g_default_gateway, IP_STR_LEN,
					gateway_tmp, strlen(gateway_tmp));
		}

		iRet = nac_sys_net_set_default_gateway(gateway_tmp);
		if (iRet != HUPU_OK)
    	{
        	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_net_set_default_gateway error, iRet = %d\n", __FUNCTION__, iRet);
        	return HUPU_ERR;
    	}
	}

    return HUPU_OK;
}

static HUPU_INT32 nac_sys_init_arp_monitor_config(const HUPU_CHAR* filename)
{
	HUPU_INT32 iRet;
	FILE *nac_read_fp;
	HUPU_CHAR szLine[BUFF_LEN] = "";
	HUPU_UINT16 match_flag = 0;//0:no match;1:match;
	HUPU_CHAR* cfg_content;

	if ((nac_read_fp = fopen(filename, "r")) == HUPU_NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

	while((fgets(szLine, BUFF_LEN, nac_read_fp)) != HUPU_NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(szLine, "arp_monitor") != HUPU_NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
            if (strlen(szLine) < 2)
            {
                break;
            }
        }

		cfg_content = HUPU_NULL;
		if ((cfg_content = strstr(szLine, "arp_enable=")) != HUPU_NULL)
		{
            cfg_content = cfg_content + strlen("arp_enable=");
            clean_newline_character(cfg_content);
			gst_arp_monitor_config.enable = atoi(cfg_content);
        }
		else if ((cfg_content = strstr(szLine, "cycle_time=")) != HUPU_NULL)
		{
			cfg_content = cfg_content + strlen("cycle_time=");
            clean_newline_character(cfg_content);
			gst_arp_monitor_config.cycle_time = atoi(cfg_content);
		}
		else if ((cfg_content = strstr(szLine, "monitor_port=")) != HUPU_NULL)
		{
			cfg_content = cfg_content + strlen("monitor_port=");
			clean_newline_character(cfg_content);

			if (strlen(cfg_content) <= 2)
			{
				break;
			}

			iRet = sscanf(cfg_content, "%[^;];%s",
					gst_arp_monitor_config.monitor_port,
					gst_arp_monitor_config.port_attr);

			if (iRet != 2)
			{
				nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
							"%s-->get arp_monitor port and attr error\n", __FUNCTION__);
				break;
			}
		}

        memset(szLine, '\0', BUFF_LEN);
    }

    fclose(nac_read_fp);
	return HUPU_OK;
}

static HUPU_INT32 nac_sys_init_asc_enable_flag_config(const HUPU_CHAR* filename)
{
	HUPU_INT32 iRet;
	FILE *nac_read_fp;
	HUPU_CHAR szLine[BUFF_LEN] = "";
	HUPU_UINT16 match_flag = 0;//0:no match;1:match;
	HUPU_CHAR* cfg_content;
	HUPU_INT16 enable_tmp = -1;

	if ((nac_read_fp = fopen(filename, "r")) == HUPU_NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

	while((fgets(szLine, BUFF_LEN, nac_read_fp)) != HUPU_NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(szLine, "asc_enable_flag") != HUPU_NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
            if (strlen(szLine) < 2)
            {
                break;
            }
			cfg_content = HUPU_NULL;
			if ((cfg_content = strstr(szLine, "enable")) != HUPU_NULL)
			{
				enable_tmp = ASC_ENABLE;
        	}
			else if ((cfg_content = strstr(szLine, "disable")) != HUPU_NULL)
			{
				enable_tmp = ASC_DISABLE;
			}

		}

        memset(szLine, '\0', BUFF_LEN);
    }
    fclose(nac_read_fp);

	if (enable_tmp == -1 && match_flag == 0)
	{
		return HUPU_ERR;
	}

	iRet = nac_sys_enable_or_disable_asc(enable_tmp);
	if (iRet == HUPU_ERR)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
				"%s-->enable_or_disable_asc error!\n", __FUNCTION__);
		return HUPU_ERR;
	}

	return HUPU_OK;
}

/*
//asc_escape_flag config
fputs("# asc_escape_flag configuration(enable/disable)\n",	nac_save_fp);
fprintf(nac_save_fp, "asc_escape_flag=%s\n",
		(g_asc_escape_enable_flag == 1)?("enable"):("disable"));
fputs("\n\n", nac_save_fp);

static HUPU_INT32 nac_sys_init_asc_escape_flag_config(const HUPU_CHAR* filename)
{
		FILE *nac_read_fp;
		HUPU_CHAR szLine[BUFF_LEN] = "";
		HUPU_UINT16 match_flag = 0;//0:no match;1:match;
		HUPU_CHAR* cfg_content;
		HUPU_INT16 enable_tmp = HUPU_DISABLE;

		if ((nac_read_fp = fopen(filename, "r")) == HUPU_NULL)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
						"%s-->read open %s error\n", __FUNCTION__, filename);
			return HUPU_ERR;
		}

		while((fgets(szLine, BUFF_LEN, nac_read_fp)) != HUPU_NULL)
		{
			if (match_flag == 0)
			{
				if (strstr(szLine, "asc_escape_flag") != HUPU_NULL)
				{
					match_flag = 1;
				}
			}
			else
			{
				if (strlen(szLine) < 2)
				{
					break;
				}
				cfg_content = HUPU_NULL;
				if ((cfg_content = strstr(szLine, "enable")) != HUPU_NULL)
				{
					enable_tmp = HUPU_ENABLE;
				}else if ((cfg_content = strstr(szLine, "disable")) != HUPU_NULL)
				{
					enable_tmp = HUPU_DISABLE;
				}
				memset(szLine, '\0', BUFF_LEN);
			}
		}
		fclose(nac_read_fp);

		if (match_flag == 1)
		{
			nac_sys_escape_config_deal(enable_tmp);
		}

		return HUPU_OK;
}
*/

static HUPU_INT32 nac_sys_init_ntpdate_server_config(const HUPU_CHAR* filename)
{
	HUPU_INT32 iRet;
	FILE *nac_read_fp;
	HUPU_CHAR szLine[BUFF_LEN] = "";
	HUPU_UINT16 match_flag = 0;//0:no match;1:match;
	HUPU_CHAR* cfg_content;

	if ((nac_read_fp = fopen(filename, "r")) == HUPU_NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

	while((fgets(szLine, BUFF_LEN, nac_read_fp)) != HUPU_NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(szLine, "ntpdate_server") != HUPU_NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
            if (strlen(szLine) < 2)
            {
                break;
            }
        }

		cfg_content = HUPU_NULL;
		if ((cfg_content = strstr(szLine, "auto_sync=")) != HUPU_NULL)
		{
            cfg_content = cfg_content + strlen("auto_sync=");
            clean_newline_character(cfg_content);
			gst_nac_ntp_server.self_sync_enable = atoi(cfg_content);
        }
		else if ((cfg_content = strstr(szLine, "ntp_server=")) != HUPU_NULL)
		{
			cfg_content = cfg_content + strlen("ntp_server=");
			clean_newline_character(cfg_content);
			memset(gst_nac_ntp_server.ntp_server, '\0', MAX_DOMAIN_LEN);
			mymemcpy(gst_nac_ntp_server.ntp_server, MAX_DOMAIN_LEN, cfg_content, strlen(cfg_content));
		}
        memset(szLine, '\0', BUFF_LEN);
    }
    fclose(nac_read_fp);

	if (strlen(gst_nac_ntp_server.ntp_server) == 0)
	{
		return HUPU_ERR;
	}

	iRet = nac_ntpdate_time_server(gst_nac_ntp_server.ntp_server);
	if (iRet != HUPU_OK)
    {
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->ntpdate time_server error!\n", __FUNCTION__);
		return HUPU_ERR;
    }

	return HUPU_OK;
}

/*
policy_type = 1; except_terminal;NAC_APP_EXCEPT_TERMINAL = 1;
policy_type = 2; except_server;NAC_APP_EXCEPT_SERVER = 2;
policy_type = 3; safe_ipzone;NAC_APP_SAFE_IPZONE     = 3;
policy_type = 4; isolate_ipzone;NAC_APP_ISOLATE_IPZONE  = 4;
*/

HUPU_INT32 nac_sys_init_safe_ipzone_config(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet;
    FILE *nac_read_fp;
    HUPU_CHAR buffer[BUFF_LEN] = "";
    HUPU_UINT16 match_flag = 0, enter_flag = 0;//0:no match;1:match;

	HUPU_UINT16 policy_type;

	NAC_APP_POLICY app_iprange_st;
	HUPU_CHAR ip_min_str[16];
	HUPU_CHAR ip_max_str[16];

    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(buffer, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(buffer, "iprange_policy") != NULL)
            {
                match_flag = 1;
            }
        }
        else if (match_flag == 1)
        {
            if (enter_flag == 0)
            {
                enter_flag = 1;
                continue;
            }

			//id type plyname iprange comment
            if (strlen(buffer) < 2)
            {
                break;
            }

			sscanf(buffer, "%*d%hd", &policy_type);

			if (policy_type != NAC_APP_SAFE_IPZONE)
			{
				continue;
			}

			memset(&app_iprange_st,  '\0', sizeof(NAC_APP_POLICY));
			sscanf(buffer, "%d %hd %s %[^-]-%s %s", &app_iprange_st.id, &app_iprange_st.type,
				app_iprange_st.plyname, ip_min_str, ip_max_str, app_iprange_st.comment);

			if (app_iprange_st.id > 0 && strlen(app_iprange_st.plyname) > 0
				&& nac_app_preg_match_iprange(ip_min_str, ip_max_str) == HUPU_OK)
			{
				app_iprange_st.union_ply.iprange.ip_min = inet_network(ip_min_str);
				app_iprange_st.union_ply.iprange.ip_max = inet_network(ip_max_str);
			}
			else
            {
				continue;
			}

            SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->id=%d--policy_type=%d--plyname=%s--iprange=%s-%s--comment=%s\n",
						__FUNCTION__, app_iprange_st.id, app_iprange_st.type, app_iprange_st.plyname,
						ip_min_str, ip_max_str, app_iprange_st.comment);

			iRet = nac_system_add_iprange_policy(&app_iprange_st);
			if (iRet != HUPU_OK)
			{
				nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
							"%s-->nac_sys_add_safe_ipzone_policy error,iRet = %d\n", __FUNCTION__, iRet);
				//continue;
			}
			else
			{
				g_policy_index = app_iprange_st.id;
			}

        }
        memset(buffer, '\0', BUFF_LEN);
    }

    fclose(nac_read_fp);
	return HUPU_OK;
}

static HUPU_INT32 nac_sys_init_iprange_policy_config(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet;
    FILE *nac_read_fp;
    HUPU_CHAR buffer[BUFF_LEN] = "";
    HUPU_UINT16 match_flag = 0, enter_flag = 0;//0:no match;1:match;

	HUPU_UINT16 policy_type;

	NAC_APP_POLICY app_iprange_st;
	HUPU_CHAR ip_min_str[16];
	HUPU_CHAR ip_max_str[16];

    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(buffer, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(buffer, "iprange_policy") != NULL)
            {
                match_flag = 1;
            }
        }
        else if (match_flag == 1)
        {
            if (enter_flag == 0)
            {
                enter_flag = 1;
                continue;
            }

			//id type plyname iprange comment
            if (strlen(buffer) < 2)
            {
                break;
            }

			sscanf(buffer, "%*d%hd", &policy_type);
			if (policy_type != NAC_APP_EXCEPT_TERMINAL && policy_type != NAC_APP_EXCEPT_SERVER
				&& policy_type != NAC_APP_SAFE_IPZONE && policy_type != NAC_APP_ISOLATE_IPZONE)
			{
				continue;
			}

			memset(&app_iprange_st,  '\0', sizeof(NAC_APP_POLICY));
			sscanf(buffer, "%d %hd %s %[^-]-%s %s", &app_iprange_st.id, &app_iprange_st.type,
				app_iprange_st.plyname, ip_min_str, ip_max_str, app_iprange_st.comment);

			if (app_iprange_st.id > 0 && strlen(app_iprange_st.plyname) > 0
				&& nac_app_preg_match_iprange(ip_min_str, ip_max_str) == HUPU_OK)
			{
				app_iprange_st.union_ply.iprange.ip_min = inet_network(ip_min_str);
				app_iprange_st.union_ply.iprange.ip_max = inet_network(ip_max_str);
			}
			else
            {
				continue;
			}

            SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->id=%d--policy_type=%d--plyname=%s--iprange=%s-%s--comment=%s\n",
						__FUNCTION__, app_iprange_st.id, app_iprange_st.type, app_iprange_st.plyname,
						ip_min_str, ip_max_str, app_iprange_st.comment);

			iRet = nac_system_add_iprange_policy(&app_iprange_st);
			if (iRet != HUPU_OK)
			{
				if (app_iprange_st.type == NAC_APP_EXCEPT_TERMINAL)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_add_except_terminal_policy error,iRet = %d\n",__FUNCTION__, iRet);
				}
				else if (app_iprange_st.type == NAC_APP_EXCEPT_SERVER)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_add_except_server_policy error,iRet = %d\n", __FUNCTION__, iRet);
				}
				else if (app_iprange_st.type == NAC_APP_SAFE_IPZONE)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_add_safe_ipzone_policy error,iRet = %d\n", __FUNCTION__, iRet);
				}
				else if (app_iprange_st.type == NAC_APP_ISOLATE_IPZONE)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_add_isolate_ipzone_policy error,iRet = %d\n", __FUNCTION__, iRet);
				}
				//continue;
			}
			else
			{
				g_policy_index = app_iprange_st.id;
			}

        }
        memset(buffer, '\0', BUFF_LEN);
    }

    fclose(nac_read_fp);
	return HUPU_OK;
}

//policy_type = 4; except_domain;  NAC_APP_EXCEPT_DOMAIN = 4;
//policy_type = 5; isolate_domain; NAC_APP_ISOLATE_DOMAIN = 5;
static HUPU_INT32 nac_sys_init_domain_policy_config(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet;
    FILE *nac_read_fp;
    HUPU_CHAR buffer[BUFF_LEN] = "";
    HUPU_UINT16 match_flag = 0, enter_flag = 0;//0:no match;1:match;

	NAC_APP_DOMAIN app_domain_st;

    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(buffer, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(buffer, "domain_policy") != NULL)
            {
                match_flag = 1;
            }
        }
        else if(match_flag == 1)
        {
            if (enter_flag == 0)
            {
                enter_flag = 1;
                continue;
            }

			//id type plyname iprange comment
            if (strlen(buffer) < 2)
            {
                break;
            }

			memset(&app_domain_st, '\0', sizeof(NAC_APP_DOMAIN));
			sscanf(buffer, "%d %hd %s %s %s", &app_domain_st.id, &app_domain_st.type,
				app_domain_st.plyname, app_domain_st.domain, app_domain_st.comment);

			if (!(strlen(app_domain_st.plyname) > 0 && strlen(app_domain_st.domain) > 0))
			{
				continue;
			}

			SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->id=%d-->policy_type=%d--plyname=%s--domain=%s--comment=%s\n",
				__FUNCTION__, app_domain_st.id, app_domain_st.type, app_domain_st.plyname, app_domain_st.domain,
				app_domain_st.comment);

			iRet = nac_system_add_domain_policy(&app_domain_st);
			if (iRet != HUPU_OK)
			{
				if (app_domain_st.type == NAC_APP_ISOLATE_DOMAIN)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_add_isolate_domain policy error, iRet = %d\n", __FUNCTION__, iRet);
                }
				else if (app_domain_st.type == NAC_APP_EXCEPT_DOMAIN)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_add_except_domain policy error, iRet = %d\n", __FUNCTION__, iRet);
				}
			}
			else
			{
				g_policy_index = app_domain_st.id;
			}

        }
        memset(buffer, '\0', BUFF_LEN);
    }
    fclose(nac_read_fp);

	return HUPU_OK;
}


static HUPU_INT32 nac_sys_init_pbr_advance_setup_config(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet;
	HUPU_INT16 ret_flag = 0;
    FILE *nac_read_fp;
    HUPU_CHAR buffer[BUFF_LEN] = "";
    HUPU_UINT16 match_flag = 0;//0:no match;1:match;
    HUPU_CHAR* cfg_content = HUPU_NULL;

    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(buffer, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(buffer, "pbr_advance_setup") != NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
            if (strlen(buffer) < 2)
            {
                break;
            }

			cfg_content = NULL;
            if ((cfg_content = strstr(buffer, "onein_oneout_switch=")) != NULL)
            {
				cfg_content = cfg_content + 20;
				clean_newline_character(cfg_content);

				nac_pbr_onein_oneout_flag = atoi(cfg_content);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,"oneout_flag--%d\n", nac_pbr_onein_oneout_flag);

				if (nac_pbr_onein_oneout_flag == HUPU_FALSE)
				{
					break;
				}

            }

			if ((cfg_content = strstr(buffer, "nexthop_sw_ip=")) != NULL)
            {
				cfg_content = cfg_content + 14;
				clean_newline_character(cfg_content);
				pbr_advance_setup.nexthop_ip = inet_network(cfg_content);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,"nexthop_sw_ip=%s\n", cfg_content);
            }

			if ((cfg_content = strstr(buffer, "nexthop_sw_mac=")) != NULL)
            {
				cfg_content = cfg_content + 15;
				clean_newline_character(cfg_content);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,"nexthop_sw_mac=%s\n", cfg_content);
				if (sscanf(cfg_content, COLON_LOWER_MACFMT, &(pbr_advance_setup.nexthop_mac[0]), &(pbr_advance_setup.nexthop_mac[1]),
                    &(pbr_advance_setup.nexthop_mac[2]), &(pbr_advance_setup.nexthop_mac[3]), &(pbr_advance_setup.nexthop_mac[4]),
                    &(pbr_advance_setup.nexthop_mac[5]) ) != ETH_ALEN)
                {
                    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->conf_file nexthop_mac format error\n", __FUNCTION__);
					ret_flag = -1;
                    break;
                }

                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
                            "%s-->switch=%d-->nexthop_sw_ip=%u.%u.%u.%u-->nexthop_sw_mac=%02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx\n",
                            __FUNCTION__, nac_pbr_onein_oneout_flag, LIPQUAD(pbr_advance_setup.nexthop_ip), MAC_FORMAT(pbr_advance_setup.nexthop_mac));
            }


        }
        memset(buffer, '\0', BUFF_LEN);
    }
    fclose(nac_read_fp);

	if (ret_flag == -1)
	{
		return HUPU_ERR;
	}
	else
	{
		iRet = nac_sys_add_pbr_advance_setup(nac_pbr_onein_oneout_flag, &pbr_advance_setup);
		if (iRet != HUPU_OK)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_add_pbr_advance_setup error!\n", __FUNCTION__);
			return HUPU_ERR;
		}
		return HUPU_OK;
	}
}


static HUPU_INT32 nac_sys_read_nat_manage_list(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet,line_len;
    FILE *nac_read_fp;
    /*0:no match;1:match;*/
    HUPU_UINT16 match_flag = 0;
    HUPU_CHAR line_item[BUFF_LEN] = "";
    NAC_APP_NAT nat_item_tmp;
    HUPU_CHAR ip_str[IP_STR_LEN];


    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(line_item, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(line_item, "nat_list") != NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
            if (line_item[0] == '#')
            {
                continue;
            }

            line_len = strlen(line_item);
            if (line_len < 2)
            {
                break;
            }

            line_item[line_len-1] = '\0';
            memset(ip_str, '\0', sizeof(ip_str));
            iRet = sscanf(line_item, "%hd %s %hhd %s\n",
                    &nat_item_tmp.id, ip_str,
                    &nat_item_tmp.action, nat_item_tmp.describe);
            if (iRet != 4)
            {
                continue;
            }
            nat_item_tmp.ip = inet_network(ip_str);
            nat_item_tmp.type = NAT_MANUAL_ADD;
            if (g_nat_policy_index <= nat_item_tmp.id)
            {
                g_nat_policy_index = nat_item_tmp.id;
            }
            nac_app_nat_add(&nat_item_tmp);
        }
        memset(line_item, '\0', BUFF_LEN);
    }
    fclose(nac_read_fp);
    return HUPU_OK;
}

static HUPU_INT32 nac_sys_read_nat_manage_conf(const HUPU_CHAR* filename)
{
    HUPU_INT32 iRet,line_len;
    FILE *nac_read_fp;
    /*0:no match;1:match;*/
    HUPU_UINT16 match_flag = 0;
    HUPU_CHAR line_item[BUFF_LEN] = "";
    HUPU_CHAR nat_switch_tmp = -1;

    if ((nac_read_fp = fopen(filename, "r")) == NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->read open %s error\n", __FUNCTION__, filename);
        return HUPU_ERR;
    }

    while((fgets(line_item, BUFF_LEN, nac_read_fp)) != NULL)
    {
        if (match_flag == 0)
        {
            if (strstr(line_item, "nat_manage") != NULL)
            {
                match_flag = 1;
            }
        }
        else
        {
            if (line_item[0] == '#')
            {
                continue;
            }

            line_len = strlen(line_item);
            if (line_len < 2)
            {
                break;
            }

            line_item[line_len-1] = '\0';
            iRet = sscanf(line_item, "%hhd %hhd %hd\n",
                    &nat_switch_tmp, &g_nat_config_st.auto_found,
                    &g_nat_config_st.default_action);
            if (iRet != 3)
            {
                continue;
            }
            else
            {
                nac_system_deal_nat_manage_switch(nat_switch_tmp);
                nac_app_set_auto_nat_found(g_nat_config_st.auto_found);
                break;
            }
       }
        memset(line_item, '\0', BUFF_LEN);
    }
    fclose(nac_read_fp);
    return HUPU_OK;
}

/*
 * if you cannot want to reboot for read nac_sys.conf,
 * you must excute nac_app_flush_all_system_config before.
*/

HUPU_INT32 nac_app_read_sys_config_from_file(const HUPU_CHAR* config_file, HUPU_UINT8 flag)
{
    HUPU_INT32 iRet;
    if (flag == 0)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin ifconfig\n", __FUNCTION__);
        iRet = nac_sys_init_ifconfig_config(config_file);
        nac_update_escape_check_event();
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end ifconfig\n", __FUNCTION__);


        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin default_gateway\n", __FUNCTION__);
        nac_sys_init_default_gateway_config(config_file);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end default_gateway\n", __FUNCTION__);
	}

    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin nameserver\n", __FUNCTION__);
    nac_sys_init_nameserver_config(config_file);
    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end nameserver\n", __FUNCTION__);

	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin asc_access_mode\n", __FUNCTION__);
    nac_sys_get_access_mode_from_configure(config_file);
    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   asc_access_mode\n", __FUNCTION__);

    if (flag == 0)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin redirect_url\n", __FUNCTION__);
        nac_sys_get_redirect_config_from_configure(config_file);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end redirect_url\n", __FUNCTION__);
    }

	if (asc_access_mode == NAC_MVG_MODE)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin vlanmap\n", __FUNCTION__);
    	nac_sys_init_vlanmap_config(config_file);
    	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end vlanmap\n", __FUNCTION__);

	}
	else if (asc_access_mode == NAC_PBR_MODE)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin pbr advance setup\n", __FUNCTION__);
		nac_sys_init_pbr_advance_setup_config(config_file);
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end pbr advance setup\n", __FUNCTION__);
	}

	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin arp_monitor\n", __FUNCTION__);
	nac_sys_init_arp_monitor_config(config_file);
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   arp_monitor\n", __FUNCTION__);

	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin ntpdate_server\n", __FUNCTION__);
	nac_sys_init_ntpdate_server_config(config_file);
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   ntpdate_server\n", __FUNCTION__);

    if (flag == 0)
	{
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin asc_enable_flag\n", __FUNCTION__);
	    nac_sys_init_asc_enable_flag_config(config_file);
	    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   asc_enable_flag\n", __FUNCTION__);

	    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin asc_escape_flag\n", __FUNCTION__);
	    //nac_sys_init_asc_escape_flag_config(config_file);
	    nac_sys_get_escape_config_from_configure(config_file);
	    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   asc_escape_flag\n", __FUNCTION__);
    }

	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin iprange policy\n", __FUNCTION__);
	nac_sys_init_iprange_policy_config(config_file);
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end iprange policy\n", __FUNCTION__);

	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin domain policy\n", __FUNCTION__);
	nac_sys_init_domain_policy_config(config_file);
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end domain policy\n", __FUNCTION__);

	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin netapp check\n", __FUNCTION__);
	nac_sys_read_netapp_config(config_file);
	nac_sys_read_netapp_except_list(config_file);
    nac_sys_set_enable_netapp_config(tmp_netapp_enable_id);
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   netapp check\n", __FUNCTION__);

	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin nat_manage check\n", __FUNCTION__);
    nac_sys_read_nat_manage_list(config_file);
    nac_sys_read_nat_manage_conf(config_file);
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   net_manage check\n", __FUNCTION__);
    get_exceptapp_data_form_configure(config_file);
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   except app\n", __FUNCTION__);
	nac_sys_get_dhcp_manage_data_form_configure(config_file);
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   dhcp manage\n", __FUNCTION__);

    nac_sys_get_except_mac_data_form_configure(config_file);
    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   except app\n", __FUNCTION__);

    nac_sys_get_os_check_swit_from_configure(config_file);
    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   os_check_swit_config\n", __FUNCTION__);

    if (flag == 0)
    {
        nac_sys_get_ha_backup_config_form_configure(config_file);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->end   ha_backup config\n", __FUNCTION__);
    }

    return HUPU_OK;
}
