#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_net.h"
#include "nac_system_redirect_manager_ip.h"
#include "nac_system_set_remote_server.h"
#include "nac_system_deal_license.h"
#include "nac_system_deal_sysconfig.h"
#include "nac_system_save_sysconfig.h"
#include "nac_system_redis_subscribe.h"
#include "nac_system_ha_backup.h"

pthread_t sync_pthread_id = 0;
NAC_HA_BACKUP_CONFIG gst_ha_backup_config;

HUPU_INT32 ha_backup_load_my_sync_config(HUPU_VOID);
HUPU_INT32 ha_backup_load_sys_config(HUPU_VOID);
HUPU_INT32 ha_backup_load_knl_online_user(HUPU_VOID);
HUPU_INT32 ha_backup_sync_knl_timeout_user(NAC_SYS_USER *user);
HUPU_INT32 ha_backup_load_vtl_mac(NAC_HA_BACKUP_CONFIG *pst_config);
HUPU_INT32 nac_system_ha_backup_on_or_off(NAC_HA_BACKUP_CONFIG* ha_config);
HUPU_INT32 nac_system_read_ha_backup_config(NAC_HA_BACKUP_CONFIG* ha_config);
HUPU_INT32 ha_backup_enable_mysql_sync_config(HUPU_UINT16 status, NAC_HA_BACKUP_CONFIG *pst_config);


HUPU_VOID nac_app_debug_ha_backup_config(NAC_HA_BACKUP_CONFIG *pst_config, FILE *fp)
{
    HUPU_CHAR state_buf[32] = "";
    fputs("ha_backup config---------------------\n", fp);
    fprintf(fp, "ha_switch = %s\n", (pst_config->ha_switch == 1)?("enable"):("disable"));
    fprintf(fp, "ha_priority = %hd\n", pst_config->priority);
    if ( pst_config->init_status == HA_MASTER_MODE )
    {
        strcpy(state_buf, "master");
    }
    else if ( pst_config->init_status == HA_BACKUP_MODE )
    {
        strcpy(state_buf, "backup");
    }
    else
    {
        strcpy(state_buf, "null");
    }
    fprintf(fp, "init_status = %s\n", state_buf);

    memset(state_buf, '\0', strlen(state_buf));
    switch(pst_config->run_status)
    {
        case HA_FAULT_STATUS:
            strcpy(state_buf, "fault");
            break;
        case HA_BACKUP_STATUS:
            strcpy(state_buf, "backup");
            break;
        case HA_MASTER_STATUS:
            strcpy(state_buf, "master");
            break;
        default:
            strcpy(state_buf, "null");
            break;
    }
    fprintf(fp, "run_status = %s\n", state_buf);

    memset(state_buf, '\0', strlen(state_buf));
    switch(pst_config->sync_status)
    {
        case HA_SYNC_START:
            strcpy(state_buf, "start");
            break;
        case HA_SYNC_FINISH:
            strcpy(state_buf, "finish");
            break;
        case HA_SYNC_LOCK:
            strcpy(state_buf, "lock");
            break;
        case HA_SYNC_UNLOCK:
            strcpy(state_buf, "unlock");
            break;
        default:
            strcpy(state_buf, "null");
            break;
    }
    fprintf(fp, "sync_status = %s\n", state_buf);

    fprintf(fp, "ha_eth = %s\n", pst_config->ha_eth);
    fprintf(fp, "local_mac = %02X-%02X-%02X-%02X-%02X-%02X\n", MAC_FORMAT_2(pst_config->local_mac));
    fprintf(fp, "vtl_mac = %02X-%02X-%02X-%02X-%02X-%02X\n", MAC_FORMAT_2(pst_config->vtl_mac));
    fprintf(fp, "local_ha_addr = %u.%u.%u.%u--%u.%u.%u.%u\n",
            LIPQUAD(pst_config->local_ha_addr.ipaddr),
            LIPQUAD(pst_config->local_ha_addr.netmask));

   fprintf(fp, "other_ha_addr = %u.%u.%u.%u--%u.%u.%u.%u\n",
            LIPQUAD(pst_config->other_ha_addr.ipaddr),
            LIPQUAD(pst_config->other_ha_addr.netmask));

   fprintf(fp, "vip_addr = %u.%u.%u.%u--%u.%u.%u.%u\n",
            LIPQUAD(pst_config->vip_addr.ipaddr),
            LIPQUAD(pst_config->vip_addr.netmask));
   fputs("end----------------------------------\n", fp);
   return;
}

//write except_mac data to config file
HUPU_INT32 nac_sys_write_ha_backup_config_to_configure(FILE* fp)
{
    HUPU_CHAR content[1024*10] = {0};
    HUPU_CHAR buffer[512]={0};
    strcat(content, "ha_backup_config\n{\n");
    sprintf(buffer,"    enable=%d\n", gst_ha_backup_config.ha_switch);
    strcat(content, buffer);
    sprintf(buffer,"    other_ha=%u.%u.%u.%u;%u.%u.%u.%u\n",
            LIPQUAD(gst_ha_backup_config.other_ha_addr.ipaddr),
            LIPQUAD(gst_ha_backup_config.other_ha_addr.netmask));
    strcat(content, buffer);
    strcat(content, "}\n\n");
    fprintf(fp, "%s", content);
    return 0;
}

HUPU_INT32 nac_sys_get_ha_backup_config_form_configure(const HUPU_CHAR *file_path)
{
    HUPU_INT32 iRet;
    HUPU_CHAR buffer[1024*1024] = {0};
    HUPU_CHAR content[1024*10] = {0};
    HUPU_CHAR ip_str[2][16];
    HUPU_INT32 fd = 0;
    HUPU_CHAR  *p_value = NULL;

    fd = open(file_path, O_RDONLY);
    read(fd, buffer, 1024*1024);
    close(fd);

    memset(content, 0, sizeof(content));
    if(get_content(buffer, content, "ha_backup_config") < 0)
    {
        goto GO_EXIT;
    }

    p_value = each_line_search(content, "enable");
    gst_ha_backup_config.ha_switch = atoi(p_value);

    p_value = each_line_search(content, "other_ha");
    if (strlen(p_value))
    {
        memset(ip_str, '\0', sizeof(ip_str));
        iRet = sscanf(p_value, "%[^;];%s", ip_str[0], ip_str[1]);
        if (iRet == 2)
        {
            struct in_addr in_ip, in_netmask;
            if(inet_aton(ip_str[0], &in_ip))
            {
                gst_ha_backup_config.other_ha_addr.ipaddr= ntohl(in_ip.s_addr);
            }

            if(inet_aton(ip_str[1], &in_netmask))
            {
                gst_ha_backup_config.other_ha_addr.netmask= ntohl(in_netmask.s_addr);
            }

        }
    }
    nac_system_ha_backup_on_or_off(&gst_ha_backup_config);

    return 0;
    GO_EXIT:
        return -1;
}

static HUPU_UINT32 convert_ipv4_netmask(HUPU_UINT8 count)
{
    HUPU_UINT32 mask = 0x00000000;
    HUPU_UINT32 bit_flag = 0x80000000;
    HUPU_UINT32 i;

    for (i = 0; i < count;  i++)
    {
        mask = mask | bit_flag;
        bit_flag = bit_flag >> 1;
    }

    return mask;
}

static HUPU_UINT32 convert_count_netmask(HUPU_UINT32 ip)
{
    HUPU_INT32 cnt = 0;
    HUPU_UINT32 bit_flag = 0x80000000;
    while((ip&bit_flag) == bit_flag)
    {
        cnt++;
        if (cnt == 32)
        {
            break;
        }
        bit_flag = bit_flag>>1;
    }
    return cnt;
}

int nac_get_popen_result(char* get_option_cmd, char* result)
{
    int i, len;
    FILE *popen_fp;
    char szLine[256] = "";

    popen_fp = popen(get_option_cmd, "r");
    if (popen_fp == NULL)
    {
        return -1;
    }

    if (fgets(szLine, 256, popen_fp) != NULL)
    {
    	SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS, "szLine=%s\n", szLine);
        len = strlen(szLine);
		if (szLine[len-1] == '\n')
		{
			szLine[len-1] = '\0';
		}

        i = 0;
        while(szLine[i] == '\t' && i < len)
        {
            i++;
        }

        memcpy(result, &szLine[i], (len-i));
        SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS, "result=%s\n", result);
    }

    fclose(popen_fp);
    return 0;
}

HUPU_INT32 nac_close_ha_backup_process(HUPU_VOID)
{
    HUPU_INT32 iRet;
    nac_exec_system("rm -rf /bak/ha_sync/*");
    iRet = nac_exec_system("killall -15 net_ha >/dev/null 2>&1");
    return iRet;
}

HUPU_INT32 nac_restart_ha_backup_process(HUPU_VOID)
{
    HUPU_INT32 iRet;
    iRet = nac_exec_system("killall -15 net_ha >/dev/null 2>&1");
    nac_exec_system("> /var/log/ha_status");
    iRet = nac_exec_system("/nac/bin/net_ha -f /nac/config/nac_ha.conf >/dev/null 2>&1");
    return iRet;
}

/*ip addr del 10.10.2.158/24 dev eth0*/
HUPU_INT32 rmv_manager_virtual_ip(HUPU_VOID)
{
    HUPU_INT32 iRet = 0;
    HUPU_CHAR *get_manager_addr = "/bin/sed -n '/^.*dev.*$/p' /nac/config/nac_ha.conf";
    HUPU_CHAR buffer[120];
    HUPU_CHAR cmd[160];

    memset(buffer, 0, sizeof(buffer));
    iRet = nac_get_popen_result(get_manager_addr, buffer);
    if (iRet == HUPU_OK)
    {
        memset(cmd, 0, sizeof(cmd));
        snprintf(cmd, sizeof(cmd), "ip addr del %s >/dev/null 2>&1", buffer);
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "cmd=%s\n", cmd);
        nac_exec_system(cmd);
    }

    return HUPU_OK;
}

HUPU_INT32 nac_system_init_ha_backup(HUPU_VOID)
{
    HUPU_INT32 iRet;
    memset(&gst_ha_backup_config, '\0', sizeof(gst_ha_backup_config));
    gst_ha_backup_config.ha_switch  = 0;
    gst_ha_backup_config.init_status= 0;
    gst_ha_backup_config.run_status = 0;
    gst_ha_backup_config.sync_status= 0;

    nac_system_read_ha_backup_config(&gst_ha_backup_config);

    iRet = nac_app_get_special_ifindex("ha");
    memcpy(gst_ha_backup_config.ha_eth, nac_sys_ifname[iRet], strlen(nac_sys_ifname[iRet]));
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s\n", gst_ha_backup_config.ha_eth);

    gst_ha_backup_config.local_ha_addr.ipaddr  = inet_network(g_nac_net_device[iRet].if_ip);
    gst_ha_backup_config.local_ha_addr.netmask = inet_network(g_nac_net_device[iRet].if_mask);
    iRet = nac_app_get_eth0_ifindex();
    nac_get_netdev_mac(nac_sys_ifname[iRet], gst_ha_backup_config.local_mac, ETH_ALEN);
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%02x-%02x-%02x-%02x-%02x-%02x\n",
                        MAC_FORMAT(gst_ha_backup_config.local_mac));
    return HUPU_OK;
}

HUPU_INT32 nac_system_modify_asc_knl_device_id(HUPU_CHAR* mac)
{
    HUPU_INT32 iRet;
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "mac=%02x-%02x-%02x-%02x-%02x-%02x\n", MAC_FORMAT_2(mac));
    iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_ETH0_MAC, 0, mac, ETH_ALEN);
    if (iRet != HUPU_OK)
    {
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "set device_id eth0_mac to knl error\n");
    }
    return HUPU_OK;
}

HUPU_INT32 nac_system_modify_ruby_switch_device_id(HUPU_CHAR* mac)
{
    memset(g_manager_mac_addr, '\0', ETH_ALEN);
    memcpy(g_manager_mac_addr, mac, ETH_ALEN);
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "mac=%02x-%02x-%02x-%02x-%02x-%02x\n", MAC_FORMAT(g_manager_mac_addr));
    nac_sys_send_ruby_switch_usr1();
    return HUPU_OK;
}

/*tcp sync master dynamic config to backup*/
static HUPU_INT32 backup_send_msg_to_master(NAC_WEB_MSG* pst_msg, HUPU_UINT32 ip_addr)
{
    HUPU_INT32 iRet;
    fd_set      readfd;
    struct timeval  st_timeout;
    HUPU_INT32  recv_len;
    HUPU_CHAR   ac_buffer_recv[1024*10];
    HUPU_UINT32 ui_ha_master_fd = 0;
    HUPU_UINT32 config_msg_len;
    ui_ha_master_fd = nac_tcp_crt_cli();
    if (ui_ha_master_fd == HUPU_ERR)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "create tcp client error!\n");
        goto EXIT_FUNC;
    }

    iRet = nac_tcp_connect(ui_ha_master_fd, ip_addr, NAC_APP_SERVER_LISTEN_PORT);
    if (iRet < 0)
    {
        if (errno == EINPROGRESS)
        {
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "tcp connect timeout\n");
        }
        goto EXIT_FUNC_1;
    }
    config_msg_len = pst_msg->ui_len + sizeof(NAC_WEB_MSG);
    iRet = nac_tcp_sendto(ui_ha_master_fd, (HUPU_CHAR*)pst_msg, config_msg_len);
    if (iRet != config_msg_len)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_tcp_sendto error!\n");
        goto EXIT_FUNC_1;
    }

    st_timeout.tv_sec  = 5;
    st_timeout.tv_usec = 0;
    FD_ZERO(&readfd);
    FD_SET(ui_ha_master_fd, &readfd);
    iRet = select(ui_ha_master_fd + 1,
                &readfd,
                HUPU_NULL,
                HUPU_NULL,
                &st_timeout);
    if (iRet <= HUPU_ERR)
    {
        /*
        if (errno == EINTR)
        {
            continue;
        }
        */
        goto EXIT_FUNC_1;
    }
    else if (iRet == HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "select timeout!\n");
        goto EXIT_FUNC_1;
    }

    if (FD_ISSET(ui_ha_master_fd, &readfd) > 0)
    {
        memset(ac_buffer_recv, '\0', sizeof(ac_buffer_recv));
        iRet = nac_tcp_recvfrom(ui_ha_master_fd, ac_buffer_recv, sizeof(ac_buffer_recv));
        if (iRet <= 0)
        {
                SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ui_ha_master_fd read error!\n");
        }
        else
        {
            recv_len = iRet;
            NAC_WEB_MSG *pst_sock_msg = (NAC_WEB_MSG*)ac_buffer_recv;
            if (pst_sock_msg->us_cmd == (SYS_WEBUI_HA_BACKUP_SYNC + 1))
            {
                if (strstr(pst_sock_msg->ac_buf, "sync_try_ok") != HUPU_NULL)
                {
                    gst_ha_backup_config.sync_status = HA_SYNC_START;
                }
                /*
                else if (strstr(pst_sock_msg->ac_buf, "sync_finish") != HUPU_NULL)
                {
                    gst_ha_backup_config.sync_status = HA_SYNC_START;
                }
                */

            }
            SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS, "backup_host_ret_msg:recv_len=%d=%d=%d=%s\n",
                            recv_len, pst_sock_msg->us_cmd, pst_sock_msg->ui_len, pst_sock_msg->ac_buf);
        }
    }

EXIT_FUNC_1:
    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_tcp_destroy--ui_ha_master_fd=%d\n", ui_ha_master_fd);
    nac_tcp_destroy(ui_ha_master_fd);
EXIT_FUNC:
    return HUPU_OK;
}

HUPU_INT32 ha_backup_sync_static_config(NAC_HA_BACKUP_CONFIG *pst_config)
{
    HUPU_INT32 iRet;
    HUPU_CHAR exec_cmd[512];
    HUPU_CHAR *scp_sync_config_cmd =
            "/nac/bin/sshpass -p imanupdate scp -o StrictHostKeyChecking=no -p nacupdate@%u.%u.%u.%u:/bak/ha_sync/*  /bak/ha_sync >/dev/null 2>&1";
    memset(exec_cmd, '\0', sizeof(exec_cmd));
    sprintf(exec_cmd, scp_sync_config_cmd, LIPQUAD(pst_config->other_ha_addr.ipaddr));
    iRet = nac_exec_system(exec_cmd);
    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s--%d\n", exec_cmd, iRet);
    if (iRet != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ha_backup sync static_config fault!\n");
        return HUPU_ERR;
    }

    HUPU_UINT16 flag_tmp;
    nac_sys_get_knl_pass_switch(&flag_tmp);
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "flag_tmp=%d\n", flag_tmp);
    /*--dobetter--clean the backup knl config*/
    nac_app_flush_all_system_config();
    ha_backup_load_sys_config();
    ha_backup_load_knl_online_user();

    //ha_backup_load_my_sync_config();
    ha_backup_enable_mysql_sync_config(HA_BACKUP_STATUS, pst_config);

    //nac_exec_system("rm -rf /bak/ha_sync/*");
    ha_backup_load_vtl_mac(pst_config);
    nac_system_modify_asc_knl_device_id(pst_config->vtl_mac);
    nac_system_modify_ruby_switch_device_id(pst_config->vtl_mac);
    nac_system_destroy_tcp_long_sockfd();
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
            "ac_redirect_ip=%s-->control_manager_ip=%s-->server_manager_ip=%s\n",
            gst_redirect_manager_ip.ac_redirect_ip,
            gst_redirect_manager_ip.ac_control_manager_ip,
            gst_redirect_manager_ip.ac_server_manager_ip);
   /*
   HUPU_CHAR ip_str[16] = "";
   sprintf(ip_str, "%u.%u.%u.%u", LIPQUAD(pst_config->vip_addr.ipaddr));
   nac_sys_set_redirect_ip(ip_str);
   */

   nac_sys_get_knl_pass_switch(&flag_tmp);
   SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "flag_tmp=%d\n", flag_tmp);

   pst_config->sync_status = HA_SYNC_FINISH;
   return HUPU_OK;
}

HUPU_INT32 ha_backup_send_master_sync_msg(NAC_HA_BACKUP_CONFIG *pst_config, HUPU_CHAR *msg)
{
    HA_SYNC_MSG st_msg;
    HUPU_UINT32 master_ha_addr;
    memset(&st_msg, '\0', sizeof(HA_SYNC_MSG));
    st_msg.us_cmd = SYS_WEBUI_HA_BACKUP_SYNC + 1;
    st_msg.reserve = 0;
    st_msg.ui_len  = sizeof(HUPU_UINT32) + 18;
    st_msg.ip_addr = pst_config->local_ha_addr.ipaddr;
    memcpy(st_msg.sync_msg, msg, strlen(msg));//?????????????????
    master_ha_addr = pst_config->other_ha_addr.ipaddr;

    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "len=%d--msg=%s--status=%d\n",
                      st_msg.ui_len, st_msg.sync_msg, pst_config->sync_status);

    backup_send_msg_to_master((NAC_WEB_MSG*)&st_msg, master_ha_addr);

    return HUPU_OK;
}

/*(139+1)+0+msg_len+msg(local_ha_addr+sync_msg)*/
HUPU_VOID* ha_backup_sync_master_config_thread(HUPU_VOID *argv)
{
    HUPU_INT32 iRet;
    pthread_detach(pthread_self());
    while (1)
    {
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "run_status=%d--sync_status=%d\n",
                            gst_ha_backup_config.run_status, gst_ha_backup_config.sync_status);

        if (gst_ha_backup_config.run_status == HA_BACKUP_STATUS
             && gst_ha_backup_config.sync_status < HA_SYNC_FINISH)
        {

            ha_backup_send_master_sync_msg(&gst_ha_backup_config, "sync_try");
            if (gst_ha_backup_config.sync_status == HA_SYNC_START)
            {
                iRet = ha_backup_sync_static_config(&gst_ha_backup_config);
                if (iRet == HUPU_OK)
                {
                    gst_ha_backup_config.sync_status = HA_SYNC_FINISH;
                    ha_backup_send_master_sync_msg(&gst_ha_backup_config, "sync_finish");
                    //goto THREAD_EXIT;
                }
                else
                {
                    gst_ha_backup_config.sync_status = HA_SYNC_NULL;
                }
            }
        }
        sleep(20);
    }
    //THREAD_EXIT:
    return HUPU_NULL;
}

HUPU_INT32 nac_system_ha_deal_sync_msg(NAC_WEB_MSG* pst_web_msg, HUPU_INT32 sock_fd)
{
    HUPU_INT32 iRet;
    NAC_WEB_MSG *pst_msg;
    HUPU_CHAR sz_msg[160];
    HUPU_UINT32 msg_len;
    HUPU_CHAR sync_result[120];
    memset(sync_result, '\0', sizeof(sync_result));
    HA_SYNC_MSG* pst_sync_msg = (HA_SYNC_MSG*)pst_web_msg;
    HUPU_CHAR exec_cmd[512];

    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
                    "len=%d-->msg=%s-->%u.%u.%u.%u\n",
                    pst_sync_msg->ui_len, pst_sync_msg->sync_msg,
                    LIPQUAD(pst_sync_msg->ip_addr));
    if (strstr(pst_sync_msg->sync_msg, "sync_try") != HUPU_NULL)
    {
        if (gst_ha_backup_config.run_status == HA_MASTER_STATUS
            && pst_sync_msg->ip_addr == gst_ha_backup_config.other_ha_addr.ipaddr)
        {
            memcpy(sync_result, "sync_try_ok", strlen("sync_try_ok"));
            gst_ha_backup_config.sync_status = HA_SYNC_LOCK;

            nac_exec_system("rm -rf /bak/ha_sync/*");
            nac_app_save_sys_config_to_file("/nac/config/nac_sys.conf");
            nac_exec_system("/bin/cp -f /nac/config/nac_sys.conf /bak/ha_sync");
            nac_exec_system("/bin/cp -f /proc/nac/nac_knl_user_online /bak/ha_sync");

            memset(exec_cmd, '\0', sizeof(exec_cmd));
            sprintf(exec_cmd, "echo \"vtl_mac=%02X-%02X-%02X-%02X-%02X-%02X\">/bak/ha_sync/vtl_mac.conf",
                    MAC_FORMAT(gst_ha_backup_config.vtl_mac));
            nac_exec_system(exec_cmd);

            ha_backup_enable_mysql_sync_config(HA_MASTER_STATUS, &gst_ha_backup_config);
            // begin copy all master static to /bak/ha_sync
        }
        else
        {
            memcpy(sync_result, "sync_error", strlen("sync_error"));
        }

   }else if (strstr(pst_sync_msg->sync_msg, "sync_finish") != HUPU_NULL)
   {
        gst_ha_backup_config.sync_status = HA_SYNC_UNLOCK;
        memcpy(sync_result, "sync_ok", strlen("sync_ok"));
   }
   else
   {
        memcpy(sync_result, "sync_error", strlen("sync_error"));
   }

    memset(sz_msg, '\0', sizeof(sz_msg));
    pst_msg = (NAC_WEB_MSG*)sz_msg;
    pst_msg->us_cmd = pst_sync_msg->us_cmd;
    pst_msg->reserve = 0;
    pst_msg->ui_len  = strlen(sync_result);
    memcpy(pst_msg->ac_buf, sync_result, strlen(sync_result));
    msg_len = pst_msg->ui_len + sizeof(NAC_WEB_MSG);

    iRet = nac_tcp_sendto(sock_fd, (HUPU_CHAR*)pst_msg, msg_len);
    if (iRet != msg_len)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_tcp_sendto error!\n");
    }

    return HUPU_OK;
}

HUPU_INT32 nac_system_read_ha_backup_config(NAC_HA_BACKUP_CONFIG* ha_config)
{
    HUPU_CHAR   ip_str[16]   = "";
    HUPU_CHAR   mask_cnt[4]  = "";
    HUPU_CHAR   get_result[240]  = "";
    HUPU_CHAR   get_conf_cmd[256] = "";
    HUPU_CHAR*  ha_config_path  = "/nac/config/nac_ha.conf";
    HUPU_CHAR*  ha_status_cmd   = "/bin/sed -n '/state/'p %s";
    HUPU_CHAR*  ha_vip_cmd      = "/bin/sed -n '/dev/p' %s";
    HUPU_CHAR*  ha_get_priority = "/bin/sed -n '/priority/p' %s | awk '{print $2}'";

    if (access(ha_config_path, F_OK) != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s is unexist\n", ha_config_path);
        return HUPU_ERR;
    }

    sprintf(get_conf_cmd, ha_status_cmd, ha_config_path);
    nac_get_popen_result(get_conf_cmd, get_result);
    if (strlen(get_result))
    {
        if (strstr(get_result, "MASTER") != HUPU_NULL)
        {
            ha_config->init_status = HA_MASTER_MODE;
        }
        else if (strstr(get_result, "BACKUP") != HUPU_NULL)
        {
            ha_config->init_status = HA_BACKUP_MODE;
        }
    }

    memset(get_result, '\0', sizeof(get_result));
    memset(get_conf_cmd, '\0', sizeof(get_conf_cmd));
    sprintf(get_conf_cmd, ha_get_priority, ha_config_path);
    nac_get_popen_result(get_conf_cmd, get_result);
    if (strlen(get_result))
    {
        ha_config->priority = atoi(get_result);
    }

    memset(get_result, '\0', sizeof(get_result));
    memset(get_conf_cmd, '\0', sizeof(get_conf_cmd));
    sprintf(get_conf_cmd, ha_vip_cmd, ha_config_path);
    nac_get_popen_result(get_conf_cmd, get_result);
    if (strlen(get_result))
    {
        memset(get_conf_cmd, '\0', sizeof(get_conf_cmd));
        sscanf(get_result, "%s %*s %*s", get_conf_cmd);
        if (strlen(get_conf_cmd))
        {
            sscanf(get_conf_cmd, "%[^/]/%s", ip_str, mask_cnt);
            ha_config->vip_addr.ipaddr  = inet_network(ip_str);
            ha_config->vip_addr.netmask = convert_ipv4_netmask(atoi(mask_cnt));
        }
    }
    return HUPU_OK;
}

/*if ha or manager have change, must call this and restart net_ha*/
HUPU_INT32 nac_system_update_ha_backup_config(HUPU_CHAR* key, HUPU_CHAR* value)
{
    //HUPU_INT32 iRet;
    HUPU_CHAR  update_conf_cmd[256];
    HUPU_CHAR* ha_config_path = "/nac/config/nac_ha.conf";
    HUPU_CHAR* ha_interface = "/bin/sed -i 's/^\tinterface.*$/\tinterface %s/' %s";
    HUPU_CHAR* ha_track_interface = "/bin/sed -i 's/^\teth.*$/\t%s/' %s";
    HUPU_CHAR* ha_virtual_ipaddress = "/bin/sed -i 's/^.*dev.*$/\t%u.%u.%u.%u\\/%d dev %s/' %s";

    if (access(ha_config_path, F_OK) != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s is unexist\n", ha_config_path);
        return HUPU_ERR;
    }

    if (strcmp(key, "ha_interface") == HUPU_OK)
    {
        memset(update_conf_cmd, '\0', sizeof(update_conf_cmd));
        sprintf(update_conf_cmd, ha_interface, value, ha_config_path);
        nac_exec_system(update_conf_cmd);
    }
    else if (strcmp(key, "manager_interface") == HUPU_OK)
    {
        memset(update_conf_cmd, '\0', sizeof(update_conf_cmd));
        sprintf(update_conf_cmd, ha_track_interface, value, ha_config_path);
        nac_exec_system(update_conf_cmd);

        memset(update_conf_cmd, '\0', sizeof(update_conf_cmd));
        sprintf(update_conf_cmd, ha_virtual_ipaddress,
                LIPQUAD(gst_ha_backup_config.vip_addr.ipaddr),
                convert_count_netmask(gst_ha_backup_config.vip_addr.netmask),
                value, ha_config_path);
        nac_exec_system(update_conf_cmd);
    }

    if (gst_ha_backup_config.ha_switch == HA_ENABLE)
    {
        nac_restart_ha_backup_process();
    }

    return HUPU_OK;
}

HUPU_INT32 nac_system_ha_backup_on_or_off(NAC_HA_BACKUP_CONFIG* ha_config)
{
    HUPU_INT32 iRet = 0;
    if (ha_config->ha_switch == HA_ENABLE)
    {
        iRet = nac_restart_ha_backup_process();
        HUPU_CHAR ip_str[16] = "";
        //set ha_vip instead of redirect_ip;
        sprintf(ip_str, "%u.%u.%u.%u", LIPQUAD(gst_ha_backup_config.vip_addr.ipaddr));
        nac_sys_set_redirect_ip(ip_str);

        if (sync_pthread_id == 0)
        {
            iRet = pthread_create(&sync_pthread_id, NULL, ha_backup_sync_master_config_thread, "ha_backup");
            if (iRet != HUPU_OK)
            {
                SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ha_backup_sync_master_config_thread fail\n");
            }
        }
    }
    else
    {
        iRet = nac_close_ha_backup_process();
        ha_config->run_status  = HA_NULL_STATUS;
        ha_config->sync_status = HA_SYNC_NULL;

        if (sync_pthread_id)
        {
            //pthread_kill(sync_pthread_id, SIGQUIT);
            iRet = pthread_cancel(sync_pthread_id);
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "sync_pthread_id=%u--iRet=%d!\n", sync_pthread_id, iRet);
            sync_pthread_id = 0;
        }

        //asc enable
        nac_exec_system("echo 0 > /proc/sys/net/nac_knl_pass_switch_flags");

        //ha default all forward;
        nac_exec_system("echo 0 > /proc/sys/net/nac_knl_switch_flags");

        //recover manage_ip
        iRet = nac_app_get_special_ifindex("manage");
        nac_sys_set_redirect_ip(g_nac_net_device[iRet].if_ip);

        //recover device_id
        nac_system_modify_asc_knl_device_id(ha_config->local_mac);
        nac_system_modify_ruby_switch_device_id(ha_config->local_mac);

        //recover my.cnf
        ha_backup_enable_mysql_sync_config(HA_NULL_STATUS, NULL);
        nac_system_destroy_tcp_long_sockfd();
    }
    nac_app_save_sys_config_to_file(nac_sys_cfg_file);
    //for monitor platform
    send_redis_pub_command("ha_status");
    return iRet;
}

HUPU_INT32 nac_system_save_ha_backup_config(NAC_HA_BACKUP_CONFIG *ha_config)
{
    HUPU_INT32 iRet;
    HUPU_CHAR  exec_cmd[256];
    HUPU_CHAR* ha_config_path = "/nac/config/nac_ha.conf";
    HUPU_CHAR* ha_priority_cmd = "/bin/sed -i 's/^.*priority.*$/\tpriority %d/' %s";
    HUPU_CHAR* ha_track_interface = "/bin/sed -i 's/^\teth.*$/\t%s/' %s";
    HUPU_CHAR* ha_vip_cmd = "/bin/sed -i 's/^.*dev.*$/\t%u.%u.%u.%u\\/%d dev %s/' %s";
    //HUPU_CHAR* ha_status_cmd = "/bin/sed -i 's/^\tstate.*$/\tstate %s/' %s";

    iRet = 0;
    if (access(ha_config_path, F_OK) != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s is unexist\n", ha_config_path);
        iRet = HUPU_ERR;
        goto FUNC_EXIT;
    }

    memset(exec_cmd, '\0', sizeof(exec_cmd));
    sprintf(exec_cmd, ha_priority_cmd, ha_config->priority, ha_config_path);
    nac_exec_system(exec_cmd);

    iRet = nac_app_get_special_ifindex("manager");
    memset(exec_cmd, '\0', sizeof(exec_cmd));
    sprintf(exec_cmd, ha_track_interface, nac_sys_ifname[iRet], ha_config_path);
    nac_exec_system(exec_cmd);

    //update the vip must clean the old
    rmv_manager_virtual_ip();
    memset(exec_cmd, '\0', sizeof(exec_cmd));
    sprintf(exec_cmd, ha_vip_cmd, LIPQUAD(ha_config->vip_addr.ipaddr),
            convert_count_netmask(ha_config->vip_addr.netmask),
            nac_sys_ifname[iRet], ha_config_path);
    nac_exec_system(exec_cmd);

    FUNC_EXIT:
        return iRet;
}

static xmlDocPtr nac_system_get_ha_backup_config(HUPU_UINT16 cmd_id)
{
    HUPU_INT32 iRet = 0;
    xmlDocPtr  doc;
    xmlNodePtr root_node;
    HUPU_CHAR xml_min_cnt[MIN_BUFF_LEN] = "";
    HUPU_CHAR xml_max_cnt[SMALL_BUFF_LEN] = "";

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    sprintf(xml_min_cnt, "%d", (cmd_id + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST xml_min_cnt);

    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");

    memset(xml_min_cnt, '\0', sizeof(xml_min_cnt));
    sprintf(xml_min_cnt, "%d", gst_ha_backup_config.ha_switch);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "haSwitch", BAD_CAST xml_min_cnt);

    memset(xml_min_cnt, '\0', sizeof(xml_min_cnt));
    sprintf(xml_min_cnt, "%d", gst_ha_backup_config.run_status);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "runStatus", BAD_CAST xml_min_cnt);

    HUPU_INT16 status = HA_SYNC_NULL;
    iRet = nac_app_get_netdev_enable_link_status(gst_ha_backup_config.ha_eth);
    if (iRet == HUPU_ENABLE)
    {
        if (gst_ha_backup_config.sync_status >= HA_SYNC_START)
        {
            status = HA_SYNC_START;
        }
    }
    else
    {
        gst_ha_backup_config.sync_status = HA_SYNC_NULL;
    }
    memset(xml_min_cnt, '\0', sizeof(xml_min_cnt));
    sprintf(xml_min_cnt, "%d", status);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "syncStatus", BAD_CAST xml_min_cnt);

    memset(xml_min_cnt, '\0', sizeof(xml_min_cnt));
    sprintf(xml_min_cnt, "%d", gst_ha_backup_config.priority);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "priority", BAD_CAST xml_min_cnt);

    memset(xml_max_cnt, '\0', sizeof(xml_max_cnt));
    iRet = nac_app_get_special_ifindex("ha");
    gst_ha_backup_config.local_ha_addr.ipaddr  = inet_network(g_nac_net_device[iRet].if_ip);
    gst_ha_backup_config.local_ha_addr.netmask = inet_network(g_nac_net_device[iRet].if_mask);
    sprintf(xml_max_cnt, "%s;%s", g_nac_net_device[iRet].if_ip, g_nac_net_device[iRet].if_mask);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "localHaIP", BAD_CAST xml_max_cnt);

    memset(xml_max_cnt, '\0', sizeof(xml_max_cnt));
    sprintf(xml_max_cnt, "%u.%u.%u.%u;%u.%u.%u.%u",
            LIPQUAD(gst_ha_backup_config.vip_addr.ipaddr),
            LIPQUAD(gst_ha_backup_config.vip_addr.netmask));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "virtualIP", BAD_CAST xml_max_cnt);

    memset(xml_max_cnt, '\0', sizeof(xml_max_cnt));
    sprintf(xml_max_cnt, "%u.%u.%u.%u;%u.%u.%u.%u",
            LIPQUAD(gst_ha_backup_config.other_ha_addr.ipaddr),
            LIPQUAD(gst_ha_backup_config.other_ha_addr.netmask));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "otherHaIP", BAD_CAST xml_max_cnt);

    return doc;
}

xmlDocPtr nac_system_parse_ha_backup_config(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_INT32  iRet, error_id;
	xmlDocPtr	nac_doc = HUPU_NULL;
	xmlNodePtr	cur_node;
	xmlChar     *xml_value;
	HUPU_UINT8	action_type;
    HUPU_CHAR   ip_addr[16];
    HUPU_CHAR   net_mask[16];

	/*actionType mark is NULL or not!*/
	cur_node = nac_xml_parse_get_action(doc, &action_type);
	if (cur_node == HUPU_NULL)
	{
		nac_free_xmlDoc(doc);
		return HUPU_NULL;
	}

	error_id = 0;
	switch (action_type)
	{
	case NAC_SHOW:
	    nac_free_xmlDoc(doc);
        nac_system_read_ha_backup_config(&gst_ha_backup_config);
		nac_doc = nac_system_get_ha_backup_config(cmd_id);
		break;
	case NAC_MODIFY:
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "haSwitch")))
			{
				xml_value = xmlNodeGetContent(cur_node);
				gst_ha_backup_config.ha_switch= atoi((HUPU_CHAR*)xml_value);
                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "haSwitch----%s\n", (HUPU_CHAR*)xml_value);
				xmlFree(xml_value);
			}
			else if (!(xmlStrcmp(cur_node->name, BAD_CAST "priority"))) //0~255
			{
				xml_value = xmlNodeGetContent(cur_node);
                gst_ha_backup_config.priority = atoi((HUPU_CHAR*)xml_value);
                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "priority----%s\n", (HUPU_CHAR*)xml_value);
				xmlFree(xml_value);
			}
            else if (!(xmlStrcmp(cur_node->name, BAD_CAST "virtualIP")))
            {
                xml_value = xmlNodeGetContent(cur_node);
                memset(ip_addr, '\0', sizeof(ip_addr));
                memset(net_mask, '\0', sizeof(net_mask));
                sscanf((HUPU_CHAR*)xml_value, "%[^;];%s", ip_addr, net_mask);
                gst_ha_backup_config.vip_addr.ipaddr  = inet_network(ip_addr);
                gst_ha_backup_config.vip_addr.netmask = inet_network(net_mask);
                xmlFree(xml_value);
                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "virtualIP----%s--%s--%02x--%02x\n",
                                ip_addr, net_mask, gst_ha_backup_config.vip_addr.ipaddr,
                                gst_ha_backup_config.vip_addr.netmask);
            }
            else if (!(xmlStrcmp(cur_node->name, BAD_CAST "otherHaIP")))
            {
                xml_value = xmlNodeGetContent(cur_node);
                memset(ip_addr, '\0', sizeof(ip_addr));
                memset(net_mask, '\0', sizeof(net_mask));
                sscanf((HUPU_CHAR*)xml_value, "%[^;];%s", ip_addr, net_mask);
                gst_ha_backup_config.other_ha_addr.ipaddr  = inet_network(ip_addr);
                gst_ha_backup_config.other_ha_addr.netmask = inet_network(net_mask);
                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "otherHaIP----%s--%s--%02x--%02x\n",
                                ip_addr, net_mask, gst_ha_backup_config.other_ha_addr.ipaddr,
                                gst_ha_backup_config.other_ha_addr.netmask);
                xmlFree(xml_value);
            }
            cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);
        iRet = nac_system_save_ha_backup_config(&gst_ha_backup_config);
        if (iRet != HUPU_OK)
        {
            error_id = HUPU_ERR;
        }
        else
        {
            nac_system_ha_backup_on_or_off(&gst_ha_backup_config);
        }
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "action_type=%d----error_id=%d\n", action_type, error_id);
        nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;
	default:
		nac_free_xmlDoc(doc);
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->invalid action_type\n", __FUNCTION__);
		break;
	}
	return nac_doc;
}
HUPU_INT32 nac_system_ha_sync_dynamic_config(xmlDocPtr doc, NAC_WEB_MSG* pst_xml_config)
{
    //HUPU_INT32 iRet;
    xmlNodePtr curNode;
    xmlChar *szKey;
    HUPU_UINT16 cmd_action;

    if (!(gst_ha_backup_config.run_status == HA_MASTER_STATUS
        && gst_ha_backup_config.sync_status == HA_SYNC_UNLOCK))
    {
        return HUPU_OK;
    }

    curNode = xmlDocGetRootElement(doc);
    if (HUPU_NULL == curNode)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "error empty document: %s\n");
        return HUPU_ERR;
    }

    if (xmlStrcmp(curNode->name, BAD_CAST "nac"))
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "error root document\n");
        return HUPU_ERR;
    }

    curNode = curNode->xmlChildrenNode;
    while(curNode != HUPU_NULL)
    {
        if (!(xmlStrcmp(curNode->name, BAD_CAST "actionType")))
        {
            szKey = xmlNodeGetContent(curNode);
            cmd_action = atoi((char*)szKey);
            xmlFree(szKey);
            break;
        }
        curNode = curNode->next;
    }

    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "HA_SYNC_DYNAMIC--action=%d--cmd=%d--len=%d--%s\n",
                    cmd_action, pst_xml_config->us_cmd, pst_xml_config->ui_len,
                    pst_xml_config->ac_buf);
    if (cmd_action == NAC_ADD
        || cmd_action == NAC_DEL
        || cmd_action == NAC_MODIFY)
    {
        backup_send_msg_to_master(pst_xml_config, gst_ha_backup_config.other_ha_addr.ipaddr);
    }

    return HUPU_OK;
}


HUPU_INT32 ha_backup_sync_knl_timeout_user(NAC_SYS_USER *user)
{
    HUPU_INT32 iRet;
    xmlDocPtr doc;
    xmlNodePtr root_node;
    HUPU_CHAR xml_min_cnt[MIN_BUFF_LEN];
	HUPU_CHAR xml_max_cnt[MID_BUFF_LEN];

    if (!(gst_ha_backup_config.run_status == HA_MASTER_STATUS
        && gst_ha_backup_config.sync_status == HA_SYNC_FINISH))
    {
        return HUPU_OK;
    }

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    memset(xml_min_cnt, '\0', sizeof(xml_min_cnt));
    sprintf(xml_min_cnt, "%d", SYS_WEBUI_USER_AUTH);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST xml_min_cnt);

    memset(xml_min_cnt, '\0', sizeof(xml_min_cnt));
    sprintf(xml_min_cnt, "%d", NAC_DEL);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST xml_min_cnt);

    memset(xml_max_cnt, '\0', strlen(xml_max_cnt));
	sprintf(xml_max_cnt, "%d:%d:%02x-%02x-%02x-%02x-%02x-%02x,%u.%u.%u.%u",
	        user->userid, user->depid, MAC_FORMAT(user->mac), LIPQUAD(user->ip));

    xmlNodePtr tmp_node = xmlNewChild(root_node, HUPU_NULL, BAD_CAST "onlineUser", BAD_CAST xml_max_cnt);
    memset(xml_min_cnt, '\0', sizeof(xml_min_cnt));
    sprintf(xml_min_cnt, "%d", user->user_type);
    xmlNewProp(tmp_node, BAD_CAST "type", BAD_CAST xml_min_cnt);

    xmlChar*    doc_buffer;
    HUPU_INT32  doc_size;
    NAC_WEB_MSG *pst_xml_msg;
    HUPU_UINT32 xml_msg_len;

    xmlDocDumpFormatMemoryEnc(doc, &doc_buffer, &doc_size, "UTF-8", 1);
    nac_free_xmlDoc(doc);

    xml_msg_len = doc_size + sizeof(NAC_WEB_MSG) + 1;
    pst_xml_msg = (NAC_WEB_MSG*)malloc((sizeof(HUPU_CHAR)*xml_msg_len));
    if (pst_xml_msg == HUPU_NULL)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "malloc fail\n");
        xmlFree(doc_buffer);
        return HUPU_ERR;
    }

    memset(pst_xml_msg, '\0', xml_msg_len);
    pst_xml_msg->us_cmd  = SYS_WEBUI_USER_AUTH;
    pst_xml_msg->reserve = 0;
    pst_xml_msg->ui_len  = doc_size;
    memcpy(pst_xml_msg->ac_buf, doc_buffer, doc_size);
    xmlFree(doc_buffer);

    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "cmd=%d--len=%d--buf=%s\n",
                    pst_xml_msg->us_cmd, pst_xml_msg->ui_len, pst_xml_msg->ac_buf);
    iRet = backup_send_msg_to_master(pst_xml_msg, gst_ha_backup_config.other_ha_addr.ipaddr);

    free(pst_xml_msg);
    return HUPU_OK;
}

HUPU_INT32 ha_backup_enable_mysql_sync_config(HUPU_UINT16 status, NAC_HA_BACKUP_CONFIG *pst_config)
{
    HUPU_INT32 iRet = 0;
    HUPU_CHAR  exec_cmd[1024] = "";
    HUPU_CHAR  enable_mysql_backup_path[] = "/nac/script/enable_mysql_backup.sh";
    HUPU_CHAR  enable_mysql_master_path[] = "/nac/script/enable_mysql_master.sh";
    HUPU_CHAR  disable_mysql_sync_path[] = "/nac/script/disable_mysql_sync.sh";
    HUPU_CHAR  *pst_script = HUPU_NULL;

    switch(status)
    {
    case HA_NULL_STATUS:
        pst_script = disable_mysql_sync_path;
        if ((iRet=access(pst_script, X_OK)) == HUPU_OK)
        {
            sprintf(exec_cmd, "%s", pst_script);
        }
        break;

    case HA_BACKUP_STATUS:
        pst_script = enable_mysql_backup_path;
        if ((iRet=access(pst_script, X_OK)) == HUPU_OK)
        {
            sprintf(exec_cmd, "%s %u.%u.%u.%u", pst_script,
                    LIPQUAD(pst_config->other_ha_addr.ipaddr));
        }
        break;

    case HA_MASTER_STATUS:
        pst_script = enable_mysql_master_path;
        if ((iRet=access(pst_script, X_OK)) == HUPU_OK)
        {
            sprintf(exec_cmd, "%s %u.%u.%u.%u", pst_script,
                    LIPQUAD(pst_config->other_ha_addr.ipaddr));
        }
        break;

    default:
        break;
    }

    if (iRet != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s unexistence or unexecutable!\n", pst_script);
        return HUPU_ERR;
    }

    iRet = nac_exec_system(exec_cmd);
    if (iRet != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "exec %s fault\n", exec_cmd);
        return HUPU_ERR;
    }

    return HUPU_OK;
}

HUPU_INT32 ha_backup_load_sys_config(HUPU_VOID)
{
    HUPU_CHAR* sys_conf_path = "/bak/ha_sync/nac_sys.conf";
    nac_app_read_sys_config_from_file(sys_conf_path, 1);
    return HUPU_OK;
}

HUPU_INT32 ha_backup_load_vtl_mac(NAC_HA_BACKUP_CONFIG *pst_config)
{
    HUPU_INT32  iRet;
    HUPU_CHAR   get_result[256]  = "";
    HUPU_CHAR   *vtl_mac_path    = "/bak/ha_sync/vtl_mac.conf";
    HUPU_CHAR   *get_vtl_mac_cmd = "cat /bak/ha_sync/vtl_mac.conf";
    HUPU_CHAR   mac_str[18] = "";
    //vtl_mac=%02X-%02X-%02X-%02X-%02X-%02X
    if (access(vtl_mac_path, F_OK) != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s is unexist\n", vtl_mac_path);
        return HUPU_ERR;
    }

    nac_get_popen_result(get_vtl_mac_cmd, get_result);
    if (strlen(get_result) > 8)
    {
        sscanf(get_result, "%*[^=]=%s", mac_str);
        if (strlen(mac_str) == 17)
        {
            iRet = sscanf(mac_str, "%02hhX-%02hhX-%02hhX-%02hhX-%02hhX-%02hhX",
                    &pst_config->vtl_mac[0], &pst_config->vtl_mac[1],
                    &pst_config->vtl_mac[2], &pst_config->vtl_mac[3],
                    &pst_config->vtl_mac[4], &pst_config->vtl_mac[5]);
        }
    }

    return HUPU_OK;
}

HUPU_INT32 ha_backup_load_knl_online_user(HUPU_VOID)
{
    HUPU_INT32 iRet, i;
    FILE* fp;
    HUPU_CHAR sz_line[512] = "";
    HUPU_CHAR* knl_user_path = "/bak/ha_sync/nac_knl_user_online";
    NAC_USER_ST st_user_tmp;
    NAC_KNL_USER_OBJECT st_knl_obj;

    HUPU_INT32  zone_sum;
    HUPU_CHAR   zone_str[128];
    HUPU_CHAR   *token, *running;
    HUPU_UINT32 token_id;

    if ((fp = fopen(knl_user_path, "r")) == HUPU_NULL)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "open %s fault\n", knl_user_path);
        return HUPU_ERR;
    }

    while((fgets(sz_line, sizeof(sz_line), fp)) != HUPU_NULL)
    {
        if (strstr(sz_line, "user_type") != HUPU_NULL
            || strstr(sz_line, "number") != HUPU_NULL)
        {
            continue;
        }

        memset(&st_user_tmp, '\0', sizeof(NAC_USER_ST));
        iRet = sscanf(sz_line, "%hd %d %hd %s %s %*d %d %s %*s",
                &st_user_tmp.user_type,
                &st_user_tmp.user_id,
                &st_user_tmp.dep_id,
                st_user_tmp.ip,
                st_user_tmp.mac,
                &st_user_tmp.status,
                st_user_tmp.isolate_id);
        if (iRet != 7)
        {
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "sscanf %s fault\n", sz_line);
            continue;
        }

        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%d--%d--%d--%s--%s--%d--%s\n",
                        st_user_tmp.user_type, st_user_tmp.dep_id,
                        st_user_tmp.user_id, st_user_tmp.ip,
                        st_user_tmp.mac, st_user_tmp.status,
                        st_user_tmp.isolate_id);

        memset(&st_knl_obj, 0, sizeof(NAC_KNL_USER_OBJECT));
        st_knl_obj.user_type = st_user_tmp.user_type;
        st_knl_obj.id  = st_user_tmp.user_id;
        st_knl_obj.gid = st_user_tmp.dep_id;
        st_knl_obj.ip = inet_network(st_user_tmp.ip);
        sscanf(st_user_tmp.mac, "%02hhx-%02hhx-%02hhx-%02hhx-%02hhx-%02hhx",
            &st_knl_obj.mac[0], &st_knl_obj.mac[1], &st_knl_obj.mac[2],
            &st_knl_obj.mac[3], &st_knl_obj.mac[4], &st_knl_obj.mac[5]);
        st_knl_obj.state = st_user_tmp.status;

        memset(zone_str, '\0', sizeof(zone_str));
        iRet = sscanf(st_user_tmp.isolate_id, "%d(%[^)]", &zone_sum, zone_str);
        if (iRet != 2)
        {
            zone_sum = 0;
        }
        st_knl_obj.isolation_num = zone_sum;

        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%d--%d--%d--%u.%u.%u.%u--%02x-%02x-%02x-%02x-%02x-%02x--%d--%d--%s\n",
                        st_knl_obj.user_type, st_knl_obj.gid, st_knl_obj.id, LIPQUAD(st_knl_obj.ip),
                        st_knl_obj.mac[0], st_knl_obj.mac[1], st_knl_obj.mac[2], st_knl_obj.mac[3],
                        st_knl_obj.mac[4], st_knl_obj.mac[5], st_knl_obj.state,
                        st_knl_obj.isolation_num, zone_str);
        if (zone_sum > 0)
        {
            running = zone_str;
            for(i = 0; i < zone_sum; i++)
            {
                token = strsep(&running, ";");
                token_id = atoi(token);
                if (token_id)
                {
                    st_knl_obj.isolation_zone[i] = token_id;
                }
            }
        }

        iRet = nac_set_data_to_knl(NAC_CMD_USER_INS, 0, &st_knl_obj, sizeof(NAC_KNL_USER_OBJECT));
    }

    return HUPU_OK;
}

HUPU_VOID nac_system_catch_siguser1(HUPU_INT32 sig)
{
    HUPU_INT32 iRet = 0;
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "old_status=%d--new_status=%d\n",
                    gst_ha_backup_config.run_status, HA_MASTER_STATUS);

    if (gst_ha_backup_config.run_status == HA_BACKUP_STATUS)
    {
        iRet = nac_app_get_netdev_enable_link_status(gst_ha_backup_config.ha_eth);
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,  "nac_app_get_netdev_enable_link_status--%s--%d\n",
                            gst_ha_backup_config.ha_eth, iRet);
        if (iRet != HUPU_ENABLE)
        {
            rmv_manager_virtual_ip();
            goto FUNC_EXIT;
        }

    }

    gst_ha_backup_config.run_status  = HA_MASTER_STATUS;
    gst_ha_backup_config.sync_status = HA_SYNC_NULL;

    //asc permit ruby_switch upload info
    nac_exec_system("echo 0 > /proc/sys/net/nac_knl_switch_flags");//all forward
    nac_exec_system("echo 0 > /proc/sys/net/nac_knl_pass_switch_flags");
    nac_sys_send_ruby_switch_usr1();
    if (gst_ha_backup_config.vtl_mac[0] == 0x00)
    {
        memset(gst_ha_backup_config.vtl_mac, 0, ETH_ALEN);
        memcpy(gst_ha_backup_config.vtl_mac, gst_ha_backup_config.local_mac, ETH_ALEN);
    }
    FUNC_EXIT:
        return;
}

HUPU_VOID nac_system_catch_siguser2(HUPU_INT32 sig)
{
    //HUPU_UINT32 iRet = 0;
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "old_status=%d--new_status=%d\n",
                    gst_ha_backup_config.run_status, HA_BACKUP_STATUS);
    gst_ha_backup_config.run_status  = HA_BACKUP_STATUS;
    gst_ha_backup_config.sync_status = HA_SYNC_NULL;
    //asc forbidden ruby_switch no_upload info
    nac_exec_system("echo 1 > /proc/sys/net/nac_knl_switch_flags");//all noforward
    nac_exec_system("echo 1 > /proc/sys/net/nac_knl_pass_switch_flags");
    nac_sys_send_ruby_switch_usr1();
    return;
}


HUPU_VOID nac_system_catch_sigrtmin(HUPU_INT32 sig)
{
    //HUPU_INT32 iRet = 0;
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "old_status=%d--new_status=%d\n",
                    gst_ha_backup_config.run_status, HA_FAULT_STATUS);
    if ( gst_ha_backup_config.run_status == HA_FAULT_STATUS )
    {
        goto FUNC_EXIT;
    }
    gst_ha_backup_config.run_status  = HA_FAULT_STATUS;
    gst_ha_backup_config.sync_status = HA_SYNC_NULL;

    //my_sql data base recover!
    ha_backup_enable_mysql_sync_config(HA_NULL_STATUS, NULL);
    nac_exec_system("echo 1 > /proc/sys/net/nac_knl_switch_flags");//all noforward
    nac_exec_system("echo 1 > /proc/sys/net/nac_knl_pass_switch_flags");
    nac_sys_send_ruby_switch_usr1();

    FUNC_EXIT:
        return;
}

