#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_errorlog.h"
#include "nac_system_main.h"//extern struct nac_hlist_head nac_vlanmap_hash[];
#include "nac_system_xml.h"
#include "nac_system_net.h"
#include "nac_system_common_lib.h"
#include "nac_system_vlanmap.h"

HUPU_UINT16 g_vlanmap_index = 0;
struct nac_hlist_head nac_vlanmap_hash[NAC_SYS_VLANMAP_HASH_SIZE];
pthread_mutex_t system_vlanmap_mutex = PTHREAD_MUTEX_INITIALIZER;

HUPU_VOID nac_system_init_vlanmap(HUPU_VOID)
{
    int i;

	for (i = 0; i < NAC_SYS_VLANMAP_HASH_SIZE; i++)
    {
        NAC_INIT_HLIST_HEAD(&nac_vlanmap_hash[i]);
    }
    //pthread_mutex_init(&system_vlanmap_mutex HUPU_NULL);
    return;
}

HUPU_INT32 nac_sys_net_setvlan(NAC_SET_ACTION flag,
									nac_knl_policy_vlap* vlanmap_st,
									nac_knl_in_out_eth* pst_in_out_eth)
{
	HUPU_CHAR *set_vlan_cmd = "ifconfig %s up && vconfig add %s %d && ifconfig %s.%d 0.0.0.0 up";
	HUPU_CHAR *del_vlan_cmd = "vconfig rem %s.%d";
	HUPU_INT32 iRet;
	HUPU_CHAR exec_vconfig_cmd[120];

	return HUPU_OK;

	if (flag == NAC_ADD)
    {
		memset(exec_vconfig_cmd, '\0', strlen(exec_vconfig_cmd));
        sprintf(exec_vconfig_cmd, set_vlan_cmd, pst_in_out_eth->ac_in_eth,
				pst_in_out_eth->ac_in_eth, vlanmap_st->insulate_vlan,
				pst_in_out_eth->ac_in_eth, vlanmap_st->insulate_vlan);

		iRet = nac_exec_system(exec_vconfig_cmd);
		if (iRet == HUPU_OK)
		{
			memset(exec_vconfig_cmd, '\0', strlen(exec_vconfig_cmd));
        	sprintf(exec_vconfig_cmd, set_vlan_cmd, pst_in_out_eth->ac_out_eth,
					pst_in_out_eth->ac_out_eth, vlanmap_st->pass_vlan,
					pst_in_out_eth->ac_out_eth, vlanmap_st->pass_vlan);
			nac_exec_system(exec_vconfig_cmd);
		}
    }
    else if (flag == NAC_DEL)
    {
		memset(exec_vconfig_cmd, '\0', strlen(exec_vconfig_cmd));
        sprintf(exec_vconfig_cmd, del_vlan_cmd, pst_in_out_eth->ac_in_eth,
				vlanmap_st->insulate_vlan);
		iRet = nac_exec_system(exec_vconfig_cmd);
		if (iRet == HUPU_OK)
		{
			memset(exec_vconfig_cmd, '\0', strlen(exec_vconfig_cmd));
			sprintf(exec_vconfig_cmd, del_vlan_cmd, pst_in_out_eth->ac_out_eth,
					vlanmap_st->pass_vlan);
			nac_exec_system(exec_vconfig_cmd);
		}
    }
	return HUPU_OK;
}



/*insert success: return HUPU_OK; insert failure: return HUPU_ERR*/
HUPU_INT32 insert_vlanmap_hlist(NAC_APP_VLANMAP* st_vlanmap)
{
    HUPU_INT16 key;
    NAC_APP_VLANMAP *vlan_ent = HUPU_NULL;

    key = (st_vlanmap->id) % NAC_SYS_VLANMAP_HASH_SIZE;
    vlan_ent = (NAC_APP_VLANMAP*)malloc(sizeof(NAC_APP_VLANMAP));
    if (vlan_ent == HUPU_NULL)
    {
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->malloc nac_app_vlanmap error\n", __FUNCTION__);
        return HUPU_ERR;
    }
	memset(vlan_ent, '\0', sizeof(NAC_APP_VLANMAP));

    vlan_ent->id = st_vlanmap->id;
    vlan_ent->isolate_vlantag = st_vlanmap->isolate_vlantag;
    vlan_ent->normal_vlantag = st_vlanmap->normal_vlantag;
	memcpy(vlan_ent->comment, st_vlanmap->comment, strlen(st_vlanmap->comment));
    nac_hlist_add_head(&vlan_ent->node, &nac_vlanmap_hash[key]);

    return HUPU_OK;
}

/*find: return != HUPU_NULL; no find: return == HUPU_NULL*/
static NAC_APP_VLANMAP* find_vlanmap_hlist(HUPU_UINT32 index)
{
    HUPU_INT16 key;
    NAC_APP_VLANMAP *vlan_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    key = index % NAC_SYS_VLANMAP_HASH_SIZE;
    if (!nac_hlist_empty(&nac_vlanmap_hash[key]))
    {
        nac_hlist_for_each_entry_safe(vlan_ent, pos, n, &nac_vlanmap_hash[key], node)
        {
            if (vlan_ent->id == index)
            {
                return vlan_ent;
            }
        }
    }
    return HUPU_NULL;
}

/*remove success: return HUPU_OK; remove failure: return HUPU_ERR*/
static HUPU_INT32 remove_vlanmap_hlist(HUPU_UINT32 index)
{
    HUPU_INT16 key;
    NAC_APP_VLANMAP *vlan_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    key = index % NAC_SYS_VLANMAP_HASH_SIZE;

    if (!nac_hlist_empty(&nac_vlanmap_hash[key]))
    {
        nac_hlist_for_each_entry_safe(vlan_ent, pos, n, &nac_vlanmap_hash[key], node)
        {
            if (vlan_ent->id == index)
            {
                nac_hlist_del(&vlan_ent->node);
                free(vlan_ent);
                return HUPU_OK;
            }
        }
    }
	return HUPU_ERR;
}
/*modify success: return HUPU_OK; modify failure: return HUPU_ERR*/
static HUPU_INT32 modify_vlanmap_hlist(NAC_APP_VLANMAP* st_vlanmap)
{
    HUPU_INT16 key;
    NAC_APP_VLANMAP *vlan_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    key = (st_vlanmap->id) % NAC_SYS_VLANMAP_HASH_SIZE;

    if (!nac_hlist_empty(&nac_vlanmap_hash[key]))
    {
        nac_hlist_for_each_entry_safe(vlan_ent, pos, n, &nac_vlanmap_hash[key], node)
        {
            if (vlan_ent->id == st_vlanmap->id)
            {
				vlan_ent->isolate_vlantag = st_vlanmap->isolate_vlantag;
				vlan_ent->normal_vlantag  = st_vlanmap->normal_vlantag;
				memset(vlan_ent->comment, '\0', MAX_COMMENT_LEN);
				memcpy(vlan_ent->comment, st_vlanmap->comment, strlen(st_vlanmap->comment));
                return HUPU_OK;
            }
        }
    }
	return HUPU_ERR;
}

/*find it: return HUPU_ERR; no find it: return HUPU_OK*/
/*avoid repeat argument interface*/
static HUPU_INT32 search_vlanmap_hlist(HUPU_UINT16 rpt_isolate, HUPU_UINT16 rpt_normal)
{
    HUPU_INT16 key;
    NAC_APP_VLANMAP *vlan_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    for (key = 0; key < NAC_SYS_VLANMAP_HASH_SIZE; key++)
    {
        if (!nac_hlist_empty(&nac_vlanmap_hash[key]))
        {
            nac_hlist_for_each_entry_safe(vlan_ent, pos, n, &nac_vlanmap_hash[key], node)
            {
               if (vlan_ent->isolate_vlantag == rpt_isolate
                    && vlan_ent->normal_vlantag == rpt_normal)
				{
					return HUPU_ERR;
				}
            }
        }
    }

	return HUPU_OK;
}

HUPU_VOID destroy_entire_vlanmap_hlist(HUPU_VOID)
{
    HUPU_INT16  key;
    NAC_APP_VLANMAP *vlan_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    for (key = 0; key < NAC_SYS_VLANMAP_HASH_SIZE; key++)
    {
        if (!nac_hlist_empty(&nac_vlanmap_hash[key]))
        {
            nac_hlist_for_each_entry_safe(vlan_ent, pos, n, &nac_vlanmap_hash[key], node)
            {
                nac_hlist_del(&vlan_ent->node);
                free(vlan_ent);
            }
        }
    }
}

HUPU_VOID nac_app_set_all_hlist_vlanmap(HUPU_VOID)
{
	HUPU_INT16  key;
    NAC_APP_VLANMAP *vlan_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;
	nac_knl_policy_vlap st_vlan;

    for (key = 0; key < NAC_SYS_VLANMAP_HASH_SIZE; key++)
    {
        if (!nac_hlist_empty(&nac_vlanmap_hash[key]))
        {
            nac_hlist_for_each_entry_safe(vlan_ent, pos, n, &nac_vlanmap_hash[key], node)
            {
				memset(&st_vlan, '\0', sizeof(nac_knl_policy_vlap));
				st_vlan.insulate_vlan   = vlan_ent->isolate_vlantag;
    			st_vlan.pass_vlan       = vlan_ent->normal_vlantag;
				nac_sys_net_setvlan(NAC_ADD, &st_vlan, &gst_in_out_eth);
            }
        }
    }
}

/*get all the vlanmap config*/
static xmlDocPtr nac_sys_get_vlanmap_hlist(HUPU_UINT16 command_id)
{
    xmlDocPtr doc;
    xmlNodePtr root_node;

    HUPU_INT16 key;
    NAC_APP_VLANMAP *vlan_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;
	HUPU_CHAR get_buffer[SEND_BUFFER_LEN] ="";

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    sprintf(get_buffer, "%d", (command_id + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST get_buffer);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");

	for (key = 0; key < NAC_SYS_VLANMAP_HASH_SIZE; key++)
    {
        if (!nac_hlist_empty(&nac_vlanmap_hash[key]))
        {
            nac_hlist_for_each_entry_safe(vlan_ent, pos, n, &nac_vlanmap_hash[key], node)
            {
				memset(get_buffer, '\0', sizeof(get_buffer));
				sprintf(get_buffer, "%d;%d,%d;%s", vlan_ent->id, vlan_ent->isolate_vlantag,
					vlan_ent->normal_vlantag, vlan_ent->comment);
				xmlNewChild(root_node, HUPU_NULL, BAD_CAST "vlanMap", BAD_CAST get_buffer);
			}
        }
    }

    return doc;
}

HUPU_INT32 nac_sys_add_vlanmap(NAC_APP_VLANMAP* st_vlanmap)
{
	HUPU_UINT32 iRet;
	nac_knl_policy_vlap st_vlan;

    /*VLAN_MAX_RANGE = 4096*/
    /*The vlan_id is the identifier (0-4095) of the VLAN you are operating on.*/
	if ((st_vlanmap->isolate_vlantag <= 0 && st_vlanmap->isolate_vlantag >= VLAN_MAX_RANGE)
		||(st_vlanmap->normal_vlantag <= 0 && st_vlanmap->normal_vlantag >= VLAN_MAX_RANGE))
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->vlan_tag beyond 0-4095 error\n", __FUNCTION__);
		return NAC_SYS_ERROR_ILLEGAL_VLANTAG;
	}

	iRet = search_vlanmap_hlist(st_vlanmap->isolate_vlantag, st_vlanmap->normal_vlantag);
	if (iRet == HUPU_ERR)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->vlan_map argument repeat error\n", __FUNCTION__);
		return NAC_SYS_ERROR_REPEAT_VLANMAP;
	}

	st_vlan.insulate_vlan	= st_vlanmap->isolate_vlantag;
	st_vlan.pass_vlan		= st_vlanmap->normal_vlantag;

	//添加VLAN映射时，先配置系统VLAN，然后配置内核VLAN数据；
	iRet = nac_sys_net_setvlan(NAC_ADD, &st_vlan, &gst_in_out_eth);
	if (iRet == HUPU_ERR)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_net_setvlan-->add error\n", __FUNCTION__);
		return NAC_SYS_ERROR_ADD_VCONFIG_FAIL;
	}

	iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_VLAN_MAP, 0, &st_vlan, sizeof(nac_knl_policy_vlap));
	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_SYS_SET_VLAN_MAP error\n", __FUNCTION__);
		return NAC_KNL_ERROR_INSERT_VLANMAP_FAIL;
	}

	iRet = insert_vlanmap_hlist(st_vlanmap);
	if (iRet == HUPU_ERR)
	{
		return NAC_SYS_ERROR_ADD_VLANMAP_FAIL;
	}

	return HUPU_OK;
}

HUPU_INT32 nac_sys_del_vlanmap(HUPU_UINT32 del_id)
{
	HUPU_UINT32 iRet;
	NAC_APP_VLANMAP *vlanmap_ent = HUPU_NULL;
	nac_knl_policy_vlap st_vlan;

	vlanmap_ent = find_vlanmap_hlist(del_id);
	if (vlanmap_ent == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->find_vlanmap_hlist-->delete vlanmap unexist\n", __FUNCTION__);
		return NAC_SYS_ERROR_DELETE_VLANMAP_UNEXIST;
	}

	st_vlan.insulate_vlan = vlanmap_ent->isolate_vlantag;
    st_vlan.pass_vlan     = vlanmap_ent->normal_vlantag;

	//删除VLAN映射时，先删除内核VLAN映射，再删除系统VLAN映射；
	iRet = nac_set_data_to_knl(NAC_CMD_SYS_FLUSH_VLAN_MAP, 0, &st_vlan, sizeof(nac_knl_policy_vlap));
	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_SYS_FLUSH_VLAN_MAP error\n", __FUNCTION__);
		return NAC_KNL_ERROR_REMOVE_VLANMAP_FAIL;
	}

	iRet = nac_sys_net_setvlan(NAC_DEL, &st_vlan, &gst_in_out_eth);
	if (iRet == HUPU_ERR)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_net_setvlan-->del error\n", __FUNCTION__);
		return NAC_SYS_ERROR_REM_VCONFIG_FAIL;
	}

	remove_vlanmap_hlist(del_id);

	return HUPU_OK;
}

HUPU_INT32 nac_sys_modify_vlanmap(NAC_APP_VLANMAP* st_vlanmap)
{
	HUPU_UINT32 iRet;
	NAC_APP_VLANMAP *vlanmap_ent = HUPU_NULL;
	nac_knl_policy_vlap st_vlan;

    if ((st_vlanmap->isolate_vlantag <= 0 && st_vlanmap->isolate_vlantag >= VLAN_MAX_RANGE)
		||(st_vlanmap->normal_vlantag <= 0 && st_vlanmap->normal_vlantag >= VLAN_MAX_RANGE))
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->vlan_tag beyond 0-4095 error\n", __FUNCTION__);
		return NAC_SYS_ERROR_ILLEGAL_VLANTAG;;
	}

	vlanmap_ent = find_vlanmap_hlist(st_vlanmap->id);
	if (vlanmap_ent == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->find_vlanmap_hlist-->modify vlanmap unexist\n", __FUNCTION__);
		return NAC_SYS_ERROR_MODIFY_VLANMAP_UNEXIST;
	}

	if (vlanmap_ent->isolate_vlantag == st_vlanmap->isolate_vlantag
		&&vlanmap_ent->normal_vlantag == st_vlanmap->normal_vlantag)//only modify comment
	{
		modify_vlanmap_hlist(st_vlanmap);
	}
	else
	{
		st_vlan.insulate_vlan = vlanmap_ent->isolate_vlantag;
		st_vlan.pass_vlan     = vlanmap_ent->normal_vlantag;
		iRet = nac_set_data_to_knl(NAC_CMD_SYS_FLUSH_VLAN_MAP, 0, &st_vlan, sizeof(nac_knl_policy_vlap));
		if (iRet != HUPU_OK)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_SYS_FLUSH_VLAN_MAP error\n", __FUNCTION__);
			return NAC_KNL_ERROR_REMOVE_VLANMAP_FAIL;
		}

		iRet = nac_sys_net_setvlan(NAC_DEL, &st_vlan, &gst_in_out_eth);
		if (iRet == HUPU_ERR)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_net_setvlan-->del error\n", __FUNCTION__);
			return NAC_SYS_ERROR_REM_VCONFIG_FAIL;
		}

		/*repeat vlanmap search,find return HUPU_ERR*/
		iRet = search_vlanmap_hlist(st_vlanmap->isolate_vlantag, st_vlanmap->normal_vlantag);
		if (iRet == HUPU_ERR)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->search_vlanmap_hlist-->vlan_map argument repeat error\n", __FUNCTION__);
			return NAC_SYS_ERROR_REPEAT_VLANMAP;
		}

		st_vlan.insulate_vlan	= st_vlanmap->isolate_vlantag;
		st_vlan.pass_vlan		= st_vlanmap->normal_vlantag;
		//添加VLAN映射时，先配置系统VLAN，然后配置内核VLAN数据；
		iRet = nac_sys_net_setvlan(NAC_ADD, &st_vlan, &gst_in_out_eth);
		if (iRet == HUPU_ERR)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_net_setvlan-->add error\n", __FUNCTION__);
			return NAC_SYS_ERROR_ADD_VCONFIG_FAIL;
		}

		iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_VLAN_MAP, 0, &st_vlan, sizeof(nac_knl_policy_vlap));
		if (iRet != HUPU_OK)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_SYS_SET_VLAN_MAP error\n", __FUNCTION__);
			return NAC_KNL_ERROR_INSERT_VLANMAP_FAIL;
		}

		iRet = modify_vlanmap_hlist(st_vlanmap);
		if (iRet == HUPU_ERR)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->modify_vlanmap_hlist error\n", __FUNCTION__);
			return NAC_SYS_ERROR_MODIFY_VLANMAP_FAIL;
		}
	}

	return HUPU_OK;
}

xmlDocPtr nac_xml_parse_vlantag_map(xmlDocPtr doc, HUPU_UINT16 cmd_id, HUPU_UINT8 *opt_type)
{
	HUPU_INT32  iRet, error_id;
	xmlDocPtr   nac_doc = HUPU_NULL;
	xmlNodePtr  cur_node;
	xmlChar     *szKey, *szAttr;
	HUPU_UINT8  action_type;
	NAC_APP_VLANMAP xml_vlanmap_st;//strlen(comment)=12*3
	HUPU_UINT32 policy_id;

	/*actionType mark is NULL or not!*/
	cur_node = nac_xml_parse_get_action(doc, &action_type);
	if (cur_node == HUPU_NULL)
	{
		nac_free_xmlDoc(doc);
		return HUPU_NULL;
	}

    *opt_type = action_type;
	error_id = 0;
	switch (action_type)
	{
		case NAC_SHOW:
			nac_free_xmlDoc(doc);
			nac_doc = nac_sys_get_vlanmap_hlist(cmd_id);
			break;

		case NAC_ADD:
			while (cur_node != HUPU_NULL)
			{
				memset(&xml_vlanmap_st, '\0', sizeof(NAC_APP_VLANMAP));
				if (!(xmlStrcmp(cur_node->name, BAD_CAST "vlanMap")))
				{
					szKey = xmlNodeGetContent(cur_node);
					sscanf((char*)szKey,"%hd,%hd;%s", &xml_vlanmap_st.isolate_vlantag,
						&xml_vlanmap_st.normal_vlantag, xml_vlanmap_st.comment);
					xmlFree(szKey);

					g_vlanmap_index = g_vlanmap_index + 1;
					xml_vlanmap_st.id = g_vlanmap_index;
					iRet = nac_sys_add_vlanmap(&xml_vlanmap_st);
					if (iRet != HUPU_OK)
					{
						error_id = iRet;
						g_vlanmap_index = g_vlanmap_index - 1;
						nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_add_vlanmap error\n", __FUNCTION__);
						break;
					}
				}
				cur_node = cur_node->next;
			}
			nac_free_xmlDoc(doc);
			nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
			break;

		case NAC_DEL:
			while(cur_node != HUPU_NULL)
			{
				if (!(xmlStrcmp(cur_node->name, BAD_CAST "vlanMap")) && (xmlHasProp(cur_node, BAD_CAST "id")))
				{
					szAttr = xmlGetProp(cur_node, BAD_CAST "id");
					policy_id = atoi((char*)szAttr);
					xmlFree(szAttr);

					iRet = nac_sys_del_vlanmap(policy_id);
					if (iRet != HUPU_OK)
					{
						error_id = iRet;
						nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_del_vlanmap error\n", __FUNCTION__);
						break;
					}
				}
				cur_node = cur_node->next;
			}
			nac_free_xmlDoc(doc);
			nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
			break;

		case NAC_MODIFY:
			while(cur_node != HUPU_NULL)
			{
				memset(&xml_vlanmap_st, '\0', sizeof(NAC_APP_VLANMAP));
				if (!(xmlStrcmp(cur_node->name, BAD_CAST "vlanMap")))
				{
					szAttr = xmlGetProp(cur_node, BAD_CAST "id");
					xml_vlanmap_st.id = atoi((char*)szAttr);
                    xmlFree(szAttr);

					szKey = xmlNodeGetContent(cur_node);
					sscanf((char*)szKey,"%hd,%hd;%s", &xml_vlanmap_st.isolate_vlantag,
						&xml_vlanmap_st.normal_vlantag, xml_vlanmap_st.comment);
					xmlFree(szKey);

					iRet = nac_sys_modify_vlanmap(&xml_vlanmap_st);
					if (iRet != HUPU_OK)
					{
						error_id = iRet;
						nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_modify_vlanmap error\n", __FUNCTION__);
						break;
					}
				}
				cur_node = cur_node->next;
			}
			nac_free_xmlDoc(doc);
			nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
			break;

		default:
            nac_free_xmlDoc(doc);
            nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
            break;
	}

	return nac_doc;
}

//return old sys_vlan count_num
int nac_app_rem_all_old_vconfig(void)
{
	FILE *nac_fp = NULL;
	char *rem_vlan_cmd = "vconfig rem %s";
    char szLine[BUFF_LEN] = "";
	char szName[IFNAMSIZE] = "";
    int nCount = 0;

	return nCount;

	if ((nac_fp = fopen("/proc/net/vlan/config", "r")) == NULL)
    {
        printf("open /proc/net/vlan/config failed by %s!\n", strerror(errno));
        return nCount;
    }

    fgets(szLine, sizeof(szLine), nac_fp);
    fgets(szLine, sizeof(szLine), nac_fp);
	memset(szLine, '\0', sizeof(szLine));

    while ((fgets(szLine, sizeof(szLine), nac_fp)) != NULL)
    {

		memset(szName, '\0', sizeof(szName));
		sscanf(szLine, "%s", szName);

		int nLen = strlen(szName);
		if (nLen <= 0)
		{
			memset(szLine, '\0', sizeof(szLine));
			continue;
		}
		else if (strstr(szName, "eth") == NULL)
		{
			//strcmp(szName, "lo") == 0
			memset(szLine, '\0', sizeof(szLine));
			continue;
		}
		else if (strstr(szName, ".")  == NULL)
		{
			memset(szLine, '\0', sizeof(szLine));
			continue;
		}

		memset(szLine, '\0', sizeof(szLine));
		sprintf(szLine, rem_vlan_cmd, szName);
		nac_exec_system(szLine);

		memset(szLine, '\0', sizeof(szLine));
        nCount++;
    }

	fclose(nac_fp);
    return nCount;
}
