#ifndef NAC_SYSTEM_NET_H
#define NAC_SYSTEM_NET_H

#include <linux/sockios.h>
#include <linux/ethtool.h>
#include "nac_system_common_lib.h"

/*-1:error; 1: link up; 0: link down*/
int get_netdev_link_status(const char *if_name);

/*char mac[18] = ""; char mac[ETH_ALEN]; success:0; fault:-1*/
int nac_get_netdev_mac(const char* ifname, char* mac, int mac_size);

/*unsigned int cpu[4];get_cpu_id(cpu);*/
void get_cpu_id(unsigned int *buf);

/*char buf[35] = ""*/
void get_cpu_id_str(char* buf);

HUPU_INT32 nac_sys_net_set_ifconfig(NAC_NET_DEVICE* if_st);
HUPU_INT32 nac_sys_net_set_default_gateway(HUPU_CHAR* gateway_str);
HUPU_INT32 nac_sys_net_set_dnserver(NAC_DNS_SERVER* dns_server_st);
HUPU_VOID nac_sys_save_ifconfig(FILE* fp);
HUPU_VOID nac_sys_save_ifconfig_status(FILE* fp);

xmlDocPtr nac_sys_parse_net_device(xmlDocPtr doc, HUPU_UINT16 cmd_id);
xmlDocPtr nac_sys_parse_net_gateway(xmlDocPtr doc, HUPU_UINT16 cmd_id);
xmlDocPtr nac_sys_parse_net_dnserver(xmlDocPtr doc, HUPU_UINT16 cmd_id);
xmlDocPtr nac_sys_parse_shut_or_boot(xmlDocPtr doc, HUPU_UINT16 cmd_id, HUPU_UINT8 *opt_action);


HUPU_INT32 nac_sys_net_set_promisc(NAC_MODE mode, nac_knl_in_out_eth* pst_inout_eth);
HUPU_INT32 nac_app_get_eth0_ifindex(HUPU_VOID);
HUPU_INT32 nac_app_get_manager_ifindex(HUPU_VOID);
HUPU_INT32 nac_app_get_special_ifindex(HUPU_CHAR *eth_label);
HUPU_INT32 nac_app_get_special_ifaddr_by_label(HUPU_CHAR *eth_label, HUPU_CHAR *eth_addr);
HUPU_INT32 nac_app_clear_if_promisc_mode(HUPU_VOID);
HUPU_INT32 nac_app_get_sys_in_and_out_eth(nac_knl_in_out_eth *in_out_eth);
HUPU_INT32 nac_app_set_knl_in_and_out_eth(nac_knl_in_out_eth *in_out_eth);
HUPU_INT32 nac_system_init_network_ifconfig(HUPU_VOID);

HUPU_INT32 nac_sys_net_enable_eth_device(HUPU_CHAR *eth_name, HUPU_BOOL flag);
HUPU_INT32 nac_system_enable_all_eth_dev(HUPU_VOID);
HUPU_INT32 nac_app_get_netdev_all_status(HUPU_UINT16 index);

#endif // end of NAC_SYSTEM_NET_H
