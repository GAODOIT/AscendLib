#include "nac_app_knl_lib.h"


HUPU_INT32 nac_set_data_to_knl(HUPU_UINT32 subjor, HUPU_UINT32 iden,
                               HUPU_VOID *buff, HUPU_UINT32	ui_len)
{
	NAC_CMD_MSG_HEAD	cmd_h;
	HUPU_INT32			fd;
	int err;

	// �򿪹����豸
	fd = open(NAC_APP_DEV_NAME, 0);
	if(fd < 0)
    {
		printf("%s-->cann't open the cmd device\n", __FUNCTION__);//__FILE__,__LINE__,__FUNCTION__
		return HUPU_ERR;
	}

	// ��ʼ��������Ϣͷ
	cmd_h.major		= NAC_CMD_SET;
	cmd_h.subjor	= subjor;
	cmd_h.iden		= iden;
	cmd_h.data	    = (HUPU_VOID *)(buff);
	cmd_h.data_len	= ui_len;

	// ���Ͳ�����Ϣ
	err = ioctl(fd, NAC_CMD_COMMAND, &cmd_h);
	close(fd);
	return err;
}


HUPU_INT32 nac_get_data_from_knl(HUPU_UINT32 subjor,
                                 HUPU_UINT32 iden,
                                 HUPU_VOID   *buff,
                                 HUPU_UINT32 ui_len)
{
	NAC_CMD_MSG_HEAD	cmd_h;
	HUPU_INT32			fd;
	int err;

	// �򿪹����豸
	fd = open(NAC_APP_DEV_NAME, 0);
	if(fd < 0)
    {
		printf("%s-->cann't open the cmd device\n", __FUNCTION__);
		return HUPU_ERR;
	}

	// ��ʼ��������Ϣͷ
	cmd_h.major		= NAC_CMD_GET;
	cmd_h.subjor	= subjor;
	cmd_h.iden		= iden;
	cmd_h.data	    = (HUPU_VOID *)(buff);
	cmd_h.data_len	= ui_len;

	// ���Ͳ�����Ϣ
	err = ioctl(fd, NAC_CMD_COMMAND, &cmd_h);
	close(fd);
	return err;
}

/*
 * HDR + BLOCK1(attr + policy) + ... + BLOCKn
*/
HUPU_INT32 nac_app_set_data_to_knl(struct nac_knl_policy *pst_ply,
                                   HUPU_UINT32	ply_num,
                                   HUPU_UINT32	user_num,
                                   HUPU_UINT32	*user_list,
                                   const HUPU_UINT32 ui_opt)
{
	struct nac_knl_policy_hdr *hdr;
	nac_knl_policy_attr *attr;
	HUPU_INT32	iret = HUPU_ERR;
    HUPU_UINT32	size;
	HUPU_UINT32	i;

	if(!pst_ply)
    {
		return HUPU_ERR;
	}

	size = sizeof(struct nac_knl_policy_hdr) + sizeof(nac_knl_policy_attr)
	       + sizeof(struct nac_knl_policy) + 4*user_num;

	hdr = (void *)malloc(size);
	hdr->policy_nr = ply_num;

    attr = (void *)((char *)hdr + sizeof(struct nac_knl_policy_hdr));
	attr->t = 0;
	attr->l = sizeof(struct nac_knl_policy) + 4*user_num;
	memcpy(attr->v, pst_ply, sizeof(*pst_ply));
	if(user_num
	   && HUPU_NULL != user_list)
    {
		memcpy(attr->v + sizeof(*pst_ply), user_list, sizeof(unsigned long) * user_num);
		for(i = 0; i < user_num; i++)
        {
			user_list++;
		}
	}

	iret = nac_set_data_to_knl(ui_opt, 0, hdr, size);
	free(hdr);
	return iret;
}


