#ifndef	__NAC_APP_KNL_LOG_H__
#define	__NAC_APP_KNL_LOG_H__

#define NAC_MAX_DEBUG_BUFFER_LEN  			        1024*1024
#define NAC_DEBUG_LOG_FILE_PATH				        "/var/log/nac_asc/"
#define NAC_ERROR_LOG_FILE_FOR_NAC_SYS				"nac_sys_error.log"
#define NAC_DEBUG_LOG_FILE_FOR_NAC_SYS				"nac_sys_debug.log"
#define NAC_DEBUG_LOG_FILE_FOR_NAC_USER		        "nac_sys_user.log"
#define NAC_DEBUG_LOG_FILE_FOR_NAC_DB		        "nac_sys_db.log"
#define NAC_DEBUG_LOG_FILE_FOR_NAC_SOCKET			"nac_sys_socket.log"
#define NAC_DEBUG_LOG_FILE_FOR_NAC_DB_TRANSIT       "nac_sys_db_transit.log"
#define NAC_DEBUG_LOG_FILE_FOR_NAC_AUDIT            "nac_sys_audit.log"
#define NAC_DEBUG_LOG_FILE_FOR_NAC_DDNS             "nac_sys_ddns.log"
//#define NAC_DEBUG_LOG_FILE_FOR_NAC_SYS			"nac_sys.log"

#define NAC_MAX_APP_FILE_SIZE                       1024*1024*6
#define NAC_SYSTEM_PID_FILE							"/var/run/nac_system.pid"

extern HUPU_UINT8	nac_app_advanced_debug_switch;
extern HUPU_UINT8	nac_app_debug_log_switch;

typedef enum
{
	DEBUG_LOG_FOR_NAC_USER = 0,
	DEBUG_LOG_FOR_NAC_SYS,
	DEBUG_LOG_FOR_NAC_DB,
	DEBUG_LOG_FOR_NAC_SOCKET,
	DEBUG_LOG_FOR_NAC_DB_TRANSIT,
	DEBUG_LOG_FOR_AUDIT,
	DEBUG_LOG_FOR_DDNS,
}NAC_DEBUG_LOG_TYPE;

HUPU_VOID nac_lib_create_pid_file(HUPU_CHAR *pc_pid_file_path);

HUPU_INT32 nac_lib_debug(HUPU_INT32 flags,	const HUPU_CHAR *fmt, ...);

#endif

