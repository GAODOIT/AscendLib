#include "nac_precomp.h"
#include "nac_knl_def.h"
#include "nac_app_knl_lib.h"
#include "tpn_user_main.h"

HUPU_INT32 gi_netlink_fd;

HUPU_INT32 user_add()
{
	NAC_KNL_USER_OBJECT	knl_obj;

	// ��ʼ���ں�����
	memset(&knl_obj, 0, sizeof(NAC_KNL_USER_OBJECT));


	knl_obj.ip			= 168428199;
	knl_obj.id			= 11;

	// �����ں�����
	return nac_set_data_to_knl(NAC_CMD_USER_INS, 0, &knl_obj, sizeof(NAC_KNL_USER_OBJECT));

}

HUPU_INT32 user_flush()
{
	// �����ں�����
	return nac_set_data_to_knl(NAC_CMD_USER_FLUSH, 0, NULL, 0);
}

int user_rmv(unsigned long  usr_ip)
{
	return nac_set_data_to_knl(NAC_CMD_USER_RMV, usr_ip, NULL, 0);
}


HUPU_INT32 user_init()
{
    #define MAC_FORMAT(addr) \
        ((unsigned char *)&addr)[0], \
        ((unsigned char *)&addr)[1], \
        ((unsigned char *)&addr)[2], \
        ((unsigned char *)&addr)[3], \
        ((unsigned char *)&addr)[4], \
        ((unsigned char *)&addr)[5]
    user_flush();

    user_add();

    unsigned  char ac_mac[6];
    char buffer[]="00-90-7f-84-50-94";
    sscanf(buffer, "%02x-%02x-%02x-%02x-%02x-%02x",
           (unsigned int *)&ac_mac[0], (unsigned int *)&ac_mac[1],
           (unsigned int *)&ac_mac[2], (unsigned int *)&ac_mac[3],
           (unsigned int *)&ac_mac[4], (unsigned int *)&ac_mac[5]);
    printf("%02X-%02X-%02X-%02X-%02X-%02X\n", MAC_FORMAT(ac_mac));

    //sscanf(mac, "%x:%x:%x:%x:%x:%x", buf, buf+1, buf+2, buf+3, buf+4, buf+5);

    //sscanf(buffer, "%2x-%2x-%2x-%2x-%2x-%2x", &tmp[0],&tmp[1],&tmp[2],&tmp[3],&tmp[4],&tmp[5]);
    //for (i = 0; i < 6; i++)
    //{
    //    ac_mac[i] = (unsigned char)tmp[i];
    //}

    //printf("%02X-%02X-%02X-%02X-%02X-%02X\n", MAC_FORMAT(ac_mac));
    gi_netlink_fd = nac_app_netlink_create(NAC_NETLINK_USER_OPEN);
    if(HUPU_ERR == gi_netlink_fd)
    {
        return HUPU_ERR;
    }
    return gi_netlink_fd;
}

HUPU_INT32 user_handling_from_kernel_msg(HUPU_UINT32 ui_fd)
{
    struct nlmsghdr *pst_netlink_head    = HUPU_NULL;
    NAC_KNL_USER_MSG *pst_add_netlink_usr_msg = HUPU_NULL;

    //HUPU_UINT32 ui_line;
    //HUPU_UINT32 ui_error_code;
    HUPU_INT32 iRet;

    HUPU_CHAR buffer[1024] = {0};
    printf("\nnac_user:user_handling_from_kernel_msg\n");
    /*�����ں�����*/
    iRet = nac_app_netlink_recv(ui_fd, buffer, sizeof(buffer));
    if(iRet <= 0)
    {
        goto HUPU_EXIT_FUNC;
    }

    pst_netlink_head = (struct nlmsghdr *)buffer;
    printf("\nnac_user:pst_netlink_head->nlmsg_type = %d\n", pst_netlink_head->nlmsg_type);
    printf("\nnac_user:pst_netlink_head->nlmsg_len  = %d\n", pst_netlink_head->nlmsg_len);


    pst_add_netlink_usr_msg = (NAC_KNL_USER_MSG *)(buffer + NLMSG_HDRLEN);
    printf("\nnac_user:pst_netlink_head->dst_ip  = %lu\n", pst_add_netlink_usr_msg->dst_ip);
/*
    switch(pst_netlink_head->nlmsg_type)
    {
    case TPN_NETLINK_NEW_USR:
        user_add_ip_mac_user(pst_add_netlink_usr_msg);
        break;
    case TPN_NETLINK_TIMEOUT_USER:
        user_rmv_ip_user(pst_delete_netlink_usr_msg->usr_ip, HUPU_TRUE);
        break;
    case TPN_NETLINK_TC_ADD:
        user_add_tc(pst_usr_flow_msg);
        break;
    case TPN_NETLINK_TC_DEL:
        user_del_tc(pst_usr_flow_msg);
        break;
    case TPN_NETLINK_MAXUSER:
        user_over_maxuser_log();
        break;
    default:
        goto HUPU_EXIT_FUNC;
    }
*/
    return HUPU_OK;

HUPU_EXIT_FUNC:
    return HUPU_ERR;
}



HUPU_INT32 main(HUPU_INT32 argc,HUPU_CHAR *argv[])
{
    HUPU_INT32 iRet;

    HUPU_UINT32 ui_max_fd = 0;
    fd_set readfd;
    struct timeval	st_timeout;

    iRet = user_init();
    printf("\nnac_user:main->user_init, iRet = %d\n", iRet);
    ui_max_fd = MAX_3(0, 0, gi_netlink_fd);
    while(1)
    {
        // ���ó�ʱʱ��5��
    	st_timeout.tv_sec	= 5;
    	st_timeout.tv_usec	= 0;

        FD_ZERO(&readfd);
        FD_SET(gi_netlink_fd, &readfd);
        iRet = select(ui_max_fd + 1,
                      &readfd,
                      HUPU_NULL,
                      HUPU_NULL,
                      &st_timeout);

        if(HUPU_ERR == iRet)
        {
            if(errno == EINTR)
            {
                continue;
            }
            exit(1);
        }
        if(FD_ISSET(gi_netlink_fd, &readfd) > 0)
        {
            //���������ں�ģ�����Ϣ
            user_handling_from_kernel_msg(gi_netlink_fd);
        }
		printf("\nnac_user:main->select, iRet = %d\n", iRet);
    }
    return iRet;
}



