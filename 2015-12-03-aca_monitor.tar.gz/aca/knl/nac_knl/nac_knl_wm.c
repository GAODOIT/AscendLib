#include "include/precomp.h"

#define FREE(p) {kfree(p); p = NULL;}

WM_STRUCT *wm_new(void)
{
	WM_STRUCT *p = (WM_STRUCT *)kmalloc(sizeof(WM_STRUCT), GFP_KERNEL);
	if(!p)
    {
		printk("no memory in wm_new()\n");
		return NULL;
	}

	memset(p, 0, sizeof(*p));
	p->msSmallest = 1000;

	return p;
}

void wm_rmv_single(WM_STRUCT *ps, char *ac_buff)
{
    WM_PATTERN_STRUCT *pst_tmp = ps->plist, *curr = ps->plist, *ppp;
    while(pst_tmp)
    {
        if(memcmp(ac_buff, pst_tmp->psPat, pst_tmp->psLen) == 0)
        {
            ps->msNumPatterns--;
            if(pst_tmp == ps->plist)
            {
               ps->plist = ps->plist->next;
            }
            else
            {
                curr->next = pst_tmp->next;
            }
            ppp = pst_tmp->next;
            FREE(pst_tmp->psPat);
            FREE(pst_tmp);
            pst_tmp = ppp;
        }
        else
        {
            curr = pst_tmp;
            pst_tmp = pst_tmp->next;
        }

    }
    if(ps->msNumPatterns == 0)
    {
        if(ps->msPrefix)
		{
			FREE(ps->msPrefix);
		}

		if(ps->msShift)
		{
			FREE(ps->msShift);
		}

		if(ps->msHash)
		{
			FREE(ps->msHash);
		}

		if(ps->msNumArray)
		{
			FREE(ps->msNumArray);
		}

		if(ps->msPatArray)
		{
			FREE(ps->msPatArray);
		}
		memset(ps, 0, sizeof(*ps));
	    ps->msSmallest = 1000;
    }
}

void wm_free_all(WM_STRUCT *ps)
{
	WM_PATTERN_STRUCT *curr = NULL, *next = NULL;
	int k = 0;

	if(!ps)
	{
		return;
	}

	if(ps->msPrefix)
		FREE(ps->msPrefix);

	if(ps->msShift)
		FREE(ps->msShift);

	if(ps->msHash)
		FREE(ps->msHash);

	if(ps->msNumArray)
		FREE(ps->msNumArray);

	if(ps->msPatArray)
		FREE(ps->msPatArray);

	curr = ps->plist;
	while(k++ < ps->msNumPatterns && curr != NULL)
    {
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "wm free pattern %d-%s\n", k, curr->psPat);
		next = curr->next;
		if(curr->psPat)
			FREE(curr->psPat);
		FREE(curr);
		curr  = next;
	}

	memset(ps, 0, sizeof(*ps));
	ps->msSmallest = 1000;
}

int wm_add_pattern(WM_STRUCT *ps, unsigned char *P, int m, int cls)
{
	WM_PATTERN_STRUCT *p;

	/*The shortest pattern length must be 2*/
	if(!ps || !P || m < 2)
	{
		return NAC_KNL_ERR;
	}

	p = (WM_PATTERN_STRUCT *)kmalloc(sizeof(WM_PATTERN_STRUCT), GFP_ATOMIC);
	if(!p)
    {
		printk("wm_add_pattern:No memory in wm_add_pattern()\n");
		return NAC_KNL_ERR;
	}

	p->psPat = (unsigned char*)kmalloc(m + 1, GFP_ATOMIC);
	if(!p->psPat)
    {
		printk("wm_add_pattern:No memory in wm_add_pattern()\n");
		FREE(p);
		return NAC_KNL_ERR;
	}
	memset(p->psPat + m, 0, 1);

	memcpy(p->psPat, P, m);
	p->psLen = m;
	p->cls   = cls;
	ps->msNumPatterns++;

	if(p->psLen < (unsigned int)ps->msSmallest)
	{
		ps->msSmallest = p->psLen;
	}
	p->next = ps->plist;
	ps->plist = p;
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "wm add pattern %s\n", p->psPat);
	return NAC_KNL_OK;
}

static unsigned int HASH16(unsigned char *T)
{
	return (unsigned short) (((*T) << 8) | *(T + 1));
}

static void wm_sort(WM_STRUCT *ps)
{
	int m = ps->msSmallest;
	int i, j, temp_cls;
	unsigned char *temp;
	int flag;
	unsigned temp_psLen;

	for(i = ps->msNumPatterns - 1, flag = 1; i > 0 && flag; i--)
    {
		flag = 0;
		for(j = 0; j < i; j++)
        {
			if(HASH16(&(ps->msPatArray[j + 1].psPat[m - 2])) < HASH16(&(ps->msPatArray[j].psPat[m - 2])))
            {
				flag = 1;
				temp = ps->msPatArray[j+1].psPat;
				ps->msPatArray[j+1].psPat = ps->msPatArray[j].psPat;
				ps->msPatArray[j].psPat = temp;

				temp_psLen = ps->msPatArray[j+1].psLen;
				ps->msPatArray[j+1].psLen = ps->msPatArray[j].psLen;
				ps->msPatArray[j].psLen = temp_psLen;

				temp_cls = ps->msPatArray[j+1].cls;
				ps->msPatArray[j+1].cls = ps->msPatArray[j].cls;
				ps->msPatArray[j].cls = temp_cls;
			}
		}
	}
}


static void wm_prep_hashed_pattern_groups(WM_STRUCT *ps)
{
	unsigned int sindex, hindex, ningroup;
	int i;
	int m = ps->msSmallest;

	ps->msNumHashEntries = HASHTABLESIZE;
	ps->msHash = (HASH_TYPE * )kmalloc(sizeof(HASH_TYPE) * ps->msNumHashEntries, GFP_ATOMIC);
	if(!ps->msHash)
    {
		printk("KTPN_WM:No memory for wm_prep_hashed_pattern_groups()\n");
		return;
	}

	for(i = 0; i < (int)ps->msNumHashEntries; i++)
    {
		ps->msHash[i] = -1;
	}

	for(i = 0; i < ps->msNumPatterns; i++)
    {
		hindex = HASH16(&ps->msPatArray[i].psPat[m - 2]);
		sindex = ps->msHash[hindex] = i;
		ningroup = 1;
		while((++i < ps->msNumPatterns) && (hindex == HASH16(&ps->msPatArray[i].psPat[m - 2])))
		{
			ningroup++;
		}
		ps->msNumArray[sindex] = ningroup;
		i--;
	}
}


static void wm_prep_shift_table(WM_STRUCT *ps)
{
	int i;
	unsigned short m, k, cindex;
	unsigned int shift;

	m = (unsigned short)ps->msSmallest;
	ps->msShift = (unsigned char *)kmalloc(SHIFTTABLESIZE * sizeof(char), GFP_ATOMIC);
	if(!ps->msShift)
	{
		return;
	}

	for(i = 0; i < SHIFTTABLESIZE; i++)
    {
		ps->msShift[i] = (unsigned int)(m - 2 + 1);
	}

	for(i = 0; i < ps->msNumPatterns; i++)
    {
		for(k = 0; k < m - 1; k++)
        {
			shift  = (unsigned short)(m - 2 - k);
			cindex = ((ps->msPatArray[i].psPat[k] << 8) | (ps->msPatArray[i].psPat[k + 1]));
			if(shift < ps->msShift[cindex])
			{
				ps->msShift[cindex] = shift;
			}
		}
	}
}


static void wm_prep_prefix_table(WM_STRUCT *ps)
{
	int i;

	ps->msPrefix = (HASH_TYPE *)kmalloc(sizeof(HASH_TYPE) * ps->msNumPatterns, GFP_ATOMIC);
	if(!ps->msPrefix)
    {
		printk("wm_prep_prefix_table:No memory in wm_prep_prefix_table()\n");
		return;
	}
	for(i = 0; i < ps->msNumPatterns; i++)
    {
		ps->msPrefix[i] = HASH16(ps->msPatArray[i].psPat);
	}
}


int wm_group_match(WM_STRUCT *ps, int lindex,
	               unsigned char *Tx, unsigned char *T)
{
	WM_PATTERN_STRUCT *patrn;
	WM_PATTERN_STRUCT *patrnEnd;
	int text_prefix;
	unsigned char *px, *qx;

	if(!ps || !Tx || !T)
	{
		return NAC_KNL_ERR;
	}

	patrn = &ps->msPatArray[lindex];
	patrnEnd = patrn + ps->msNumArray[lindex];
	text_prefix = HASH16(T);

	for(;patrn && patrn < patrnEnd; patrn ++)
    {
		if(ps->msPrefix[lindex++] != text_prefix)
		{
			continue;
		}
		else
        {
			px = patrn->psPat;
			qx = T;
			while(*(px++) == *(qx++) && *(qx - 1) != '\0');
			if(*(px - 1) == '\0')
            {
				nac_knl_debug(NAC_KNL_MODULE_POLICY, "wm match %s, cls %d offset=%d\n",
					          patrn->psPat, patrn->cls, T-Tx + patrn->psLen );
				return patrn->cls?:T-Tx + patrn->psLen;
			}
		}
	}
	return NAC_KNL_OK;
}


int wm_prep_patterns(WM_STRUCT *ps)
{
	int kk;
	WM_PATTERN_STRUCT *plist;

	if(!ps || !ps->msNumPatterns)
	{
		return NAC_KNL_ERR;
	}

	ps->msPatArray = (WM_PATTERN_STRUCT *)kmalloc(sizeof(WM_PATTERN_STRUCT) * ps->msNumPatterns, GFP_ATOMIC);
	if(!ps->msPatArray)
    {
		printk("wm_prep_patterns:No memory in wm_prep_patterns()\n");
		return NAC_KNL_ERR;
	}
	ps->msNumArray = (unsigned short * )kmalloc(sizeof(short) * ps->msNumPatterns, GFP_ATOMIC);
	if(!ps->msNumArray)
    {
		printk("wm_prep_patterns:No memory in wm_prep_patterns()\n");
		FREE(ps->msPatArray);
		return NAC_KNL_ERR;
	}

	for(kk = 0, plist = ps->plist; plist != NULL && kk < ps->msNumPatterns; plist = plist->next)
    {
		memcpy(&ps->msPatArray[kk ++], plist, sizeof(WM_PATTERN_STRUCT));
	}

	wm_sort(ps);
	wm_prep_hashed_pattern_groups(ps);
	wm_prep_shift_table(ps);
	wm_prep_prefix_table(ps);

	return NAC_KNL_OK;
}


int wm_search(WM_STRUCT *ps, unsigned char *Tx, int n)
{
	int Tleft, lindex, tshift, cls;
	unsigned char *T, *Tend, *window;

	if(!ps || !Tx || !n)
	{
		return NAC_KNL_ERR;
	}

	Tleft = n;
	Tend  = Tx + n;

	if(n < ps->msSmallest)
	{
		return NAC_KNL_ERR;
	}

	for(T = Tx, window = Tx + ps->msSmallest - 1; window < Tend; T++, window++, Tleft--)
    {
		tshift = ps->msShift[(*(window - 1) << 8) | *window];
		while(tshift)
        {
			window += tshift;
			T      += tshift;
			Tleft  -= tshift;
			if(window > Tend)
			{
				return NAC_KNL_ERR;
			}
			tshift = ps->msShift[(*(window - 1) << 8) | *window];
		}

		if((lindex = ps->msHash[(*(window - 1) << 8) | *window]) == (HASH_TYPE)-1)
		{
			continue;
		}

		lindex = ps->msHash[(*(window - 1) << 8) | *window];
		if((cls = wm_group_match(ps, lindex, Tx, T)) > 0)
        {
			return cls;
		}
	}

	return NAC_KNL_OK;
}

void wm_show(WM_STRUCT *ps)
{
    char ac_buf[200];
    struct wm_pattern_struct *pst_tmp = ps->plist;
    while(pst_tmp)
    {
        memset(ac_buf, '\0', sizeof(ac_buf));
        if(pst_tmp->psLen < sizeof(ac_buf) - 1)
        {
            memcpy(ac_buf, pst_tmp->psPat, pst_tmp->psLen);
            if(GLOBAL_DOMAIN == pst_tmp->cls)
            {
                nac_knl_debug(NAC_KNL_MODULE_POLICY, "url = %s\n", ac_buf);
            }
            else
            {
                nac_knl_debug(NAC_KNL_MODULE_POLICY, "url = %s, isolation_id = %d\n", ac_buf, pst_tmp->cls);
            }
        }
        pst_tmp = pst_tmp->next;
    }
}

