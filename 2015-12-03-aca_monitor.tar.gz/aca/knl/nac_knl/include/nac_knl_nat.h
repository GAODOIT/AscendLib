#ifndef __NAC_KNL_NAT_H__
#define __NAC_KNL_NAT_H__

#define NAT_HASH_MAP_SIZE 2048

#define NAT_TIME 60

#define ARRAYLEN(a)	(sizeof(a)/sizeof(a[0]))

typedef enum
{
    OTHERS = 0,
    LINUX,
    WINDOWS,
    ANDROID,
    IOS,
    OSX,
    WPHONE,
    TYPE_MAX
} USER_AGENT_TYPE;


typedef struct NAC_KNL_NAT_STRU
{
    struct list_head  nat_list;
	struct hlist_node nat_ip;
	struct rcu_head   nat_rcu;
	unsigned long src_ip;
    unsigned long last_time;

    unsigned long time;

    unsigned long ttl_time;

    unsigned long timestamp;
    unsigned long timestamp_time;
    unsigned long agent_time;
    unsigned long window_time;
    unsigned long shift_time;

    //unsigned long id_find_time_first;
    unsigned long ttl_first_time;
    unsigned short window;
    unsigned char shift;
    unsigned char shift_count;
    unsigned char window_count;
	unsigned char ttl;
    unsigned char ttl_count:4, agent_count:2, time_count:2;
    unsigned char is_nat:2, agent:6;
}NAC_KNL_NAT;


struct options_received_tcp {

	long	ts_recent_stamp;
	unsigned int ts_recent;
	unsigned int	rcv_tsval;
	unsigned int	rcv_tsecr;
	unsigned short 	saw_tstamp : 1,
		tstamp_ok : 1,
		dsack : 1,
		wscale_ok : 1,
		sack_ok : 4,
		snd_wscale : 4,
		rcv_wscale : 4;
	unsigned char	cookie_plus:6,
		cookie_out_never:1,
		cookie_in_always:1;
	unsigned char	num_sacks;
	unsigned short	user_mss;
	unsigned short	mss_clamp;
};


typedef enum
{
    NAT_ENABLE = 1,
    NAT_DISABLE,
    NAT_NULL,
}NAC_SWIC;

extern unsigned char nat_swit;
extern unsigned int nat_ip_num;


void nac_knl_nat_set_swit(unsigned char swit);
void nac_knl_nat_check(struct sk_buff *skb, char is_agent_flag, unsigned int *agent_cls);
int nac_knl_nat_add(NAC_KNL_NAT *pst_nac_knl_nat, int len);
int nac_knl_nat_del(const NAC_KNL_NAT *pst_nac_knl_nat, int len);
void nac_knl_nat_timeout(unsigned long now, char *pc_time);
int nac_knl_nat_init(void);
void nac_knl_nat_exit(void);

#endif

