#ifndef	__PRECOMP_H__
#define	__PRECOMP_H__



///////////////////////////////////////
#include <linux/module.h>
#include <linux/spinlock.h>
#include <linux/skbuff.h>
#include <linux/times.h>
#include <asm/uaccess.h>
#include <asm/percpu.h>
#include <linux/version.h>

#include <linux/netfilter.h>
#include <linux/netfilter/nfnetlink_conntrack.h>
#include <linux/netfilter_bridge.h>
#include <linux/netfilter_ipv4.h>
#include <net/netfilter/nf_conntrack_core.h>
#include <net/netfilter/nf_conntrack.h>
#include <linux/ip.h>
#include <linux/if_arp.h>
#include <net/xfrm.h>
#include <linux/tcp.h>
#include <linux/icmp.h>
#include <net/icmp.h>
#include <net/tcp.h>
#include <linux/inetdevice.h>
#include <linux/list.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <net/snmp.h>
#include <net/arp.h>
#include <linux/kthread.h>
#include <linux/rtc.h>
#include "net/pkt_sched.h"
#include <linux/if_arp.h>
#include <linux/if_bridge.h>
#include <linux/ppp_defs.h>
#include <linux/sched.h>
#include <linux/netdevice.h>
#include <linux/nls.h>
#include <linux/rbtree.h>
#include <linux/rwsem.h>

#include "nac_knl_log.h"
#include "nac_net_core.h"
#include "nac_knl_sys.h"
#include "nac_knl_ioctl.h"
#include "nac_knl_policy.h"
#include "nac_knl_user.h"
#include "nac_knl_netlink.h"
#include "nac_knl_proc.h"
#include "nac_knl_rbtree.h"
#include "nac_knl_algorithm.h"
#include "nac_knl_wm.h"
#include "nac_knl_url.h"
#include "nac_knl_pbr.h"
#include "nac_knl_mvg.h"
#include "nac_knl_bridge.h"
#include "nac_knl_domain.h"
#include "nac_knl_nat.h"
#include "nac_knl_protocol.h"

#endif

