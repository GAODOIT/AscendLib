#ifndef	__NAC_KNL_POLICY_H__
#define	__NAC_KNL_POLICY_H__

extern unsigned short vlan_ago_after_map_table[];

extern struct list_head *nac_knl_policy_pool[];
extern struct nac_knl_net_app gst_net_app;
extern struct nac_knl_ip_info gst_ip_info;

extern unsigned int ui_redirect_ip;
extern unsigned int ui_control_manager_ip;
extern unsigned int ui_server_manager_ip;
extern unsigned int ui_control_untrust_ip;
extern unsigned int ui_control_untrust_ip;
extern unsigned int os_check_swit;

extern unsigned int ui_vrrp_ip;

extern char ac_get_proxy[];

#define WEIDUN_SERVER_PORT 8237

#define TIME_RANGE_NR 4

#define VLAN_MAX_RANGE 4097

#define GLOBAL_DOMAIN 0x7FFFFFFF

/*
*TPN policy operation code.
*We use this code to diff some implict policy
*/
enum
{
	NAC_KNL_POL_OP_TPNCT, 		/* route-mark, ipdeny, fw, ip/mac */
	NAC_KNL_POL_OP_TC = 1, 		/* appctl */
	NAC_KNL_POL_OP_APPCTL, 		/* appctl */
	NAC_KNL_POL_OP_APP_FILTER,	/* appfilter */
	NAC_KNL_POL_OP_SS_TC,		/* user static shared tc */
	NAC_KNL_POL_OP_ABN_TC,		/* user application balance nest tc */
	NAC_KNL_POL_OP_URL,
	NAC_KNL_POL_OP_L7,
	NAC_KNL_POL_OP_URLSEARCH,
	NAC_KNL_POL_OP_VLAN,
	NAC_KNL_POL_OP_QQBLACKLIST,
};

typedef enum
{
    NAC_MVG_MODE = 1,
    NAC_PBR_MODE,
    NAC_BRIDGE_MODE,
    NAC_8021X_MODE,
    NAC_NULL_MODE,
}NAC_MODE;

extern NAC_MODE nac_mode;

#define NAC_KNL_NR_LINE 16
#define NAC_KNL_ALIGN   16
#define IPPROTO_TCP_UDP 0



struct nac_knl_line_attr
{
	unsigned long ispid;
	unsigned long mark;
};
struct nac_knl_net_app
{
	unsigned short	switc;  //0-->close  1-->open
    unsigned short	times;  //time_number
	unsigned short	dst_port;//ntohs
	unsigned short	protocol;//tcp=6,udp=17,any=0;
	unsigned int 	cycle;
};


typedef enum
{
    NAC_KNL_POLICY_DROP     = 0,
	NAC_KNL_POLICY_REDIRECT = 1,
}ENUM_POLICY_REDIRECT;

struct nac_knl_ip_info
{
	char ac_redirect_ip[16];
    char ac_control_manager_ip[16];
    char ac_control_untrust_ip[16];
    char ac_control_trust_ip[16];
    char ac_server_manager_ip[16];
    ENUM_POLICY_REDIRECT en_redirect_flag;
};


#define NAC_KNL_NR_APP_PROTO	1024

#define NAC_KNL_POLICY_KEYLEN (128)
#define NAC_KNL_POLICY_CODELEN (128 - 14)

/* Object bitmap */
enum
{
	NAC_KNL_OBJ_TM,
	NAC_KNL_OBJ_D_TC,
	NAC_KNL_OBJ_S_TC,
	NAC_KNL_OBJ_URL,
	NAC_KNL_OBJ_FILE,
	NAC_KNL_OBJ_NUM,
};

/* NAC_KNL policy type */
typedef enum
{
	NAC_KNL_POLICY_NONE,
	NAC_KNL_POLICY_OBJ,

	NAC_KNL_POLICY_MODE,
	NAC_KNL_POLICY_VLAN_MAP,
	NAC_KNL_POLICY_BYPASS_IP_RANGE,
	NAC_KNL_POLICY_BYPASS, /* Bellow hash list */

	NAC_KNL_POLICY_NUM,
}ENUM_POLICY_TYPE;

struct nac_knl_time_range
{
	unsigned int start_sec;
	unsigned int end_sec;    /* seconds */
};

struct nac_knl_obj_time
{
	struct nac_knl_time_range range[TIME_RANGE_NR];
	unsigned int week:7, nr:25;
};


struct nac_knl_obj
{
	unsigned int obj_bit;
	union
    {
        struct nac_knl_obj_time tm;
	}uni;
};


struct nac_knl_policy_entry
{
	unsigned short  sync:2, type:10, op:4;

	unsigned short andid; /* after set, we must go thru all the policy with the proper andid and decide which action should deploy */

	int priority;

	union
    {
		struct
        {
			unsigned long mark;
			unsigned long link_id;
		}route;

		struct
        {
			unsigned long action;
		}acl;

		struct
        {
			unsigned long action;
			unsigned long bitmap[NAC_KNL_NR_APP_PROTO/32];
			struct
            {
				unsigned char gb2312[NAC_KNL_POLICY_KEYLEN];
				unsigned char utf8[NAC_KNL_POLICY_KEYLEN];
 			}filter;
		}appctl, apptc, appfilter;

		struct
		{
			unsigned long ena:1, ctl:3, fena:1, fctl:3, expr:4;
			unsigned long app_id;
			unsigned long filesize;
			char key[NAC_KNL_POLICY_KEYLEN];
		}audit;

		struct
        {
			unsigned long action;
		}url;

		struct
        {
			unsigned long action;
			unsigned char gb2312[NAC_KNL_POLICY_CODELEN];
			unsigned char utf8[NAC_KNL_POLICY_CODELEN];
		}search;

		struct
        {
			unsigned long app_id;
		} app_custom;
        struct nac_knl_obj obj;
	}u;

	/* Support 32 obj type */
	unsigned long obj_mask;

	unsigned short obj_id[NAC_KNL_OBJ_NUM];
	unsigned short policy_id;

	unsigned short obj_size; 	/* used by kernel */
	unsigned char obj[0];		/* used by kernel */
};



struct nac_knl_selector
{
	union
    {
		struct
        {
			unsigned long min_addr;
			unsigned long max_addr;
		}bypass_ipseg;


		struct
        {
			unsigned long dst_addr;
		}bypass;

		struct
        {
			unsigned long addr_min;
			unsigned long addr_max;
			unsigned short port_min;
			unsigned short port_max;
			unsigned char protocol;
		} app_custom;
	}u;
};

typedef struct nac_knl_policy_attr_stru
{
	unsigned short t;
	unsigned short l;
	unsigned char v[0];
}nac_knl_policy_attr;

struct nac_knl_policy
{
	struct nac_knl_selector selector;
	struct nac_knl_policy_entry entry;
	struct list_head policy_list;

	unsigned short u_nr;
	unsigned short g_nr;
	unsigned long id_list[0];
};

typedef struct nac_knl_policy_vlap_stru
{
    unsigned short insulate_vlan;
    unsigned short pass_vlan;
}nac_knl_policy_vlap;

typedef struct nac_knl_policy_pass_ip_stru
{
    unsigned long ip_min;
    unsigned long ip_max;
}nac_knl_policy_pass_ip;



/* Align to 16 */
struct nac_knl_policy_hdr
{
	unsigned long policy_nr;
};

typedef struct nac_knl_eth3_mac_stru
{
    char ac_eth3_mac[ETH_ALEN];
    char ac_eth3_sw_mac[ETH_ALEN];
}nac_knl_eth3_mac;

typedef struct nac_knl_in_out_eth_stru
{
    char ac_in_eth[6];
    char ac_out_eth[6];
    unsigned short us_in_index;
    unsigned short us_out_index;
}nac_knl_in_out_eth;


extern nac_knl_eth3_mac st_eth3;
extern nac_knl_in_out_eth st_in_out_eth;


#define TPN_PEL (ALIGN(sizeof( struct nac_knl_policy_entry), TPN_ALIGN))

int nac_knl_policy_set_mode(NAC_MODE nac_mode_tmp);
int nac_knl_policy_set_os_check(unsigned int flag);
int nac_knl_policy_pbr_2_eth_switch(int eth_switch);
int nac_knl_policy_pbr_2_eth_mac(nac_knl_eth3_mac *pst_eth3, unsigned int len);
int nac_knl_policy_eth0_mac(char *pc_mac, unsigned int len);
int nac_knl_policy_in_out_eth(nac_knl_in_out_eth *pst_in_out_eth, unsigned int len);
int nac_knl_policy_set_vlan_map(const nac_knl_policy_vlap *pst_vlan_map, unsigned int len, int action);
int nac_knl_policy_set_bypass(const nac_knl_policy_pass_ip *pst_pass_ip, unsigned int len);
int nac_knl_policy_set_ip_info(const struct nac_knl_ip_info *pst_ip_info, unsigned int len);
int nac_knl_policy_set_net_app(const struct nac_knl_net_app *pst_net_app, unsigned int len);
int nac_knl_policy_add(const struct nac_knl_policy_hdr *hdr, unsigned int len);
int nac_knl_policy_del(const struct nac_knl_policy_hdr *hdr, unsigned int len);
int __nac_knl_lookup_policy(ENUM_POLICY_TYPE type, void *buf, int len);
void nac_knl_policy_flush(ENUM_POLICY_TYPE policy_type);
int nac_knl_policy_show(void);

int nac_knl_policy_init(void);
void nac_knl_policy_exit(void);


#endif

