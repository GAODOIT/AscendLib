#ifndef	__NAC_KNL_MVG_H__
#define	__NAC_KNL_MVG_H__

extern unsigned short vlan_ago_after_map_table[VLAN_MAX_RANGE]; //vlan_ago_after_map_table[0] no use
extern unsigned char vlan_in_index[VLAN_MAX_RANGE];
extern unsigned char vlan_out_index[VLAN_MAX_RANGE];

int nac_knl_mvg(struct sk_buff *skb, unsigned short vlan_id);
int nac_knl_mvg_init(void);

#endif

