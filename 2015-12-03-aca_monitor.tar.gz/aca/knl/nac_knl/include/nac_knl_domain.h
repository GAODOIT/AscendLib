#ifndef	__NAC_KNL_DOMAIN_H__
#define	__NAC_KNL_DOMAIN_H__


#define	DOMAIN_HASH_MAP_SIZE 1024

extern atomic_t g_domain_number;

typedef struct NAC_KNL_DOMAIN_OBJECT_STRU
{
	struct list_head  domain_list;
	struct hlist_node domain_ip;
	struct rcu_head   domain_rcu;

    atomic_t refcnt;
	unsigned int src_ip;
    unsigned short src_port;
    unsigned long last_time;
}NAC_KNL_DOMAIN_OBJECT;


int nac_knl_domain_add(const NAC_KNL_DOMAIN_OBJECT *pst_domain, int len);
int nac_knl_domain_flush(void);
int nac_knl_domain_del(const NAC_KNL_DOMAIN_OBJECT *pst_domain, int len);
void nac_knl_domain_timeout(unsigned long now, char *pc_time);
int nac_knl_domain_get_hash_by_mac(const unsigned char *mac);
NAC_KNL_DOMAIN_OBJECT * __nac_knl_domain_find_by_ip(unsigned long ip, unsigned short sport, unsigned short dport);
NAC_KNL_DOMAIN_OBJECT * __nac_knl_domain_find(unsigned long ip, unsigned short sport, unsigned short dport);

int nac_knl_domain_init(void);
void nac_knl_domain_exit(void);

#endif

