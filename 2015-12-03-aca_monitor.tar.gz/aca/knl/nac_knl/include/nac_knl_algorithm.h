#ifndef	__NAC_KNL_ALGORITHM_H__
#define	__NAC_KNL_ALGORITHM_H__

#define MAX_CHAR_SIZE 256

#define HTTP_KEY_WORD  " HTTP/1.1"
#define HOST_KEY_WORD  "Host: "
#define USER_AGENT_KEY_WORD "User-Agent: "

#define ENTER_KEY_WORD "\r\n"

void nac_knl_setCharStep(char *subStr, int *charStep);
int nac_knl_looup_string(char *mainStr, char *subStr, int *charStep);

#endif

