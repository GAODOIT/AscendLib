#include "include/precomp.h"

struct nac_knl_rbtree_node
{
	struct rb_node node;
	struct nac_knl_rbtree_entry entry;
};


static struct rb_root nac_knl_ipseg_tree           = RB_ROOT;
static struct rb_root nac_knl_insulate_tree        = RB_ROOT;
static struct rb_root nac_knl_except_terminal_tree = RB_ROOT;
static struct rb_root nac_knl_except_net_app_tree  = RB_ROOT;
static struct rb_root nac_knl_except_server_tree   = RB_ROOT;
static struct rb_root nac_knl_except_port_tree     = RB_ROOT;
static struct rb_root nac_knl_except_domain_tree   = RB_ROOT;
static struct rb_root nac_knl_exmpt_ip_tree        = RB_ROOT;
static struct rb_root nac_knl_exmpt_mac_tree       = RB_ROOT;
static struct rb_root nac_knl_exmpt_ip_mac_tree    = RB_ROOT;
static struct rb_root nac_knl_weidun_tree          = RB_ROOT;
static struct rb_root nac_knl_nat_server_tree      = RB_ROOT;
static struct rb_root nac_knl_dhcp_server_tree     = RB_ROOT;


static struct rb_root *nac_knl_rbtree_root[NAC_KNL_RBTREE_NUM] =
{
	NULL,
	&nac_knl_ipseg_tree,
	&nac_knl_insulate_tree,
	&nac_knl_except_terminal_tree,
	&nac_knl_except_net_app_tree,
	&nac_knl_except_server_tree,
	&nac_knl_except_port_tree,
	&nac_knl_except_domain_tree,
	&nac_knl_exmpt_ip_tree,
	&nac_knl_exmpt_mac_tree,
	&nac_knl_exmpt_ip_mac_tree,
	&nac_knl_weidun_tree,
	&nac_knl_nat_server_tree,
	&nac_knl_dhcp_server_tree,
};

static DEFINE_SPINLOCK(nac_knl_rbtree_root_rwsem);

void nac_knl_rbtree_read_lock(void)
{
	//read_lock(&nac_knl_rbtree_root_rwsem);
}

void nac_knl_rbtree_read_unlock(void)
{
	//read_unlock(&nac_knl_rbtree_root_rwsem);
}


/* the lower version has't this function. so copy it to here. */
static inline void nac_knl_rb_init_node(struct rb_node *rb)
{
	rb->rb_parent_color = 0;
	rb->rb_right = NULL;
	rb->rb_left = NULL;
	RB_CLEAR_NODE(rb);
}

static int nac_knl_rbtree_entry_invalid(struct nac_knl_rbtree_entry *entry)
{
	if(entry->type <= NAC_KNL_RBTREE_NONE || entry->type >= NAC_KNL_RBTREE_NUM)
	{
		return NAC_KNL_ERR;
	}

	return NAC_KNL_OK;
}

static void nac_knl_rbtree_show_entry(const char *prefix, struct nac_knl_rbtree_entry *ety)
{
    unsigned int ip_min = htonl(ety->union_rbtree.ip.ip_min);
    unsigned int ip_max = htonl(ety->union_rbtree.ip.ip_max);
    unsigned int ip     = htonl(ety->union_rbtree.port.ip_addr);

	switch(ety->type)
    {
    case NAC_KNL_RBTREE_EXCEPT_TERMINAL:
    case NAC_KNL_RBTREE_EXCEPT_NET_APP:
    case NAC_KNL_RBTREE_EXCEPT_SERVER:
    case NAC_KNL_RBTREE_EXCEPT_DOMAIN:
    case NAC_KNL_RBTREE_IP_RANGE:
    case NAC_KNL_RBTREE_NETAPP_SERVER:
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "%d.%d.%d.%d<--->%d.%d.%d.%d\n", NIPQUAD(ip_min), NIPQUAD(ip_max));
		break;
    case NAC_KNL_RBTREE_NAT_SERVER:
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "%d.%d.%d.%d<--->%d.%d.%d.%d %s\n", NIPQUAD(ip_min), NIPQUAD(ip_max), ety->union_rbtree.ip.isolation_id == 1?"enable":"disable");
		break;
    case NAC_KNL_RBTREE_EXCEPT_MAC:
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "%02X-%02X-%02X-%02X-%02X-%02X\n", MAC_FORMAT(ety->union_rbtree.mac.ac_mac));
        break;
    case NAC_KNL_RBTREE_EXCEPT_IP_MAC:
        //ip = htonl(ety->union_rbtree.ip_mac.ip_addr);
        //nac_knl_debug(NAC_KNL_MODULE_POLICY, "%d.%d.%d.%d---%02X-%02X-%02X-%02X-%02X-%02X\n", NIPQUAD(ip), MAC_FORMAT(ety->union_rbtree.ip_mac.ac_mac));
        break;
    case NAC_KNL_RBTREE_ISOLATION_ZONE:
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "%d.%d.%d.%d<--->%d.%d.%d.%d, id = %u\n", NIPQUAD(ip_min), NIPQUAD(ip_max), ety->union_rbtree.ip.isolation_id);
        break;
    case NAC_KNL_RBTREE_HTTP_PROXY_SERVER:
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "%d.%d.%d.%d<--->%d.%d.%d.%d\n", NIPQUAD(ip_min), NIPQUAD(ip_max));
        break;
    case NAC_KNL_RBTREE_EXCEPT_PORT:
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "dst_ip = %d.%d.%d.%d, dport = %d, protocol = %d\n", NIPQUAD(ety->union_rbtree.port.ip_addr), ety->union_rbtree.port.dst_port, ety->union_rbtree.port.protocol);
        break;
    case NAC_KNL_RBTREE_DHCP_SERVER:
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "ip = %d.%d.%d.%d\n", NIPQUAD(ip));
        break;
	default:
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "nac_knl_rbtree_show_entry error-->rbtree entry type: %d\n", ety->type);
        break;
	}
}


static int nac_knl_rbtree_entry_locate(struct nac_knl_rbtree_entry *ety,
                                       struct nac_knl_rbtree_entry *cur,
                                       int locate_type)
{
	if(ety->type != cur->type)
	{
		return NAC_KNL_RBTREE_LOC_WRONG;
	}

	switch(ety->type)
    {
    case NAC_KNL_RBTREE_EXCEPT_TERMINAL:
    case NAC_KNL_RBTREE_EXCEPT_NET_APP:
    case NAC_KNL_RBTREE_EXCEPT_SERVER:
    case NAC_KNL_RBTREE_EXCEPT_DOMAIN:
    case NAC_KNL_RBTREE_IP_RANGE:
    case NAC_KNL_RBTREE_ISOLATION_ZONE:
    case NAC_KNL_RBTREE_EXCEPT_IP_MAC:
    case NAC_KNL_RBTREE_NETAPP_SERVER:
    case NAC_KNL_RBTREE_NAT_SERVER:
    case NAC_KNL_RBTREE_HTTP_PROXY_SERVER:
		switch (locate_type)
        {
		case NAC_KNL_RBTREE_LOC_TYPE_INS:
		case NAC_KNL_RBTREE_LOC_TYPE_DEL:
			if (ety->union_rbtree.ip.ip_max < cur->union_rbtree.ip.ip_min)
			{
				return NAC_KNL_RBTREE_LOC_LEFT;
			}

			if (ety->union_rbtree.ip.ip_min > cur->union_rbtree.ip.ip_max)
			{
				return NAC_KNL_RBTREE_LOC_RIGHT;
			}

			if (ety->union_rbtree.ip.ip_min == cur->union_rbtree.ip.ip_max)
			{
				return NAC_KNL_RBTREE_LOC_MATCH;
			}
			break;

		case NAC_KNL_RBTREE_LOC_TYPE_SRH:
			if(ety->union_rbtree.ip_key.ip_addr < cur->union_rbtree.ip.ip_min)
			{
				return NAC_KNL_RBTREE_LOC_LEFT;
			}

			if(ety->union_rbtree.ip_key.ip_addr > cur->union_rbtree.ip.ip_max)
			{
				return NAC_KNL_RBTREE_LOC_RIGHT;
			}

			return NAC_KNL_RBTREE_LOC_MATCH;

		default:
			break;
		}
		break;
    case NAC_KNL_RBTREE_EXCEPT_PORT:
        switch (locate_type)
        {
		case NAC_KNL_RBTREE_LOC_TYPE_INS:
		case NAC_KNL_RBTREE_LOC_TYPE_DEL:
        case NAC_KNL_RBTREE_LOC_TYPE_SRH:
			if (ety->union_rbtree.port.dst_port < cur->union_rbtree.port.dst_port)
			{
				return NAC_KNL_RBTREE_LOC_RIGHT;
			}
			if (ety->union_rbtree.port.dst_port > cur->union_rbtree.port.dst_port)
			{
				return NAC_KNL_RBTREE_LOC_LEFT;
			}
            return NAC_KNL_RBTREE_LOC_MATCH;
		default:
			break;
		}
        break;
    case NAC_KNL_RBTREE_DHCP_SERVER:
        switch (locate_type)
        {
		case NAC_KNL_RBTREE_LOC_TYPE_INS:
		case NAC_KNL_RBTREE_LOC_TYPE_DEL:
        case NAC_KNL_RBTREE_LOC_TYPE_SRH:
			if (ety->union_rbtree.port.ip_addr < cur->union_rbtree.port.ip_addr)
			{
				return NAC_KNL_RBTREE_LOC_RIGHT;
			}
			if (ety->union_rbtree.port.ip_addr > cur->union_rbtree.port.ip_addr)
			{
				return NAC_KNL_RBTREE_LOC_LEFT;
			}
            return NAC_KNL_RBTREE_LOC_MATCH;
		default:
			break;
		}
        break;
    case NAC_KNL_RBTREE_EXCEPT_MAC:
        switch (locate_type)
        {
		case NAC_KNL_RBTREE_LOC_TYPE_INS:
		case NAC_KNL_RBTREE_LOC_TYPE_DEL:
        case NAC_KNL_RBTREE_LOC_TYPE_SRH:
            if(memcmp(ety->union_rbtree.mac.ac_mac, cur->union_rbtree.mac.ac_mac, ETH_ALEN) < 0)
			{
				return NAC_KNL_RBTREE_LOC_RIGHT;
			}
			if(memcmp(ety->union_rbtree.mac.ac_mac, cur->union_rbtree.mac.ac_mac, ETH_ALEN) > 0)
			{
				return NAC_KNL_RBTREE_LOC_LEFT;
			}
            return NAC_KNL_RBTREE_LOC_MATCH;
		default:
			break;
		}
		break;
/*
    case NAC_KNL_RBTREE_INSULATE:
        switch(locate_type)
        {
        case NAC_KNL_RBTREE_LOC_TYPE_INS:
	    case NAC_KNL_RBTREE_LOC_TYPE_DEL:
        case NAC_KNL_RBTREE_LOC_TYPE_SRH:
            if(ety->u.qq.qq_number > cur->u.qq.qq_number)
            {
                return NAC_KNL_RBTREE_LOC_LEFT;
            }
            if(ety->u.qq.qq_number < cur->u.qq.qq_number)
            {
                return NAC_KNL_RBTREE_LOC_RIGHT;
            }
            return NAC_KNL_RBTREE_LOC_MATCH;
        }
        break;
*/
	default:
		break;
	}
	return NAC_KNL_RBTREE_LOC_WRONG;
}


int nac_knl_rbtree_insert(struct nac_knl_rbtree_entry *ety, int len)
{
	int err = NAC_KNL_OK;
	struct nac_knl_rbtree_node * trnode = NULL;

	struct rb_root * root = NULL;
	struct rb_node **new = NULL;
	struct rb_node *parent = NULL;
	struct nac_knl_rbtree_node *this = NULL;
	int location;

	if(len < sizeof(struct nac_knl_rbtree_entry) || NAC_KNL_OK != nac_knl_rbtree_entry_invalid(ety))
	{
		return -EINVAL;
	}

	trnode = kmalloc(sizeof(struct nac_knl_rbtree_node), GFP_KERNEL);
	if(!trnode)
    {
		err = -ENOMEM;
		goto out;
	}

	if(0 != copy_from_user(&trnode->entry, ety, sizeof(struct nac_knl_rbtree_entry)))
    {
        err = -EACCES;
        kfree(trnode);
        goto out;
	}

	nac_knl_rb_init_node(&trnode->node);

	spin_lock_bh(&nac_knl_rbtree_root_rwsem);

	root = nac_knl_rbtree_root[ety->type];
	new = &(root->rb_node);

	while(*new)
    {
		parent = *new;
		this = rb_entry(*new, struct nac_knl_rbtree_node, node);

		location = nac_knl_rbtree_entry_locate(&trnode->entry, &this->entry, NAC_KNL_RBTREE_LOC_TYPE_INS);

		if(location == NAC_KNL_RBTREE_LOC_LEFT)
		{
			new = &((*new)->rb_left);
		}
		else if(location == NAC_KNL_RBTREE_LOC_RIGHT)
		{
			new = &((*new)->rb_right);
		}
		else
        {
			spin_unlock_bh(&nac_knl_rbtree_root_rwsem);
			err = -EEXIST;
			kfree(trnode);
			goto out;
		}
	}

	rb_link_node(&trnode->node, parent, new);
	rb_insert_color(&trnode->node, root);
	spin_unlock_bh(&nac_knl_rbtree_root_rwsem);
	//nac_knl_rbtree_show_entry("insert", &trnode->entry);
out:
	return err;
}


struct nac_knl_rbtree_node *__nac_knl_rbtree_search(struct nac_knl_rbtree_entry *ety)
{
	struct rb_root *root = NULL;
	struct rb_node *node = NULL;
	struct nac_knl_rbtree_node *trnode = NULL;
	int location;

	if(NAC_KNL_OK != nac_knl_rbtree_entry_invalid(ety))
	{
		return NULL;
	}

	root = nac_knl_rbtree_root[ety->type];
	node = root->rb_node;

	while(node)
    {
		trnode = rb_entry(node, struct nac_knl_rbtree_node, node);
		location = nac_knl_rbtree_entry_locate(ety, &trnode->entry, NAC_KNL_RBTREE_LOC_TYPE_SRH);

		if(location == NAC_KNL_RBTREE_LOC_WRONG)
		{
			break;
		}

		if(location == NAC_KNL_RBTREE_LOC_LEFT)
		{
			node = node->rb_left;
		}
		else if(location == NAC_KNL_RBTREE_LOC_RIGHT)
		{
			node = node->rb_right;
		}
		else
		{
			return trnode;
		}
	}

	return NULL;
}


/* Should be protected by read_lock. */

struct nac_knl_rbtree_entry *nac_knl_rbtree_search(struct nac_knl_rbtree_entry *ety)
{
	struct nac_knl_rbtree_node *trnode = NULL;

	trnode = __nac_knl_rbtree_search(ety);
	if(trnode)
	{
		return &trnode->entry;
	}

	return NULL;
}

int nac_knl_rbtree_delete(struct nac_knl_rbtree_entry *ety, int len)
{
	struct nac_knl_rbtree_node *trnode = NULL;
	struct rb_root *root = NULL;

	if(len < sizeof(struct nac_knl_rbtree_entry) || NAC_KNL_OK != nac_knl_rbtree_entry_invalid(ety))
	{
		return -EINVAL;
	}

	spin_lock_bh(&nac_knl_rbtree_root_rwsem);

	root = nac_knl_rbtree_root[ety->type];
	trnode = __nac_knl_rbtree_search(ety);
	if(trnode)
    {
		//nac_knl_rbtree_show_entry("delete", &trnode->entry);
		rb_erase(&trnode->node, root);
		kfree(trnode);
	}

	spin_unlock_bh(&nac_knl_rbtree_root_rwsem);

	return NAC_KNL_OK;
}

int nac_knl_rbtree_flush_single(NAC_KNL_RBTREE_TYPE type)
{
	struct rb_root *root = NULL;
	struct rb_node *node = NULL;
	struct nac_knl_rbtree_node *trnode = NULL;
    int i;

    spin_lock_bh(&nac_knl_rbtree_root_rwsem);

    root = nac_knl_rbtree_root[type];
	node = rb_first(root);
	while(node)
    {
		trnode = rb_entry(node, struct nac_knl_rbtree_node, node);
		node = rb_next(node);

		//nac_knl_rbtree_show_entry("delete", &trnode->entry);
		rb_erase(&trnode->node, root);
		kfree(trnode);
	}

	spin_unlock_bh(&nac_knl_rbtree_root_rwsem);

	return NAC_KNL_OK;
}

int nac_knl_rbtree_flush(void)
{
	struct rb_root *root = NULL;
	struct rb_node *node = NULL;
	struct nac_knl_rbtree_node *trnode = NULL;
    int i;

    spin_lock_bh(&nac_knl_rbtree_root_rwsem);

    for(i = (NAC_KNL_RBTREE_NONE + 1); i < NAC_KNL_RBTREE_NUM; ++i)
    {
		root = nac_knl_rbtree_root[i];
        node = rb_first(root);
    	while(node)
        {
    		trnode = rb_entry(node, struct nac_knl_rbtree_node, node);
    		node = rb_next(node);

    		//nac_knl_rbtree_show_entry("delete", &trnode->entry);
    		rb_erase(&trnode->node, root);
    		kfree(trnode);
    	}
	}

	spin_unlock_bh(&nac_knl_rbtree_root_rwsem);
	return NAC_KNL_OK;
}

int nac_knl_rbtree_show(void)
{
	struct rb_root * root = NULL;
	struct rb_node * node = NULL;
	struct nac_knl_rbtree_node * trnode = NULL;
	unsigned char proto_name[8] = "";
	int i;
	
	
	spin_lock_bh(&nac_knl_rbtree_root_rwsem);

	for(i = (NAC_KNL_RBTREE_NONE + 1); i < NAC_KNL_RBTREE_NUM; ++i)
    {
		root = nac_knl_rbtree_root[i];
		if(root == NULL)
		{
			continue;
		}
        switch(i)
        {
        case NAC_KNL_RBTREE_EXCEPT_TERMINAL:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "except terminal ip start--------------\n");
    		break;
        case NAC_KNL_RBTREE_EXCEPT_NET_APP:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "except net app ip start--------------\n");
    		break;
        case NAC_KNL_RBTREE_EXCEPT_SERVER:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "except server start-----------------\n");
    		break;
        case NAC_KNL_RBTREE_EXCEPT_PORT:
			continue;			
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "except dport start-----------------\n");
    		break;
        case NAC_KNL_RBTREE_EXCEPT_DOMAIN:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "except domain start-----------------\n");
    		break;
        case NAC_KNL_RBTREE_IP_RANGE:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "ip range start-----------------\n");
    		break;
        case NAC_KNL_RBTREE_EXCEPT_MAC:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "except terminal mac start--------\n");
    		break;
        case NAC_KNL_RBTREE_EXCEPT_IP_MAC:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "except ip and mac start-----------------\n");
    		break;
        case NAC_KNL_RBTREE_NETAPP_SERVER:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "net_app check start-----------------\n");
            nac_knl_debug(NAC_KNL_MODULE_POLICY, "switc		= %d\n", gst_net_app.switc);
			nac_knl_debug(NAC_KNL_MODULE_POLICY, "cycle		= %d\n", gst_net_app.cycle);
            nac_knl_debug(NAC_KNL_MODULE_POLICY, "times		= %d\n", gst_net_app.times);
			if (gst_net_app.switc == 0)
			{
				nac_knl_debug(NAC_KNL_MODULE_POLICY, "protocol	= %d\n", gst_net_app.protocol);
				break;
			}
			
			switch (gst_net_app.protocol)
			{
			case IPPROTO_TCP_UDP:
				memcpy(proto_name, "any", strlen("any"));
				break;
			case IPPROTO_TCP:
				memcpy(proto_name, "tcp", strlen("tcp"));
				break;
			case IPPROTO_UDP:
				memcpy(proto_name, "udp", strlen("udp"));
				break;
			default:
				nac_knl_debug(NAC_KNL_MODULE_POLICY, "netapp check protocol error!\n");
				break;
			}
			nac_knl_debug(NAC_KNL_MODULE_POLICY, "protocol = %s\n", proto_name);
			nac_knl_debug(NAC_KNL_MODULE_POLICY, "dst_port = %d\n", gst_net_app.dst_port);
			break;
        case NAC_KNL_RBTREE_NAT_SERVER:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "nat server start-----------------\n");
    		break;
        case NAC_KNL_RBTREE_ISOLATION_ZONE:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "isolation zone start-----------------\n");
    		break;
        case NAC_KNL_RBTREE_HTTP_PROXY_SERVER:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "proxy server ip start----------------\n");
    		break;
        case NAC_KNL_RBTREE_DHCP_SERVER:
    		nac_knl_debug(NAC_KNL_MODULE_POLICY, "dhcp server ip start----------------\n");
            switch(nac_knl_dhcp_flag)
            {
            case DHCP_CLOSE:
                nac_knl_debug(NAC_KNL_MODULE_POLICY, "close\n");
                break;
            case DHCP_ENABLE:
                nac_knl_debug(NAC_KNL_MODULE_POLICY, "enable\n");
                break;
            case DHCP_DISABLE:
                nac_knl_debug(NAC_KNL_MODULE_POLICY, "disable\n");
                break;
            default:
                break;
            }
    		break;
    	default:
            break;
    	}

		for(node = rb_first(root); node; node = rb_next(node))
        {
  			trnode = rb_entry(node, struct nac_knl_rbtree_node, node);
            nac_knl_rbtree_show_entry("show", &trnode->entry);
		}

        if(i == NAC_KNL_RBTREE_IP_RANGE)
        {
            nac_knl_port_ip_show();
        }
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "end-----------------\n");
	}

	spin_unlock_bh(&nac_knl_rbtree_root_rwsem);

	return NAC_KNL_OK;
}

int nac_knl_rbtree_init(void)
{
	int i;
	struct rb_root * root;

    printk("nac_knl_rbtree_init\n");
	spin_lock_bh(&nac_knl_rbtree_root_rwsem);

	for(i = (NAC_KNL_RBTREE_NONE + 1); i < NAC_KNL_RBTREE_NUM; ++i)
    {
		root = nac_knl_rbtree_root[i];
		*root = RB_ROOT;
	}

	spin_unlock_bh(&nac_knl_rbtree_root_rwsem);
	return NAC_KNL_OK;
}

int nac_knl_rbtree_exit(void)
{
	nac_knl_rbtree_flush();
    printk("nac_knl_rbtree_exit\n");
	return NAC_KNL_OK;
}
