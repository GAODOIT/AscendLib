/*
 *
 * Part:        nac framwork.
 *
 * Author:      ydh
 *
 */

#include "include/precomp.h"



void nac_knl_setCharStep(char *subStr, int *charStep)
{
	int i;
	int subStrLen = strlen(subStr);
	for(i = 0; i < MAX_CHAR_SIZE; i++)
	{
		charStep[i] = subStrLen + 1;
	}

	for(i = 0; i < subStrLen; i++)
	{
		charStep[(unsigned char)subStr[i]] = subStrLen - i;
	}
}

int nac_knl_looup_string(char *mainStr, char *subStr, int *charStep)
{
    int mainStrLen = strlen(mainStr);
    int subStrLen  = strlen(subStr);
    int main_i = 0;
    int sub_j = 0;

    if((mainStrLen == 0)
        || (subStrLen == 0))
    {
        return NAC_KNL_ERR;
    }

    while(main_i < mainStrLen)
    {
        int tem = main_i;
        while(sub_j < subStrLen)
        {
            if(mainStr[main_i] == subStr[sub_j])
            {
                main_i++;
                sub_j++;
                continue;
            }
            else
            {
                 if(tem + subStrLen > mainStrLen)
                 {
                    return NAC_KNL_ERR;
                 }
                 char firstRightChar = mainStr[tem + subStrLen];
                 main_i += charStep[(unsigned char)firstRightChar];
                 sub_j = 0;
                 break;
            }
        }
        if(sub_j == subStrLen)
        {
            return main_i - subStrLen;
        }
    }
    return NAC_KNL_ERR;
}


