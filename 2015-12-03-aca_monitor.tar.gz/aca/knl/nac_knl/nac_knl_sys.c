/*
 *
 * Part:        nac framwork.
 *
 * Author:      ydh
 */

#include "include/precomp.h"

MODULE_DESCRIPTION("HUPU(R) NAC Module");
MODULE_AUTHOR("Copyright(c) 2013-2014 HUPU Corporation");
MODULE_LICENSE("GPL");
MODULE_VERSION("8.0.0 -"__DATE__"-"__TIME__);

char *pc_eth0_mac = "23-51-32-01-24-98";
module_param(pc_eth0_mac, charp, S_IRUSR);

struct net_device *pst_in_interface[1];
struct net_device *pst_out_interface[1];

nac_knl_eth3_mac st_eth3;

int nac_knl_flag __read_mostly = 0;


int hostStep[MAX_CHAR_SIZE];
int httpStep[MAX_CHAR_SIZE];
int user_agent[MAX_CHAR_SIZE];

DEFINE_SPINLOCK(nac_knl_vlan_map);

unsigned int eth2_ip = 0; //eth2 device ip

//http://10.10.2.251/RedirectServlet?ip=10.10.2.53&mac=10-10-10-10-10-10&tourl=www.baidu.com&userAgent=0(USER_AGENT_TYPE)&getType=1&nacType=1&natType=1&netapp_switch=%d&userType=1&eth0_mac=%s>;
static void set_redirect_url(char *pc_url_redirect,
                             char *direct_url_ip,
                             char *pc_user_ip,
                             char *pc_user_mac,
                             char *original_url,
                             char user_agent,
                             char get_type,
                             char nac_type,
                             char nat_type,
                             char netapp_switch,
                             char user_type)
{

    char *http_redirect_header =
    "HTTP/1.1 301 Moved Permanently\r\n"
    "Location: http://%s/RedirectServlet?ip=%s&mac=%s&tourl=%s&userAgent=%d&getType=%d&nacType=%d&natType=%d&netapp_switch=%d&userType=%d&eth0_mac=%s\r\n"
    "Content-length: 0\r\n"
    "Cache-control: no-cache\r\n"
    "\r\n";
    sprintf(pc_url_redirect, http_redirect_header,
                             direct_url_ip,
                             pc_user_ip,
                             pc_user_mac,
                             original_url,
                             user_agent,
                             get_type,
                             nac_type,
                             nat_type,
                             netapp_switch,
                             user_type,
                             pc_eth0_mac);
}
int skb_iphdr_init(struct sk_buff *skb, unsigned char protocol,
                    unsigned int saddr, unsigned int daddr, int ip_len)
{
    struct iphdr *iph = NULL;

    // skb->data �ƶ���ip�ײ�
    skb_push(skb, sizeof(struct iphdr));
    //С·��û��skb_reset_network_header��ip_hdr����
    skb_reset_network_header(skb);
    iph = ip_hdr(skb);

    /* iph->version = 4; iph->ihl = 5; */
#if 0
    put_unaligned( 0x45, ( unsigned char * )iph );
    iph->tos      = 0;
    put_unaligned( htons( ip_len ), &( iph->tot_len ) );
    iph->id       = 0;
    iph->frag_off = htons(IP_DF);
    iph->ttl      = 64;
    iph->protocol = IPPROTO_UDP;
    iph->check    = 0;
    put_unaligned( saddr, &( iph->saddr ) );
    put_unaligned( daddr, &( iph->daddr ) );
    iph->check    = ip_fast_csum( ( unsigned char * )iph, iph->ihl );
#else
    iph->version  = 4;
    iph->ihl      = 5;
    iph->tos      = 0;
    iph->tot_len  = htons(ip_len);
    iph->id       = 0;
    iph->frag_off = htons(IP_DF);
    iph->ttl      = 64;
    iph->protocol = protocol;
    iph->check    = 0;
    iph->saddr    = saddr;
    iph->daddr    = daddr;
    iph->check    = ip_fast_csum((unsigned char *)iph, iph->ihl);
#endif
    return NAC_KNL_OK;
}


struct sk_buff* tcp_newpack(unsigned int saddr, unsigned int daddr,
                            unsigned short sport, unsigned short dport,
                            unsigned int seq, unsigned int ack_seq,
                            unsigned char *msg, int len, char is_local)
{
    struct sk_buff *skb = NULL;
    int total_len, eth_len, ip_len, header_len;
    int tcp_len;
    struct tcphdr *tcph;
    struct iphdr *iph;

    __wsum tcp_hdr_csum;

    // ���ø���Э�����ݳ���
    tcp_len = len + sizeof(*tcph);
    ip_len  = tcp_len + sizeof(*iph);

    eth_len = ip_len + ETH_HLEN;

    total_len = eth_len + NET_IP_ALIGN;
    total_len += LL_MAX_HEADER;

    header_len = total_len - len;

    // ����skb
    skb = alloc_skb(total_len, GFP_ATOMIC);
    if(!skb)
    {
        printk("tcp_newpack-->alloc_skb length %d failed.\n", total_len);
        return NULL;
    }

    // Ԥ�ȱ���skb��Э���ײ����ȴ�С
    skb_reserve(skb, header_len);

    // ������������
    //С·����Ҫmemcpy����������copy
    //skb_copy_to_linear_data( skb, msg, len );
    memcpy(skb->data, msg, len);
    skb->len += len;

    // skb->data �ƶ���tcp�ײ�
    skb_push(skb, sizeof(*tcph));
    //С·��û��skb_reset_transport_header��tcp_hdr����
    skb_reset_transport_header(skb);
    tcph = tcp_hdr(skb);

    memset(tcph, 0, sizeof(*tcph));
    tcph->doff    = 5;
    tcph->source  = sport;
    tcph->dest    = dport;
    tcph->seq     = seq;
    tcph->ack_seq = ack_seq;
    tcph->urg_ptr = 0;

    if(is_local)
	{
		tcph->fin = 1;
	}
    tcph->psh = 0x1;
    tcph->ack = 0x1;

    tcph->window = htons(65535);
    tcph->check  = 0;
    tcp_hdr_csum = csum_partial(tcph, tcp_len, 0);
    tcph->check  = csum_tcpudp_magic(saddr, daddr,
                                     tcp_len, IPPROTO_TCP,
                                     tcp_hdr_csum);
    skb->csum = tcp_hdr_csum;
    if(tcph->check == 0)
    {
        tcph->check = CSUM_MANGLED_0;
    }

    skb_iphdr_init(skb, IPPROTO_TCP, saddr, daddr, ip_len);
    return skb;
}



int http_send_redirect(char *pc_url_redirect,
                       unsigned short url_redirect_len,
                       struct sk_buff *skb,
                       struct iphdr *iph,
                       struct tcphdr *tcph,
                       char is_local,
                       unsigned short vlan_id)
{
    struct sk_buff *pskb = NULL;
    struct ethhdr *eth = NULL;
    struct vlan_hdr *vhdr = NULL;
    int tcp_len = 0;
    unsigned int ack_seq = 0;
    int nac_ret = NAC_KNL_ERR;

    // ���¼��� Acknowledgement number
    tcp_len = ntohs(iph->tot_len) - ((iph->ihl + tcph->doff) << 2);
    ack_seq = ntohl(tcph->seq) + (tcp_len);
    ack_seq = htonl(ack_seq);
    pskb = tcp_newpack(iph->daddr, iph->saddr,
                       tcph->dest, tcph->source,
                       tcph->ack_seq, ack_seq,
                       pc_url_redirect,
                       url_redirect_len,
					   is_local);

    if(NULL == pskb)
    {
        goto _out;
    }

    /* ����VLAN ��Ϣ
    if(__constant_htons(ETH_P_8021Q) == skb->protocol)
    {
        vhdr = (struct vlan_hdr *)skb_push(pskb, VLAN_HLEN);
        vhdr->h_vlan_TCI = vlan_eth_hdr(skb)->h_vlan_TCI;
        vhdr->h_vlan_encapsulated_proto = __constant_htons(ETH_P_IP);
    }
	*/

    if((nac_mode == NAC_MVG_MODE
        || nac_mode == NAC_BRIDGE_MODE)
        && vlan_id > 0)
    {
        pskb->vlan_tci = vlan_id | VLAN_TAG_PRESENT;
    }
    //skb->data �ƶ���eth�ײ�
    eth = (struct ethhdr *)skb_push(pskb, ETH_HLEN);
    skb_reset_mac_header(pskb);
    pskb->protocol  = eth_hdr(skb)->h_proto;
    eth->h_proto    = eth_hdr(skb)->h_proto;
    memcpy(eth->h_source, eth_hdr(skb)->h_dest, ETH_ALEN);
    memcpy(eth->h_dest, eth_hdr(skb)->h_source, ETH_ALEN);

    if(skb->dev)
    {
        pskb->dev = skb->dev;
        dev_queue_xmit(pskb);
    }
    else
    {
        kfree_skb(pskb);
        printk(KERN_DEBUG "http_send_redirect-->skb->dev is NULL\n" );
    }
_out:
    return nac_ret;
}

static int __nac_knl_lookup_rbtree(unsigned int dst_ip,
                                   unsigned int src_ip,
                                   unsigned short dst_port,
                                   unsigned char protocol,
                                   unsigned int *isolation_id,
                                   NAC_KNL_DHCP *pst_dhcp,
                                   unsigned char *src_mac)
{
    struct nac_knl_rbtree_entry search, *pst_entry = NULL;
    int iRet = 0;
    int i;

    if(pst_dhcp->ip != 0)
    {
        goto DHCP_RBTREE;
    }

    for(i = (NAC_KNL_RBTREE_NONE + 1); i < NAC_KNL_RBTREE_NUM; ++i)
    {
        search.type = i;
        switch(i)
        {
        case NAC_KNL_RBTREE_IP_RANGE:
    		search.union_rbtree.ip_key.ip_addr = src_ip;
            pst_entry = nac_knl_rbtree_search(&search);
            if(!pst_entry)
            {
                iRet |= NAC_FORWARD;
                return iRet;
            }
            if(__nac_knl_hash_find(dst_port, dst_ip, protocol, 0))
            {
                iRet |= NAC_FORWARD;
                return iRet;
            }
    		break;
        case NAC_KNL_RBTREE_EXCEPT_TERMINAL:
    	    search.union_rbtree.ip_key.ip_addr = src_ip;
            pst_entry = nac_knl_rbtree_search(&search);
            if(pst_entry)
            {
                iRet |= NAC_FORWARD;
                return iRet;
            }
    		break;
        case NAC_KNL_RBTREE_EXCEPT_NET_APP:
            search.union_rbtree.ip_key.ip_addr = src_ip;
            pst_entry = nac_knl_rbtree_search(&search);
            if(pst_entry)
            {
                iRet |= NAC_NETAPP_EXCEPT;
            }
    		break;
        case NAC_KNL_RBTREE_EXCEPT_SERVER:
    	    search.union_rbtree.ip_key.ip_addr = dst_ip;
            pst_entry = nac_knl_rbtree_search(&search);
            if(pst_entry)
            {
                iRet |= NAC_FORWARD;
                return iRet;
            }
    		break;
        case NAC_KNL_RBTREE_EXCEPT_PORT:
    	    search.union_rbtree.ip_key.port = dst_port;
            pst_entry = nac_knl_rbtree_search(&search);
            if(pst_entry)
            {
                if(pst_entry->union_rbtree.port.protocol == protocol
                    ||(pst_entry->union_rbtree.port.protocol == IPPROTO_TCP_UDP
                       &&(protocol == IPPROTO_UDP
                          || protocol == IPPROTO_TCP)))
                {
                    if(pst_entry->union_rbtree.port.ip_addr == 0)
                    {
                        iRet |= NAC_FORWARD;
                        return iRet;
                    }
                    else
                    {
                        if(pst_entry->union_rbtree.port.ip_addr == dst_ip)
                        {
                            iRet |= NAC_FORWARD;
                            return iRet;
                        }
                    }
                }
            }
    		break;
        case NAC_KNL_RBTREE_EXCEPT_DOMAIN:
    		search.union_rbtree.ip_key.ip_addr = dst_ip;
            pst_entry = nac_knl_rbtree_search(&search);
            if(pst_entry)
            {
                iRet |= NAC_FORWARD;
                return iRet;
            }
    		break;
        case NAC_KNL_RBTREE_EXCEPT_MAC:
            if(nac_mode != NAC_MVG_MODE
               || !src_mac)
            {
                break;
            }
            memcpy(search.union_rbtree.mac.ac_mac, src_mac, ETH_ALEN);
            pst_entry = nac_knl_rbtree_search(&search);
            if(pst_entry)
            {
                iRet |= NAC_FORWARD;
                return iRet;
            }
    		break;
        case NAC_KNL_RBTREE_EXCEPT_IP_MAC:
            //nac_knl_debug(NAC_KNL_MODULE_POLICY, "exempt ip and mac start-----------------\n");
    		break;
        case NAC_KNL_RBTREE_NETAPP_SERVER:
			if (gst_net_app.switc == 0)
			{
				continue;
			}
			if ((gst_net_app.protocol == IPPROTO_TCP_UDP
				&&(protocol == IPPROTO_TCP || protocol == IPPROTO_UDP))
				||(gst_net_app.protocol == IPPROTO_TCP && protocol == IPPROTO_TCP)
				||(gst_net_app.protocol == IPPROTO_UDP && protocol == IPPROTO_UDP))
			{
    			search.union_rbtree.ip_key.ip_addr = dst_ip;
            	pst_entry = nac_knl_rbtree_search(&search);
            	if(pst_entry)
            	{
                	iRet |= NAC_NETAPP;
                	continue;
                	//return iRet;  �������ݰ���⵽�󣬻���Ҫ�ж��Ƿ��ڷ��з�����������
            	}
			}
    		break;
        case NAC_KNL_RBTREE_NAT_SERVER:
    		search.union_rbtree.ip_key.ip_addr = src_ip;
            pst_entry = nac_knl_rbtree_search(&search);
            if(pst_entry)
            {
                if(pst_entry->union_rbtree.ip.isolation_id == NAT_ENABLE)
                {
                    iRet |= NAC_NAT_SERVER_ENABLE;
                }
                else if(pst_entry->union_rbtree.ip.isolation_id == NAT_DISABLE)
                {
                    iRet |= NAC_NAT_SERVER_DISABLE;
                }

                return iRet;
            }
    		break;
        case NAC_KNL_RBTREE_ISOLATION_ZONE:
            search.union_rbtree.ip_key.ip_addr = dst_ip;
            pst_entry = nac_knl_rbtree_search(&search);
            if(pst_entry)
            {
                *isolation_id = pst_entry->union_rbtree.ip.isolation_id;
                iRet |= NAC_ISOLATION;
                return iRet;
            }
            break;
        case NAC_KNL_RBTREE_HTTP_PROXY_SERVER:
            search.union_rbtree.ip_key.ip_addr = dst_ip;
            pst_entry = nac_knl_rbtree_search(&search);
            if(pst_entry)
            {
                iRet |= NAC_HTTP_PROXY_SERVER;
                return iRet;
            }
            break;
        case NAC_KNL_RBTREE_DHCP_SERVER:
DHCP_RBTREE:
            if(pst_dhcp->ip == 0)
            {
                break;
            }
			search.type = NAC_KNL_RBTREE_DHCP_SERVER;
            search.union_rbtree.ip_key.ip_addr = ntohl(pst_dhcp->ip);
            pst_entry = nac_knl_rbtree_search(&search);
            if(pst_entry)
            {
                pst_dhcp->flag = 1;
                return iRet;
            }
            break;
    	default:
            break;
    	}
    }

    if(iRet & NAC_NETAPP)
    {
        return NAC_NETAPP;
    }
    return iRet;
}

static void nac_knl_skb_print(struct sk_buff *skb, unsigned short vlan_id)
{
    struct ethhdr *pst_eth = NULL;
    struct arphdr *arp, arph;
    unsigned char *arp_ptr;
	unsigned char *sha;
    unsigned int src_ip, dst_ip;
    struct nac_knl_arp st_arp;

    //pst_eth = eth_hdr(skb);
    if(skb->protocol == htons(ETH_P_ARP))
    {
        arp = arp_hdr(skb);//skb_header_pointer(skb, 0, sizeof(arph), &arph);
        if(arp)
        {
            memset(&st_arp, '\0', sizeof(st_arp));
            memcpy(&st_arp, arp + 1, sizeof(st_arp));
            src_ip = nac_knl_get_u32(st_arp.ar_sip, 0);
            dst_ip = nac_knl_get_u32(st_arp.ar_tip, 0);
            //simple_strtoll(const char *, char * *, unsigned int)
            nac_knl_debug(NAC_KNL_MODULE_ARP, "nac_knl_skb_print_arp-->%d.%d.%d.%d===>%d.%d.%d.%d, %02X-%02X-%02X-%02X-%02X-%02X===>%02X-%02X-%02X-%02X-%02X-%02X, arp_op = %d, skb_protocol = %02X, skb->pkt_type = %d, skb->dev->name = %s, skb->dev->ifindex = %d, skb->dev = %p, skb->sp = %p\n",
                          NIPQUAD(src_ip),
                          NIPQUAD(dst_ip),
                          MAC_FORMAT(st_arp.ar_sha),
                          MAC_FORMAT(st_arp.ar_tha),
                          ntohs(arp->ar_op),
                          ntohs(skb->protocol),
                          skb->pkt_type,
                          skb->dev->name,
                          skb->dev->ifindex,
                          skb->dev,
                          skb->sp);
                          //vlan_id);
                          //vlan_dev_array[vlan_id]);
        }
    }
    else
    {
        nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_knl_skb_print_ip-->%d.%d.%d.%d===>%d.%d.%d.%d, skb_protocol = %02X, protocol = %d, ttl = %d, skb->pkt_type = %d, skb->dev->name = %s, skb->dev->ifindex = %d, skb->dev = %p, skb->sp = %p\n",
                    NIPQUAD(ip_hdr(skb)->saddr),
                    NIPQUAD(ip_hdr(skb)->daddr),
                    ntohs(skb->protocol),
                    ip_hdr(skb)->protocol,
                    ip_hdr(skb)->ttl,
                    skb->pkt_type,
                    skb->dev->name,
                    skb->dev->ifindex,
                    skb->dev,
                    skb->sp);
                    //vlan_id,
                    //vlan_dev_array[vlan_id]);
    }
}

int nac_knl_check_domain(char *ac_host, unsigned int type_flag, unsigned int src_ip,
                         unsigned short src_port, NAC_KNL_USER_OBJECT *pst_user)
{
    int iRet = NAC_KNL_ERR;
    iRet = nac_knl_wm_search(ac_host, pst_url_wm, nac_knl_url_wm, "url");
    if(iRet <= 0)
    {
        return NAC_REDIRECT;
    }

    if(iRet == GLOBAL_DOMAIN)
    {
        type_flag |= NAC_TYPE_DOMAIN;
    }
    else if(pst_user)
    {
        int i;
        for(i = 0; i < pst_user->isolation_num; i++)
        {
            if(iRet == pst_user->isolation_zone[i])
            {
                type_flag |= NAC_TYPE_DOMAIN;
            }
        }
    }
    else
    {
        if(type_flag & NAC_TYPE_POST)
        {
            return NAC_KNL_ERR;
        }
        return NAC_REDIRECT;
    }

    if(type_flag & NAC_TYPE_DOMAIN)
    {
        if((type_flag & NAC_TYPE_PROXY)
            || (type_flag & NAC_TYPE_POST))
        {
            NAC_KNL_USER_MSG st_user_new;
            st_user_new.src_ip  = src_ip;
            st_user_new.result  = src_port;
            nac_knl_netlink_user_send(&st_user_new, sizeof(NAC_KNL_USER_MSG), NAC_NETLINK_DOMAIN_NEW);
        }
        if(!(type_flag & NAC_TYPE_LOCAL))
        {
            return NAC_FORWARD;
        }
    }
    if(type_flag & NAC_TYPE_POST)
    {
        return NAC_KNL_ERR;
    }
    return NAC_REDIRECT;
}

static int nac_knl_check_netbios_host_announce(struct sk_buff *skb, unsigned int *system_type)
{
    struct iphdr *iph   = ip_hdr(skb);
	struct tcphdr *tcph = NULL;
	struct udphdr *udph = NULL;
    unsigned int src_ip, dst_ip;
    unsigned short src_port = 0, dst_port= 0;
    char *payload = NULL;
    int plen = 0, hlen, iRet = 0, os_type = 0;;
    src_ip = iph->saddr;
    dst_ip = iph->daddr;
    hlen   = iph->ihl * 4;
    if(IPPROTO_UDP != iph->protocol)
    {
        return NAC_KNL_ERR;
    }

    udph     = (struct udphdr *)((char *)iph + hlen);
    dst_port = ntohs(udph->dest);
    src_port = ntohs(udph->source);
    plen = ntohs(udph->len) - sizeof(*udph);
    if (src_port == 138 && dst_port == 138
        && ntohs(udph->len) >= 209
        && 255 == ((unsigned char *)&dst_ip)[3])
    {
           payload = (unsigned char *)udph +  sizeof(struct udphdr);
           unsigned char message_type = nac_knl_get_u8_1(payload, 0);
           unsigned char command      = nac_knl_get_u8_1(payload, 168);
           /*
           #MAC
           Browser Protocol Major Version: 21(0x15)
           Browser Protocol Minor Version: 1 (0x01)
           #windows
           Browser Protocol Major Version: 15(0x0f)
           Browser Protocol Minor Version: 1 (0x01)
           */
           unsigned char major_ver = nac_knl_get_u8_1(payload, 196);
           unsigned char minor_ver = nac_knl_get_u8_1(payload, 197);
           nac_knl_debug(NAC_KNL_MODULE_NAT,
                       "nac_knl_check_netbios_host_announce-->%u.%u.%u.%u(%d)-->%u.%u.%u.%u(%d)--len=%d--plen=%d-%02x-%02x-%02x-%02x\n",
                       NIPQUAD(src_ip), src_port, NIPQUAD(dst_ip), dst_port, ntohs(udph->len),
                       plen, message_type, command, major_ver, minor_ver);

           if (message_type == 0x11 && command == 0x01)
           {
                char* host_comment = payload + 200;
                if (major_ver == 0x15 && minor_ver == 0x01)
                {
                    os_type = OSX; //OSX
                    nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_check_netbios_host_announce-->MAC-->osType=%d--host_comment=%s\n", os_type);
                }
                else if (major_ver == 0x0f && minor_ver == 0x01)
                {
                    os_type = WINDOWS; //windows
                    nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_check_netbios_host_announce-->WINDOWS-->osType=%d--host_comment=%s\n", os_type);
                }
                *system_type = os_type;
                /*
                iRet = nac_knl_wm_search(host_comment, pst_user_agent_wm, nac_knl_user_agent_wm, "user_agent");
                if (iRet > 0)
                {
                    os_type = iRet; //OSX
                }
                else
                {
                    os_type = WINDOWS;
                }
                */
           }

    }
    return NAC_KNL_OK;
}

//nac_mode == NAC_MVG_MODE, eth2->in eth3-->out, eth3->in eth2-->out
int nac_mvg_pbr_check(struct sk_buff *skb, unsigned short vlan_id)
{
	struct iphdr *iph   = ip_hdr(skb);
	struct tcphdr *tcph = NULL;
	struct udphdr *udph = NULL;
    unsigned int src_ip;
	unsigned int dst_ip;
    unsigned short src_port = 0;
	unsigned short dst_port = 0;
	char *payload = NULL;
    NAC_KNL_USER_OBJECT *pst_user = NULL;
    char nat_type = 0;
	unsigned int type_flag    = 0;
    unsigned int isolation_id = 0;
    char user_type = 1; //1.����֤�ְ��죬2.ֻ��֤��3. ֻ���졣
	int plen = 0, hlen, iRet = 0;
    unsigned int agent_cls = 0;
    struct ethhdr *pst_ethhdr  = NULL;
    unsigned char *pst_src_mac = NULL;

    char is_dhcp = 0;

    NAC_KNL_DHCP st_dhcp =
                        {
                         .ip   = 0,
                         .flag = 0
                        };

    nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_mvg_pbr_check-->name = %s, vlan_id = %u\n", skb->dev->name, vlan_id);
	if(ntohs(skb->protocol) == 0x9000 //cisco loopback protocol
       || (skb->dev->ifindex != st_in_out_eth.us_in_index
           && skb->dev->ifindex != st_in_out_eth.us_out_index))
    {
        return NAC_KNL_ERR;
    }

    nac_knl_skb_print(skb, vlan_id);

    if(unlikely(nac_knl_switch))
    {
        return NAC_KNL_ERR;
    }

    if(skb->sp)
    {
        return NAC_FORWARD;
    }

    if(nac_mode == NAC_MVG_MODE
        || nac_mode == NAC_BRIDGE_MODE)
    {
        if(skb->protocol == htons(ETH_P_RARP)
            || skb->protocol == htons(ETH_P_ARP))
        {
            return NAC_FORWARD;
        }
        if(skb->dev->ifindex == st_in_out_eth.us_out_index
            && skb->protocol == htons(ETH_P_IP))
        {
            if(nac_knl_dhcp_flag != DHCP_CLOSE
               && IPPROTO_UDP == iph->protocol)
            {
                hlen     = iph->ihl * 4;
                udph     = (struct udphdr *)((char *)iph + hlen);
                dst_port = ntohs(udph->dest);
                src_port = ntohs(udph->source);

                if(dst_port == 68
                   && src_port == 67)
                {
                    is_dhcp = 1;
                    dst_ip  = 0;
                    st_dhcp.ip = ip_hdr(skb)->saddr;
                    goto DHCP;
                }
            }
            return NAC_FORWARD;
        }
    }

    if(ntohs(skb->protocol) != ETH_P_IP)
    {
        nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_mvg_pbr_check-->error skb->protocol = %02X\n", ntohs(skb->protocol));
        return NAC_KNL_ERR;
    }

	if(nac_mode == NAC_PBR_MODE
       && skb->pkt_type == PACKET_HOST
       && IPPROTO_ICMP == iph->protocol
       && iph->daddr == ui_control_untrust_ip)
    {
        nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_mvg_pbr_check-->pbr untrust icmp\n");
        return NAC_KNL_ERR;
    }

    if(unlikely(nac_knl_pass_switch))
    {
        return NAC_FORWARD;
    }

    if(nat_swit == NAT_ENABLE
       && iph->saddr != 0
       && iph->ttl > 60)
    {
        nac_knl_nat_check(skb, 0, &agent_cls);
    }

    nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_mvg_pbr_check0-->iph->daddr = %u, ui_redirect_ip = %u, ui_control_manager_ip = %u, ui_server_manager_ip = %u\n", iph->daddr, ui_redirect_ip, ui_control_manager_ip, ui_server_manager_ip);
	if(iph->daddr == ui_redirect_ip
		|| iph->daddr == ui_control_manager_ip
		|| iph->daddr == ui_server_manager_ip)
    {
        if(IPPROTO_TCP != iph->protocol)
        {
            return NAC_FORWARD;
        }
    }

    src_ip = ip_hdr(skb)->saddr;
    dst_ip = ip_hdr(skb)->daddr;
    hlen   = iph->ihl * 4;
    if(IPPROTO_TCP == iph->protocol)
    {
        tcph     = (struct tcphdr *)((char *)iph + hlen);
        dst_port = ntohs(tcph->dest);
        src_port = ntohs(tcph->source);
        plen     = ntohs(iph->tot_len) - hlen - (tcph->doff * 4);

        if(plen < 2) // Handshake or keepalive
        {
            return NAC_FORWARD;
        }

		if(dst_port == 3389     //Remote
			|| src_port == 3389
			|| dst_port == 139) //File and Print Sharing
		{
			return NAC_FORWARD;
		}

        if(iph->daddr == ui_redirect_ip
			|| iph->daddr == ui_control_manager_ip
			|| iph->daddr == ui_server_manager_ip)
        {
            if(dst_port != 80)
            {
                return NAC_FORWARD;
            }
            payload = (unsigned char *)tcph + tcph->doff*4;

            if(plen >= 50
                && memcmp(payload, "GET / HTTP/1.", 13) == 0)
            {
                type_flag |= NAC_TYPE_LOCAL;
                agent_cls  = WINDOWS;
            }
            else
            {
                return NAC_FORWARD;
            }
        }
    }

    if(iph->saddr == ui_control_manager_ip)
	{
		return NAC_FORWARD;
	}

    if(IPPROTO_UDP == iph->protocol)
    {
        udph     = (struct udphdr *)((char *)iph + hlen);
        dst_port = ntohs(udph->dest);
        src_port = ntohs(udph->source);

        unsigned int dhcp_server_ip = 0;
        int len = ntohs(udph->len) - sizeof(*udph);

        if(nac_knl_dhcp_flag != DHCP_CLOSE
           && nac_mode == NAC_PBR_MODE
           && src_ip == 0
           && dst_port == 67
           && len >= 300)
        {
            nac_knl_protocol_dhcp(udph, len, &dhcp_server_ip);
            st_dhcp.ip = dhcp_server_ip > 0?dhcp_server_ip:0;
			is_dhcp    = dhcp_server_ip > 0?1:0;

			dst_ip     = 0;
            nac_knl_debug(NAC_KNL_MODULE_DHCP, "nac_knl_protocol_dhcp = %d.%d.%d.%d, is_dhcp = %d, st_dhcp.ip = %d.%d.%d.%d, st_dhcp.flag = %d\n", NIPQUAD(dhcp_server_ip), is_dhcp, NIPQUAD(st_dhcp.ip), st_dhcp.flag);
        }
    }

    if(nac_mode == NAC_MVG_MODE)
    {
        pst_ethhdr = (struct ethhdr *)skb_mac_header(skb);
        if(pst_ethhdr)
        {
            pst_src_mac = pst_ethhdr->h_source;
        }
    }
DHCP:
    iRet = __nac_knl_lookup_rbtree(ntohl(dst_ip), ntohl(src_ip), dst_port,
                                   iph->protocol, &isolation_id, &st_dhcp, pst_src_mac);
    nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_mvg_pbr_check-->__nac_knl_lookup_rbtree src_ip = %d.%d.%d.%d:%d, dst_ip = %d.%d.%d.%d:%d, protocol = %d, plen = %d, iRet = %d\n", NIPQUAD(src_ip), src_port, NIPQUAD(dst_ip), dst_port, iph->protocol, plen, iRet);
    switch(iRet)
    {
	case NAC_FORWARD:
        return NAC_FORWARD;
		break;
    case NAC_NETAPP_EXCEPT:
        type_flag |= NAC_TYPE_NETAPP_EXCEPT;
        break;
    case NAC_NETAPP:
       	if (gst_net_app.dst_port == dst_port)
        {
            type_flag |= NAC_TYPE_NETAPP;
        }
		break;
    case NAC_NETAPP | NAC_FORWARD:
        if (gst_net_app.dst_port == dst_port)
        {
            type_flag |= NAC_TYPE_NETAPP;
            type_flag |= NAC_TYPE_NETAPP_FORWARD;
        }
		break;
    case NAC_NAT_SERVER_ENABLE:
        type_flag |= NAC_TYPE_NAT_ENABLE;
        break;
    case NAC_NAT_SERVER_DISABLE:
        type_flag |= NAC_TYPE_NAT_DISABLE;
        break;
    case NAC_ISOLATION:
        type_flag |= NAC_TYPE_ISOLATION_IP;
        break;
    case NAC_HTTP_PROXY_SERVER:
        type_flag |= NAC_TYPE_HTTP_PROXY_SERVERD;
        break;
	default:
        break;
	}

    if(IPPROTO_UDP == iph->protocol)
    {
        if(is_dhcp == 1)
        {
            nac_knl_debug(NAC_KNL_MODULE_DHCP, "nac_knl_protocol_dhcp-->st_dhcp.flag = %d, nac_knl_dhcp_flag = %d\n", st_dhcp.flag, nac_knl_dhcp_flag);
            if(st_dhcp.flag == 1)
            {
                if(nac_knl_dhcp_flag == DHCP_ENABLE)
                {
                    return NAC_FORWARD;
                }
                if(nac_knl_dhcp_flag == DHCP_DISABLE)
                {
                    return NAC_KNL_ERR;
                }
            }
            else
            {
                if(nac_knl_dhcp_flag == DHCP_ENABLE)
                {
                    return NAC_KNL_ERR;
                }
                if(nac_knl_dhcp_flag == DHCP_DISABLE)
                {
                    return NAC_FORWARD;
                }
            }
        }

        //dns dst_port == 53, dhcpclient port is 67, dhcpserver port is 68, netbios computer name browser is 138
        if(dst_port <= 161 && dst_port != 138)
        {
            nac_knl_debug(NAC_KNL_MODULE_UDP, "nac_mvg_pbr_check udp-->src_ip = %d.%d.%d.%d, dst_ip = %d.%d.%d.%d, dst_port = %d\n", NIPQUAD(src_ip), NIPQUAD(dst_ip), dst_port);
            return NAC_FORWARD;
        }
    }

    if(type_flag & NAC_TYPE_LOCAL)
    {
        goto HTTP_REDIRECT;
    }

    if(iph->ttl > 160
        && type_flag & NAC_TYPE_NAT_ENABLE)
    {
        return NAC_FORWARD;
    }
    nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_mvg_pbr_check1-->%d.%d.%d.%d:%d===>%d.%d.%d.%d:%d, %02X-%02X-%02X-%02X-%02X-%02X, type_flag=%0X\n",
                   NIPQUAD(src_ip),
                   src_port,
                   NIPQUAD(dst_ip),
                   dst_port,
                   MAC_FORMAT(eth_hdr(skb)->h_source),
                   type_flag);

    if(!(type_flag & NAC_TYPE_NAT_ENABLE)) //no nat
    {
        if(nac_mode == NAC_MVG_MODE)
        {
            pst_user = __nac_knl_user_find_by_mac(eth_hdr(skb)->h_source, 0);
        }
        else
        {
            pst_user = __nac_knl_user_find(ntohl(src_ip), 0, 0);
        }
        if(pst_user)
        {
            pst_user->last_time = get_seconds();
            if(type_flag & NAC_TYPE_NETAPP)
            {
                pst_user->state |= USER_STATE_IS_NETAPP;
                pst_user->net_app_time = pst_user->last_time;
            }

            if(type_flag & NAC_TYPE_NETAPP_EXCEPT)
            {
                pst_user->state |= USER_STATE_IS_NETAPP_EXCEPT;
            }
            else
            {
                pst_user->state &= ~USER_STATE_IS_NETAPP_EXCEPT;
            }

            if (os_check_swit == 1)
            {
                if (IPPROTO_TCP == iph->protocol)
                {
                    nac_knl_nat_check(skb, 1, &agent_cls);
                }
                else if (IPPROTO_UDP == iph->protocol)
                {
                    nac_knl_check_netbios_host_announce(skb, &agent_cls);
                }

                if (agent_cls != OTHERS)
                {
                    nac_knl_user_os_type_check(pst_user, agent_cls);
                }
            }

            if(pst_user->isolation_num == 0)
            {
                return NAC_FORWARD;
            }

            if(type_flag & NAC_TYPE_ISOLATION_IP)
            {
                pst_user->state |= USER_STATE_IS_ISOLATION;
                nac_knl_debug(NAC_KNL_MODULE_SKB, "online_user->%02X-%02X-%02X-%02X-%02X-%02X, isolation_id = %d\n",MAC_FORMAT(eth_hdr(skb)->h_source), isolation_id);
                int i;
                for(i = 0; i < pst_user->isolation_num; i++)
                {
                    if(isolation_id == pst_user->isolation_zone[i])
                    {
                        return NAC_FORWARD;
                    }
                }
            }
        }
        ////////////
        if(!pst_user
            && (type_flag & NAC_TYPE_NETAPP
                || type_flag & NAC_TYPE_NETAPP_EXCEPT))
        {
            NAC_KNL_USER_MSG st_user_new;
            st_user_new.tmp_id    = 0;
            st_user_new.dept_id   = 0;
            st_user_new.user_type = 0;
            st_user_new.os_type   = 0;
            st_user_new.src_ip    = ntohl(src_ip);
            unsigned long type = (type_flag & NAC_TYPE_NETAPP)>0?NAC_NETLINK_NETAPP_FOUND:NAC_NETLINK_NETAPP_EXCEPT;
            memcpy(st_user_new.src_mac, eth_hdr(skb)->h_source, sizeof(st_user_new.src_mac));
            nac_knl_netlink_user_send(&st_user_new, sizeof(NAC_KNL_USER_MSG), type);
            if(type_flag & NAC_TYPE_NETAPP)
            {
                nac_knl_debug(NAC_KNL_MODULE_USER, "nac_mvg_pbr_check-->net_app found = %d.%d.%d.%d\n",  NIPQUAD(src_ip));
            }
            else
            {
                nac_knl_debug(NAC_KNL_MODULE_USER, "nac_mvg_pbr_check-->net_app except = %d.%d.%d.%d\n",  NIPQUAD(src_ip));
            }
            if(type_flag & NAC_TYPE_NETAPP_FORWARD)
            {
                return NAC_FORWARD;
            }
        }
        ////////////
    }

    nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_mvg_pbr_check2-->%d.%d.%d.%d:%d===>%d.%d.%d.%d:%d, %02X-%02X-%02X-%02X-%02X-%02X, type_flag = %0X\n",
                   NIPQUAD(src_ip),
                   src_port,
                   NIPQUAD(dst_ip),
                   dst_port,
                   MAC_FORMAT(eth_hdr(skb)->h_source),
                   type_flag);

    if(IPPROTO_TCP != iph->protocol)
    {
        return NAC_KNL_ERR;
    }
    payload = (unsigned char *)tcph + tcph->doff*4;

    char ac_host[64] = "";
    int pos_start    = -1;

    if(__nac_knl_domain_find(ntohl(src_ip), src_port, dst_port))
    {
        nac_knl_debug(NAC_KNL_MODULE_DOMAIN, "nac_mvg_pbr_check-->hostname found = %d.%d.%d.%d:(%d)\n",  NIPQUAD(src_ip), src_port);
        return NAC_FORWARD;
    }

    if(plen >= 50
        && memcmp(payload, "GET ", 4) == 0)
    {
        if(memcmp(payload, ac_get_proxy, strlen(ac_get_proxy)) == 0)
        {
            type_flag |= NAC_TYPE_PROXY;
        }

        //"GET http://10.10.2.227/ HTTP/1."
        if(memcmp(payload + strlen(ac_get_proxy), "/ HTTP/1.", strlen("/ HTTP/1.")) == 0)
        {
            type_flag |= NAC_TYPE_LOCAL;
        }

        goto HTTP_REDIRECT;
    }

    if(plen >= 5
        && memcmp(payload, "POST ", 5) == 0)
    {
        type_flag |= NAC_TYPE_POST;
        goto HTTP_REDIRECT;
    }

    nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_mvg_pbr_check3-->%d.%d.%d.%d:%d===>%d.%d.%d.%d:%d, %02X-%02X-%02X-%02X-%02X-%02X, plen = %d, type_flag = %0X\n",
               NIPQUAD(src_ip),
               src_port,
               NIPQUAD(dst_ip),
               dst_port,
               MAC_FORMAT(eth_hdr(skb)->h_source),
               plen,
               type_flag);
	return NAC_KNL_ERR;
HTTP_REDIRECT:
    pos_start = nac_knl_looup_string(payload + 4, HOST_KEY_WORD, hostStep);
    if(pos_start < 0)
    {
        return NAC_KNL_ERR;
    }

    char *pc_start = payload + 4 + pos_start + strlen(HOST_KEY_WORD);
    char *pc_end   = strstr(pc_start, ENTER_KEY_WORD);
    if(!pc_end)
    {
        return NAC_KNL_ERR;
    }
    int len = pc_end - pc_start;
    if(len <= 0
        || len >= (sizeof(ac_host) - strlen("http://")))
    {
        return NAC_KNL_ERR;
    }
    memset(ac_host, '\0', sizeof(ac_host));
    memcpy(ac_host, pc_start, len);
    nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_check_http_host-->src_ip:%d.%d.%d.%d(%d), host=%s\n", NIPQUAD(src_ip), src_port, ac_host);

    iRet = nac_knl_check_domain(ac_host, type_flag, ntohl(src_ip), src_port, pst_user);
    nac_knl_debug(NAC_KNL_MODULE_DOMAIN, "nac_knl_check_domain-->src_ip:%d.%d.%d.%d(%d), type_flag = %d, iRet = %d\n", NIPQUAD(src_ip), src_port, type_flag, iRet);
    if(iRet == NAC_KNL_ERR)
    {
        return NAC_KNL_ERR;
    }
    if(iRet == NAC_FORWARD)
    {
        return NAC_FORWARD;
    }

    if((gst_ip_info.en_redirect_flag == NAC_KNL_POLICY_DROP)
        && !(type_flag & NAC_TYPE_LOCAL))
    {
        return NAC_KNL_ERR;
    }

    memset(ac_host, '\0', sizeof(ac_host));
    strcat(ac_host, "http://");
    strncat(ac_host, pc_start, len);
    char ac_src_ip[16]  = "";
    char ac_src_mac[18] = "";
    sprintf(ac_src_ip, IP_FORMAT_EX, NIPQUAD(ip_hdr(skb)->saddr));
    sprintf(ac_src_mac, MAC_FORMAT_EX, MAC_FORMAT(eth_hdr(skb)->h_source));

    if(type_flag & NAC_TYPE_NAT_ENABLE)
    {
        nat_type = 1;
    }
    else if(type_flag & NAC_TYPE_NAT_DISABLE)
    {
        nat_type = 2;
    }
    else
    {
        nat_type = 0;
    }

    if (agent_cls == 0)
    {
        nac_knl_nat_check(skb, 1, &agent_cls);
    }

    if (type_flag & NAC_TYPE_POST)
    {
        return NAC_KNL_ERR;
    }

    char url_redirect[1024] = "";
    set_redirect_url(url_redirect,
                     gst_ip_info.ac_redirect_ip,
                     ac_src_ip, ac_src_mac,
                     ac_host, agent_cls,
                     1, nac_mode, nat_type,
                     gst_net_app.switc, user_type);
    http_send_redirect(url_redirect,
                       strlen(url_redirect),
                       skb, iph, tcph,
                       1, vlan_id);
    return NAC_KNL_ERR;
}

//���ת�������ݰ�,�򷵻�NAC_KNL_OK,û��ת�����ݰ�,�򷵻�NAC_KNL_ERR
static int nac_knl_pbr_mvg(struct sk_buff *skb, unsigned short vlan_id)
{
	int nac_ret = NAC_KNL_ERR;

    if(!skb
        || ipv4_is_loopback(ip_hdr(skb)->saddr)
        || ipv4_is_loopback(ip_hdr(skb)->daddr))
    {
        return NAC_KNL_ERR;
    }

    if(skb->pkt_type == PACKET_MULTICAST)
    {
        if(!ipv4_is_multicast(ip_hdr(skb)->daddr)
            && !ipv4_is_multicast(ip_hdr(skb)->saddr))
        {
            nac_knl_debug(NAC_KNL_MODULE_GROUB, "nac_knl_pbr_mvg-->group drop, %d.%d.%d.%d===>%d.%d.%d.%d\n", NIPQUAD(ip_hdr(skb)->saddr), NIPQUAD(ip_hdr(skb)->daddr));
            return NAC_KNL_ERR;
        }
        nac_knl_debug(NAC_KNL_MODULE_GROUB, "nac_knl_pbr_mvg-->group, %d.%d.%d.%d===>%d.%d.%d.%d\n", NIPQUAD(ip_hdr(skb)->saddr), NIPQUAD(ip_hdr(skb)->daddr));
        return NAC_KNL_ERR;
    }

    if(nac_mode == NAC_PBR_MODE)
    {
        if(vlan_id > 0)
        {
            return NAC_KNL_ERR;
        }
        nac_ret = nac_knl_pbr(skb);
    }
    if(nac_mode == NAC_MVG_MODE
            && vlan_id > 0)
    {
        nac_ret = nac_knl_mvg(skb, vlan_id);
    }
    if(nac_mode == NAC_BRIDGE_MODE)
    {
        nac_ret = nac_knl_bridge(skb, vlan_id);
    }
	return nac_ret;
}


extern void nac_knl_sys_timer(unsigned long data);
static DEFINE_TIMER(nac_knl_sys_time, nac_knl_sys_timer, 0, 0);
#define NAC_KNL_TIMEOUT (jiffies +  HZ)

int nac_timeout = 60;//1����
unsigned long last_time;
void nac_knl_sys_timer(unsigned long data)
{
    char ac_time[32] = "";
    unsigned long sec;

    sec = get_seconds();

    nac_knl_user_timeout(sec, ac_time);
    nac_knl_domain_timeout(sec, ac_time);
    nac_knl_nat_timeout(sec, ac_time);
    nac_knl_debug(NAC_KNL_MODULE_TIMER, "nac_knl_sys_timer-->time = %s\n", ac_time);
    mod_timer(&nac_knl_sys_time, NAC_KNL_TIMEOUT);
}

static __init int nac_knl_sys_init(void)
{
    int rc = NAC_KNL_ERR;
    printk("nac_knl_sys_init\n");

    last_time = get_seconds();
    pst_in_interface[0]  = NULL;
    pst_out_interface[0] = NULL;

    if(nac_knl_cmd_init() < 0)
    {
        return -ENODEV;
    }

	nac_knl_insert(nac_knl_pbr_mvg);
    rc = nac_knl_proc_init();
	if (0 != rc)
    {
		printk("nac_knl_sys_init-->nac_knl_proc_init error\n");
		return -ENODEV;
	}
    mod_timer(&nac_knl_sys_time, NAC_KNL_TIMEOUT);

    rc = nac_knl_user_init();
	if (0 != rc)
    {
		printk("nac_knl_sys_init-->nac_knl_user_init error\n");
		return -ENODEV;
	}

    rc = nac_knl_netlink_init();
	if (0 != rc)
    {
		printk("nac_knl_sys_init-->nac_knl_netlink_init error\n");
		return -ENODEV;
	}

    nac_knl_policy_init();
    nac_knl_rbtree_init();
    rc = nac_knl_wm_init(&pst_url_wm);
    if(0 != rc)
    {
		printk("nac_knl_sys_init-->nac_knl_wm_init url error\n");
		return -ENODEV;
	}
    rc = nac_knl_wm_init(&pst_user_agent_wm);
    if(0 != rc)
    {
		printk("nac_knl_sys_init-->nac_knl_wm_init user_agent error\n");
		return -ENODEV;
	}
    rc = nac_knl_mvg_init();
    if(0 != rc)
    {
        printk("nac_knl_sys_init-->nac_knl_mvg_init error\n");
		return -ENODEV;
    }
    rc = nac_knl_domain_init();
    if(0 != rc)
    {
        printk("nac_knl_sys_init-->nac_knl_domain_init error\n");
		return -ENODEV;
    }

    rc = nac_knl_nat_init();
    if(0 != rc)
    {
        printk("nac_knl_sys_init-->nac_knl_nat_init error\n");
		return -ENODEV;
    }

    rc = nac_knl_protocol_init();
    if(0 != rc)
    {
        printk("nac_knl_sys_init-->nac_knl_protocol_init error\n");
		return -ENODEV;
    }

    nac_knl_pbr_init();
    nac_knl_bridge_init();

    nac_knl_setCharStep(HOST_KEY_WORD, hostStep);
    nac_knl_setCharStep(HTTP_KEY_WORD, httpStep);
    nac_knl_setCharStep(USER_AGENT_KEY_WORD, user_agent);

	return NAC_KNL_OK;
}

static __exit void nac_knl_sys_exit(void)
{
	printk("nac_knl_sys_exit\n");
    //arp_send
    del_timer_sync(&nac_knl_sys_time);
	nac_knl_clean();
    nac_knl_proc_exit();
    nac_knl_cmd_exit();
    nac_knl_user_exit();
    nac_knl_netlink_exit();
    nac_knl_policy_exit();
    nac_knl_rbtree_exit();
    nac_knl_wm_exit(pst_url_wm, nac_knl_url_wm);
    nac_knl_wm_exit(pst_user_agent_wm, nac_knl_user_agent_wm);
    nac_knl_bridge_exit();
    nac_knl_domain_exit();
    nac_knl_nat_exit();
    nac_knl_protocol_exit();
}

module_init(nac_knl_sys_init);
module_exit(nac_knl_sys_exit);

