#encoding: utf-8
#######################################################################
#### Author: rubyer                                                 ###
#### Date: 2015.1.23												###
#### Description: parse common methods function						###	
#### Modify reason:													###
#### Version: 1.0													###
#### bugs report to hp104@hupu.net									###
#######################################################################
require "cisco_parse"
require "h3c_parse"
require "huawei_parse"
module Switch
	class Fetch
        def Fetch.save_arp(recv_text = "")
            config_fd = File.new("/var/log/show_arp.log", "w+")
            config_fd.write(recv_text)
            config_fd.close
        end

        def Fetch.save_mac_addr(recv_text = "")
            config_fd = File.new("/var/log/show_mac_addr.log", "w+")
            config_fd.write(recv_text)
            config_fd.close
        end

        def Fetch.save_port_status(recv_text = "")
            config_fd = File.new("/var/log/show_port_status.log", "w+")
            config_fd.write(recv_text)
            config_fd.close
        end

        def Fetch.save_current_config(recv_text = "")
            config_fd = File.new("/var/log/show_current_config.log", "w+")
            config_fd.write(recv_text)
            config_fd.close
        end

        def Fetch.save_upload_switch_info(recv_text = "")
            config_fd = File.new("/var/log/upload_switch_info.log", "w+")
            config_fd.write(recv_text)
            config_fd.close
        end

        def Fetch.format_mac_addr(mac_str = "", del = ".")
        	mac_tmp = mac_str.delete(del)	
            mac_format = ""
        	i = 0
        	while i < 12 do
            	if i == 10
                	tmp = mac_tmp[i,2]
            	else
                	tmp = mac_tmp[i,2] + "-"
            	end
        
            	mac_format += tmp
            	i = i + 2
            	tmp = ""
        	end
        	return mac_format
        end

        def Fetch.combine_switch_port_status(int_status, conf_int_status)
        	int_array = int_status
			int_array.length.times do |i|
        		port_tmp = int_array[i]["port"]
        		discribe_tmp = conf_int_status[port_tmp]["describe"]	
        		vlan_tmp	 = conf_int_status[port_tmp]["vlan"]	
        		iftrunk_tmp	 = conf_int_status[port_tmp]["iftrunk"]
        		
        		if !(vlan_tmp.empty?)
        			int_array[i]["vlan"] = vlan_tmp
        		end
        	
        		if  conf_int_status[port_tmp].has_key?("describe") && discribe_tmp != ""
        			int_array[i]["describe"] = discribe_tmp 
					Switch.log.debug "int_array[i][\"discribe\"] = discribe_tmp:#{discribe_tmp}"
        		end
        
        		if !(iftrunk_tmp.empty?)
        			int_array[i]["iftrunk"] = iftrunk_tmp
        		end
				Switch.log.debug "combine_switch_port_status000#{conf_int_status[port_tmp]}"
				Switch.log.debug "combine_switch_port_status0 #{int_array[i]}"
        	end
        
			#Switch.log.debug "int_status = #{int_status}"
			Switch.log.debug "combine_switch_port_status1 #{int_array}"
			Switch.log.debug "combine_switch_port_status2 #{conf_int_status}"
        	return int_array
        end

        
 # 100.times do
 #     ret_json_text += sw_args.to_json
 # end
 # ret_json_text += "循环结构在编程语言中是不可或缺的，所以Ruby中的循环也有其自定义的规则。"

        def Fetch.check_switch(sw_text, get_methods)
            ret_json_text = ""
            ret_switch_info_list = {}
            ret_test_switch_info = {}
            method  = sw_text["method"]
            sw_args = sw_text["result"]
            ret_switch_info_list["ip"]   = sw_text["ip"]
            ret_switch_info_list["linkStatus"] = sw_text["status"]

            #ret_test_switch_info["ip"]   = sw_text["ip"]
            #ret_test_switch_info["linkStatus"] = sw_text["status"]


            ret_test_switch_info["link"] = "连接交换机[#{sw_text["ip"]}]成功"
            if sw_text["status"] == 201
                ret_test_switch_info["link"] = "登陆交换机[#{sw_text["ip"]}]失败"
			end
            if sw_text["status"] == 203
                ret_test_switch_info["link"] = "连接交换机[#{sw_text["ip"]}]失败"
            else
                ret_test_switch_info["login"] = "交换机身份验证[%s]成功" %"#{sw_text["ip"]}"
                if sw_text["status"] == 205 || sw_text["status"] == 206
                    ret_test_switch_info["login"] = "交换机身份验证[%s]失败" %"#{sw_text["ip"]}"    
                else
                    ret_test_switch_info["super"] = "进入交换机[%s]enable/super模式成功" %sw_text["ip"]
                    if sw_text["status"] == 208
                        ret_test_switch_info["super"] = "进入交换机[%s]enable/super模式失败" %sw_text["ip"]
                    end
                end
            end

           # Fetch.save_arp(sw_args["show_arp"])
           # Fetch.save_mac_addr(sw_args["show_mac_address_table"])
           # Fetch.save_port_status(sw_args["show_interfaces_status"])
           # Fetch.save_current_config(sw_args["show_running_config"])

            if sw_args.kind_of?(Hash) && sw_args.has_key?("show_arp") && sw_args.has_key?("show_arp_command") 
                ret_switch_info_list["arpList"] = []
                ret_test_switch_info["arpCmd"] = sw_args["show_arp_command"]
                ret_test_switch_info["parseArp"] = "解析ARP信息失败"

                if Fetch.respond_to?(get_methods["show_arp"])
                    ret_switch_info_list["arpList"] = Fetch.send(get_methods["show_arp"], sw_args["show_arp"])
                else
                    puts "the #{get_methods["show_arp"]} method un_exist!"
                end

                if !(ret_switch_info_list["arpList"].empty?) 
                    ret_test_switch_info["parseArp"] = "解析ARP信息成功"
                end
            end

            if sw_args.kind_of?(Hash) && sw_args.has_key?("show_mac_address_table") && sw_args.has_key?("show_mac_address_table_command")
                ret_switch_info_list["macList"] = []
                ret_test_switch_info["macCmd"] = sw_args["show_mac_address_table_command"]
                ret_test_switch_info["parseMac"] = "解析MAC信息失败"

                if Fetch.respond_to?(get_methods["show_mac_address_table"])
                    ret_switch_info_list["macList"] = Fetch.send(get_methods["show_mac_address_table"], sw_args["show_mac_address_table"])
                else
                    puts "the #{get_methods["show_mac_address_table"]} method un_exist!"
                end

                if !(ret_switch_info_list["macList"].empty?)
                    ret_test_switch_info["parseMac"] = "解析MAC信息成功"
                end
            end
            #ret_test_switch_info["show_mac_address_table"] = (ret_switch_info_list["macList"].empty?) ? "error":"ok"
            
            if sw_args.kind_of?(Hash) && sw_args.has_key?("show_interfaces_status") && sw_args.has_key?("show_interfaces_status_command")                
                interface_status_list = []
                
                ret_test_switch_info["portCmd"] = sw_args["show_interfaces_status_command"]
                ret_test_switch_info["parsePort"] = "解析PORT信息失败"

                if Fetch.respond_to?(get_methods["show_interfaces_status"])
                    interface_status_list = Fetch.send(get_methods["show_interfaces_status"], sw_args["show_interfaces_status"])
                else
                    puts "the #{get_methods["show_interfaces_status"]} method un_exist!"
                end

                if !(interface_status_list.empty?)
                    ret_test_switch_info["parsePort"] = "解析PORT信息成功"
                end

            end
            
            if sw_args.kind_of?(Hash) && sw_args.has_key?("show_running_config") && sw_args.has_key?("show_running_config_command")                
                current_interface_status_list = {}  
                ret_test_switch_info["configCmd"] = sw_args["show_running_config_command"]
                ret_test_switch_info["parseConfig"] = "解析CONFIG失败"

                if Fetch.respond_to?(get_methods["show_running_config"])
                    current_interface_status_list = Fetch.send(get_methods["show_running_config"], sw_args["show_running_config"])
                else
                    puts "the #{get_methods["show_running_config"]} method un_exist!"
                end

                if !(current_interface_status_list.empty?)
                    ret_test_switch_info["parseConfig"] = "解析CONFIG成功"
                end

            end

            if method == "TestSwitch"
                ret_test_switch_info["result"] = "测试交换机[%s]成功" %sw_text["ip"]
                if sw_text["status"] != 200
                    ret_test_switch_info["result"] = "测试交换机[%s]失败" %sw_text["ip"]
                end
                ret_json_text = ret_test_switch_info.to_json
            elsif method = "UploadSwitchInfo" || method = "GetSwitchInfo"
                if interface_status_list.size > 0 && current_interface_status_list.size > 0
                    ret_switch_info_list["portList"] = Fetch.combine_switch_port_status(interface_status_list, current_interface_status_list)
                else
                    ret_switch_info_list["portList"] = (interface_status_list.size > 0) ? interface_status_list:current_interface_status_list
                end
                ret_json_text = ret_switch_info_list.to_json
            else
                puts "the method is unfind..."
            end

            #Fetch.save_upload_switch_info(ret_json_text)
            return ret_json_text
        end

        def Fetch.test_switch_connect(sw_text)
            ret_json_text = ""
            ret_switch_info_list = {}
            ret_test_switch_info = {}
            method  = sw_text["method"]
            sw_args = sw_text["result"]
            ret_switch_info_list["ip"]   = sw_text["ip"]
            ret_switch_info_list["linkStatus"] = sw_text["status"]
            ret_test_switch_info["ip"]   = sw_text["ip"]
            ret_test_switch_info["linkStatus"] = sw_text["status"]
            if sw_args.kind_of?(Hash) && sw_args.has_key?("show_arp")
                ret_switch_info_list["arpList"] = Fetch.get_cisco_arp(sw_args["show_arp"])
            else
                ret_switch_info_list["arpList"] = []    
            end
            ret_test_switch_info["show_arp"] = (ret_switch_info_list["arpList"].empty?)? "error":"ok"
           
            if sw_args.kind_of?(Hash) && sw_args.has_key?("show_mac_address_table")
                ret_switch_info_list["macList"] = Fetch.get_cisco_mac_addr(sw_args["show_mac_address_table"])
            else
                ret_switch_info_list["macList"] = []    
            end
            ret_test_switch_info["show_mac_address_table"] = (ret_switch_info_list["macList"].empty?) ? "error":"ok"
            
            if sw_args.kind_of?(Hash) && sw_args.has_key?("show_interfaces_status")
                interface_status_list = Fetch.get_cisco_port_status(sw_args["show_interfaces_status"])
            else
                interface_status_list = []  
            end
            ret_test_switch_info["show_interfaces_status"] = (interface_status_list.empty?)? "error":"ok"
            
            if sw_args.kind_of?(Hash) && sw_args.has_key?("show_running_config")
                current_interface_status_list = Fetch.get_cisco_current_config(sw_args["show_running_config"])
            else
                current_interface_status_list = {}  
            end
            ret_test_switch_info["show_running_config"] = (current_interface_status_list.empty?) ? "error":"ok"

            case method
            when "TestSwitch" then
                ret_json_text = ret_test_switch_info.to_json
            when "UploadSwitchInfo" then
                if interface_status_list.size > 0 && current_interface_status_list.size > 0
                    ret_switch_info_list["portList"] = Fetch.combine_switch_port_status(interface_status_list, current_interface_status_list)
                else
                    ret_switch_info_list["portList"] = (interface_status_list.size > 0) ? interface_status_list:current_interface_status_list
                end
                ret_json_text = ret_switch_info_list.to_json
            else
                puts "the method is unfind..."
            end
            return ret_json_text
        end

	end #end class Fetch
end #end module Switch
