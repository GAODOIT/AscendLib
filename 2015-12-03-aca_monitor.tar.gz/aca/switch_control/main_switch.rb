#!/usr/bin/env ruby
#encoding: utf-8
#######################################################################
#### Author: chenxiaokang                                           ###
#### Date: 2015.1.13												###
#### Description: switch controll main function						###	
#### Modify reason:													###
#### Version: 1.0													###
#### bugs report to hp104@hupu.net									###
#######################################################################
path = File.absolute_path(__FILE__)
$LOAD_PATH.unshift(File.dirname(path))
require "switch"
include Switch
#record pid and kill last process
if File.exist?("/var/run/switch.pid")
	`cat /var/run/switch.pid|xargs kill -9`
end
`echo "#{Process.pid}" > /var/run/switch.pid`
$env_type = 0
$env_type = 1 if ARGV.size > 0 && ARGV[0] == "debug"
puts "env_type = #{$env_type}"
#Thread.abort_on_exception = true
$link_s = ConnectServer.new
$link_s.read_config
#$link_s = ConnectServer.new("localhost", 6003)
#$link_s.connect
handle = Handle.new
handle.connect = $link_s
handle.start_work(5)
handle.init_heartbeat

# receive the long connect msg thread
do_rev = Thread.new{
	msg_proc = ParseMsg.new
	loop do
		#puts "#{Thread.current} receive thread running"
		status, msg_s = $link_s.read
		if status == 0
			Log.debug "#####origin msg:\n[\n#{msg_s}\n]"
			msgs = msg_proc.parse(msg_s)
			msgs.each do |msg|
				Log.debug "rev msg:\n[\n#{msg}\n]"
				method = msg["head"]["MessageMethod"]
                
                if (method == "HeartBeat")
                    $recv_timeout = 18                    
                end

				call_method = "handle_#{method}"
				begin
					if handle.respond_to?(call_method)
						Log.info "will call #{call_method}"
						handle.send(call_method, msg["body"], msg["head"])
					else
						Log.error "method error: #{msg}"
						#handle.handle_MethodError(msg["body"], msg["head"])
					end
				rescue => error_msg
					Log.error error_msg
				end
			end
		end
	end
}

# handle the switch_msg and send to server
do_msg = Thread.new{
	loop{
		#puts "#{Thread.current} fetch thread running"
		handle.msg_fetch
		sleep(0.2)
		Thread.pass
	}
}

handle.task_timer

sig_usr1_handler = Proc.new {
						handle.stop_heartbeat
                        $link_s.close 
						$link_s.read_config
						#Switch.log.info "receive signal USR1"
                    }
Signal.trap("USR1", &sig_usr1_handler);

Thread.new {
	ext = ExtHandle.new
	ext.handle_ins = handle
	ext.connect_ins = $link_s
	ext.udpserver
}
loop do
	#Thread.list.each {|t| p t}
	#puts "main current thread #{Thread.current}"
	#puts "thread number = #{Thread.list.size} master running"
	#puts "==============================================#{$link_s.link_fd}\n"
	#if $link_s.flag  != 0
	sleep(3)
	#Log.debug "nac status = #{$link_s.nac_status}"
	if $link_s.link_fd  == nil
    if $link_s.connect == 0
			handle.do_GetSwitchList
			handle.init_heartbeat
		else
			Log.error "connect server failed  will reconnect server"
		end
		sleep(30)
	end
end
