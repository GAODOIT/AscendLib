########################################################################
##### Author: chenxiaokang                                           ###
##### Date: 2015.3.25                                                ###
##### Description: switch parsing function                           ### 
##### Modify reason:                                                 ###
##### Version: 1.0                                                   ###
##### bugs report to hp104@hupu.net                                  ###
########################################################################
#encoding: UTF-8
require "parsing"
require "json"
module Switch
	class ParseHuawei
		def initialize
			@option = {}
			@option["mac_flag"] = "-"
			content = {}
			content["s_txt"] = "IP ADDRESS"
			content["d_txt"] = "Total"
			content["number"] = 2
			@option["content"] = content
			replace = {}
			reg = {}
			reg["GE"] = /GE/
			txt={}
			txt["GE"] = "GigabitEthernet"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			fetch = {}
			fetch["start"] = "" 
			fetch["first"] = ""
			fetch["key"]
			@option["fetch"] = fetch
			config = {}
			config["flag"] = "#\n"
			config["regex"] = "interface GigabitEthernet"
			@option["config"] = config
			arp = {}
			arp["mac"] = 1
			arp["ip"] = 0
			@option["arp"] = arp
			##############################
			@parse = Parsing.new
		end
		def get_vlan(sw_text)
			text = @parse.parse_args(sw_text)
			vlans = []
			if text
				config_txt = text["config"]
				cfg_dic = get_config(config_txt)
				if cfg_dic
					cfg_dic.each do |key, info|
						vlans << info["vlan"]
					end
				end
			end
			vlan_obj = {}
			vlan_obj["vlanList"] = vlans unless vlans == []
			vlan_obj["ip"] = text["ip"] unless vlans == []
			vlan_obj["method"] = text["method"] unless vlans == []
			vlan_obj == {} ? nil : JSON.generate(vlan_obj)
		end
		def get_info(sw_text)
			text = @parse.parse_args(sw_text)
			arp_txt = text["arp"]
			config_txt = text["config"]
			interface_txt = text["interface"]
			mac_txt   = text["mac"]
			cfg_dic = get_config(config_txt)
			if_dic  = get_interface(interface_txt)
			mac_dic = get_mac(mac_txt)
			arp_list = get_arp(arp_txt)
			return nil if !(cfg_dic && if_dic && mac_dic && arp_list)
			#get interface status and port list
			port_list = []
			if_dic.each do |key, array_t|
				iface = array_t[0]
				if cfg_dic.has_key?(iface)
					cfg_dic[iface]["status"] = array_t[1]
					port_list << cfg_dic[iface]
				end

			end
			#get mac list
			mac_list = []
			mac_dic.each do |key, arr|
				mac_tmp = {}
				port_str = arr[2]
				mac_str  = arr[0]
				if cfg_dic.has_key?(port_str)
					mac_tmp["port"] = port_str
					mac_tmp["mac"]  = mac_str
					mac_tmp["vlan"] = cfg_dic[mac_tmp["port"]]["vlan"]
					mac_list << mac_tmp
				end
			end
			switch_info = {}
			switch_info["arpList"] = arp_list if arp_list
			switch_info["macList"] = mac_list if mac_list
			switch_info["portList"] = port_list if port_list
			if !(switch_info == {})
				switch_info["ip"] = text["ip"]
				switch_info["linkStatus"] = text["status"]
			end
			JSON.generate(switch_info)
		end
		def get_arp(text)
			content = {}
			content["s_txt"] = "IP ADDRESS"
			content["d_txt"] = "Total"
			content["number"] = 2
			@option["content"] = content
			####################################
			replace = {}
			reg = {}
			reg["GE"] = /GE/
			txt={}
			txt["GE"] = "GigabitEthernet"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			####################################
			fetch = {}
			fetch["start"] = /\A\d/
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch
			####################################
			arp = {}
			arp["mac"] = 1
			arp["ip"] = 0
			@option["arp"] = arp

			arp_array = @parse.parse_arp(@option, text)

		end
		def get_mac(text)
			content = {}
			content["s_txt"] = "MAC Address"
			content["d_txt"] = "Total items displayed"
			content["number"] = 2
			@option["content"] = content
			####################################
			replace = {}
			reg = {}
			reg["GE"] = /GE/
			txt={}
			txt["GE"] = "GigabitEthernet"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			####################################
			fetch = {}
			fetch["start"] = /\A[0-9a-fA-F]{4}-[0-9a-fA-F]{4}/
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch	
			mac_dic = @parse.parse_mac(@option, text)
		end
		def get_interface(text)
			content = {}
			content["s_txt"] = "Interface                   PHY"
			content["d_txt"] = ""
			content["number"] = 1
			@option["content"] = content
			replace = {}
			reg = {}
			reg["cnt1"] = /up/
			reg["cnt2"] = /down/
			txt={}
			txt["cnt1"] = "connected"
			txt["cnt2"] = "notconnect"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			####################################
			fetch = {}
			fetch["start"] = /\AGigabitEthernet/
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch	
			interface_dic = @parse.parse_interface(@option, text)
		end
		def get_config(text)
			config = {}
			config["flag"] = "#\n"
			config["regex"] = /interface GigabitEthernet\d\/\d\/\d/
			@option["config"] = config
			config_array = @parse.parse_config(@option, text)
			return nil if !config_array
			config_dic =  {}
			config_array.each do |item|
				iface = item.split("\n")[0].split(" ", 2)[1]
				config_dic[iface] = item.split("\n")
			end
			regx_vlan = /port default vlan \d+/
			regx_trunk = /port link-type trunk/
			regx_trunk_vlan = /port trunk pvid vlan \d+/
			regx_access = /port link-type access/
			regx_dsrp   = /description/
			cfg_dic = {}
			if config_dic != {}
				keyes = config_dic.keys
				keyes.each do |key|
					t_cfg = {}
					t_cfg["port"] = key
					t_cfg["describe"] = ""
					t_cfg["status"] = "notconnect"
					t_cfg["vlan"]   = "1"
					t_cfg["iftrunk"] = "0"
					config_dic[key].each do |item|
						if regx_vlan =~ item
							t_cfg["vlan"] = item.split(" ", 4)[3]
						elsif regx_trunk =~ item
							t_cfg["iftrunk"] = "1"
						elsif regx_trunk_vlan =~ item
							t_cfg["vlan"] = item.split(" ", 5)[4]
						elsif regx_dsrp =~ item
							t_cfg["describe"] = item.split(" ", 2)[1]
						end
						cfg_dic[key] = t_cfg
					end
				end
			end
			cfg_dic == {} ? nil : cfg_dic
		end
		def test_switch(sw_text)
			text = @parse.parse_args(sw_text)
			result = @parse.parse_test_switch(text)
			if text && text["status"] == 200
				arp_txt = text["arp"]
				config_txt = text["config"]
				interface_txt = text["interface"]
				mac_txt   = text["mac"]
				if_dic  = get_interface(interface_txt)
				mac_dic = get_mac(mac_txt)
				arp_list = get_arp(arp_txt)
				cfg_dic  = get_config(config_txt)
				info     = get_info(sw_text)
				if arp_list && @parse.verify_info(info, "arpList")
					result["parseArp"] = "解析ARP信息成功"
					result["arpCmd"]   = text["arp_cmd"]
				else
					result["parseArp"] = "解析ARP信息失败"
					result["arpCmd"]   = text["arp_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if mac_dic && @parse.verify_info(info, "macList")
					result["parseMac"] = "解析MAC信息成功"
					result["macCmd"]   = text["mac_cmd"]
				else
					result["parseMac"] = "解析MAC信息失败"
					result["macCmd"]   = text["mac_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if if_dic && @parse.verify_info(info, "portList")
					result["parsePort"] = "解析PORT信息成功"
					result["portCmd"]   = text["interface_cmd"]
				else
					result["parsePort"] = "解析PORT信息失败"
					result["portCmd"]   = text["interface_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if cfg_dic && @parse.verify_info(info, "portList")
					result["parseConfig"] = "解析CONFIG信息成功"
					result["configCmd"]   = text["config_cmd"]
				else
					result["parseConfig"] = "解析CONFIG信息失败"
					result["configCmd"]   = text["config_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				result["result"] = "测试交换机[%s]失败" % sw_text["ip"] unless arp_list && mac_dic && if_dic && cfg_dic
			end
			result == nil ? nil : JSON.generate(result)
		end
	end
	class ParseH3c
		def initialize
			@option = {}
			@option["mac_flag"] = "-"
			content = {}
			content["s_txt"] = "IP ADDRESS"
			content["d_txt"] = "Total"
			content["number"] = 2
			@option["content"] = content
			replace = {}
			reg = {}
			reg["GE"] = /GE/
			txt={}
			txt["GE"] = "GigabitEthernet"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			fetch = {}
			fetch["start"] = "" 
			fetch["first"] = ""
			fetch["key"]
			@option["fetch"] = fetch
			config = {}
			config["flag"] = "#\n"
			config["regex"] = "interface GigabitEthernet"
			@option["config"] = config
			arp = {}
			arp["mac"] = 1
			arp["ip"] = 0
			@option["arp"] = arp
			format_s = {}
			format_s["k_regx"] = /Ethernet\d\/\d\/\d/
			format_s["s_regx"] = /\A\n/
			#@option["format"]= format_s	
			##############################
			@parse = Parsing.new
		end
		def get_arp(text)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "IP Address"
			#content["d_txt"] = "entries found"
			content["d_txt"] = ""
			content["number"] = 1
			@option["content"] = content
			####################################
			arp = {}
			arp["mac"] = 1
			arp["ip"] = 0
			@option["arp"] = arp
			###################################
			fetch = {}
			fetch["start"] = /\A\d/
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch	
			####################################
			arp = {}
			arp["mac"] = 1
			arp["ip"] = 0
			@option["arp"] = arp
			arp_array = @parse.parse_arp(@option, text)

		end
		def get_mac(text)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "MAC ADDR"
			#content["d_txt"] = "mac address(es)"
			content["d_txt"] = ""
			content["number"] = 1
			@option["content"] = content
			####################################
			fetch = {}
			fetch["start"] = /\A[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}/
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch	
			mac_dic = @parse.parse_mac(@option, text)
		end
		def get_interface(text)
			@option = @parse.init_option(@option)
			replace = {}
			reg = {}
			reg["state1"] = /UP/
			reg["state2"] = /DOWN|ADM/
			txt={}
			txt["state1"] = "connected"
			txt["state2"] = "notconnect"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			format_s = {}
			format_s["k_regx"] = /Ethernet\d\/\d\/\d/
			format_s["s_regx"] = /\n\n/
			@option["format"]= format_s	
			if_dic = @parse.parse_h3c_interface(@option, text)
			return nil if !if_dic
			#Switch.log.debug "if_dic = #{if_dic}"	
			regx_vlan = /PVID: \d+/
			regx_trunk = /Port link-type: trunk/
			regx_access = /port link-type access/
			regx_dsrp   = /Description/
			regx_status = /current state/
			inface_dic = {}
			if if_dic
				keyes = if_dic.keys
				keyes.each do |key|
					next unless  /Ethernet\d\/\d\/\d/ =~ key
					t_cfg = {}
					t_cfg["port"] = key
					t_cfg["describe"] = ""
					t_cfg["status"] = "notconnect"
					t_cfg["vlan"]   = "1"
					t_cfg["iftrunk"] = "0"
					if_dic[key].each do |item|
						if regx_vlan =~ item
							t_cfg["vlan"] = item.split(" ", 2)[1]
						elsif regx_trunk =~ item
							t_cfg["iftrunk"] = "1"
						elsif regx_dsrp =~ item
							t_cfg["describe"] = item.split(" ", 2)[1].force_encoding("ISO-8859-1").encode("UTF-8")
						elsif regx_status =~ item
							item.split.each do |state|
								t_cfg["status"] = state.strip if /notconnect|connected/ =~ state
							end
						end
						inface_dic[key] = t_cfg
					end
				end
			end
			inface_dic == {} ? nil : inface_dic
		end
		def get_info(sw_text)
			text = @parse.parse_args(sw_text)
			if text
				arp_txt = text["arp"]
				config_txt = text["config"]
				interface_txt = text["interface"]
				mac_txt   = text["mac"]
				#cfg_dic = get_config(config_txt)
				if_dic  = get_interface(interface_txt)
				mac_dic = get_mac(mac_txt)
				arp_list = get_arp(arp_txt)
				return nil if !(if_dic && mac_dic && arp_list)
				#get interface status and port list
				port_list = []
				if_dic.each do |key, array_t|
					port_list << if_dic[key]
				end
				#get mac list
				mac_list = []
				mac_dic.each do |key, arr|
					mac_tmp = {}
					mac_tmp["port"] = arr[3]
					mac_tmp["mac"]  = arr[0]
					mac_tmp["vlan"] = if_dic[mac_tmp["port"]]["vlan"]
					mac_list << mac_tmp
				end
				switch_info = {}
				switch_info["arpList"] = arp_list if arp_list
				switch_info["macList"] = mac_list if mac_list
				switch_info["portList"] = port_list if port_list
				if !(switch_info == {})
					switch_info["ip"] = text["ip"]
					switch_info["linkStatus"] = text["status"]
				end
			end
			switch_info == {} ? nil : JSON.generate(switch_info)
		end
		def get_vlan(sw_text)
			text = @parse.parse_args(sw_text)
			vlans = []
			if text
				iface_s = text["interface"]
				iface_list = get_interface(iface_s)
				if iface_list
					iface_list.each do |key, info|
						vlans << info["vlan"]
					end
				end
			end
			Switch.log.debug "get_vlan text  = #{text}"
			Switch.log.debug "get_vlan vlan list = #{vlans}"
			vlan_obj = {}
			vlan_obj["vlanList"] = vlans unless vlans == []
			vlan_obj["ip"] = text["ip"] unless vlans == []
			vlan_obj["method"] = text["method"] unless vlans == []
			vlan_obj == {} ? nil : JSON.generate(vlan_obj)
		end
		def test_switch(sw_text)
			text = @parse.parse_args(sw_text)
			result = @parse.parse_test_switch(text)
			if text && text["status"] == 200
				arp_txt = text["arp"]
				config_txt = text["config"]
				interface_txt = text["interface"]
				mac_txt   = text["mac"]
				if_dic  = get_interface(interface_txt)
				mac_dic = get_mac(mac_txt)
				arp_list = get_arp(arp_txt)
				info     = get_info(sw_text)
				if arp_list && @parse.verify_info(info, "arpList")
					result["parseArp"] = "解析ARP信息成功"
					result["arpCmd"]   = text["arp_cmd"]
				else
					result["parseArp"] = "解析ARP信息失败"
					result["arpCmd"]   = text["arp_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if mac_dic && @parse.verify_info(info, "macList")
					result["parseMac"] = "解析MAC信息成功"
					result["macCmd"]   = text["mac_cmd"]
				else
					result["parseMac"] = "解析MAC信息失败"
					result["macCmd"]   = text["mac_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if if_dic && @parse.verify_info(info, "portList")
					result["parsePort"] = "解析PORT信息成功"
					result["portCmd"]   = text["interface_cmd"]
				else
					result["parsePort"] = "解析PORT信息失败"
					result["portCmd"]   = text["interface_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if if_dic && @parse.verify_info(info, "portList")
					result["parseConfig"] = "解析CONFIG信息成功"
					result["configCmd"]   = "display current-configuration"
				else
					result["parseConfig"] = "解析CONFIG信息失败"
					result["configCmd"]   = "display current-configuration"
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				result["result"] = "测试交换机[%s]失败" % sw_text["ip"] unless arp_list && mac_dic && if_dic
			end
			result == nil ? nil : JSON.generate(result)
		end
	end
	class ParseCisco
		def initialize
			@option = {}
			@option["mac_flag"] = "."
			@parse = Parsing.new
		end
		def get_arp(text)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "Protocol  Address"
			#content["d_txt"] = "entries found"
			content["d_txt"] = ""
			content["number"] = 1
			@option["content"] = content
			####################################
			arp = {}
			arp["mac"] = 3
			arp["ip"] = 1
			@option["arp"] = arp
			###################################
			fetch = {}
			fetch["start"] = /\AInternet/
			#fetch["first"] = ""
			fetch["key"] = 1
			@option["fetch"] = fetch	
			###################################
			arp_array = @parse.parse_arp(@option, text)

		end
		def get_mac_4507(txt)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "vlan     mac address"
			#content["d_txt"] = "mac address(es)"
			content["d_txt"] = "Multicast Entries"
			content["number"] = 2
			@option["content"] = content
			# ####################################
			# replace = {}
			# reg = {}
			# reg["cnt1"] = /Fa/
			# reg["cnt2"] = /Gi/
			# txt={}
			# txt["cnt1"] = "FastEthernet"
			# txt["cnt2"] = "GigabitEthernet"
			# replace["reg"] = reg
			# replace["txt"] = txt
			# @option["replace"] = replace
			####################################
			fetch = {}
			fetch["start"] = /[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}/
			#fetch["first"] = ""
			fetch["key"] = 1
			@option["fetch"] = fetch
			mac_dic = @parse.parse_mac(@option, txt)
			mac_dic.each do |key, array|
				if array.size != 5 && array[2] == "static"
					mac_dic.delete(key)
				end
			end
			mac_dic
		end
		def get_mac_7609(text)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "vlan   mac address"
			#content["d_txt"] = "mac address(es)"
			content["d_txt"] = ""
			content["number"] = 2
			@option["content"] = content
			####################################
			replace = {}
			reg = {}
			reg["cnt1"] = /Fa/
			reg["cnt2"] = /Gi/
			reg["cnt3"] = /Po/
			txt={}
			txt["cnt1"] = "FastEthernet"
			txt["cnt2"] = "GigabitEthernet"
			txt["cnt3"] = "Port-channel"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			####################################
			fetch = {}
			fetch["start"] = /[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}/
			#fetch["first"] = ""
			fetch["key"] = 1
			@option["fetch"] = fetch
			mac_dic = @parse.parse_mac(@option, text)
			mac_dic.each do |key, array|
				if array.size != 7 && array[3] == "static"
					mac_dic.delete(key)
				end
			end
			mac_dic
		end
		def get_mac(text)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "Vlan    Mac Address"
			#content["d_txt"] = "mac address(es)"
			content["d_txt"] = ""
			content["number"] = 2
			@option["content"] = content
			####################################
			replace = {}
			reg = {}
			reg["cnt1"] = /Fa/
			reg["cnt2"] = /Gi/
			txt={}
			txt["cnt1"] = "FastEthernet"
			txt["cnt2"] = "GigabitEthernet"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			####################################
			fetch = {}
			fetch["start"] = /[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}/
			#fetch["first"] = ""
			fetch["key"] = 1
			@option["fetch"] = fetch	
			mac_dic = @parse.parse_mac(@option, text)
		end
		def get_interface(text)
			content = {}
			content["s_txt"] = "Port"
			content["d_txt"] = ""
			content["number"] = 1
			@option["content"] = content
			replace = {}
			reg = {}
			reg["cnt1"] = /Fa/
			reg["cnt2"] = /Gi/
			reg["cnt3"] = /disabled/
			reg["cnt4"] = /Not Present/
			reg["cnt5"] = /Po/
			reg["cnt6"] = /BaseLX SFP/
			reg["cnt7"] = /No X2/
			reg["cnt8"] = /No Gbic/
			reg["cnt9"] = /Te/
			reg["cnt10"] = /inactive/
			txt={}
			txt["cnt1"] = "FastEthernet"
			txt["cnt2"] = "GigabitEthernet"
			txt["cnt3"] = "notconnect"
			txt["cnt4"] = "NO"
			txt["cnt5"] = "Port-channel"
			txt["cnt6"] = "BaseLX_SFP"
			txt["cnt7"] = "No_X2"
			txt["cnt8"] = "No_Gbic"
			txt["cnt9"] = "TenGigabitEthernet"
			txt["cnt10"] = "notconnect"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			####################################
			fetch = {}
			fetch["start"] = /Ethernet\d\/\d|Port-channel\d+/
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch	
			interface_dic = @parse.parse_interface(@option, text)
		end
		def get_config(text)
			config = {}
			config["flag"] = "!\n"
			config["regex"] = /Ethernet\d\/\d|Port-channel\d+/
			@option["config"] = config
			config_array = @parse.parse_config(@option, text)
			return nil if !config_array
			config_dic =  {}
			config_array.each do |item|
				iface = item.split("\n")[0].split(" ", 2)[1]
				config_dic[iface] = item.split("\n")
			end
			regx_vlan = /switchport access vlan \d+/
			regx_trunk = /switchport mode trunk/
			regx_trunk_vlan = /switchport trunk native vlan \d+/
			regx_access = /switchport mode access/
			regx_dsrp   = /description/
			cfg_dic = {}
			if config_dic
				keyes = config_dic.keys
				keyes.each do |key|
					t_cfg = {}
					t_cfg["port"] = key
					t_cfg["describe"] = ""
					t_cfg["status"] = "notconnect"
					t_cfg["vlan"]   = "1"
					t_cfg["iftrunk"] = "0"
					config_dic[key].each do |item|
						if regx_vlan =~ item
							t_cfg["vlan"] = item.split[-1]
						elsif regx_trunk =~ item
							t_cfg["iftrunk"] = "1"
						elsif regx_trunk_vlan =~ item
							t_cfg["vlan"] = item.split[-1]
						elsif regx_dsrp =~ item
							t_cfg["describe"] = item.split(" ", 2)[1]
						end
						cfg_dic[key] = t_cfg
					end
				end
			end
			cfg_dic == {} ? nil : cfg_dic
		end
		def get_info(sw_text)
			text = @parse.parse_args(sw_text)
			if text
				arp_txt = text["arp"]
				config_txt = text["config"]
				interface_txt = text["interface"]
				mac_txt   = text["mac"]
				cfg_dic = get_config(config_txt)
				if_dic  = get_interface(interface_txt)
				mac_dic = nil
				if text["sw_type"] =~ /cisco_7609/
					mac_dic = get_mac_7609(mac_txt)
				elsif  text["sw_type"] =~ /cisco_4507/
					mac_dic = get_mac_4507(mac_txt)
				else
					mac_dic = get_mac(mac_txt)
				end
				arp_list = get_arp(arp_txt)
				return nil if !(if_dic && mac_dic && arp_list && config_txt)
				#get interface status and port list
				port_list = []
				if_dic.each do |key, array_t|
					iface = array_t[0]
					if array_t.size < 6
						iface_status = "connected"
					else
						iface_status = array_t[-5]
					end
					if cfg_dic.has_key?(iface)
						cfg_dic[iface]["status"] = iface_status
						port_list << cfg_dic[iface]
					end 

				end
				#get mac list
				mac_list = []
				mac_dic.each do |key, arr|
					if cfg_dic.has_key?(arr[-1])
						mac_tmp = {}
						if text["sw_type"] =~ /cisco_7609/
							mac_tmp["port"] = arr[-1]
							mac_tmp["mac"]  = arr[2]
						elsif text["sw_type"] =~ /cisco_4507/
							mac_tmp["port"] = arr[-1]
							mac_tmp["mac"]  = arr[1]
						else
							mac_tmp["port"] = arr[3]
							mac_tmp["mac"]  = arr[1]
						end
						mac_tmp["vlan"] = cfg_dic[mac_tmp["port"]]["vlan"]
						mac_list << mac_tmp
					end
				end
				switch_info = {}
				switch_info["arpList"] = arp_list if arp_list
				switch_info["macList"] = mac_list if mac_list
				switch_info["portList"] = port_list if port_list
				if !(switch_info == {})
					switch_info["ip"] = text["ip"]
					switch_info["linkStatus"] = text["status"]
				end
			end
			switch_info == {} ? nil : JSON.generate(switch_info)
		end
		def get_vlan(sw_text)
			text = @parse.parse_args(sw_text)
			vlans = []
			if text
				config_s = text["config"]
				config_list = get_config(config_s)
				if config_list
					config_list.each do |key, info|
						vlans << info["vlan"]
					end
				end
			end
			Switch.log.debug "get_vlan text  = #{text}"
			Switch.log.debug "get_vlan vlan list = #{vlans}"
			vlan_obj = {}
			vlan_obj["vlanList"] = vlans unless vlans == []
			vlan_obj["ip"] = text["ip"] unless vlans == []
			vlan_obj["method"] = text["method"] unless vlans == []
			vlan_obj == {} ? nil : JSON.generate(vlan_obj)
		end
		def test_switch(sw_text)
			text = @parse.parse_args(sw_text)
			result = @parse.parse_test_switch(text)
			#Switch.log.debug "test_switch text = #{text}"
			if text && text["status"] == 200
				arp_txt = text["arp"]
				config_txt = text["config"]
				interface_txt = text["interface"]
				mac_txt   = text["mac"]
				if_dic  = get_interface(interface_txt)
                if text["sw_type"] =~ /cisco_7609/
				    mac_dic = get_mac_7609(mac_txt)
                elsif text["sw_type"] =~ /cisco_4507/
                    mac_dic = get_mac_4507(mac_txt)
                else
                    mac_dic = get_mac(mac_txt)
                end
				arp_list = get_arp(arp_txt)
				cfg_dic  = get_config(config_txt)
				info = get_info(sw_text)
				if arp_list && @parse.verify_info(info, "arpList")
					result["parseArp"] = "解析ARP信息成功"
					result["arpCmd"]   = text["arp_cmd"]
				else
					result["parseArp"] = "解析ARP信息失败"
					result["arpCmd"]   = text["arp_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if mac_dic && @parse.verify_info(info, "macList")
					result["parseMac"] = "解析MAC信息成功"
					result["macCmd"]   = text["mac_cmd"]
				else
					result["parseMac"] = "解析MAC信息失败"
					result["macCmd"]   = text["mac_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
                end
				if if_dic && @parse.verify_info(info, "portList")
					result["parsePort"] = "解析PORT信息成功"
					result["portCmd"]   = text["interface_cmd"]
				else
					result["parsePort"] = "解析PORT信息失败"
					result["portCmd"]   = text["interface_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if cfg_dic && @parse.verify_info(info, "portList")
					result["parseConfig"] = "解析CONFIG信息成功"
					result["configCmd"]   = text["config_cmd"]
				else
					result["parseConfig"] = "解析CONFIG信息失败"
					result["configCmd"]   = text["config_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				result["result"] = "测试交换机[%s]失败" % sw_text["ip"] unless arp_list && mac_dic && if_dic && cfg_dic
			end
			result == nil ? nil : JSON.generate(result)
		end
	end
	class ParseShenZhouShuMa
		def initialize
			@option = {}
			@option["mac_flag"] = "-"
			@parse = Parsing.new
		end
		def get_arp(text)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "Address"
			#content["d_txt"] = "entries found"
			content["d_txt"] = ""
			content["number"] = 1
			@option["content"] = content
			####################################
			arp = {}
			arp["mac"] = 1
			arp["ip"] = 0
			@option["arp"] = arp
			###################################
			fetch = {}
			fetch["start"] = @parse.regexp_ip
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch	
			###################################
			arp_array = @parse.parse_arp(@option, text)

		end
		def get_mac(text)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "Vlan Mac Address"
			#content["d_txt"] = "mac address(es)"
			content["d_txt"] = ""
			content["number"] = 2
			@option["content"] = content
			####################################
			replace = {}
			reg = {}
			reg["cnt1"] = /Fa/
			reg["cnt2"] = /Gi/
			txt={}
			txt["cnt1"] = "FastEthernet"
			txt["cnt2"] = "GigabitEthernet"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			####################################
			fetch = {}
			fetch["start"] = /\d+/
			#fetch["first"] = ""
			fetch["key"] = 1
			@option["fetch"] = fetch	
			mac_dic = @parse.parse_mac(@option, text)
		end
		def get_interface(text)
			content = {}
			content["s_txt"] = "Interface  Link/Protocol"
			content["d_txt"] = ""
			content["number"] = 1
			@option["content"] = content
			replace = {}
			reg = {}
			reg["cnt1"] = /Fa/
			reg["cnt2"] = /Gi/
			reg["cnt3"] = /UP\/\w+/
			reg["cnt4"] = /DOWN\/\w+/
			txt={}
			txt["cnt1"] = "FastEthernet"
			txt["cnt2"] = "GigabitEthernet"
			txt["cnt3"] = "connected"
			txt["cnt4"] = "notconnect"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			####################################
			fetch = {}
			fetch["start"] = /\d\/\d/
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch	
			interface_dic = @parse.parse_interface(@option, text)
		end
		def get_config(text)
			config = {}
			config["flag"] = "!\n"
			config["regex"] = /Ethernet\d\/\d/
			@option["config"] = config
			config_array = @parse.parse_config(@option, text)
			return nil if !config_array
			config_dic =  {}
			config_array.each do |item|
				iface = item.split("\n")[0].split(" ", 2)[1]
				config_dic[iface] = item.split("\n")
			end
			regx_vlan = /switchport access vlan \d+/
			regx_trunk = /switchport mode trunk/
			regx_trunk_vlan = /switchport trunk native vlan \d+/
			regx_access = /switchport mode access/
			regx_dsrp   = /description/
			cfg_dic = {}
			if config_dic
				keyes = config_dic.keys
				keyes.each do |key|
					t_cfg = {}
					t_cfg["port"] = key
					t_cfg["describe"] = ""
					t_cfg["status"] = "notconnect"
					t_cfg["vlan"]   = "1"
					t_cfg["iftrunk"] = "0"
					config_dic[key].each do |item|
						if regx_vlan =~ item
							t_cfg["vlan"] = item.split[-1]
						elsif regx_trunk =~ item
							t_cfg["iftrunk"] = "1"
						elsif regx_trunk_vlan =~ item
							t_cfg["vlan"] = item.split[-1]
						elsif regx_dsrp =~ item
							t_cfg["describe"] = item.split(" ", 2)[1]
						end
						cfg_dic[key] = t_cfg
					end
				end
			end
			cfg_dic == {} ? nil : cfg_dic
		end
		def get_info(sw_text)
			text = @parse.parse_args(sw_text)
            #Log.debug "text = #{text}"
			if text
				arp_txt = text["arp"]
				config_txt = text["config"]
				interface_txt = text["interface"]
				mac_txt   = text["mac"]
				cfg_dic = get_config(config_txt)
				if_dic  = get_interface(interface_txt)
				mac_dic = get_mac(mac_txt)
				arp_list = get_arp(arp_txt)
				if !(if_dic && mac_dic && arp_list && config_txt)
                    Log.info "get_info parsing interface failed in #{self.class}" if !if_dic
                    Log.info "get_info parsing mac failed in #{self.class}" if !mac_dic
                    Log.info "get_info parsing arp failed in #{self.class}" if !arp_list
                    Log.info "get_info parsing cfg failed in #{self.class}" if !cfg_dic
                    return nil
				end
				#get interface status and port list
				port_list = []
				if_dic.each do |key, array_t|
					iface = "Ethernet#{array_t[0]}"
					iface_status = array_t[1]
					if cfg_dic.has_key?(iface)
						cfg_dic[iface]["status"] = iface_status
						port_list << cfg_dic[iface]
					end 

				end
				#get mac list
				mac_list = []
				mac_dic.each do |key, arr|
					if cfg_dic.has_key?(arr[-1])
						mac_tmp = {}
						mac_tmp["port"] = arr[4]
						mac_tmp["mac"]  = arr[1]
						mac_tmp["vlan"] = cfg_dic[mac_tmp["port"]]["vlan"]
						mac_list << mac_tmp
					end
				end
				switch_info = {}
				switch_info["arpList"] = arp_list if arp_list
				switch_info["macList"] = mac_list if mac_list
				switch_info["portList"] = port_list if port_list
				if !(switch_info == {})
					switch_info["ip"] = text["ip"]
					switch_info["linkStatus"] = text["status"]
				end
			end
			switch_info == {} ? nil : JSON.generate(switch_info)
		end
		def get_vlan(sw_text)
			text = @parse.parse_args(sw_text)
			vlans = []
			if text
				config_s = text["config"]
				config_list = get_config(config_s)
				if config_list
					config_list.each do |key, info|
						vlans << info["vlan"]
					end
				end
			end
			Switch.log.debug "get_vlan text  = #{text}"
			Switch.log.debug "get_vlan vlan list = #{vlans}"
			vlan_obj = {}
			vlan_obj["vlanList"] = vlans unless vlans == []
			vlan_obj["ip"] = text["ip"] unless vlans == []
			vlan_obj["method"] = text["method"] unless vlans == []
			vlan_obj == {} ? nil : JSON.generate(vlan_obj)
		end
		def test_switch(sw_text)
			text = @parse.parse_args(sw_text)
			result = @parse.parse_test_switch(text)
			#Switch.log.debug "test_switch text = #{text}"
			if text && text["status"] == 200
				arp_txt = text["arp"]
				config_txt = text["config"]
				interface_txt = text["interface"]
				mac_txt   = text["mac"]
				if_dic  = get_interface(interface_txt)
				mac_dic = get_mac(mac_txt)
				arp_list = get_arp(arp_txt)
				cfg_dic  = get_config(config_txt)
				info = get_info(sw_text)
				if arp_list && @parse.verify_info(info, "arpList")
					result["parseArp"] = "解析ARP信息成功"
					result["arpCmd"]   = text["arp_cmd"]
				else
					result["parseArp"] = "解析ARP信息失败"
					result["arpCmd"]   = text["arp_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if mac_dic && @parse.verify_info(info, "macList")
					result["parseMac"] = "解析MAC信息成功"
					result["macCmd"]   = text["mac_cmd"]
				else
					result["parseMac"] = "解析MAC信息失败"
					result["macCmd"]   = text["mac_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if if_dic && @parse.verify_info(info, "portList")
					result["parsePort"] = "解析PORT信息成功"
					result["portCmd"]   = text["interface_cmd"]
				else
					result["parsePort"] = "解析PORT信息失败"
					result["portCmd"]   = text["interface_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if cfg_dic && @parse.verify_info(info, "portList")
					result["parseConfig"] = "解析CONFIG信息成功"
					result["configCmd"]   = text["config_cmd"]
				else
					result["parseConfig"] = "解析CONFIG信息失败"
					result["configCmd"]   = text["config_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				result["result"] = "测试交换机[%s]失败" % sw_text["ip"] unless arp_list && mac_dic && if_dic && cfg_dic
			end
			result == nil ? nil : JSON.generate(result)
		end
	end
	class ParseHP
		def initialize
			@option = {}
			@option["mac_flag"] = "-"
			@parse = Parsing.new
		end
		def get_arp(text)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "IP Address"
			#content["d_txt"] = "entries found"
			content["d_txt"] = ""
			content["number"] = 2
			@option["content"] = content
			####################################
			arp = {}
			arp["mac"] = 1
			arp["ip"] = 0
			@option["arp"] = arp
			###################################
			fetch = {}
			fetch["start"] = @parse.regexp_ip
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch
			###################################
			arp_array = @parse.parse_arp(@option, text)
		end
		def get_mac(text)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "MAC Address"
			#content["d_txt"] = "mac address(es)"
			content["d_txt"] = ""
			content["number"] = 2
			@option["content"] = content
			####################################
			fetch = {}
			fetch["start"] = /[0-9a-fA-F]{6}-[0-9a-fA-F]{6}/
			#fetch["first"] = ""
			fetch["key"] = 1
			@option["fetch"] = fetch
			mac_dic = @parse.parse_mac(@option, text)
		end
		def get_interface(text)
			content = {}
			content["s_txt"] = "Link Speed"
			content["d_txt"] = ""
			content["number"] = 1
			@option["content"] = content
			replace = {}
			reg = {}
			reg["cnt1"] = /UP/
			reg["cnt2"] = /DOWN/
			txt={}
			txt["cnt1"] = "connected"
			txt["cnt2"] = "notconnect"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			####################################
			fetch = {}
			fetch["start"] = /\A\d+/
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch
			interface_dic = @parse.parse_interface(@option, text)
		end
		def get_vlan(sw_text)
			text = @parse.parse_args(sw_text)
			vlans = []
			if text
				iface_s = text["interface"]
				iface_list = get_interface(iface_s)
				if iface_list
					iface_list.each do |key, arry|
						if arry.size < 6
							next
						end
						vlans << arry[5]
					end
				end
			end
			Switch.log.debug "get_vlan text  = #{text}"
			Switch.log.debug "get_vlan vlan list = #{vlans}"
			vlan_obj = {}
			vlan_obj["vlanList"] = vlans unless vlans == []
			vlan_obj["ip"] = text["ip"] unless vlans == []
			vlan_obj["method"] = text["method"] unless vlans == []
			vlan_obj == {} ? nil : JSON.generate(vlan_obj)
		end
		def get_info(sw_text)
			text = @parse.parse_args(sw_text)
			#Log.debug "text = #{text}"
			switch_info = {}
			if text
				arp_txt = text["arp"]
				interface_txt = text["interface"]
				mac_txt   = text["mac"]
				if_dic  = get_interface(interface_txt)
				mac_dic = get_mac(mac_txt)
				arp_list = get_arp(arp_txt)
				if !(if_dic && mac_dic && arp_list)
					Log.info "get_info parsing interface failed in #{self.class}" if !if_dic
					Log.info "get_info parsing mac failed in #{self.class}" if !mac_dic
					Log.info "get_info parsing arp failed in #{self.class}" if !arp_list
					return nil
				end
				mac_arry = []
				mac_dic.each do |key, arry|
					mac_tmp = {}
					mac_tmp["port"] = arry[1]
					mac_tmp["mac"] = arry[0]
					mac_tmp["vlan"] = arry[2]
					mac_arry << mac_tmp
				end
				port_arry = []
				if_dic.each do |key, arry|
					if arry.size < 5
						next
					end
					if_tmp = {}
					if_tmp["port"] = arry[0]
					if_tmp["describe"] = ""
					if_tmp["status"] = arry[1]
					if_tmp["vlan"] = arry[5]
					if_tmp["iftrunk"]  = "0"
					if /Trk/ =~ arry[0]
						if_tmp["port"] = arry[0].split("-")[0]
						if_tmp["iftrunk"]  = "1"
					end
					if arry.size > 6
						if_tmp["describe"] = arry[-1]
					end
					port_arry << if_tmp
				end
				switch_info["arpList"] = arp_list
				switch_info["macList"] = mac_arry
				switch_info["portList"] = port_arry
				switch_info["ip"] = text["ip"]
				switch_info["linkStatus"] = text["status"]
			end
			switch_info == {} ? nil : JSON.generate(switch_info)
		end
		def test_switch(sw_text)
			text = @parse.parse_args(sw_text)
			result = @parse.parse_test_switch(text)
			#Switch.log.debug "test_switch text = #{text}"
			if text && text["status"] == 200
				arp_txt = text["arp"]
				# config_txt = text["config"]
				interface_txt = text["interface"]
				mac_txt   = text["mac"]
				if_dic  = get_interface(interface_txt)
				mac_dic = get_mac(mac_txt)
				arp_list = get_arp(arp_txt)
				# cfg_dic  = get_config(config_txt)
				info = get_info(sw_text)
				if arp_list && @parse.verify_info(info, "arpList")
					result["parseArp"] = "解析ARP信息成功"
					result["arpCmd"]   = text["arp_cmd"]
				else
					result["parseArp"] = "解析ARP信息失败"
					result["arpCmd"]   = text["arp_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if mac_dic && @parse.verify_info(info, "macList")
					result["parseMac"] = "解析MAC信息成功"
					result["macCmd"]   = text["mac_cmd"]
				else
					result["parseMac"] = "解析MAC信息失败"
					result["macCmd"]   = text["mac_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if if_dic && @parse.verify_info(info, "portList")
					result["parsePort"] = "解析PORT信息成功"
					result["portCmd"]   = text["interface_cmd"]
					result["parseConfig"] = "解析CONFIG信息成功"
					result["configCmd"]   = "show running-config"
				else
					result["parsePort"] = "解析PORT信息失败"
					result["portCmd"]   = text["interface_cmd"]
					result["parseConfig"] = "解析CONFIG信息失败"
					result["configCmd"]   = "show running-config"
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				result["result"] = "测试交换机[%s]失败" % sw_text["ip"] unless arp_list && mac_dic && if_dic
			end
			result == nil ? nil : JSON.generate(result)
		end
	end
	class ParseHP2510
		def initialize
			@option = {}
			@option["mac_flag"] = "-"
			@parse = Parsing.new
		end
		def get_arp(text)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "IP Address"
			#content["d_txt"] = "entries found"
			content["d_txt"] = ""
			content["number"] = 2
			@option["content"] = content
			####################################
			arp = {}
			arp["mac"] = 1
			arp["ip"] = 0
			@option["arp"] = arp
			###################################
			fetch = {}
			fetch["start"] = @parse.regexp_ip
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch
			###################################
			arp_array = @parse.parse_arp(@option, text)
		end
		def get_mac(text)
			@option = @parse.init_option(@option)
			content = {}
			content["s_txt"] = "MAC Address"
			#content["d_txt"] = "mac address(es)"
			content["d_txt"] = ""
			content["number"] = 2
			@option["content"] = content
			####################################
			fetch = {}
			fetch["start"] = /[0-9a-fA-F]{6}-[0-9a-fA-F]{6}/
			#fetch["first"] = ""
			fetch["key"] = 1
			@option["fetch"] = fetch
			mac_dic = @parse.parse_mac(@option, text)
		end
		def get_config(text)
			config = {}
			config["flag"] = "exit"
			config["regex"] = /vlan \d+/
			@option["config"] = config
			vlan_regx = /vlan \d+/
			vlan_port = /\A\s+untagged/
			config_array = @parse.parse_config(@option, text)
			port_vlan = {}
			config_array.each do |con_string|
				vlans_arry = con_string.split("\n")
				ports = []
				vlan_num = "0"
				vlans_arry.each do |item|
					if item =~ vlan_regx
						vlan_item = item.split[1]
						vlan_num = vlan_item
					elsif item =~ vlan_port
						port_item = item.split[1]
						ports_tmp = port_item.split(',')
						ports_tmp.each do |port_single|
							if port_single =~ /\d+-\d+/
								ports_range = (port_single.split('-')[0].to_i..port_single.split('-')[1].to_i)
								ports_range.each {|port_i| ports << port_i.to_s}
							else
								ports << port_single

							end
						end
					end
				end
				ports.each {|p| port_vlan["#{p}"] = "#{vlan_num}"}
			end
			port_vlan
		end
		def get_interface(text)
			content = {}
			content["s_txt"] = "Port  Type"
			content["d_txt"] = ""
			content["number"] = 1
			@option["content"] = content
			replace = {}
			reg = {}
			reg["cnt1"] = /Up/
			reg["cnt2"] = /Down/
			txt={}
			txt["cnt1"] = "connected"
			txt["cnt2"] = "notconnect"
			replace["reg"] = reg
			replace["txt"] = txt
			@option["replace"] = replace
			####################################
			fetch = {}
			fetch["start"] = /\A\s*\d+/
			#fetch["first"] = ""
			fetch["key"] = 0
			@option["fetch"] = fetch
			interface_dic = @parse.parse_interface(@option, text)
		end
		def get_vlan(sw_text)
			text = @parse.parse_args(sw_text)
			vlans = []
			if text
				iface_s = text["interface"]
				iface_list = get_interface(iface_s)
				if iface_list
					iface_list.each do |key, arry|
						if arry.size < 6
							next
						end
						vlans << arry[5]
					end
				end
			end
			Switch.log.debug "get_vlan text  = #{text}"
			Switch.log.debug "get_vlan vlan list = #{vlans}"
			vlan_obj = {}
			vlan_obj["vlanList"] = vlans unless vlans == []
			vlan_obj["ip"] = text["ip"] unless vlans == []
			vlan_obj["method"] = text["method"] unless vlans == []
			vlan_obj == {} ? nil : JSON.generate(vlan_obj)
		end
		def get_info(sw_text)
			text = @parse.parse_args(sw_text)
			#Log.debug "text = #{text}"
			switch_info = {}
			if text
				arp_txt = text["arp"]
				interface_txt = text["interface"]
				mac_txt   = text["mac"]
				config_txt = text["config"]
				if_dic  = get_interface(interface_txt)
				mac_dic = get_mac(mac_txt)
				arp_list = get_arp(arp_txt)
				port_vlan = get_config(config_txt)
				if !(if_dic && mac_dic && arp_list)
					Log.info "get_info parsing interface failed in #{self.class} #{if_dic}" if !if_dic
					Log.info "get_info parsing mac failed in #{self.class} #{mac_dic}" if !mac_dic
					Log.info "get_info parsing arp failed in #{self.class} #{arp_list}" if !arp_list
					return nil
				end
				vlan_port_find = Proc.new do |port, vlan_port_dic|
					myvlan = '0'
					myvlan = vlan_port_dic[port] if vlan_port_dic.has_key?(port)
					myvlan
				end
				mac_arry = []
				mac_dic.each do |key, arry|
					mac_tmp = {}
					mac_tmp["port"] = arry[1]
					mac_tmp["mac"] = arry[0]
					mac_tmp["vlan"] = vlan_port_find.(mac_tmp["port"], port_vlan)
					mac_arry << mac_tmp
				end
				port_arry = []
				if_dic.each do |key, arry|
					if arry.size < 5
						next
					end
					if_tmp = {}
					if_tmp["port"] = arry[0]
					if_tmp["describe"] = ""
					if_tmp["status"] = arry[5]
					if_tmp["vlan"] = vlan_port_find.(if_tmp["port"], port_vlan)
					if_tmp["iftrunk"]  = "0"
					if_tmp["iftrunk"]  = "1" if if_tmp["vlan"] == "0"
					if /Trk/ =~ arry[0]
						if_tmp["port"] = arry[0].split("-")[0]
						if_tmp["iftrunk"]  = "1"
					end
					if arry.size > 6
						#if_tmp["describe"] = arry[-1]
					end
					port_arry << if_tmp
				end
				switch_info["arpList"] = arp_list
				switch_info["macList"] = mac_arry
				switch_info["portList"] = port_arry
				switch_info["ip"] = text["ip"]
				switch_info["linkStatus"] = text["status"]
			end
			switch_info == {} ? nil : JSON.generate(switch_info)
		end
		def test_switch(sw_text)
			text = @parse.parse_args(sw_text)
			result = @parse.parse_test_switch(text)
			#Switch.log.debug "test_switch text = #{text}"
			if text && text["status"] == 200
				arp_txt = text["arp"]
				# config_txt = text["config"]
				interface_txt = text["interface"]
				mac_txt   = text["mac"]
				if_dic  = get_interface(interface_txt)
				mac_dic = get_mac(mac_txt)
				arp_list = get_arp(arp_txt)
				# cfg_dic  = get_config(config_txt)
				info = get_info(sw_text)
				if arp_list && @parse.verify_info(info, "arpList")
					result["parseArp"] = "解析ARP信息成功"
					result["arpCmd"]   = text["arp_cmd"]
				else
					result["parseArp"] = "解析ARP信息失败"
					result["arpCmd"]   = text["arp_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if mac_dic && @parse.verify_info(info, "macList")
					result["parseMac"] = "解析MAC信息成功"
					result["macCmd"]   = text["mac_cmd"]
				else
					result["parseMac"] = "解析MAC信息失败"
					result["macCmd"]   = text["mac_cmd"]
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				if if_dic && @parse.verify_info(info, "portList")
					result["parsePort"] = "解析PORT信息成功"
					result["portCmd"]   = text["interface_cmd"]
					result["parseConfig"] = "解析CONFIG信息成功"
					result["configCmd"]   = "show running-config"
				else
					result["parsePort"] = "解析PORT信息失败"
					result["portCmd"]   = text["interface_cmd"]
					result["parseConfig"] = "解析CONFIG信息失败"
					result["configCmd"]   = "show running-config"
					result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
				end
				result["result"] = "测试交换机[%s]失败" % sw_text["ip"] unless arp_list && mac_dic && if_dic
			end
			result == nil ? nil : JSON.generate(result)
		end
	end
end
