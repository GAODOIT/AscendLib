require "socket"
require "json"

module Switch
    class Handle
        def trunk_type_check(json_msg, head_msg)
			switch_vendor = "#{@switch_list[json_msg["ip"]]["vendor"]}_#{@switch_list[json_msg["ip"]]["type"]}"
			case switch_vendor.downcase
				when "hp_2530", "hp_2510", "hp_5412"
					trunk_args = do_get_args(json_msg, head_msg)
					insert_switch_queue(json_msg["ip"], head_msg, trunk_args)
					cmd_head= {}
					cmd_head["MessageMethod"] = "GetVlanInside"
					cmd_head["type"]          = 1000
					cmd_head["do_function"] = Proc.new do |vlans|
						json_msg_tmp = {}
						json_msg_tmp["ip"] = json_msg["ip"]
						args_vlans = []
						vlans.each do |vlan_t|
							destvlan_t = {}
							destvlan_t["destvlan"] = vlan_t
							args_vlans << destvlan_t
						end
						json_msg_tmp["list"] = args_vlans
						cmd_head_t = {}
						cmd_head_t["MessageMethod"] = "SetVlanTrunkInside"
						cmd_head_t["type"]  = 1000
						trunk_args_t = do_get_args(json_msg_tmp, cmd_head_t)
						insert_switch_queue(json_msg["ip"], cmd_head_t, trunk_args_t)
					end
					insert_switch_queue(json_msg["ip"], cmd_head)
				else
					return nil
			end
		end
		def update_cache_switch_list(*switch_ip)
            puts "in update_cache_switch_list ips = #{switch_ip}"
            switch_arry = []
            @switch_list.each do |ip, sw_info|
                #puts "ip=#{ip}, sw_info=#{sw_info}"
                next if sw_info["flag"] == -2 || sw_info["flag"] == 212
                sw_dic = {}
                sw_dic["ip"]         = ip
                sw_dic["vendor"]     = sw_info["vendor"]
                sw_dic["model"]      = sw_info["type"]
                sw_dic["params"]     = {}
                sw_dic["params"]["user"]               = sw_info["user"]
                sw_dic["params"]["password"]           = sw_info["password"]
                sw_dic["params"]["enablepassword"]     = sw_info["enablepassword"]
                switch_arry << sw_dic
            end
            sw_list = {}
            sw_list["msg_type"] = "switch_list"
            sw_list["switchList"] = switch_arry
            serialize_json = sw_list.to_json
            #$cache.set("switch.list", serialize_json)
            #$cache.set("switch.list.status", "1")
            puts "publish ok msg = #{serialize_json}"

			begin
				@redis_cache = Redis.new(host: @redis_ip, port: @redis_port, db: 6)
				@redis_cache.publish("monitor.switch", serialize_json)
				puts "publish ok msg = #{serialize_json}"
				switch_ip.each do |ip|
					cmd_head= {}
					cmd_head["MessageMethod"] = "UploadSwitchInfo"
					cmd_head["type"] = 1000
					cmd_head["do_function"] = Proc.new do |update_info|
						if update_info != nil
							update_msg = JSON.parse(update_info)
							portlist = {}
							portlist["msg_type"] = "port_list"
							portlist["ip"] = update_msg["ip"]
							portlist["portList"] = update_msg["portList"]
							serialize_json = portlist.to_json
							@redis_cache.publish("monitor.switch", serialize_json)
						end
					end
					insert_switch_queue(ip, cmd_head)
				end
				@redis_cache.quit
			rescue => error_msg
				Log.error "oprate redis error #{error_msg}"
			end

        end

		def subscribe_cache
			begin
				$cache.subscribe("control.switch") do |on|
					on.message do |channel, message|
						Log.info "receive redis channel= #{channel}, message = #{message}"
						if message == "switch_info"
							switchs = @switch_list.keys
							Thread.new { update_cache_switch_list *switchs }
						end
					end
				end
			rescue => error_msg
				Log.error "subscribe redis failed #{error_msg}"
				sleep(1)
			end
		end
    end
    class ExtHandle
		attr_accessor :handle_ins, :connect_ins
		def udpserver
			Socket.udp_server_sockets("0.0.0.0", 6800) {|sockets|
				loop {
					begin
						readable, _, _ = IO.select(sockets)
						Socket.udp_server_recv(readable) do |msg, msg_src| 
							Log.debug "msg= #{msg} msg_src=#{msg_src}"
							args = {}
							args["src"] = msg_src
							args["json"] = msg
							#args = Hash({"src"=>msg_src, "json"=>msg})
							Log.debug "args = #{args}"
							#handle_info_1000(args)
							self.send("handle_info_#{JSON.parse(msg)["cmd"]}", args)
							#1000.times do |i| 
							#	msg_src.reply("I am ok! #{i}")
							#	sleep(0.5)
							#end 
						end 
					rescue => message
						Log.error message
					end
				} 
			}

		end
		def handle_info_1003(arg = {})
			Log.log_level_set(JSON.parse(arg["json"])["level"])
		end
		def handle_info_1002(arg = {})
			$log_describe = {}
		end
		def handle_info_1001(arg = {})
			#puts "handle_info_1001"
			call_block = Proc.new do |message|
				json_obj = {}
				json_obj["cmd"] = JSON.parse(arg["json"])["cmd"]
				json_obj["value"] = message
				arg["src"].reply(JSON.generate(json_obj))
			end
			$log_describe[arg["src"].to_s] = call_block
		end
		def handle_info_1000(arg = {})
			#puts "handle_info_1000"
			json_obj = {}
			json_obj["cmd"] = JSON.parse(arg["json"])["cmd"]
			json_obj["value"] = []
			@handle_ins.switch_list.each  do |ip, info|
				switch_info = {}
				switch_info["ip"] = ip
				switch_info["vendor"] = info["vendor"]
				switch_info["type"] = info["type"]
				switch_info["cycle"] = info["cycle"]
				switch_info["timer"] = @handle_ins.report_timer[ip]["time"] if @handle_ins.report_timer[ip]
				switch_info["status"] = info["flag"] == -1 ? "online" : "offline"
				json_obj["value"] << switch_info
			end
			json_obj.delete("value") if json_obj["value"].length == 0
			#puts "json_obj = #{json_obj}"
			arg["src"].reply(JSON.generate(json_obj))
		end
    end
end
