#!/bin/bash
PID_S=$$
SWITCH_BIN=/nac/switch.bin
if [ -f "$SWITCH_BIN" ]; then
    chmod +x "$SWITCH_BIN"
    cd /nac && ./switch.bin
fi
if [ -f "/var/run/run_ruby.pid" ]; then
	cat /var/run/run_ruby.pid | xargs kill -9
fi
echo $PID_S > /var/run/run_ruby.pid
while [ 1 -eq 1 ] 
do
	sleep 5
	#ss=`ps axu|grep "main_switch"|grep -v grep`
	ss=`pgrep main_switch`
	if [ "$ss" = "" ]; then
		cat /var/run/switch.pid | xargs kill -9
		cd /nac/switch
		nohup main_switch &
		TIMESTAMP=`date`
		echo "staring ruby success at $TIMESTAMP" >> /nac/switch/startup.data
	fi
done

