#!/bin/bash

function print_usage()
{
cat <<HELP
please input ha status: master|backup|fault
HELP
}

if [ $# -lt 1 ];then
	print_usage
	exit -1
fi

ha_status=$1
current_date=`date "+%F %H:%M:%S"`
nac_system_pid=`pgrep nac_system`

if [ $? != 0 -o x"$nac_system_pid" == x ];then
	echo "$current_date nac_system process is unexist" >> /var/log/ha_status
	exit -1
fi

case "$ha_status" in
        "fault" | "FAULT")
		kill -RTMIN $nac_system_pid	
		#echo "1" > /proc/sys/net/nac_knl_switch_flags
		echo "$current_date enter $ha_status" >> /var/log/ha_status
                ;;
        "backup" | "BACKUP")
		kill -USR2 $nac_system_pid
		#echo "1" > /proc/sys/net/nac_knl_switch_flags
		echo "$current_date enter $ha_status" >> /var/log/ha_status
                ;;
        "master" | "MASTER")
		kill -USR1 $nac_system_pid
		#echo "0" > /proc/sys/net/nac_knl_switch_flags
		echo "$current_date enter $ha_status" >> /var/log/ha_status
                ;;
        *)
                echo "You input wrong,Please retry"
                print_usage
                ;;
esac
