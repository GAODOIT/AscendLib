#!/bin/bash
#2015-09-07 10:42:38 update by gaodong!

if [ -d /nac/config/my_sync ]; then
    /bin/cp -f /nac/config/my_sync/my.cnf /etc
fi
/etc/init.d/mysqld restart

exit 0
