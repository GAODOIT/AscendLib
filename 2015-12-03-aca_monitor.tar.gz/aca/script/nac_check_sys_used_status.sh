#!/bin/bash
# set -x
# History:
# create by gaodong at 2014-10-14 14:28:41
# update by gaodong at 2014-10-20 14:45:36
# echo -e "Time:`date "+%F %k:%M:%S"`"

function print_usage()
{
cat<<HELP
please input the type of sys you need check
rate:	show cpu mem disk usage*100;
irate:	show cpu mem disk usage(no point);
all:	show all below status;
cpu:	show cpu used status;
mem:	show memory used status;
disk:	show disk used status;
data:	show data partition status;
load:	show load average stauts
HELP
}

if [ $# -lt 1 ];then
	print_usage
	exit 0
fi


function get_cpu_info()
{
	cat /proc/stat | grep "^cpu" | head -n1 | awk '{used=$2+$3+$4;unused=$5+$6+$7+$8} \
	END{print used,unused}'
}

function show_cpu_status()
{
	#cpu status first
	time_point_1=`get_cpu_info`
	sleep 1

	#cpu status two
	time_point_2=`get_cpu_info`

	cpu_status=`echo $time_point_1 $time_point_2 | awk '{used=$3-$1;total=$3+$4-$1-$2; print used*100/total}'`

	#cpu_status_tmp1=`bc <<<$cpu_status*100`
	cpu_status_tmp=$(echo "$cpu_status*100" | bc)
	#echo "$cpu_status;$cpu_status_tmp1;$cpu_status_tmp"
	
	if [ "$1" == "rate" ]; then
		printf "%0.0f%s" "$cpu_status_tmp" ";"
	elif [ "$1" == "irate" ]; then	
		printf "%0.0f%s" "$cpu_status" ";"
	else
		printf "%s%0.2f\n" "cpu=" "$cpu_status"
	fi
}

function show_memory_status()
{
	#echo "#memory"
	total_memory=`free -m|grep "Mem:"|awk '{print $2 }'`
	used_memory=`free -m|grep "buffers/cache:"|awk '{print $3}'`
	mem_status=`echo $used_memory $total_memory | awk '{print $1*100/$2}'`
	#echo $total_memory";"$used_memory

	mem_status_tmp=`bc <<<$mem_status*100`
	#echo "$mem_status;$mem_status_tmp"	

	if [ "$1" == "rate" ]; then
		printf "%0.0f%s" "$mem_status_tmp" ";"
	elif [ "$1" == "irate" ]; then	
		printf "%0.0f%s" "$mem_status" ";"
	else
		printf "%s%0.2f\n" "mem=" "$mem_status"
	fi
}

function  show_disk_status()
{
	#echo "#disk"
	disk_used=`df -ml | egrep "/" | awk '{total+= $2;used+=$3};END {print total ";" used}'`
	disk_status=`echo $disk_used | awk -F ";" '{print $2*100/$1}'`
	#echo "$disk_used"
	
	disk_status_tmp=`bc <<<$disk_status*100`
	#echo "$disk_status;$disk_status_tmp"
	
	if [ "$1" == "rate" ]; then     
                printf "%0.0f\n" "$disk_status_tmp"
	elif [ "$1" == "irate" ]; then
		printf "%0.0f\n" "$disk_status"
        else
		printf "%s%0.2f\n" "disk=" "$disk_status"	
	fi
}


function show_data_part_status()
{
	echo "#data_partition_status"
	data_part_used=`df -ml |egrep "/data"|awk '{printf "%s;%s\n",$2,$3}'`
	data_part_status=`echo $data_part_used | awk -F ";" '{print $2*100/$1}'`
	echo $data_part_used
	printf "%0.2f%s\n" "$data_part_status" "%"
}

function show_load_average()
{
	echo "#load_average_status"
	load_average=`uptime | awk -F "load average: " '{print $2}'`
	echo "$load_average"
}

function show_sys_all_status()
{
	show_cpu_status
	show_memory_status
	show_disk_status
	#show_data_part_status
	#show_load_average
}

function show_sys_all_status_rate()
{
	show_cpu_status rate
	show_memory_status rate
	show_disk_status rate
}

function show_sys_all_status_irate()
{
	show_cpu_status irate
	show_memory_status irate
	show_disk_status irate
}


#main

case "$1" in
	"rate" | "RATE")
		show_sys_all_status_rate
		;;
	"irate" | "IRATE")
		show_sys_all_status_irate
		;;
	"all" | "ALL")
		show_sys_all_status
		;;
	"cpu" | "CPU")	
		show_cpu_status
		;;
	"mem" | "MEM")	
		show_memory_status
		;;
	"disk" | "DISK")
		show_disk_status
		;;
	"data" | "DATA")
		show_data_part_status
		;;
	"load" | "LOAD")
		show_load_average
		;;
	*)
		echo "You input wrong,Please retry"
		print_usage
		;;
esac
#end

