#!/bin/bash
#set -x
#History:
#	2015-05-13 10:00:42 Joyce.Luo first release
#		install package file rename
#	2015-05-13 13:15:44 Joyce.Luo two release
#		function encapsulate
#	2015-05-13 14:49:36 Joyce.Luo three release
#		update intall package config file		
#	2015-05-13 16:55:58 Joyce.Luo four release
#		at params in
#	2015-05-19 11:55:04 Joyce.Luo five release
#		code format
#


#获取服务器管理口IP
function GetServerIP()
{
	serverip=`sh /nac/script/web_manager_ip.sh`
}

#判断文件是否存在
#$@/$1:表示路径地址
function Exists()
{
	fileExist=0
	if [ -n "$1" ]; then
		if [ -x "$1" ]; then
			fileExist=1
			echo "File [$1] Exist"	
		else
			echo "File [$1] Not Exist"
		fi
	else
		echo "Params Exception"
	fi
}

#更新安装包配置文件信息
#$@/$1:表示路径
function UpdateConfigFile()
{
	echo $1
	if [ -n "$1" ]; then
		clientConfigFile="$1/client_config.xml"
		echo "Client Config File --> $clientConfigFile"
		sed -i "3c\\\t<ServerIP>$serverip</ServerIP>" $clientConfigFile
		sed -i "6c\\\t<RedirectUrl>http://$serverip/</RedirectUrl>" $clientConfigFile
		echo "Update Config File [$clientConfigFile] Success!"
	else
		echo "Params Exception, Update Config File Cancel!"
	fi

}

#调用方法，获取服务器管理口IP
serverip="$@"
if [ ! -n "$serverip" ]; then
	GetServerIP
fi
echo -e "Server IP --> $serverip \n"

#声明Windows客户端安装包目录
windowsFile="/nac/installPackage/windows"
echo "Windows Install Package --> $windowsFile"
#判断目录是否存在
Exists $windowsFile
#目录存在
if [ "$fileExist" = 1 ]; then
	cd $windowsFile
    	oldWindowsPack="*_hpidmNacSetup.exe"
    	ifExistFile=`find ./$oldWindowsPack` >/dev/null 2>&1
   	if [ -n "$ifExistFile" ];then
		echo "Find Install Package ---> $ifExistFile"
		newWindowsPack="$serverip"_hpidmNacSetup.exe
		echo "New Windows Install Package Name --> $newWindowsPack"
		mv $oldWindowsPack $newWindowsPack >/dev/null 2>&1
		echo "Windows Install Package Rename Success!"
		UpdateConfigFile $windowsFile
	else
		echo "Find Install Package ---> EMPTY"
		echo "$windowsFile/$oldWindowsPack Is Not Match"
		echo "Windows Install Package Rename Cancel!"
	fi
fi

#声明Android客户端安装包目录
androidFile="/nac/installPackage/android"
echo -e "\nAndroidInstallPackage --> $androidFile"
#判断目录是否存在
Exists $androidFile
#目录存在
if [ "$fileExist" = 1 ]; then
	cd $androidFile
	oldAndroidPack="*_hupuIMan.apk"
	ifExistFile=`find ./$oldAndroidPack` >/dev/null 2>&1
	if [ -n "$ifExistFile" ]; then
		echo "Find Install Package ---> $ifExistFile"
		newAndroidPack="$serverip"_hupuIMan.apk
		echo "New Android Install Package Name --> $newAndroidPack"
		mv $oldAndroidPack $newAndroidPack >/dev/null 2>&1
		echo "Android Install Package Rename Success!"
		UpdateConfigFile $androidFile
	else
		echo "Find Install Package ---> EMPTY"
		echo "$androidFile/$oldAndroidPack Is Not Match"
		echo "Android Install Package Rename Cancel!"
	fi
fi
