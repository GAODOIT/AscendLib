#!/bin/bash
mem_free=`free -m|sed '1,2d'|sed '2d'|awk '{print $4}'`
total=`netstat -an|awk '/^tcp/{++S[$NF]}END{for (a in S)print a,S[a]}'|awk '{print $2}'|awk '{sum+=$1} END {print sum}'`
size=`free -m|sed '1d'|sed '2,3d'|awk '{print $2}'`
if [ "$size" -gt "0" ] && [ "$size" -lt "1500" ];then		
		if [ "$total" -gt "500" ];then
				date +"%Y-%m-%d %H:%M:%S" > /var/log/nac_tcp_connection_log
				netstat -anp|grep tcp >> /var/log/nac_tcp_connection_log
		fi	
		if [ "$mem_free" -lt "100" ];then
				date +"%Y-%m-%d %H:%M:%S" > /var/log/nac_health_log
				ps aux | sed '1d' |sort -nk +4 | tail	>> /var/log/nac_health_log
		fi	
fi

if [ "$size" -gt "1500" ] && [ "$size" -lt "2100" ];then				
		if [ "$total" -gt "1000" ];then
				date +"%Y-%m-%d %H:%M:%S" > /var/log/nac_tcp_connection_log
				netstat -anp|grep tcp >> /var/log/nac_tcp_connection_log
		fi
		if [ "$mem_free" -lt "200" ];then
				date +"%Y-%m-%d %H:%M:%S" > /var/log/nac_health_log
				ps aux | sed '1d' |sort -nk +4 | tail	>> /var/log/nac_health_log
		fi	
fi

if [ "$size" -gt "2100" ] && [ "$size" -lt "4100" ];then			
		if [ "$total" -gt "1500" ];then
				date +"%Y-%m-%d %H:%M:%S" > /var/log/nac_tcp_connection_log
				netstat -anp|grep tcp >> /var/log/nac_tcp_connection_log
		fi	
		if [ "$mem_free" -lt "300" ];then
				date +"%Y-%m-%d %H:%M:%S" > /var/log/nac_health_log
				ps aux | sed '1d' |sort -nk +4 | tail	>> /var/log/nac_health_log
		fi	
fi

if [ "$size" -gt "4100" ] && [ "$size" -lt "8200" ];then				
		if [ "$total" -gt "2000" ];then
				date +"%Y-%m-%d %H:%M:%S" > /var/log/nac_tcp_connection_log
				netstat -anp|grep tcp >> /var/log/nac_tcp_connection_log
		fi
		if [ "$mem_free" -lt "400" ];then
				date +"%Y-%m-%d %H:%M:%S" > /var/log/nac_health_log
				ps aux | sed '1d' |sort -nk +4 | tail	>> /var/log/nac_health_log
		fi	
fi


if [ "$size" -gt "8200" ] && [ "$size" -lt "16200" ];then				
		if [ "$total" -gt "2500" ];then
				date +"%Y-%m-%d %H:%M:%S" > /var/log/nac_tcp_connection_log
				netstat -anp|grep tcp >> /var/log/nac_tcp_connection_log
		fi
		if [ "$mem_free" -lt "500" ];then
				date +"%Y-%m-%d %H:%M:%S" > /var/log/nac_health_log
				ps aux | sed '1d' |sort -nk +4 | tail	>> /var/log/nac_health_log
		fi
fi

