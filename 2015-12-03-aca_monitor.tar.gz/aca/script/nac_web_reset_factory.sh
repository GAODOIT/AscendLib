#!/bin/bash

#Fri Aug  8 10:36:05 CST 2014
#for webserver reset to factory by gaodong! 

rm -rf /nac/web/upload/web_user_login/*
rm -rf /nac/web/upload/softwareupload/*
rm -rf /nac/web/upload/cloud_config/*

rm -rf /bak/mysql/*

rm -rf /var/log/tomcat/WebLog
rm -rf  /var/log/tomcat/catalina.out
rm -rf /var/log/tomcat/nac.log
rm -rf /var/log/tomcat/localhost_access_log*
# 重启tomcat
service tomcat restart

#mysql -h localhost -uroot -phupu12iman! -Dhupunac < /nac/web/nac_factory/hupunac.sql
/usr/bin/python /nac/script/sql_clear.py
