#!/bin/bash
#History:
#2014-6-19 09:17:26 cody.guo first release
#2014-8-8 11:00:16 cody.guo two release
#2014-9-16 14:00:59 cody.guo three release

log="/var/log/tomcat/"
time=`date "+%Y-%m-%d %H:%M:%S"`
bak_log="/var/log/tomcat"
who_ip=`who am i|cut -d "(" -f2|cut -d ")" -f1`
war_temp="/nac/out"
nac_dir="/nac/web/tomcat"
tomcat_pid="/var/run/tomcat.pid"
nac_sys="/nac/config/nac_sys.conf"
script="/nac/script"

function Log_off()
{
	#console log off
	cat $nac_dir/hupunac/WEB-INF/classes/log4j.properties | grep "log4j.ConsoleAppender" | grep "^#" >>/dev/null
	if [ $? != 0 ];then
		sed -i '/log4j.ConsoleAppender/s/^/#/' $nac_dir/hupunac/WEB-INF/classes/log4j.properties
	fi
	
	cat $nac_dir/hupunac/WEB-INF/classes/log4j.properties | grep "log4j.rootLogger=INFO,STDOUT" | grep "^#" >>/dev/null
	if [ $? != 0 ];then
		sed -i '/log4j.rootLogger=/s/^/#/' $nac_dir/hupunac/WEB-INF/classes/log4j.properties
	fi
}

function Console_Log_Off(){
	#server console log off
	sed -i "8c\\log4j.appender.CONSOLE.Threshold=ERROR" $nac_dir/hupunac/WEB-INF/classes/log4j.properties
	dos2unix $nac_dir/hupunac/WEB-INF/classes/log4j.properties
	echo "close console log off success~~~"
}

#rm hupunac.war

rm -rf $war_temp/*.war >/dev/null 2>&1

#rz hupunac.war
while true
do
	web=`ls $war_temp/ |egrep "*.war"`
	if [ ! -n "$web"  ];then
		echo -e "--Cody.guo--Please upload your hupunac.war--\n"
		cd $war_temp
		rz
		sleep 3
	else
		break
	fi
done

# rename hupunac.war

if [ "$web" != "hupunac.war" ];then
	mv $war_temp/$web $war_temp/hupunac.war
fi

#kill java
killall -9 java > /dev/null 2>&1
echo -e "--Cody.guo--stop tomcat ok!--\n"
#remove pid
rm -rf $tomcat_pid
if [ -d "$nac_dir/hupunac/Upload" ];then
    cp -rf $nac_dir/hupunac/Upload/ $nac_dir/
fi
rm -rf $nac_dir/hupunac* 
rm -rf $nac_dir/work/*


#rm -rf /nac/out/hupunac.war

printf "%-11s%-9s%-12s%s\n" $time $who_ip "rm -rf  hupunac.war." >>$bak_log/web_update.log

#clear log
if [ ! -d $bak_log/naclog_bak ];then
        mkdir -p $bak_log/naclog_bak
fi
mv $log/catalina.out $bak_log/naclog_bak/catalina.out_"$time".bak > /dev/null 2>&1
mv $log/nac.log $bak_log/naclog_bak/nac.log_"$time".bak > /dev/null 2>&1

#unzip
unzip -x $war_temp/hupunac.war -d $nac_dir/hupunac > /dev/null 2>&1 <<EOF
A
EOF
#start tomcat
rm -rf $tomcat_pid

#console log off
#Log_off
Console_Log_Off

#move hupunac.war
mv $war_temp/hupunac.war $nac_dir/
if [ -d "$nac_dir/Upload" ];then
    mv $nac_dir/Upload $nac_dir/hupunac/
fi
echo "" 
n=1
while true
do
	ETH=`cat $nac_sys | grep "manager"|awk '{print $2}'`
	manager_ip=`ifconfig $ETH|egrep "inet addr:"|cut -d ":" -f2|awk '{print $1}'`
	echo -ne "--Cody.guo--Please wait for Restarting tomcat.......... $n"S--"\r";
	sleep 1
	netstat -an|grep $manager_ip:6002 >/dev/null
	if [ $? == 0 ];then
		echo -ne "--Cody.guo--Please wait starting tomcat.......... $n"S--"\r";
		((n++));
	else
		service tomcat start
		echo -e "\n--Cody.guo--tomcat start ok!--\n"
		sh $script/version_update.sh 
		break
	fi
done

#wall everyone
printf "%-11s%-9s%-12s%s\n" $time $who_ip "is update the war file." >$bak_log/start_time.log
printf "%-11s%-9s%-12s%s\n" $time $who_ip "is update the war file." >>$bak_log/web_update.log
echo "'--Cody.guo--$who_ip is update the war file.--'"|xargs -0 wall

#end

