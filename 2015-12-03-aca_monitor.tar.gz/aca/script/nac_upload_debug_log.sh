#!/bin/sh
# set -x
# History:
# create by gaodong at 2014-09-09 09:20:32
# update by gaodong at 2014-10-14 18:35:50
# update by gaodong at 2014-10-20 15:19:27
# update by gaodong at 2015-05-25 15:49:57
# echo -e "Time:`date "+%F %k:%M:%S"`"

# for ftp_client send log.txz to ftp_server
# ftp_sever_base_root=/bak/debug_log/asc_client_log

function print_usage()
{
cat<<HELP
please input the log type
error or debug
HELP
}

if [ $# -lt 1 ];then
	print_usage
	exit 0
fi

FTP_USER="nac_ftp"
FTP_PASSWD="qaz!@#"
LOCAL_PATH="/var/log/nac_asc"
REMOTE_PATH="asc_client_log"

ENCODE_PASS="zaq#@!"

#ASC_ID=`sed -n '1p' /nac/config/nac_device_id.conf`
ASC_ID=`ifconfig eth0|grep "inet addr"|cut -d ":" -f2|awk '{print $1}'`
ASC_LOG_PATH="/var/log/nac_asc/AscLog"
ASC_LOG_FILE="/var/log/nac_asc/AscLog/*"
ASC_ERROR_LOG="nac_sys_error.log";
ASC_DEBUG_LOG="nac_sys_debug.log";
ASC_CURRENT_CONFIG="nac_debug_sys_conf.log";
#ASC_ERROR_LOG_BK="nac_sys_error.log.*";
#ASC_DEBUG_LOG_BK="nac_sys_debug.log.*";

FTP_SERVER=`grep "serverIp" /nac/config/nac_license |awk -F '=' '{print $2}'`
if [ "$FTP_SERVER" == "" ];then
	echo "Warning: remote_server is yet not set!"
	exit 0
else
	echo "remote_server=$FTP_SERVER"
fi

cd $LOCAL_PATH && rm -f $ASC_LOG_FILE

NOW_DATE=`date "+%Y%m%d-%H%M"`
if [ "$1"x == "error"x ];then
	if [ ! -s $ASC_ERROR_LOG ];then
		echo "Warning: nac_sys_error.log unexit!"
		exit 0
	fi
	mv $ASC_ERROR_LOG $ASC_LOG_PATH/$NOW_DATE-$ASC_ERROR_LOG
	TARGET_FILE=$ASC_ID-AscLog-$NOW_DATE.txz
elif [ "$1"x == "debug"x ];then
	if [ ! -s $ASC_DEBUG_LOG ];then
		echo "Warning: nac_sys_debug.log unexit!"
		exit 0
	fi
	
	if [ ! -s $ASC_CURRENT_CONFIG ];then
		echo "Warning: nac_debug_sys_conf.log unexit!"
		exit 0
	fi
	
	mv $ASC_DEBUG_LOG $ASC_LOG_PATH/$NOW_DATE-$ASC_DEBUG_LOG
	mv $ASC_CURRENT_CONFIG $ASC_LOG_PATH/$NOW_DATE-$ASC_CURRENT_CONFIG 
	TARGET_FILE=$ASC_ID-debug-AscLog-$NOW_DATE.txz
else
	print_usage
	echo "Warning: target_file cannot create, so exit!"
	exit 0
fi

echo "the TARGET_FILE is $TARGET_FILE"
#tar and encode
tar -Jcvf - ./AscLog | openssl des3 -salt -e -k $ENCODE_PASS -out $TARGET_FILE

##upload_interface
upload_func()
{
ftp -v -n $FTP_SERVER << EOF
user $FTP_USER $FTP_PASSWD
passive
binary
cd $REMOTE_PATH
lcd $LOCAL_PATH
prompt
put $TARGET_FILE
ls
close
bye
EOF
}

#main
#test ftp_server is reach!
ping $FTP_SERVER -c 2 >/dev/null 2>&1
if [ $? == 0 ];then
	upload_func
else
	echo "$NOWDATE $0 ftp_upload $TARGET_FILE to $FTP_SERVER fail!"
	echo "$NOWDATE $0 ftp_upload $TARGET_FILE to $FTP_SERVER fail!" >/var/log/nac_asc/nac_sys_error.log
fi

#clear the TARGET_FILE!
rm -f $TARGET_FILE
