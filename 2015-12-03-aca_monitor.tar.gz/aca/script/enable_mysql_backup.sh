#!/bin/bash
# 2015-08-31 14:53:29 create by gaodong!

function print_usage()
{
cat<<HELP
please input the master address.
for example $0 7.7.7.1
HELP
}

if [ $# -lt 1 ];then
	print_usage
        exit -1
fi

MASTER_HOST=$1
HOSTNAME="127.0.0.1"
PORT="3306"
USERNAME="root"
PASSWORD="hupu12iman!"
DATABASE_NAME="hupunac"
BAK_DATABASE_PATH="/bak/ha_sync/ha_backup_db.sql"
MYSQL="/usr/local/mysql5.1.72/bin/mysql"

#sed -i "s/^master-host.*$/master-host=$MASTER_HOST/g" /nac/config/my_sync/my_backup.cnf
/bin/cp -f /nac/config/my_sync/my_backup.cnf /etc/my.cnf

#import mysql database "hupunac"
$MYSQL -h$HOSTNAME -u$USERNAME -p$PASSWORD -e "use hupunac;source $BAK_DATABASE_PATH;" 2>/dev/null

#restart mysql server
service mysqld restart

LOG_BIN=`cat /bak/ha_sync/my_log_bin`
mysql -uroot -phupu12iman!<<END
stop slave;
change master to master_host='$MASTER_HOST',master_user='backup',master_password='iman@hupu.net',master_port=3306,master_log_file='$LOG_BIN',master_log_pos=106,MASTER_CONNECT_RETRY=60;
start slave;
END
