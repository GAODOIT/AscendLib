#!/bin/bash
#History:
#2014-6-18 11:24:57 cody.guo first release

set -x
source /etc/profile
mknod /dev/nacdev c 66 0;

nac_out_path=/nac/out
file_count=`ls ${nac_out_path} | wc -l`
echo "fileCount: ${file_count}"
if [ "$file_count" -gt "0" ]; then
    echo "update software ....."
    cd $nac_out_path
    #web
    cp admin.war /nac/web/tomcat/webapps -f
    #app
    cp nac_user nac_system /nac/bin -f    
    cp libnac* /usr/lib -f 
    cp nac.version /nac/config -f 
    #knl
    cp vmlinuz-2.6.32-nac /boot
    cp *.ko /nac/bin -f
    rm -rf *  
fi
# NAT 
sysctl -w net.ipv4.tcp_timestamps=0

agetty -L 9600 ttyS0 vt100&


#start vsftpd
/etc/init.d/vsftpd restart

#start mysql
/nac/script/disable_mysql_sync.sh

# upgrade backup and install
/bak/upgrade/install_pack.sh

cd /nac/bin
#eth0_mac=`ifconfig eth0|grep HWaddr |awk -F " " '{ print $5}'|sed 's/:/-/g'`
#insmod nac_knl.ko pc_eth0_mac=$eth0_mac

#start knl
insmod nac_knl.ko


result=`cat /etc/profile|grep "ulimit -n 4096"`
if [ "$result" = "" ]; then
		echo -e 'mem=`free -m|sed '1d'|sed '2,3d'|awk \047{print $2}\047`\nif [ "$mem" -gt "3000" ];then\n    ulimit -n 4096\nfi' >> /etc/profile
fi

result=`cat /nac/web/tomcat/bin/catalina.sh|grep UseConcMarkSweepGC`
if [ "$result" = "" ]; then
		size=`free -m|sed '1d'|sed '2,3d'|awk '{print $2}'`
		if [ "$size" -gt "0" ] && [ "$size" -lt "1500" ];then				
				sed -i "100 a JAVA_OPTS='-Xms512m -Xmn128m  -Xmx512m -XX:+UseConcMarkSweepGC -XX:+UseParNewGC'" /nac/web/tomcat/bin/catalina.sh
		fi
		
		if [ "$size" -gt "1500" ] && [ "$size" -lt "2100" ];then				
				sed -i "100 a JAVA_OPTS='-Xms1024m -Xmn256m  -Xmx1024m -XX:+UseConcMarkSweepGC -XX:+UseParNewGC'" /nac/web/tomcat/bin/catalina.sh
		fi
		
		if [ "$size" -gt "2100" ] && [ "$size" -lt "4100" ];then			
				sed -i "100 a JAVA_OPTS='-Xms2048m -Xmn512m  -Xmx2048m -XX:+UseConcMarkSweepGC -XX:+UseParNewGC'" /nac/web/tomcat/bin/catalina.sh
		fi
		
		if [ "$size" -gt "4100" ] && [ "$size" -lt "8200" ];then				
				sed -i "100 a JAVA_OPTS='-Xms4096m -Xmn1024m  -Xmx4096m -XX:+UseConcMarkSweepGC -XX:+UseParNewGC'" /nac/web/tomcat/bin/catalina.sh
		fi
		
		
		if [ "$size" -gt "8200" ] && [ "$size" -lt "16200" ];then				
				sed -i "100 a JAVA_OPTS='-Xms8192m -Xmn2048m  -Xmx8192m -XX:+UseConcMarkSweepGC -XX:+UseParNewGC'" /nac/web/tomcat/bin/catalina.sh
		fi
fi
#start tomcat
service tomcat start
time=`date "+%Y-%m-%d %H:%M:%S"` >/dev/null
printf "%-11s%-9s%s\n" $time" system restart the tomcat." >/var/log/tomcat/start_time.log
#start redis server
export PATH=$PATH:/nac/bin/redis
redis-server /nac/config/redis.conf  1>/dev/null 2>&1 & 
#start linux app
nac_system &

#start switch control
if [ -f "/nac/switch.bin" ]; then
    chmod +x /nac/switch.bin
    cd /nac && ./switch.bin
fi
iptables -I INPUT -p vrrp -j ACCEPT
/nac/switch/run_ruby.sh &

sed -i '/nac_health_check/d' /etc/crontab
result=`cat /etc/crontab|grep nac_health_check`
if [ "$result" = "" ]; then
    crontab -r
    echo "*/2 * * * * /nac/script/nac_health_check.sh" >> /etc/crontab
    crontab /etc/crontab
fi

#start monitor
monitor_main &
