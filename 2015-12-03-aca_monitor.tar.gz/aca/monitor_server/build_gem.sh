#!/bin/bash
gem build monitor.gemspec 
