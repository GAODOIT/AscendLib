require 'log'
module EventMaping
    def _callbacks
        @_callbacks ||= Hash.new {|h, k| h[k] = [] }
    end
    def on(type, &blk)
        _callbacks[type] << blk
        self
    end

    def omit(type, *args)
        if _callbacks[type].size > 1
            _callbacks[type].each do |blk|
                blk.(args)
            end
        else
            _callbacks[type][0].(args)
        end
    end
end
module RedisHooks
    def _hooks
        @_hooks ||= Hash.new {|h, k| h[k] = {}}
    end
    def after_on(type, &blk)
        _hooks[:after][type] = blk
    end
    def before_on(type, &blk)
        _hooks[:before][type] = blk
    end
    def omit_after(type, *args)
        _hooks[:after][type].(args) if _hooks[:after].has_key?(type)
    end
    def omit_before(type, *args)
        _hooks[:before][type].(args) if _hooks[:after].has_key?(type)
    end
end
module Message
    def set_head(heads)
        MsgTransfer::MSG_HEAD.each do |key|
            @head[key] = heads[key] if heads.has_key?(key)
        end
    end

    def get_head
        msg_head = ''
        MsgTransfer::MSG_HEAD.each do |key|
            if @head[key] != nil
                msg_head += key + ": #{@head[key]}" + "\r\n"
            end
        end
        "#{msg_head}"
    end

    def init_head
        @head = {}
    end

    def msg_package(msg, msg_info)
        init_head
        MsgTransfer::Log.debug "msg_package msg_info = #{msg_info}"
        set_head "MessageMethod" => msg_info["method"]
        set_head "MessageType" => "json"
        set_head "CompressType" => "nil"
        set_head "DateTime" => DateTime.now.httpdate.gsub(/:/, '.')
        set_head "ClientCode" => msg_info["client_id"]
        set_head "MessageLength" => "0"
        set_head "MessageLength" => msg.bytesize if msg != nil
        package = get_head
        if msg != nil
            package += msg += "\r\n"
        end
        MsgTransfer::Log.debug "msg_package return #{package}"
        package
    end
end
module MsgTransfer
    class ParseMsg
        def initialize
            # @msg_head = ["MessageMethod", "MessageType", "CompressType" , \
            # 	"DateTime", "ClientCode", "Address", "StatusCode", "MessageLength" ]
            @rev_msg = ""
        end

        def parse(json_data)
            @rev_msg += json_data if json_data != nil
            msgs = []
            head = {}
            body = {}
            msg_mark = 0
            rev_data = @rev_msg.split("\r\n")
            len_arry = Array(0..rev_data.length-1)
            len_arry.each do |j|
                #puts "#########rev_data = #{rev_data[j]}ength = #{rev_data[j].size}"
                arry_msg = rev_data[j].split(":")
                if arry_msg.length >= 2 && MSG_HEAD.include?(arry_msg[0].strip)
                    head[arry_msg[0].strip] = arry_msg[1].strip
                    msg_mark = 1
                    next unless (head.has_key?("MessageLength") && head["MessageLength"].to_i == 0)
                end
                if head.has_key?("MessageLength") && (head["MessageLength"].to_i == 0) && (msg_mark == 1)
                    msg = {}
                    msg["head"] = head
                    msg["body"] = nil
                    head = {}
                    msgs << msg
                    @rev_msg = "" if j == len_arry.length - 1
                    next
                elsif head.has_key?("MessageLength") && (head["MessageLength"].to_i == rev_data[j].length) && (msg_mark == 1)
                    msg = {}
                    msg["head"] = head
                    msg["body"] = JSON.parse(rev_data[j])
                    msgs << msg
                    head = {}
                    msg_mark = 0
                    @rev_msg = "" if j == len_arry.length - 1
                elsif Log.info "message not complete"
                    if j == len_arry.length - 1
                        @rev_msg = rev_data[j]
                    end
                    if j < len_arry.length - 1
                        @rev_msg = ""
                        rev_data[j..-1].each { |last_msg| @rev_msg += "\r\n"+last_msg }
                    end

                end

            end
            msgs
        end
    end
end