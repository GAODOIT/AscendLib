path = File.absolute_path(__FILE__)
$LOAD_PATH.unshift(File.dirname(path))
require 'socket' # Get sockets from stdlib
require 'server'
require 'ultility'
require 'json'
include Message
include MsgTransfer
include Socket::Constants

msg_info = {}
msg_info["method"] = "HeartBeat"
msg_info["client_id"] = "B0:51:8E:03:A4:13"
msg0 = Message::msg_package(nil, msg_info)

msg_info = {}
msg_info["method"] = "ShowSwitchPort"
msg_info["client_id"] = "test_test"
msg = Message::msg_package(nil, msg_info)

msg_info["method"] = "ShowNacMode"
msg_info["client_id"] = "test_test"
msg1 = Message::msg_package(nil, msg_info)

msg_info["method"] = "ShowInterfaceStatus"
msg_info["client_id"] = "test_test"
msg2 = Message::msg_package(nil, msg_info)

msg_info["method"] = "ShowVlanMaping"
msg_info["client_id"] = "test_test"
msg3 = Message::msg_package(nil, msg_info)

msg_info["method"] = "ShowSwitchList"
msg_info["client_id"] = "test_test"
msg4 = Message::msg_package(nil, msg_info)

msg_info["method"] = "ShowProcessStatus"
msg_info["client_id"] = "test_test"
msg4 = Message::msg_package(nil, msg_info)

fd = Socket.new(AF_INET, SOCK_STREAM, 0)
server = "127.0.0.1"
server_addr = Socket.pack_sockaddr_in(6005, server)
fd.connect server_addr
rev = nil
rev = Thread.new{
	loop do
		if fd.respond_to?(:readpartial)
			revs = fd.readpartial(1048576)
			puts "#############################################"
			puts "receive:\n#{revs}"
		end
	end
}
	loop do
		begin
            sleep 2

			fd.write msg0
			# fd.write msg
			# fd.write msg1
			# fd.write msg2
			# fd.write msg3
			# fd.write msg4
			#client.write msg0
			#client.write msg1
			#client.write msg2
			#client.write msg4
			#client.write msg5
			#client.write msg6
			#sleep(8)
			#client.write msg3
			puts "send mesg success msg = #{msg0}"
		rescue => err
			puts err
			fd.close
			break
		end
		sleep(10)
	end
	#client.close
 
