require 'redis'
require 'log'
require 'ultility'
module MsgTransfer
    class RedisCache
        include RedisHooks
        def initialize(host, port, db)
            @host = host
            @port = port
            @db = db
            @redis = Redis.new(host: @host, port: @port, db: @db)
        end
        def reinitialize
            begin
                @redis = Redis.new(host: @host, port: @port, db: @db)
            rescue => err_msg
                Log.error "#{err_msg}"
            end
        end

        def get(key)
            begin
               result = @redis.get(key)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end
            result

        end
        def set(key, value, options = {})
            begin
               result = @redis.set(key, value, options)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end
            omit_after(:event_set, key)
            result
        end
        def publish(channel, message)
            begin
                result = @redis.publish(channel, message)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end
            # omit_after(:event_publish, channel)
            result
        end
        def subscribe(*channels, &block)
            begin
                return @redis.subscribe(*channels, &block)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end

        end

        def hset(key, field, value)
            begin
                result =  @redis.hset(key, field, value)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end
            # omit_after(:event_set, key)
            result

        end

        def keys(pattern = "*")
            begin
                return @redis.keys(pattern)
            rescue => err_msg
                Log.error "#{err_msg}"
                reinitialize
                retry
            end

        end
        def quit
            @redis.quit
        end
        def method_missing(method_call, *args)
            begin
                return @redis.send(method_call, *args)
            rescue => err_msg
                Log.error "method missing method error #{method_call}, #{err_msg}"
                reinitialize
                retry
            end

        end

    end

end