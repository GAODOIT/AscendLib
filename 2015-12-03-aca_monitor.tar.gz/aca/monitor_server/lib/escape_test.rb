path = File.absolute_path(__FILE__)
$LOAD_PATH.unshift(File.dirname(path))
require 'wrap_redis'
require 'json'
arg = ARGV[0]
args = ['if_down', 'if_up']
if !args.include? arg
    puts "args only permit [if_down\\if_up]"
    exit
end
redis = MsgTransfer::RedisCache.new("localhost", 6999, 6)
if arg == 'if_down'
    msg = {"msg_type" =>"iface_status","manager" => "true","ha"=>"true","untrust" =>"false","trust" =>"false"}
elsif arg == 'if_up'
    msg = {"msg_type" =>"iface_status","manager" => "true","ha"=>"true","untrust" =>"true","trust" =>"true"}
end
redis.publish("monitor.nacapp", JSON.generate(msg))
redis.quit
puts "send msg sucess msg = #{msg}"

