require 'packet'
require 'thread'
require 'log'
require 'ultility'
module MsgTransfer
	class Stream
		include EventMaping
        include Message
        attr_accessor :client_id
        attr_accessor :status, :heart_timer
		def initialize(stream)
			@io = stream
			@s_addrinfos = {}
			@client_id = "0"
			@status = true
			@msg_parse = MsgTransfer::ParseMsg.new
            @heart_timer = -1
            @mutex = Mutex.new
		end
		def handle_receive
			begin
				# puts "in handle_receive"
				msg = @io.readpartial(1024*1024)
				packets = @msg_parse.parse(msg)
				# packets = msg
				omit(:data, packets, self)
			rescue => error
				puts error
				@status = false
                delete
				Thread.exit
			end
		end

        def send_msg(msg, method)
            return if method == "ErrorMethod"
            @mutex.synchronize do
                msg_info = {}
                msg_info["method"] = method
                msg_info["client_id"] = @client_id
                packet = msg_package(msg, msg_info)
                Log.debug "send to client msg:\n #{packet}"
                begin
                    @io.write(packet)
                rescue
                    @status = false
                end
            end
        end
        def delete
            begin
                @io.close
            rescue => error
                Log.error "#{error}"
            end
        end
	end
	class MsgServer
		include EventMaping
		attr_accessor :streams
		def initialize(port, addr)
			@streams = []
			@threads = []
			@port = port
			@addr = addr
			@queue = Queue.new
			@thread_dic = {}
			@thread_dic[:msgs] = []
            on(:th_check) do |th_st, status|
=begin
                Log.debug "th_st = #{th_st}"
                Log.debug "th_st class = #{th_st.class}"
                case th_st.status
                    when "aborting"
                        Log.error "thread key = #{th_key} aborting"
                    when false
                        Log.warn "thread key = #{th_key} thread is terminated normally"
                    when nil
                        Log.error "thread key = #{th_key} terminated with an exception"
                end
                Log.debug "#{th_st} status #{th_st.status}"
=end
            end
            on(:netstream) do
                speed_dic = {}
                uptime = `cat /proc/uptime`
                speed_dic[:uptime] = uptime.split[0].to_i.to_s
                traffic = `ifconfig eth0`
                rx_data = /RX bytes:\d+/.match(traffic).to_s.split(":")[1]
                rx_data = rx_data.to_i/1024
                speed_dic[:rx_data] = rx_data.to_s
                tx_data = /TX bytes:\d+/.match(traffic).to_s.split(":")[1]
                tx_data = tx_data.to_i/1024
                speed_dic[:tx_data] = tx_data.to_s
                netspeed = `vnstat -i eth0 -tr 2 -ru`
                speed_arry = netspeed.split("\n")
                speed_arry.each do |txt|
                    txt_arry = txt.split
                    if /\A\s+rx/ =~ txt
                        speed_dic[:rx] = txt_arry[1]
                        speed_dic[:rx_unit] = txt_arry[2]
                    elsif /\A\s+tx/ =~ txt
                        speed_dic[:tx] = txt_arry[1]
                        speed_dic[:tx_unit] = txt_arry[2]
                    end
                end
                if speed_dic[:tx_unit] == "MiB/s"
                    speed_dic[:tx] =  speed_dic[:tx].to_i * 1000
                    speed_dic[:tx] = speed_dic[:tx].to_s
                    speed_dic[:tx_unit] = "KiB/s"
                else
                    speed_dic[:tx] = speed_dic[:tx].to_i.to_s
                end
                if speed_dic[:rx_unit] == "MiB/s"
                    speed_dic[:rx] =  speed_dic[:tx].to_i * 1000
                    speed_dic[:rx] =  speed_dic[:rx].to_s
                    speed_dic[:rx_unit] = "KiB/s"
                else
                    speed_dic[:rx] = speed_dic[:rx].to_i.to_s
                end
                speed_dic[:time] = Time.now.to_i.to_s
                puts speed_dic.to_json
                speed_dic
            end
        end
        # server init status, and listen socket
		def server_init
			socket = Socket.new(:INET, :STREAM, 0)
			socket_addr = Socket.sockaddr_in(@port, @addr)
            socket.setsockopt(Socket::SOL_SOCKET, Socket::SO_REUSEADDR, true)
            begin
			    socket.bind(socket_addr)
            rescue Errno::EADDRINUSE
                sleep(5)
                retry
            end
			socket.listen(10)
			@thread_dic[:accecpt] = Thread.new do
				loop do
					client, addrinfo = socket.accept
                    Log.debug "#{addrinfo.ip_unpack}   socket = #{client.to_s}"
					stream = Stream.new(client)
					stream.on(:close) do
						client.close
					end
					stream.on(:data) do |msg, stream|
						Log.debug "client said\n#{msg}"
						args = []
						args << msg
						args << stream
						@queue << args
					end
					@streams << stream
					#@socket_addrinfo[client.to_s] =  addrinfo
					@thread_dic[:msgs] << Thread.new do
						loop do
							stream.handle_receive
						end
					end
				end
			end
			do_thread
        end
        def server_send(msg, method)
            @streams.each do |stream|
                stream.send_msg(msg, method)
            end
        end
        def escape_notify(msg)
            Log.debug "##################escape notify = #{msg}"
            info ||= {}
            info["status"] = "#{msg["status"]}"
            info["type"]   = "#{msg["type"]}"
            msg.delete("status")
            msg.delete("type")
            info["item_status"] = info["type"] == "process_info" ? msg["list"] : msg
            Log.debug "################### #{__method__}   notify info = #{JSON.generate(info)}"
            @streams.each do |stream|
                stream.send_msg(JSON.generate(info), "ShowTrafficStatus")
            end
        end

        # start thread method
        def do_thread
            @thread_dic[:handle] = Thread.new do
                loop do
                    packet, stream = @queue.pop
                    omit(:handle, packet, stream)
                end
            end
            @thread_dic[:timer] = Thread.new do
                @timer_1 = 0
                loop do
                    if @timer_1 > 9
                        @streams.each do |stream|
                            if stream.status
                                stream.send_msg(nil, "HeartBeat") if stream.client_id != "0"
                                @timer_1 = 0
                                Log.debug "send heart beat success"
                                #TO DO send heart beat
                            else
                                @streams.delete(stream)
                            end
                        end
                    end
                    sleep(1)
                    @timer_1 += 1
                    # Log.debug "timer_1 = #{@timer_1}"
                    @thread_dic.each do |th_key, thread_st|
                        # Log.debug "thread key = #{th_key} #{thread_st} class = #{thread_st.class}"
                        if thread_st.kind_of? Array
                            thread_st.each do |th_st|
                                omit(:th_check,th_key,th_st.status)
                            end
                        else
                            omit(:th_check, th_key,thread_st.status)

                        end
                    end
                end
            end
            @thread_dic[:netstream] = Thread.new do
                loop do
                    begin
                        # info = omit(:netstream)
                        omit(:net_info)
                        # puts "info = #{info}"
                    rescue => error_msg
                        Log.debug "netstream error #{error_msg}"
                    end
                end
            end
            @thread_dic[:escape] = Thread.new do
                loop do
                    begin
                        omit(:escape_check)
                    rescue => error_msg
                        Log.debug "escape error #{error_msg}"
                    end
                end
            end
        end
		def start
			server_init
		end
	end
end
