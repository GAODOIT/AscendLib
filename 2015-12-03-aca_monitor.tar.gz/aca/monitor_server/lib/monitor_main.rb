#!/usr/bin/env ruby
#encoding: utf-8
########################################################################
##### Author: chenxiaokang                                           ###
##### Date: 2015.9.10                                                ###
##### Description: monitor server main function                      ### 
##### Modify reason:                                                 ###
##### Version: 1.0                                                   ###
##### bugs report to hp104@hupu.net                                  ###
########################################################################
path = File.absolute_path(__FILE__)
$LOAD_PATH.unshift(File.dirname(path))
# puts File.dirname(path)
require 'server'
server = MsgTransfer::MsgServer.new(6005,"0.0.0.0")
handle = MsgTransfer::MsgHandle.new(server)
server.on(:handle) do |data, stream|
	handle.do_handle(data, stream)
end
server.on(:net_info) do
    handle.handle_traffic
end
server.on(:escape_check) do
    handle.escape_check
end
server.start
Thread.new do
    loop do
        begin
            handle.subscribe
            sleep 5
        rescue => err_msg
            Log.error "#{err_msg}"
        end
        sleep 5
    end
end
handle.notify_get_info
loop do
    begin
        handle.course_check
    rescue => error_msg
        Log.error "#{error_msg}"
    end
	sleep(5)
end
