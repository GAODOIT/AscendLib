require 'logger'
module MsgTransfer
    class Log
        $debug_log = nil
        $log_describe = {}
        class << self
            def debug(msg=nil, name=nil)
                #puts "Log debug##################3"
                log_value(msg, "#{name} DEBUG ", 0)
                #puts "msg = #{msg}"
                $debug_log.add(Logger::DEBUG, msg, name)
                # log_txt = ''
                # msg.to_s.each_byte do |char_ord|
                # 	if char_ord == 10 || (char_ord >31 && char_ord <127)
                # 		log_txt += char_ord.chr
                # 	end
                # end
                # $debug_log.add(Logger::DEBUG, log_txt, name)
            end
            def info(msg=nil, name=nil)
                log_value(msg, "#{name} INFO ", 1)
                $debug_log.add(Logger::INFO, msg, name)
                # log_txt = ''
                # msg.to_s.each_byte do |char_ord|
                # 	if char_ord == 10 || (char_ord >31 && char_ord <127)
                # 		log_txt += char_ord.chr
                # 	end
                # end
                # $debug_log.add(Logger::INFO, log_txt, name)
            end
            def warn(msg=nil, name=nil)
                log_value(msg, "#{name} WARN ", 2)
                $debug_log.add(Logger::WARN, msg, name)
            end
            def error(msg=nil, name=nil)
                log_value(msg, "#{name} ERROR ", 3)
                $debug_log.add(Logger::ERROR, msg, name)
                # log_txt = ''
                # msg.to_s.each_byte do |char_ord|
                # 	if char_ord == 10 || (char_ord >31 && char_ord <127)
                # 		log_txt += char_ord.chr
                # 	end
                # end
                # $debug_log.add(Logger::ERROR, log_txt, name)
            end
            def log_value(msg = nil,name = nil, level = 0)
                $log_describe.each do |key, value|
                    value.call("#{DateTime.now.to_time.to_s}[#{name}]--#{msg}") if $debug_log.level <= level
                end
                if !$debug_log
                    # $debug_log = Logger.new(STDERR)
                    $debug_log = Logger.new('/var/log/moniter.log', 2, 1024000*25)
                    $debug_log.level = Logger::DEBUG
                    # $debug_log.level = Logger::INFO
                    #$debug_log.level = Logger::ERROR
                    $debug_log.datetime_format = '%Y-%m-%d %H:%M:%S'
                end
                $debug_log
            end
            def log_level_set(level = nil)
                case level
                    when "debug"
                        $debug_log.level = Logger::DEBUG
                    when "info"
                        $debug_log.level = Logger::INFO
                    when "warn"
                        $debug_log.level = Logger::WARN
                    when "error"
                        $debug_log.level = Logger::ERROR
                    else
                        error("log level args error")
                end
            end
        end
    end
end