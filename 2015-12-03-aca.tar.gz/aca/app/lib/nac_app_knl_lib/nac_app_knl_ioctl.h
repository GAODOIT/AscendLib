#ifndef	__NAC_APP_KNL_IOCTL_H__
#define	__NAC_APP_KNL_IOCTL_H__


HUPU_INT32 nac_set_data_to_knl(HUPU_UINT32 subjor, HUPU_UINT32 iden,
                               HUPU_VOID *buff, HUPU_UINT32	ui_len);

HUPU_INT32 nac_get_data_from_knl(HUPU_UINT32 subjor, HUPU_UINT32 iden,
                            	HUPU_VOID *buff, HUPU_UINT32 ui_len);

HUPU_INT32 nac_app_set_data_to_knl(struct nac_knl_policy *pst_ply,
                                   HUPU_UINT32	ply_num,
                                   HUPU_UINT32	user_num,
                                   HUPU_UINT32	*user_list,
                                   const HUPU_UINT32 ui_opt);


#endif

