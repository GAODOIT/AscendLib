#include "nac_app_knl_lib.h"

HUPU_INT32 nac_udp_crt_svr(const HUPU_UINT16 port)
{
    struct sockaddr_in	svr_addr;
	HUPU_INT32			sock_fd;
	size_t				iRet;

	// ����socket�����׽���
	if((sock_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SOCKET,
					"%s-->create socket error = %d\n",
					__FUNCTION__, sock_fd);
		
        return HUPU_ERR;
    }

	// ��ʼ������˵�ַ
	memset(&svr_addr, 0, sizeof(struct sockaddr_in));
	svr_addr.sin_family = AF_INET;
    svr_addr.sin_addr.s_addr = INADDR_ANY;
    svr_addr.sin_port = htons(port);

	// ��local socket������˵�ַ
    iRet = bind(sock_fd,
               (struct sockaddr *)&svr_addr,
               sizeof(struct sockaddr));
    if(iRet < 0)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SOCKET, 
					"%s-->bind local socket error = %d\n",
					__FUNCTION__, iRet);
		
        return HUPU_ERR;
    }

    return sock_fd;
}



HUPU_INT32 nac_udp_crt_cli(HUPU_VOID)
{
	HUPU_INT32 sock_fd;

	// ����socket�����׽���
	if((sock_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
	{
	    nac_lib_debug(DEBUG_LOG_FOR_NAC_SOCKET, 
					"%s-->create socket error = %d\n",
					__FUNCTION__, sock_fd);
		
	    return HUPU_ERR;
	}

    return sock_fd;
}

HUPU_INT32 nac_udp_destroy(const HUPU_INT32 sock_fd)
{
	if(sock_fd < 0)
	{
		return HUPU_ERR;
	}
	printf("--------------------%s------%d\n", __FUNCTION__, __LINE__);
	//�ر�������
	close( sock_fd );

	return HUPU_OK;
}


HUPU_INT32 nac_udp_sendto(const HUPU_INT32	sock_fd,
                           const HUPU_ULONG32	dst_ip,
                           const HUPU_UINT16	dst_port,
                           const HUPU_VOID		*msgbuf,
                           const HUPU_INT32 msglen)
{
	struct	sockaddr_in	peer_addr;

	// ���ȼ�����
	if( NULL == msgbuf || 0 == msglen)
	{
		return HUPU_ERR;
	}

	// ��ʼ���Զ˵�ַ
	memset(&peer_addr, 0, sizeof(struct sockaddr_in));
	peer_addr.sin_family = AF_INET;
    peer_addr.sin_addr.s_addr = htonl(dst_ip);
    peer_addr.sin_port = htons(dst_port);

	return sendto(sock_fd, msgbuf, msglen, 0,
				  (struct sockaddr *)&peer_addr, sizeof(struct sockaddr));
}



HUPU_INT32 nac_udp_recvfrom(const HUPU_INT32 sock_fd,
                            HUPU_ULONG32	*dst_ip,
                            HUPU_UINT16	*dst_port,
                            HUPU_VOID		*msgbuf,
                            const HUPU_INT32 msglen)
{
	struct sockaddr_in	peer_addr;
	socklen_t			addr_len;
	HUPU_INT32					iRet;

	// ���ȼ�����
	if(NULL == msgbuf || 0 == msglen)
    {
		return HUPU_ERR;
	}
	addr_len = sizeof(struct sockaddr);

	// ��ʼ���Զ˵�ַ
	memset(&peer_addr, 0, sizeof(struct sockaddr_in));
 	*dst_ip = ntohl(peer_addr.sin_addr.s_addr);
	*dst_port = ntohs(peer_addr.sin_port);

	// ��������
	iRet = recvfrom(sock_fd, msgbuf, msglen, 0,
		            (struct sockaddr *)&peer_addr, &addr_len);

 	*dst_ip		= ntohl(peer_addr.sin_addr.s_addr);
	*dst_port	= ntohs(peer_addr.sin_port);

	return iRet;
}

