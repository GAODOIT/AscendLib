#ifndef	__NAC_APP_KNL_NETLINK_H__
#define	__NAC_APP_KNL_NETLINK_H__


HUPU_UINT32 nac_app_netlink_create(HUPU_UINT32 type);
HUPU_UINT32 nac_app_netlink_destroy(HUPU_UINT32 sock_fd, HUPU_UINT32 type);
HUPU_UINT32 nac_app_netlink_recv(HUPU_UINT32 sock_fd, HUPU_CHAR *buffer, HUPU_UINT32 length);
HUPU_UINT32 nac_app_netlink_cmd(HUPU_UINT32	sock_fd, HUPU_UINT32 msg_type);

#endif

