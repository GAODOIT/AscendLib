#ifndef	__NAC_APP_KNL_TCP_H__
#define	__NAC_APP_KNL_TCP_H__



/////////////////////////////////////////////////////

#define NAC_APP_TCP_PORT 6003
#define BACKLOG			 20		//���������ո���������ʱ�ĵȴ������е�������
#define  GETWAY_PORT     6001

/////////////////////////////////////////////////////
HUPU_INT32 nac_tcp_crt_svr(HUPU_UINT16	port);

HUPU_INT32 nac_tcp_crt_cli(HUPU_VOID);

HUPU_INT32 nac_tcp_destroy(const HUPU_INT32	sock_fd);

HUPU_INT32 nac_tcp_listen(const HUPU_INT32 sock_fd, const HUPU_INT32 lst_num);

HUPU_INT32 nac_tcp_accept(const HUPU_INT32 sock_fd,
                        	HUPU_ULONG32 *dst_ip,
                        	HUPU_UINT16 *dst_port);

HUPU_INT32 nac_tcp_connect(const HUPU_INT32	sock_fd,
                            HUPU_ULONG32 dst_ip,
                            HUPU_UINT16 dst_port);

HUPU_INT32 nac_tcp_sendto(const HUPU_INT32	sock_fd,
                          HUPU_VOID *msgbuf,
                          const HUPU_INT32 msglen);

HUPU_INT32 nac_tcp_recvfrom(const HUPU_INT32 sock_fd,
                            HUPU_VOID *msgbuf,
                            const HUPU_INT32 msglen);
#endif


