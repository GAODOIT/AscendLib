#ifndef NAC_APP_DEBUG_USER_H
#define NAC_APP_DEBUG_USER_H

typedef enum
{
    USER_SHOW,
    USER_ADD,
    USER_DEL,
    USER_MODIFY,
    USER_FLUSH=9,
} USER_CMD_ACTION;

typedef struct __DEBUG_USER_OBJECT
{
    unsigned short action;
    unsigned char  ac_mac[18];
    unsigned char  ip_addr[16];
} O_DEBUG_USER, *P_DEBUG_USER;

#define XML_MSG_FORMAT "<?xml version=\"1.0\" encoding=\"UTF-8\"?><nac><commandID>%d</commandID><actionType>%d</actionType>%s</nac>"

/*"<onlineUser type="%d">98:5:88-32-9B-3D-53-EB,10.10.2.98,1,0</onlineUser>"*/
#define USER_ADD_FORMAT "<onlineUser usType=\"%d\" osType=\"%d\">0:0:%s,%s,1,0</onlineUser>"

/*"<onlineUser type="1">98:5:88-32-9B-3D-53-EB,10.10.2.98</onlineUser>"*/
#define USER_DEL_FORMAT "<onlineUser usType=\"%d\" osType=\"%d\">0:0:%s,%s</onlineUser>"

int nac_app_debug_user_deal(P_DEBUG_USER debug);

#endif
