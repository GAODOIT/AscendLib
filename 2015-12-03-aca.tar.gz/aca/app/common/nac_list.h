#ifndef __NAC_LIST_H__
#define __NAC_LIST_H__

#define member_offsetof(TYPE, MEMBER) ((unsigned long) &((TYPE *)0)->MEMBER)

#define nac_container_of(ptr, type, member) ({			\
	const typeof( ((type *)0)->member ) *__mptr = (ptr);	\
	(type *)( (char *)__mptr - member_offsetof(type,member) );})


#define nac_list_entry(ptr, type, member) \
	nac_container_of(ptr, type, member)

struct nac_list_head
{
	struct nac_list_head *pst_next, *pst_prev;
};

#define NAC_LIST_HEAD_INIT(name) { &(name), &(name) }

#define NAC_LIST_HEAD(name) \
	struct nac_list_head name = NAC_LIST_HEAD_INIT(name)

/*
static inline void nac_init_list_head(struct nac_list_head *pst_list)
{
	pst_list->pst_next = pst_list;
	pst_list->pst_prev = pst_list;
}
*/
static inline void NAC_INIT_LIST_HEAD(struct nac_list_head *pst_list)
{
	pst_list->pst_next = pst_list;
	pst_list->pst_prev = pst_list;
}

static inline void _list_add(struct nac_list_head *pst_newnode,
							    struct nac_list_head *pst_prev,
							    struct nac_list_head *pst_next)
{
	pst_next->pst_prev    = pst_newnode;
	pst_newnode->pst_next = pst_next;
	pst_newnode->pst_prev = pst_prev;
	pst_prev->pst_next    = pst_newnode;
}

static inline void nac_list_add_head(struct nac_list_head *pst_newnode, struct nac_list_head *pst_head)
{
	_list_add(pst_newnode, pst_head, pst_head->pst_next);
}

static inline void nac_list_add_tail(struct nac_list_head *pst_newnode, struct nac_list_head *pst_head)
{
	_list_add(pst_newnode, pst_head->pst_prev, pst_head);
}

static inline void __list_del(struct nac_list_head * pst_prev, struct nac_list_head * pst_next)
{
	pst_next->pst_prev = pst_prev;
	pst_prev->pst_next = pst_next;
}

static inline void nac_list_del(struct nac_list_head *pst_entry)
{
	__list_del(pst_entry->pst_prev, pst_entry->pst_next);
}

static inline int nac_list_empty(const struct nac_list_head *pst_head)
{
	return pst_head->pst_next == pst_head;
}


static inline void nac_prefetch(void *x)
{
   
}

#define nac_list_for_each(pos, head) \
    for (pos = (head)->pst_next, nac_prefetch(pos->pst_next);\
         pos != (head); \
         pos = pos->pst_next, nac_prefetch(pos->pst_next))


#define nac_list_for_each_prev(pos, head) \
        for (pos = (head)->pst_prev, nac_prefetch(pos->pst_prev);\
             pos != (head); \
             pos = pos->pst_prev, nac_prefetch(pos->pst_prev))

#define nac_list_for_each_safe(pos, n, head) \
            for (pos = (head)->pst_next, n = pos->pst_next; \
                 pos != (head); \
                 pos = n, n = pos->pst_next)

/** must known st_pos cannot set NULL;st_pos used for iterate over list.
 *	nac_list_for_each_entry	-	iterate over list of given type
 *  @pos:	the type * to use as a loop cursor.
 *  @head:	the head for your list.
 *  @member:	the name of the list_struct within the struct.
 */

/*
#define nac_list_for_each_entry(pos, head, member)					\
    for (pos = nac_list_entry((head)->pst_next, typeof(*pos), member);	\
     	&pos->member != (head);     \
     	pos = nac_list_entry(pos->member.pst_next, typeof(*pos), member))
*/
#define nac_list_for_each_entry(pos, head, member)					\
	for (pos = nac_list_entry((head)->pst_next, typeof(*pos), member);	\
		nac_prefetch(pos->member.pst_next), &pos->member != (head); 	\
		pos = nac_list_entry(pos->member.pst_next, typeof(*pos), member))


/** must known st_pos and st_n cannot set NULL;st_pos and st_n used for iterate over list.
 * nac_list_for_each_entry_safe - iterate over list of given type safe against removal of list entry
 * @pos:	the type * to use as a loop cursor.
 * @n:		another type * to use as temporary storage
 * @head:	the head for your list.
 * @member:	the name of the list_struct within the struct.
 */

#define nac_list_for_each_entry_safe(pos, n, head, member)			\
	for (pos = nac_list_entry((head)->pst_next, typeof(*pos), member),	\
		n = nac_list_entry(pos->member.pst_next, typeof(*pos), member);	\
	     &pos->member != (head); 					\
	     pos = n, n = nac_list_entry(n->member.pst_next, typeof(*n), member))


#define nac_list_for_each_prev_safe(pos, n, head) \
        for (pos = (head)->prev, n = pos->prev; \
             prefetch(pos->prev), pos != (head); \
             pos = n, n = pos->prev)

#define nac_list_for_each_entry_reverse(pos, head, member)			\
        for (pos = list_entry((head)->prev, typeof(*pos), member);  \
             prefetch(pos->member.prev), &pos->member != (head);    \
             pos = list_entry(pos->member.prev, typeof(*pos), member))

#define nac_list_prepare_entry(pos, head, member) \
            ((pos) ? : list_entry(head, typeof(*pos), member))

#define nac_list_for_each_entry_continue(pos, head, member) 		\
	for (pos = list_entry(pos->member.next, typeof(*pos), member);	\
	     prefetch(pos->member.next), &pos->member != (head);	\
	     pos = list_entry(pos->member.next, typeof(*pos), member))


#define nac_list_for_each_entry_continue_reverse(pos, head, member)		\
        for (pos = list_entry(pos->member.prev, typeof(*pos), member);  \
             prefetch(pos->member.prev), &pos->member != (head);    \
             pos = list_entry(pos->member.prev, typeof(*pos), member))

#define nac_list_for_each_entry_from(pos, head, member) 			\
            for (; prefetch(pos->member.next), &pos->member != (head);  \
                 pos = list_entry(pos->member.next, typeof(*pos), member))

#define nac_list_for_each_entry_safe_continue(pos, n, head, member) 		\
                for (pos = list_entry(pos->member.next, typeof(*pos), member),      \
                    n = list_entry(pos->member.next, typeof(*pos), member);     \
                     &pos->member != (head);                        \
                     pos = n, n = list_entry(n->member.next, typeof(*n), member))

#define nac_list_for_each_entry_safe_from(pos, n, head, member) 			\
                    for (n = list_entry(pos->member.next, typeof(*pos), member);        \
                         &pos->member != (head);                        \
                         pos = n, n = list_entry(n->member.next, typeof(*n), member))

#define nac_list_for_each_entry_safe_reverse(pos, n, head, member)		\
                        for (pos = list_entry((head)->prev, typeof(*pos), member),  \
                            n = list_entry(pos->member.prev, typeof(*pos), member); \
                             &pos->member != (head);                    \
                             pos = n, n = list_entry(n->member.prev, typeof(*n), member))

#define nac_list_first_entry(ptr, type, member) \
                            list_entry((ptr)->pst_next, type, member)

#define nac_list_prepare_entry(pos, head, member) \
                        ((pos) ? : list_entry(head, typeof(*pos), member))


//////////////////////////////////////

struct nac_hlist_head {
    struct nac_hlist_node *first;
};

struct nac_hlist_node {
    struct nac_hlist_node *next, **pprev;
};

#define NAC_HLIST_HEAD_INIT { .first = NULL }
#define NAC_HLIST_HEAD(name) struct nac_hlist_head name = {  .first = NULL }
#define NAC_INIT_HLIST_HEAD(ptr) ((ptr)->first = NULL)
static inline void INIT_HLIST_NODE(struct nac_hlist_node *h)
{
    h->next = NULL;
    h->pprev = NULL;
}

static inline int nac_hlist_unhashed(const struct nac_hlist_node *h)
{
    return !h->pprev;
}

static inline int nac_hlist_empty(const struct nac_hlist_head *h)
{
    return !h->first;
}

static inline void nac___hlist_del(struct nac_hlist_node *n)
{
    struct nac_hlist_node *next = n->next;
    struct nac_hlist_node **pprev = n->pprev;
    *pprev = next;
    if (next)
        next->pprev = pprev;
}


#define NAC_LIST_POISON1  ((void *) 0x00100100)
#define NAC_LIST_POISON2  ((void *) 0x00200200)
static inline void nac_hlist_del(struct nac_hlist_node *n)
{
    nac___hlist_del(n);
    n->next = (struct nac_hlist_node *)NAC_LIST_POISON1;
    n->pprev = (struct nac_hlist_node **)NAC_LIST_POISON2;
}

static inline void nac_hlist_del_init(struct nac_hlist_node *n)
{
    if (!nac_hlist_unhashed(n)) {
        nac___hlist_del(n);
        INIT_HLIST_NODE(n);
    }
}

static inline void nac_hlist_add_head(struct nac_hlist_node *n, struct nac_hlist_head *h)
{
    struct nac_hlist_node *first = h->first;
    n->next = first;
    if (first)
        first->pprev = &n->next;
    h->first = n;
    n->pprev = &h->first;
}

/* next must be != NULL */
static inline void nac_hlist_add_before(struct nac_hlist_node *n,
                    struct nac_hlist_node *next)
{
    n->pprev = next->pprev;
    n->next = next;
    next->pprev = &n->next;
    *(n->pprev) = n;
}

static inline void nac_hlist_add_after(struct nac_hlist_node *n,
                    struct nac_hlist_node *next)
{
    next->next = n->next;
    n->next = next;
    next->pprev = &n->next;

    if(next->next)
        next->next->pprev  = &next->next;
}

static inline void nac_hlist_move_list(struct nac_hlist_head *old,
                   struct nac_hlist_head *pst_newnode)
{
    pst_newnode->first = old->first;
    if (pst_newnode->first)
        pst_newnode->first->pprev = &pst_newnode->first;
    old->first = NULL;
}

#define nac_hlist_entry(ptr, type, member) nac_container_of(ptr,type,member)

#define nac_hlist_for_each(pos, head) \
        for (pos = (head)->first; pos && ({ nac_prefetch(pos->next); 1; }); \
             pos = pos->next)

#define nac_hlist_for_each_safe(pos, n, head) \
        for (pos = (head)->first; pos && ({ n = pos->next; 1; }); \
             pos = n)

#define nac_hlist_for_each_entry(tpos, pos, head, member)			 \
        for (pos = (head)->first;                    \
             pos && ({ nac_prefetch(pos->next); 1;}) &&          \
            ({ tpos = nac_hlist_entry(pos, typeof(*tpos), member); 1;}); \
             pos = pos->next)

    
#define nac_hlist_for_each_entry_continue(tpos, pos, member)		 \
        for (pos = (pos)->next;                      \
             pos && ({ nac_prefetch(pos->next); 1;}) &&          \
            ({ tpos = nac_hlist_entry(pos, typeof(*tpos), member); 1;}); \
             pos = pos->next)

  
#define nac_hlist_for_each_entry_from(tpos, pos, member)			 \
        for (; pos && ({ nac_prefetch(pos->next); 1;}) &&            \
            ({ tpos = nac_hlist_entry(pos, typeof(*tpos), member); 1;}); \
             pos = pos->next)

    
#define nac_hlist_for_each_entry_safe(tpos, pos, n, head, member) 		 \
        for (pos = (head)->first;                    \
             pos && ({ n = pos->next; 1; }) &&               \
            ({ tpos = nac_hlist_entry(pos, typeof(*tpos), member); 1;}); \
             pos = n)


/////////////////

void nac_list_test();

#if 0

#define nac_list_first_entry(ptr, type, member) \
	nac_list_entry((ptr)->next, type, member)


#define nac_list_for_each_entry_safe_reverse(pos, n, head, member)		\
	for (pos = nac_list_entry((head)->prev, typeof(*pos), member),	\
		n = nac_list_entry(pos->member.prev, typeof(*pos), member);	\
	     &pos->member != (head); 					\
	     pos = n, n = nac_list_entry(n->member.prev, typeof(*n), member))
#endif
#endif //__NAC_LIST__

