#ifndef HUPU_H
#define HUPU_H

#ifdef __cplusplus
extern "C" {
#endif

#define HUPU_BOOL int
#define HUPU_TRUE 1
#define HUPU_FALSE 0

#define HUPU_OK  0
#define HUPU_ERR -1
#define HUPU_NULL ((void *)0)

#define HUPU_ENABLE		1
#define HUPU_DISABLE	0

/*��Чֵ*/
#define HUPU_INVALID_VALUE  0XFFFFFFFF




/*�����������Ͷ���*/
typedef void  			        HUPU_VOID;
typedef unsigned char  			HUPU_UCHAR;
typedef char          			HUPU_CHAR;
typedef unsigned int   			HUPU_UINT32;
typedef int     			      HUPU_INT32;
typedef short unsigned int  HUPU_UINT16;
typedef short int      			HUPU_INT16;
typedef unsigned char   	    HUPU_UINT8;
typedef signed long int     HUPU_LONG32;
typedef unsigned long int   HUPU_ULONG32;
typedef float 				      HUPU_FLOAT32;
typedef double 				      HUPU_DOUBLE64;


#define MAX_3(a, b, c) \
            ((a) > (b)?(a): (b)) > (c)?((a) > (b)?(a): (b)):(c)

#define MAX_4(A, B, C, D) \
            ((A)>(B)?(A):(B))>((C)>(D)?(C):(D))?((A)>(B)?(A):(B)):((C)>(D)?(C):(D))



#ifdef __cplusplus
}
#endif

#endif//end of HUPU_H
