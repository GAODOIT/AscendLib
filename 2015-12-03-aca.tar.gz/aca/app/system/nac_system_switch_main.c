#include "nac_precomp.h" //nac_list.h
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_switch_main.h"
#include "nac_system_switch_snmp.h"
#include "nac_system_switch_telnet.h"
#include "nac_system_switch_ssh.h"



HUPU_UINT16 g_nac_switch_index = 0;
HUPU_UINT32 g_nac_switch_time_out = 3*60;
struct nac_hlist_head nac_switch_hash_by_id[NAC_SYSTEM_SWITCH_HASH_SIZE];
pthread_mutex_t system_switch_mutex = PTHREAD_MUTEX_INITIALIZER;



HUPU_VOID nac_system_switch_lock()
{
    pthread_mutex_lock(&system_switch_mutex);
}

HUPU_VOID nac_system_switch_unlock()
{
    pthread_mutex_unlock(&system_switch_mutex);
}

static HUPU_INT32 nac_system_get_switch_hash_by_switch_id(HUPU_UINT32 switch_id)
{
	return switch_id&(NAC_SYSTEM_SWITCH_HASH_SIZE - 1);
}

/*
static HUPU_INT32 nac_system_get_switch_hash_by_ip(HUPU_UINT32 ip)
{
	return ip&(NAC_SYSTEM_SWITCH_HASH_SIZE - 1);
}
*/

HUPU_VOID nac_system_init_switch(HUPU_VOID)
{
    int i;

    for(i = 0; i < NAC_SYSTEM_SWITCH_HASH_SIZE; i++)
    {
        NAC_INIT_HLIST_HEAD(&nac_switch_hash_by_id[i]);
    }

	pthread_mutex_init(&system_switch_mutex, HUPU_NULL);

	return;
}

HUPU_INT32 nac_system_add_switch(NAC_SYSTEM_SWITCH *pst_switch_st)
{
	HUPU_UINT32 hash;
    NAC_SYSTEM_SWITCH *pst_switch_tmp;

	hash = nac_system_get_switch_hash_by_switch_id(pst_switch_st->switch_id);
    pst_switch_tmp = (NAC_SYSTEM_SWITCH *)malloc(sizeof(NAC_SYSTEM_SWITCH));
	if(pst_switch_tmp == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->malloc error\n", __FUNCTION__);
		return HUPU_ERR;
	}
	memset(pst_switch_tmp, '\0', sizeof(NAC_SYSTEM_SWITCH));
    memcpy(pst_switch_tmp, pst_switch_st, sizeof(NAC_SYSTEM_SWITCH));
    nac_system_switch_lock();
    nac_hlist_add_head(&pst_switch_tmp->node, &nac_switch_hash_by_id[hash]);
    nac_system_switch_unlock();

	return HUPU_OK;
}

//return HUPU_ERR:no this switch; return HUPU_OK:find the switch,and rmv it.
HUPU_INT32 nac_system_rmv_switch(HUPU_UINT32 switch_id)
{
    HUPU_UINT32 hash;
    struct nac_hlist_node *pos, *n;
    NAC_SYSTEM_SWITCH *pst_switch_tmp;

    hash = nac_system_get_switch_hash_by_switch_id(switch_id);

    nac_system_switch_lock();
	nac_hlist_for_each_entry_safe(pst_switch_tmp, pos, n, &nac_switch_hash_by_id[hash], node)
    {
        if(pst_switch_tmp->switch_id == switch_id)
        {
			nac_hlist_del(&pst_switch_tmp->node);
			nac_system_switch_unlock();

			if (pst_switch_tmp->login_type == NAC_SWITCH_SSH
				&& pst_switch_tmp->login_type == NAC_SWITCH_TELNET
				&& pst_switch_tmp->switch_fd > 0)
			{
            	close(pst_switch_tmp->switch_fd);
			}
            free(pst_switch_tmp);
            return HUPU_OK;
        }
    }
    nac_system_switch_unlock();

	return HUPU_ERR;
}

HUPU_INT32 nac_system_search_switch(HUPU_UINT32 switch_id, NAC_SYSTEM_SWITCH *pst_tmp)
{
    HUPU_UINT32 hash;
    struct nac_hlist_node *pos, *n;
    NAC_SYSTEM_SWITCH *pst_switch_tmp;

    hash = nac_system_get_switch_hash_by_switch_id(switch_id);
    nac_system_switch_lock();
    nac_hlist_for_each_entry_safe(pst_switch_tmp, pos, n, &nac_switch_hash_by_id[hash], node)
    {
        if(pst_switch_tmp->switch_id == switch_id)
        {
            memcpy(pst_tmp, pst_switch_tmp, sizeof(NAC_SYSTEM_SWITCH));
            nac_system_switch_unlock();
            return HUPU_OK;
        }
    }
    nac_system_switch_unlock();
    return HUPU_ERR;
}


HUPU_INT32 nac_system_modify_switch_st(NAC_SYSTEM_SWITCH *pst_switch_st)
{
	HUPU_UINT32 hash;
    struct nac_hlist_node *pos, *n;
    NAC_SYSTEM_SWITCH *pst_switch_tmp;

    hash = nac_system_get_switch_hash_by_switch_id(pst_switch_st->switch_id);

	nac_system_switch_lock();
    nac_hlist_for_each_entry_safe(pst_switch_tmp, pos, n, &nac_switch_hash_by_id[hash], node)
    {
        if(pst_switch_tmp->switch_id == pst_switch_st->switch_id)
        {
        	/*
        	error_segment fault
			memset(pst_switch_tmp, '\0', sizeof(NAC_SYSTEM_SWITCH));
			memcpy(pst_switch_tmp, pst_switch_st, sizeof(NAC_SYSTEM_SWITCH));
			*/

			pst_switch_tmp->switch_ip    = pst_switch_st->switch_ip;
			pst_switch_tmp->connect_port = pst_switch_st->connect_port;
			memset(pst_switch_tmp->switch_factory, '\0', NAC_SWITCH_NAME_SIZE);
			strcpy(pst_switch_tmp->switch_factory, pst_switch_st->switch_factory);
			memset(pst_switch_tmp->switch_model, '\0', NAC_SWITCH_PASSWORD_SIZE);
			strcpy(pst_switch_tmp->switch_model, pst_switch_st->switch_model);
			memset(pst_switch_tmp->switch_dename, '\0', NAC_SWITCH_NAME_SIZE);
			strcpy(pst_switch_tmp->switch_dename, pst_switch_st->switch_dename);

			pst_switch_tmp->switch_fd = pst_switch_st->switch_fd;
			pst_switch_tmp->pthread_id = pst_switch_st->pthread_id;
			pst_switch_tmp->add_time = pst_switch_st->add_time;
			pst_switch_tmp->switch_status = pst_switch_st->switch_status;

			/*
			if (pst_switch_tmp->login_type == NAC_SWITCH_SNMP)
			{

				memset(pst_switch_tmp->union_passwd.snmp, '\0',
						sizeof(pst_switch_tmp->union_passwd.snmp));
			}
			else
			{
				memset(pst_switch_tmp->union_passwd.passwd, '\0',
						sizeof(pst_switch_tmp->union_passwd.passwd));
			}

			pst_switch_tmp->login_type = pst_switch_st->login_type;

			if (pst_switch_st->login_type == NAC_SWITCH_SNMP)
			{

				strcpy(pst_switch_tmp->union_passwd.snmp,
						pst_switch_st->union_passwd.snmp);

			}
			else
			{
				strcpy(pst_switch_tmp->union_passwd.passwd,
						pst_switch_st->union_passwd.passwd);
			}

			memset((char*)pst_switch_tmp->union_passwd,
						'\0', sizeof(pst_switch_tmp->union_passwd));
			memcpy((char*)pst_switch_tmp->union_passwd,
					(char*)pst_switch_st->union_passwd,
					sizeof(pst_switch_tmp->union_passwd));
			*/


			if (pst_switch_tmp->login_type == NAC_SWITCH_SNMP)
			{
				memset(pst_switch_tmp->union_passwd.snmp.ro_community,
						'\0', NAC_SWITCH_PASSWORD_SIZE);
				memset(pst_switch_tmp->union_passwd.snmp.rw_community,
						'\0', NAC_SWITCH_PASSWORD_SIZE);
			}
			else
			{
				memset(pst_switch_tmp->union_passwd.passwd.name,
						'\0', NAC_SWITCH_PASSWORD_SIZE);
				memset(pst_switch_tmp->union_passwd.passwd.pass,
						'\0', NAC_SWITCH_PASSWORD_SIZE);
				memset(pst_switch_tmp->union_passwd.passwd.super_pass,
						'\0', NAC_SWITCH_PASSWORD_SIZE);

			}
			pst_switch_tmp->login_type = pst_switch_st->login_type;

			if (pst_switch_st->login_type == NAC_SWITCH_SNMP)
			{
				pst_switch_tmp->union_passwd.snmp.version = pst_switch_st->union_passwd.snmp.version;
				strcpy(pst_switch_tmp->union_passwd.snmp.ro_community,
						pst_switch_st->union_passwd.snmp.ro_community);
				strcpy(pst_switch_tmp->union_passwd.snmp.rw_community,
						pst_switch_st->union_passwd.snmp.rw_community);

			}
			else
			{
				pst_switch_tmp->union_passwd.passwd.mode = pst_switch_st->union_passwd.passwd.mode;
				strcpy(pst_switch_tmp->union_passwd.passwd.name,
						pst_switch_st->union_passwd.passwd.name);

				strcpy(pst_switch_tmp->union_passwd.passwd.pass,
						pst_switch_st->union_passwd.passwd.name);

				strcpy(pst_switch_tmp->union_passwd.passwd.name,
						pst_switch_st->union_passwd.passwd.super_pass);

			}

			nac_system_switch_unlock();
            return HUPU_OK;
        }
    }
    nac_system_switch_unlock();

    return HUPU_ERR;
}

HUPU_INT32 nac_system_modify_switch_status(HUPU_UINT32 switch_id,
                                    HUPU_UINT32 switch_fd,
                                    NAC_SYSTEM_SWITCH_STATUS status)
{
    HUPU_UINT32 hash;
    struct nac_hlist_node *pos, *n;
    NAC_SYSTEM_SWITCH *pst_switch_tmp;

    hash = nac_system_get_switch_hash_by_switch_id(switch_id);
    nac_system_switch_lock();
    nac_hlist_for_each_entry_safe(pst_switch_tmp, pos, n, &nac_switch_hash_by_id[hash], node)
    {
        if(pst_switch_tmp->switch_id == switch_id)
		{
			pst_switch_tmp->switch_status = status;

			if (status != NAC_SYSTEM_SWITCH_CONNECT_OK
				&& pst_switch_tmp->login_type == NAC_SWITCH_SNMP)
			{
				pst_switch_tmp->pthread_id = 0;
			}

			if (pst_switch_tmp->login_type == NAC_SWITCH_SSH
				&& pst_switch_tmp->login_type == NAC_SWITCH_TELNET)
			{
            	if(switch_fd > 0)
            	{
                	pst_switch_tmp->switch_fd = switch_fd;
            	}
			}

            nac_system_switch_unlock();
            return HUPU_OK;
        }
    }
    nac_system_switch_unlock();
	return HUPU_ERR;
}

//////////////////////////////////////////////////////////////////////////////////////////
/*
typedef enum
{
   SWITCH_SHOW,
   SWITCH_ADD,
   SWITCH_DEL,
   SWITCH_MODIFY,
   SWITCH_TEST,
}NAC_SYSTEM_SWITCH_ACTION;
*/

/*
<?xml version="1.0" encoding="UTF-8"?>
<nac>
<commandID>125+100</commandID>
<actionType>0</actionType>
<result>0</result>
<switchInfo type="SNMP" mode="0">22;cisco2560;192.168.10.2;cisco;3560;nacpublic;nacprivate</switchInfo>
</nac>
*/
xmlDocPtr nac_system_show_all_switch (HUPU_VOID)
{
	HUPU_UINT32 i, switch_sum;
	xmlDocPtr doc;
    xmlNodePtr root_node, pnode;

    struct nac_hlist_node *pos, *n;
    NAC_SYSTEM_SWITCH *pst_switch_tmp;
	HUPU_CHAR get_buffer[SEND_BUFFER_LEN] = "";
	HUPU_CHAR cmd_buffer[16] = "";

	HUPU_UINT16 command_ID = SYS_WEBUI_SET_SWITCH_CONTROL;
	//HUPU_UINT8  action_ID  = SWITCH_SHOW;

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    sprintf(cmd_buffer, "%d", (command_ID + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_buffer);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");

	switch_sum = 0;
    for(i = 0; i < NAC_SYSTEM_SWITCH_HASH_SIZE; i++)
    {
    	nac_system_switch_lock();
 		nac_hlist_for_each_entry_safe(pst_switch_tmp, pos, n, &nac_switch_hash_by_id[i], node)
 		{
 			memset(get_buffer, '\0', sizeof(get_buffer));
			if (pst_switch_tmp->login_type == NAC_SWITCH_SNMP)
			{
				sprintf(get_buffer,"%d;%s;%u.%u.%u.%u;%s;%s;%s;%s",
						pst_switch_tmp->switch_id, pst_switch_tmp->switch_dename,
						LIPQUAD(pst_switch_tmp->switch_ip),
						pst_switch_tmp->switch_factory, pst_switch_tmp->switch_model,
						pst_switch_tmp->union_passwd.snmp.ro_community,
						pst_switch_tmp->union_passwd.snmp.rw_community);
				pnode = xmlNewChild(root_node, HUPU_NULL, BAD_CAST "switchInfo", BAD_CAST get_buffer);

				xmlNewProp(pnode, BAD_CAST "type", BAD_CAST "SNMP");
				memset(cmd_buffer, '\0', sizeof(cmd_buffer));
				sprintf(cmd_buffer, "%d", pst_switch_tmp->union_passwd.snmp.version);
				xmlNewProp(pnode, BAD_CAST "mode", BAD_CAST cmd_buffer);

			}
			else
			{
				sprintf(get_buffer,"%d;%s;%u.%u.%u.%u;%s;%s;%s;%s;%s",
						pst_switch_tmp->switch_id, pst_switch_tmp->switch_dename,
						LIPQUAD(pst_switch_tmp->switch_ip),
						pst_switch_tmp->switch_factory, pst_switch_tmp->switch_model,
						pst_switch_tmp->union_passwd.passwd.name,
						pst_switch_tmp->union_passwd.passwd.pass,
						pst_switch_tmp->union_passwd.passwd.super_pass);
				pnode = xmlNewChild(root_node, HUPU_NULL, BAD_CAST "switchInfo", BAD_CAST get_buffer);

				if (pst_switch_tmp->login_type == NAC_SWITCH_SSH)
				{
					xmlNewProp(pnode, BAD_CAST "type", BAD_CAST "SSH");
				}
				else if (pst_switch_tmp->login_type == NAC_SWITCH_TELNET)
				{
					xmlNewProp(pnode, BAD_CAST "type", BAD_CAST "TELNET");
				}

				memset(cmd_buffer, '\0', sizeof(cmd_buffer));
				sprintf(cmd_buffer, "%d", pst_switch_tmp->union_passwd.passwd.mode);
				xmlNewProp(pnode, BAD_CAST "mode", BAD_CAST cmd_buffer);

			}

			if (pst_switch_tmp->switch_status == NAC_SYSTEM_SWITCH_CONNECT_OK)
			{
				xmlNewProp(pnode, BAD_CAST "status", BAD_CAST "1");
			}
			else
			{
				xmlNewProp(pnode, BAD_CAST "status", BAD_CAST "0");
			}

			switch_sum = switch_sum + 1;
 		}
		nac_system_switch_unlock();
    }

	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->switch_sum = %d\n",
				__FUNCTION__, switch_sum);

    return doc;
}


HUPU_INT32 nac_system_switch_create_thread(NAC_SYSTEM_SWITCH *pst_switch)
{
    NAC_SYSTEM_SWITCH *pst_switch_tmp;
    HUPU_INT32 iRet;
    pthread_t thread_id;
	HUPU_VOID *(*create_thread_fun)(HUPU_VOID *);

    pst_switch_tmp = (NAC_SYSTEM_SWITCH *)malloc(sizeof(NAC_SYSTEM_SWITCH));
    if(HUPU_NULL == pst_switch_tmp)
    {
        return HUPU_ERR;
    }
    memcpy(pst_switch_tmp, pst_switch, sizeof(NAC_SYSTEM_SWITCH));


	switch(pst_switch_tmp->login_type)
	{
	case NAC_SWITCH_SNMP:
		create_thread_fun = (HUPU_VOID *)nac_system_switch_snmp_walk_thread_enter;
		break;

	case NAC_SWITCH_SSH:
	case NAC_SWITCH_TELNET:
		//create_thread_fun = (HUPU_VOID *)nac_system_switch_tcp_connect_thread_enter;
		break;
	}

	iRet = pthread_create(&thread_id, HUPU_NULL,
						create_thread_fun, pst_switch_tmp);
    if(HUPU_OK != iRet)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "\nnac_system:nac_system_switch_create_thread->pthread_create error, iRet = %d, errno = %d, error info = %s\n", iRet, errno, strerror(errno));
        free(pst_switch_tmp);
        return iRet;
    }

	pst_switch->pthread_id = thread_id;

    return HUPU_OK;
}



HUPU_UINT8 nac_system_get_switch_login_type(HUPU_CHAR* type_str)
{
	HUPU_UINT8 login_type = 0;
	if(strcmp(type_str, "SNMP") == 0)
	{
		login_type = NAC_SWITCH_SNMP;
	}
	else if(strcmp(type_str, "SSH") == 0)
	{
		login_type = NAC_SWITCH_SSH;
	}
	else if (strcmp(type_str, "TELNET") == 0)
	{
		login_type = NAC_SWITCH_TELNET;
	}

	return login_type;
}

xmlDocPtr nac_system_test_switch_control(NAC_SYSTEM_SWITCH* pst_switch_st)
{
	xmlDocPtr test_doc = HUPU_NULL;
	NAC_SYSTEM_SWITCH_LOGIN em_switch_login_type;

	em_switch_login_type = pst_switch_st->login_type;

	switch (em_switch_login_type)
	{
	case NAC_SWITCH_SSH:
		test_doc = nac_system_test_switch_ssh_control(pst_switch_st);
		break;

	case NAC_SWITCH_SNMP:
		test_doc = nac_system_test_switch_snmp_control(pst_switch_st);
		break;

	case NAC_SWITCH_TELNET:
		test_doc = nac_system_test_switch_telnet_control(pst_switch_st);
		break;
	}

	return test_doc;

}


HUPU_INT32 nac_system_add_switch_control(NAC_SYSTEM_SWITCH* pst_switch_st)
{
	HUPU_INT32 iRet;
	time_t current_time  = 0;
	NAC_SYSTEM_SWITCH_LOGIN em_switch_login_type;

	em_switch_login_type = pst_switch_st->login_type;

	time(&current_time);
	pst_switch_st->add_time = current_time;

	switch (em_switch_login_type)
	{
	case NAC_SWITCH_SSH:
		iRet = nac_system_add_switch_ssh_control(pst_switch_st);
		break;

	case NAC_SWITCH_SNMP:
		iRet = nac_system_add_switch_snmp_control(pst_switch_st);
		break;

	case NAC_SWITCH_TELNET:
		iRet = nac_system_add_switch_telnet_control(pst_switch_st);
		break;
	}

	return iRet;
}

HUPU_INT32 nac_system_modify_switch_control(NAC_SYSTEM_SWITCH* pst_switch_st)
{
	HUPU_INT32 iRet;
	time_t current_time  = 0;
	NAC_SYSTEM_SWITCH_LOGIN em_switch_login_type;

	em_switch_login_type = pst_switch_st->login_type;

	time(&current_time);
	pst_switch_st->add_time = current_time;

	switch (em_switch_login_type)
	{
	case NAC_SWITCH_SSH:
		iRet = nac_system_modify_switch_ssh_control(pst_switch_st);
		break;

	case NAC_SWITCH_SNMP:
		iRet = nac_system_modify_switch_snmp_control(pst_switch_st);
		break;

	case NAC_SWITCH_TELNET:
		iRet = nac_system_modify_switch_telnet_control(pst_switch_st);
		break;
	}

	return iRet;
}

xmlDocPtr nac_sys_parse_set_switch_control(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_INT32 iRet, error_id;
    xmlDocPtr nac_doc = HUPU_NULL;
	xmlChar *login_type_szAttr;
	xmlChar *login_mode_szAttr;
	xmlChar *switch_info_szKey;
    xmlNodePtr cur_node;
    HUPU_UINT8 action_type;
	HUPU_UINT16 switch_id_tmp;
	NAC_SYSTEM_SWITCH st_switch_tmp;
	HUPU_CHAR ip_str[IP_STR_LEN] = "";

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
	switch_id_tmp = 0;
	memset(ip_str, '\0', IP_STR_LEN);
	memset(&st_switch_tmp, '\0', sizeof(NAC_SYSTEM_SWITCH));

    switch (action_type)
    {
	case SWITCH_SHOW:
		nac_free_xmlDoc(doc);
		nac_doc = nac_system_show_all_switch();
		break;

	case SWITCH_DEL:
		while(cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "switchInfo")))
            {
            	switch_info_szKey = xmlNodeGetContent(cur_node);
				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
							"%s-->del-->switchInfo-->%s\n",
							__FUNCTION__, (HUPU_CHAR*)switch_info_szKey);
				switch_id_tmp = atoi((HUPU_CHAR*)switch_info_szKey);
				xmlFree(switch_info_szKey);
			}
			cur_node = cur_node->next;
        }
		nac_free_xmlDoc(doc);
		iRet = nac_system_rmv_switch(switch_id_tmp);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

    case SWITCH_MODIFY:
		//test_error; and modify_error;
		while(cur_node != HUPU_NULL)
        {
        	if (!(xmlStrcmp(cur_node->name, BAD_CAST "switchInfo"))
				&& xmlHasProp(cur_node, BAD_CAST "type")
				&& xmlHasProp(cur_node, BAD_CAST "mode"))
            {
				login_type_szAttr = xmlGetProp(cur_node, BAD_CAST "type");
				st_switch_tmp.login_type = nac_system_get_switch_login_type((HUPU_CHAR*)login_type_szAttr);
				if (st_switch_tmp.login_type == 0)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->switch_login_type error!\n", __FUNCTION__);
				}
				xmlFree(login_type_szAttr);


				switch_info_szKey = xmlNodeGetContent(cur_node);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->modify--test-->switchInfo-->%s\n",
							__FUNCTION__, (HUPU_CHAR*)switch_info_szKey);

				login_mode_szAttr = xmlGetProp(cur_node, BAD_CAST "mode");

				if (st_switch_tmp.login_type == NAC_SWITCH_SNMP)
				{
					sscanf((HUPU_CHAR*)switch_info_szKey,
						"%hd;%[^;];%[^;];%[^;];%[^;];%[^;];%s",
						&switch_id_tmp, st_switch_tmp.switch_dename, ip_str,
						st_switch_tmp.switch_factory, st_switch_tmp.switch_model,
						st_switch_tmp.union_passwd.snmp.ro_community,
						st_switch_tmp.union_passwd.snmp.rw_community);
					st_switch_tmp.union_passwd.snmp.version = atoi((HUPU_CHAR*)login_mode_szAttr);
				}
				else
				{
					sscanf((HUPU_CHAR*)switch_info_szKey,
						"%hd;%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%s",
						&switch_id_tmp, st_switch_tmp.switch_dename, ip_str,
						st_switch_tmp.switch_factory, st_switch_tmp.switch_model,
						st_switch_tmp.union_passwd.passwd.name,
						st_switch_tmp.union_passwd.passwd.pass,
						st_switch_tmp.union_passwd.passwd.super_pass);
					st_switch_tmp.union_passwd.passwd.mode = atoi((HUPU_CHAR*)login_mode_szAttr);
				}
				xmlFree(switch_info_szKey);
				xmlFree(login_mode_szAttr);

				break;
			}

			cur_node = cur_node->next;

		}
		nac_free_xmlDoc(doc);

		st_switch_tmp.switch_id = switch_id_tmp;
		st_switch_tmp.switch_ip = inet_network(ip_str);

		error_id = nac_system_modify_switch_control(&st_switch_tmp);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

	case SWITCH_ADD:
	case SWITCH_TEST:
		while(cur_node != HUPU_NULL)
        {
        	if (!(xmlStrcmp(cur_node->name, BAD_CAST "switchInfo"))
				&& xmlHasProp(cur_node, BAD_CAST "type")
				&& xmlHasProp(cur_node, BAD_CAST "mode"))
            {
				login_type_szAttr = xmlGetProp(cur_node, BAD_CAST "type");
				st_switch_tmp.login_type = nac_system_get_switch_login_type((HUPU_CHAR*)login_type_szAttr);
				if (st_switch_tmp.login_type == 0)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->switch_login_type error!\n", __FUNCTION__);
				}
				xmlFree(login_type_szAttr);


				switch_info_szKey = xmlNodeGetContent(cur_node);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->add--test-->switchInfo-->%s\n",
							__FUNCTION__, (HUPU_CHAR*)switch_info_szKey);

				login_mode_szAttr = xmlGetProp(cur_node, BAD_CAST "mode");

				if (st_switch_tmp.login_type == NAC_SWITCH_SNMP)
				{
					sscanf((HUPU_CHAR*)switch_info_szKey, "%[^;];%[^;];%[^;];%[^;];%[^;];%s",
						st_switch_tmp.switch_dename, ip_str,
						st_switch_tmp.switch_factory, st_switch_tmp.switch_model,
						st_switch_tmp.union_passwd.snmp.ro_community,
						st_switch_tmp.union_passwd.snmp.rw_community);
					st_switch_tmp.union_passwd.snmp.version = atoi((HUPU_CHAR*)login_mode_szAttr);
				}
				else
				{
					sscanf((HUPU_CHAR*)switch_info_szKey, "%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%s",
						st_switch_tmp.switch_dename, ip_str,
						st_switch_tmp.switch_factory, st_switch_tmp.switch_model,
						st_switch_tmp.union_passwd.passwd.name,
						st_switch_tmp.union_passwd.passwd.pass,
						st_switch_tmp.union_passwd.passwd.super_pass);
					st_switch_tmp.union_passwd.passwd.mode = atoi((HUPU_CHAR*)login_mode_szAttr);
				}
				xmlFree(switch_info_szKey);
				xmlFree(login_mode_szAttr);

				break;
			}

			cur_node = cur_node->next;

		}
		nac_free_xmlDoc(doc);

		st_switch_tmp.switch_ip = inet_network(ip_str);

		if (action_type == SWITCH_ADD)
		{
			g_nac_switch_index = g_nac_switch_index + 1;
			st_switch_tmp.switch_id = g_nac_switch_index;
			iRet = nac_system_add_switch_control(&st_switch_tmp);
			if (iRet != HUPU_OK)
			{
				error_id = iRet;
				g_nac_switch_index = g_nac_switch_index - 1;
			}

			nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		}
		else if (action_type == SWITCH_TEST)
		{
			nac_doc = nac_system_test_switch_control(&st_switch_tmp);
		}

		break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}




