#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_common_lib.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_net.h"
#include "nac_system_save_sysconfig.h"
#include "nac_system_get_hardwareId.h"
#include "nac_system_vlanmap.h"
#include "nac_system_pbr_advance_setup.h"
#include "nac_system_iprange_policy.h"
#include "nac_system_domain_policy.h"
#include "nac_system_time.h"
#include "nac_system_get_sys_status.h"
#include "nac_system_redirect_manager_ip.h"
#include "nac_system_user.h"
#include "nac_system_set_remote_server.h"
#include "nac_system_netapp_user.h"
#include "nac_system_netapp_check.h"
#include "nac_system_switch_main.h"
#include "nac_system_deal_license.h"
#include "nac_system_arp_monitor.h"
#include "nac_system_deal_sysconfig.h" //nac_app_flush_all_system_config
#include "nac_system_debug_switch.h"
#include "nac_system_escape_deal.h"
#include "nac_system_nat_manage.h"
#include "nac_system_exceptapp.h"
#include "nac_system_ha_backup.h"
#include "nac_system_dhcp_manage.h"
#include "nac_system_except_mac.h"
#include "nac_system_net_traffic.h"
#include "nac_system_redis_subscribe.h"
#include "nac_system_os_check.h"
#include "nac_system_access_mode.h"




HUPU_UINT16 g_nac_asc_enable_flag;
HUPU_INT16	Ret_cmd_offset = 100;

HUPU_VOID nac_free_xmlDoc(xmlDocPtr doc)
{
    xmlFreeDoc(doc);
   	//xmlCleanupParser();
    xmlMemoryDump();
}

/*add 0/-1; del 0/-1; modify 0/-1; show -1*/
xmlDocPtr nac_sys_ret_action_result(HUPU_UINT16 cmd_id, HUPU_UINT8 action, HUPU_INT16 ret_status, HUPU_VOID *ret_msg)
{
	xmlDocPtr doc;
	xmlNodePtr root_node;
	HUPU_CHAR cmd_str[10];
    HUPU_CHAR nac_send_buffer[SEND_BUFFER_LEN] = "";

	doc = xmlNewDoc(BAD_CAST "1.0");
	root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
	xmlDocSetRootElement(doc, root_node);
	memset(cmd_str, '\0', sizeof(cmd_str));
	sprintf(cmd_str, "%d", (cmd_id + Ret_cmd_offset));
	xmlNewChild (root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_str);

	memset(cmd_str, '\0', sizeof(cmd_str));
	sprintf(cmd_str, "%d", action);
	xmlNewChild (root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST cmd_str);
	if (ret_status == 0)
	{
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");
	}
	else if (ret_status == -1)
	{
		sprintf(nac_send_buffer, "-1:%s", (HUPU_CHAR*)ret_msg);
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST nac_send_buffer);
	}

	return doc;
}

//add 0/-1; del 0/-1; modify 0/-1;
xmlDocPtr nac_sys_return_web_action_result(HUPU_UINT16 cmd_id, HUPU_UINT8 action, HUPU_UINT16 error_id)
{
    xmlDocPtr doc;
    xmlNodePtr root_node;
    HUPU_CHAR cmd_str[10] = "";
    HUPU_CHAR nac_send_buffer[SEND_BUFFER_LEN] = "";

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);
    memset(cmd_str, '\0', sizeof(cmd_str));
    sprintf(cmd_str, "%d", (cmd_id + Ret_cmd_offset));
    xmlNewChild (root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_str);

    memset(cmd_str, '\0', sizeof(cmd_str));
    sprintf(cmd_str, "%d", action);
    xmlNewChild (root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST cmd_str);

    if (error_id == HUPU_OK)
    {
        xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");
    }
	else if (error_id == HUPU_ERR)
	{
        xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "-1:null");
	}
    else
    {
        sprintf(nac_send_buffer, "-1:%s", nac_sys_get_error_log(error_id));
        xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST nac_send_buffer);
    }

    return doc;
}

/*show success 0 有数据 和 无数据 actionType=0,result=0*/
xmlDocPtr nac_sys_ret_show_result(HUPU_UINT16 cmd_id, HUPU_VOID *show_msg)
{
    HUPU_INT16 i;
	xmlDocPtr doc;
	xmlNodePtr root_node, tmp_node;
	HUPU_CHAR cmd_str[10];
	HUPU_UINT16	must_link_flag;
    HUPU_CHAR nac_send_buffer[SEND_BUFFER_LEN] = "";

	doc = xmlNewDoc(BAD_CAST "1.0");
	root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
	xmlDocSetRootElement(doc, root_node);

	memset(cmd_str, '\0', sizeof(cmd_str));
	sprintf(cmd_str, "%d", (cmd_id + Ret_cmd_offset));
	xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_str);

	xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");
	xmlNewChild(root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");
	if (show_msg == HUPU_NULL)
	{
		return doc;
	}

	switch(cmd_id)
	{
	case SYS_WEBUI_REDIRECT_URL:
        tmp_node = xmlNewChild(root_node, HUPU_NULL, BAD_CAST "redirectUrl", BAD_CAST gst_redirect_manager_ip.ac_redirect_ip);
        if (gst_redirect_manager_ip.en_redirect_flag == NAC_KNL_POLICY_DROP)
        {
            xmlNewProp(tmp_node, BAD_CAST "type", BAD_CAST "0");
        }
        else
        {
            xmlNewProp(tmp_node, BAD_CAST "type", BAD_CAST "1");
        }
        xmlNewChild(root_node, HUPU_NULL, BAD_CAST "serManagerIp", BAD_CAST gst_redirect_manager_ip.ac_server_manager_ip);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "ctrManagerIp", BAD_CAST gst_redirect_manager_ip.ac_control_manager_ip);
		break;

	case SYS_WEBUI_SET_IFCONFIG:
		for (i = 0; i < gi_netdev_count; i++)
		{
			must_link_flag = nac_app_get_netdev_all_status(i);

			sprintf(nac_send_buffer, "%hd;%s;%s;%s;%hhd;%hhd", i, g_nac_net_device[i].if_label,
					g_nac_net_device[i].if_ip, g_nac_net_device[i].if_mask,
					g_nac_net_device[i].if_link, must_link_flag);

			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "netDevice", BAD_CAST nac_send_buffer);
			memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
		}
		break;

	case SYS_WEBUI_SET_GATEWAY:
		//g_default_gateway == NULL,表示删除默认网关。
		//memset(g_default_gateway, '\0', IP_STR_LEN);
		//nac_app_get_system_default_gateway(g_default_gateway);
        if (strlen(g_default_gateway))
        {
		    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "gateway", BAD_CAST g_default_gateway);
        }
        else
        {
		    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "gateway", BAD_CAST "NULL");
        }
		break;

	case SYS_WEBUI_SET_DNS:
		//nameServer1或者nameServer2 = NULL, 表示没有配置主DNS或者辅DNS.
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "nameServer1", BAD_CAST gst_dns_server.nameserver1);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "nameServer2", BAD_CAST gst_dns_server.nameserver2);
		break;

	case SYS_WEBUI_GET_CONTROLLER_LINK_STATUS:
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "companyId", BAD_CAST gi_link_company_code);

		memset(nac_send_buffer, '\0', sizeof(nac_send_buffer));
		sprintf(nac_send_buffer, "%u.%u.%u.%u", LIPQUAD(gi_link_server_ip));
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "serverIp", BAD_CAST nac_send_buffer);

		/*
		//last time connect serverip and company_code
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "companyId", BAD_CAST last_link_company_code);
		memset(nac_send_buffer, '\0', sizeof(nac_send_buffer));
		sprintf(nac_send_buffer, "%u.%u.%u.%u", LIPQUAD(last_link_remote_ip));
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "serverIp", BAD_CAST nac_send_buffer);
		*/

		memset(cmd_str, '\0', sizeof(cmd_str));
		sprintf(cmd_str, "%d", gi_link_fd);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "linkStatus", BAD_CAST cmd_str);
		break;

	case SYS_WEBUI_SET_SYS_TIME:
		if (memcmp(show_msg, "all_time", strlen("all_time")) == HUPU_OK)
		{
			memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
			nac_get_system_current_time(nac_send_buffer);
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "currentTime", BAD_CAST nac_send_buffer);

			memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
			nac_get_system_start_time(nac_send_buffer);
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "startTime", BAD_CAST nac_send_buffer);

			memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
			nac_get_system_last_run_time(nac_send_buffer);
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "lastTime", BAD_CAST nac_send_buffer);
		}
		else if (memcmp(show_msg, "current_time", strlen("current_time")) == HUPU_OK)
		{
			memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
			nac_get_system_current_time(nac_send_buffer);
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "currentTime", BAD_CAST nac_send_buffer);
		}
		else if (memcmp(show_msg, "ntp_server", strlen("ntp_server")) == HUPU_OK)
		{
			memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
			nac_get_system_current_time(nac_send_buffer);
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "currentTime", BAD_CAST nac_send_buffer);

			memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
			sprintf(nac_send_buffer, "%d;%s", gst_nac_ntp_server.self_sync_enable,
					gst_nac_ntp_server.ntp_server);
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "ntpServer", BAD_CAST nac_send_buffer);
		}
		break;

	case SYS_WEBUI_GET_SYS_STATUS:
		memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
		nac_get_system_cpu_status(nac_send_buffer);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "cpuStatus", BAD_CAST nac_send_buffer);

		memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
		nac_get_system_load_average_status(nac_send_buffer);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "loadAverage", BAD_CAST nac_send_buffer);

		memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
		nac_get_system_memory_status(nac_send_buffer);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "memStatus", BAD_CAST nac_send_buffer);

		memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
		nac_get_system_disk_status(nac_send_buffer);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "diskStatus", BAD_CAST nac_send_buffer);

		memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
		nac_get_system_data_partition_status(nac_send_buffer);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "dataPartStatus", BAD_CAST nac_send_buffer);
		break;

	case SYS_WEBUI_SET_SYS_LANG:
		memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
		switch (nac_system_language_type)
		{
		case LG_english:
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "systemLanguage", BAD_CAST "1");
			break;

		case LG_schinese:
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "systemLanguage", BAD_CAST "2");
			break;

		case LG_tchinese:
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "systemLanguage", BAD_CAST "3");
			break;

		default:
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "systemLanguage", BAD_CAST "null");
			break;
		}
		break;

	case SYS_WEBUI_SET_ARP_MONITOR_PORT:
		if (gst_arp_monitor_config.enable == HUPU_TRUE)
		{
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "enable", BAD_CAST "1");
		}
		else
		{
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "enable", BAD_CAST "0");
		}

		memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
		sprintf(nac_send_buffer, "%d",	gst_arp_monitor_config.cycle_time);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "cycleTime", BAD_CAST nac_send_buffer);

		memset(nac_send_buffer, '\0', SEND_BUFFER_LEN);
		sprintf(nac_send_buffer, "%s;%s", gst_arp_monitor_config.monitor_port,
				gst_arp_monitor_config.port_attr);
		xmlNewChild(root_node, HUPU_NULL, BAD_CAST "arpMonitor", BAD_CAST nac_send_buffer);
		break;

	case SYS_WEBUI_SET_ASC_ENABLE_FLAG:
		nac_sys_get_knl_pass_switch(&g_nac_asc_enable_flag);
		if (g_nac_asc_enable_flag == ASC_ENABLE)
    	{
        	xmlNewChild(root_node, HUPU_NULL, BAD_CAST "ascEnable", BAD_CAST "1");
    	}
		else if (g_nac_asc_enable_flag == ASC_DISABLE)
    	{
        	xmlNewChild(root_node, HUPU_NULL, BAD_CAST "ascEnable", BAD_CAST "0");
    	}
		break;

	case SYS_WEBUI_ADVANCED_DEBUG_SWITCH:
		if (nac_app_advanced_debug_switch == HUPU_ENABLE)
		{
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "debugSwitch", BAD_CAST "1");
		}
		else if (nac_app_advanced_debug_switch == HUPU_DISABLE)
		{
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "debugSwitch", BAD_CAST "0");
		}
		break;

	case SYS_WEBUI_ESCAPE_ENABLE_FLAG:
        if (g_asc_escape_enable_flag >= HUPU_TRUE)
        {
            g_asc_escape_enable_flag = HUPU_TRUE;
        }
        insert_number_xml_new_child(root_node, "escapeEnable", g_asc_escape_enable_flag);
        insert_string_xml_new_child(root_node, "maxFlowSpeed", g_untrust_max_flow_speed);
        break;
	default:
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid show command_id\n", __FUNCTION__);
		break;
	}

	return doc;
}

HUPU_INT32 nac_sys_return_idm_connect_asc_requset(HUPU_INT32 sock_fd)
{
	HUPU_INT32 iRet, send_msg_len;
	HUPU_CHAR asc_response_idm[12];
	NAC_WEB_MSG *pst_asc_response_idm;

	memset(asc_response_idm, '\0', sizeof(asc_response_idm));
	pst_asc_response_idm = (NAC_WEB_MSG*)asc_response_idm;
	pst_asc_response_idm->us_cmd = SYS_WEBUI_IDM_CONNECT_ASC_REQUEST + 1000;
    pst_asc_response_idm->reserve = 0;
    pst_asc_response_idm->ui_len = strlen("OK");
	memcpy(pst_asc_response_idm->ac_buf, "OK", strlen("OK"));
	send_msg_len = sizeof(NAC_WEB_MSG) + strlen("OK");

	if (sock_fd <= 0)
	{
		return HUPU_ERR;
	}

	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->asc_response_idm-->%d-->%d-->%s\n",
				__FUNCTION__, pst_asc_response_idm->us_cmd, pst_asc_response_idm->ui_len,
				pst_asc_response_idm->ac_buf);

	iRet = nac_tcp_sendto(sock_fd, (HUPU_CHAR*)asc_response_idm, send_msg_len);
	if (iRet > 0 && iRet == send_msg_len)
	{
		return HUPU_OK;
	}
	else
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->send asc_response_idm error-->%d\n",
						__FUNCTION__, iRet);
		return HUPU_ERR;
	}

	return HUPU_OK;
}

HUPU_INT32 nac_sys_return_heart_beat_to_webserver(HUPU_INT32 sock_fd, HUPU_CHAR *rev_heart)
{
    HUPU_INT32 iRet, heart_msg_size;
	NAC_WEB_MSG *ret_heart_beat;

    heart_msg_size = sizeof(NAC_WEB_MSG) + 1 + 1;
    ret_heart_beat = (NAC_WEB_MSG*)malloc(heart_msg_size);

    if (ret_heart_beat  == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->malloc fail\n", __FUNCTION__);
		return HUPU_ERR;
	}

    memset(ret_heart_beat, 0x00, heart_msg_size);
    ret_heart_beat->us_cmd  = 0x01;
    ret_heart_beat->reserve = 0x00;
	ret_heart_beat->ui_len  = 0x01;
	memcpy(ret_heart_beat->ac_buf, "0", 1);
    ret_heart_beat->ac_buf[1] = '\0';

    if (sock_fd <= 0)
	{
		return HUPU_ERR;
	}

	/*
    SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->return heart_beat-->%d-->%d-->%s\n",
				__FUNCTION__, ret_heart_beat->us_cmd, ret_heart_beat->ui_len,
				ret_heart_beat->ac_buf);
	*/
	iRet = nac_tcp_sendto(sock_fd, (HUPU_CHAR*)ret_heart_beat, (heart_msg_size-1));
    free(ret_heart_beat);
	if (iRet > 0 && iRet == (heart_msg_size-1))
	{
		return HUPU_OK;
	}
	else
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->send return_heart_beat error-->%d\n",
						__FUNCTION__, iRet);
		return HUPU_ERR;
	}

	return HUPU_OK;
}

HUPU_INT32 nac_sys_send_xmlstr_to_webserver(HUPU_INT32 sock_fd, HUPU_UINT32 length,
                                            HUPU_UINT16 cmd, HUPU_CHAR* xml_msg_tmp)
{
    HUPU_INT32 iRet;
	NAC_WEB_MSG *pst_xml_msg = HUPU_NULL;
	HUPU_UINT32 xml_msg_len;

	xml_msg_len = sizeof(NAC_WEB_MSG) + length + 1;
	pst_xml_msg = (NAC_WEB_MSG *)malloc(xml_msg_len);
	if (pst_xml_msg == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->malloc fail\n", __FUNCTION__);
		return HUPU_ERR;
	}
	memset((HUPU_CHAR*)pst_xml_msg, '\0', xml_msg_len);
	if (cmd == SYS_WEBUI_ASC_IMPORT_DEVICE_INFO
		|| cmd == ASC_CLIENT_REGISTER)
	{
		pst_xml_msg->us_cmd = cmd;
	}
	else
	{
		pst_xml_msg->us_cmd = cmd + Ret_cmd_offset;
	}
    pst_xml_msg->reserve = 0;
	pst_xml_msg->ui_len = length;
	memcpy(pst_xml_msg->ac_buf, xml_msg_tmp, pst_xml_msg->ui_len);
	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "cmd=%d-->len=%d-->msg=%s\n",
					pst_xml_msg->us_cmd, pst_xml_msg->ui_len, pst_xml_msg->ac_buf);

	iRet = nac_tcp_sendto(sock_fd, (HUPU_CHAR*)pst_xml_msg, (xml_msg_len - 1));
	free(pst_xml_msg);
	if (!(iRet > 0 && iRet == xml_msg_len - 1))
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_tcp_sendto error-->sockfd=%d--iRet=%d\n", __FUNCTION__, sock_fd, iRet);
        return HUPU_ERR;
    }

	return HUPU_OK;
}

HUPU_INT32 nac_sys_send_xmldoc_to_webserver(HUPU_INT32 sock_fd, xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_INT32 iRet;
    xmlChar* doc_buffer;
	HUPU_INT32 doc_size;
	HUPU_CHAR *send_buffer = HUPU_NULL;
	HUPU_UINT32 send_buffer_len;
	NAC_WEB_MSG *pst_send_buffer_xml;

	xmlDocDumpFormatMemoryEnc(doc, &doc_buffer, &doc_size, "UTF-8", 1);

	send_buffer_len = doc_size + sizeof(NAC_WEB_MSG) + 1;
	send_buffer = (HUPU_CHAR *)malloc(sizeof(HUPU_CHAR)*send_buffer_len);
	if (send_buffer == HUPU_NULL)
	{
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->malloc fail\n", __FUNCTION__);
		nac_free_xmlDoc(doc);
        xmlFree(doc_buffer);
		return HUPU_ERR;
	}

	memset(send_buffer, '\0', send_buffer_len);
	pst_send_buffer_xml = (NAC_WEB_MSG*)send_buffer;

	if (cmd_id == SYS_WEBUI_ASC_IMPORT_DEVICE_INFO
		|| cmd_id == ASC_CLIENT_REGISTER)
	{
		pst_send_buffer_xml->us_cmd = cmd_id;
	}
	else
	{
		pst_send_buffer_xml->us_cmd = cmd_id + Ret_cmd_offset;
	}
    pst_send_buffer_xml->reserve    = 0;
	pst_send_buffer_xml->ui_len     = doc_size;

	memcpy(pst_send_buffer_xml->ac_buf, doc_buffer, doc_size);
	xmlFree(doc_buffer);
	nac_free_xmlDoc(doc);

	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_send_buffer_xml-->%d-->%d-->%s\n",
                __FUNCTION__, pst_send_buffer_xml->us_cmd, pst_send_buffer_xml->ui_len,
				pst_send_buffer_xml->ac_buf);

	iRet = nac_tcp_sendto(sock_fd, send_buffer, (send_buffer_len-1));
	if (iRet > 0 && iRet == send_buffer_len - 1)
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s--nac_tcp_sendto--sockfd=%d--iRet=%d\n", __FUNCTION__, sock_fd, iRet);
		free(send_buffer);
		return HUPU_OK;
	}
	else
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_tcp_sendto error-->sockfd=%d--iRet = %d\n", __FUNCTION__, sock_fd, iRet);
		free(send_buffer);
        return HUPU_ERR;
    }

}

/////////////////////////////////////////////////////////////////////////////////
xmlNodePtr nac_xml_parse_get_action(xmlDocPtr doc, HUPU_UINT8 *action)
{
	xmlNodePtr curNode;
	xmlChar *szKey;
    HUPU_UINT8 get_action_flag;

	curNode = xmlDocGetRootElement(doc);
    if (HUPU_NULL == curNode)
    {
        fprintf(stderr, "error empty document: %s\n", __FUNCTION__);
        return HUPU_NULL;
    }

    if (xmlStrcmp(curNode->name, BAD_CAST "nac"))
    {
        fprintf(stderr, "error root document: %s\n", __FUNCTION__);
        return HUPU_NULL;
    }

	curNode = curNode->xmlChildrenNode;

    while(curNode != HUPU_NULL)
    {
        if (!(xmlStrcmp(curNode->name, BAD_CAST "actionType")))
        {
            szKey = xmlNodeGetContent(curNode);
            *action = atoi((char*)szKey);
            xmlFree(szKey);
            get_action_flag = HUPU_OK;
            break;
        }
        curNode = curNode->next;
    }

    if (get_action_flag == HUPU_OK)
    {
        return curNode;
    }
    else
    {
        fprintf(stderr, "xml document no actionType: %s\n", __FUNCTION__);
	    return HUPU_NULL;
    }
}

xmlDocPtr nac_sys_parse_saveconfig_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    HUPU_UINT8 action_type;
    HUPU_INT32 iRet;
    HUPU_INT16 action_result;
    HUPU_CHAR error_msg[ERROR_LEN];

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

    switch (action_type)
    {
    case NAC_SAVE_SYS_CONFIG:
        nac_free_xmlDoc(doc);
        memset(error_msg, '\0', ERROR_LEN);
        iRet = nac_app_save_sys_config_to_file(nac_sys_cfg_file);
        if (iRet == HUPU_ERR)
        {
            action_result = -1;
            nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_app_save_sys_config_to_file error\n", __FUNCTION__);
            memcpy(error_msg, "save system config error!", strlen("save system config error!"));

        }
        else
        {
            action_result = 0;
        }
        nac_doc = nac_sys_ret_action_result(cmd_id, action_type, action_result, error_msg);
        break;

    case NAC_SHOW:
    case NAC_ADD:
    case NAC_DEL:
    case NAC_MODIFY:
    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

HUPU_INT32 nac_sys_enable_or_disable_asc(HUPU_UINT16 flag)
{
	HUPU_INT32 	iRet;
	//open switch for default all forward, no control.= app_asc_enable_flag = ASC_DISABLE;
	HUPU_CHAR	nac_knl_pass_switch_open_cmd[]  = "echo 1 > /proc/sys/net/nac_knl_pass_switch_flags";

	//open switch for default not forward, if policy is ok, forwarding. = app_asc_enable_flag = ASC_ENABLE;
	HUPU_CHAR	nac_knl_pass_switch_close_cmd[] = "echo 0 > /proc/sys/net/nac_knl_pass_switch_flags";
	HUPU_CHAR	*pst_exec_cmd = HUPU_NULL;

	iRet = HUPU_OK;
	if(flag == ASC_ENABLE)
	{
		pst_exec_cmd = nac_knl_pass_switch_close_cmd;
	}
	else if (flag == ASC_DISABLE)
	{
		pst_exec_cmd = nac_knl_pass_switch_open_cmd;
	}
	else
	{
		return HUPU_ERR;
	}

	if (pst_exec_cmd)
	{
		iRet = nac_exec_system(pst_exec_cmd);
		if (iRet == HUPU_ERR)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->nac_exec_system=%s-->iRet=%d-->errno = %d,error info = %s.\n",
                    __FUNCTION__, pst_exec_cmd, iRet, errno, strerror(errno));

			return HUPU_ERR;
		}
		else
		{
			g_nac_asc_enable_flag = flag;
		}

		//imform ruby to reconnect;
		nac_sys_send_ruby_switch_usr1();
	}

	return HUPU_OK;
}

HUPU_INT32 nac_sys_get_knl_pass_switch(HUPU_UINT16 *flag)
{
	FILE *popen_fp;
	HUPU_CHAR szLine[BUFF_LEN] = "";
	HUPU_CHAR* get_knl_pass_switch_cmd= "cat /proc/sys/net/nac_knl_pass_switch_flags";
	HUPU_INT32 flag_tmp = 99;

	popen_fp = popen(get_knl_pass_switch_cmd, "r");
	if (popen_fp == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->popen error!\n", __FUNCTION__);
		return HUPU_ERR;
	}

	if (fgets(szLine, BUFF_LEN, popen_fp) == HUPU_NULL)
	{
		pclose(popen_fp);
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->fgets error!\n", __FUNCTION__);
		return HUPU_ERR;
	}
	pclose(popen_fp);

	int length = strlen(szLine);
	szLine[length-1] = '\0';

	if (sscanf(szLine, "%d", &flag_tmp) != 1)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->sscanf error!\n", __FUNCTION__);
		return HUPU_ERR;
	}

	if (flag_tmp == 0)
	{
		*flag = 1;
	}
	else if (flag_tmp >= 1)
	{
		*flag = 0;
	}

	return HUPU_OK;
}

static xmlDocPtr nac_sys_parse_set_asc_enable_flag(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    xmlDocPtr	nac_doc = HUPU_NULL;
    xmlNodePtr	cur_node;
	xmlChar		*xml_tag_szKey;
    HUPU_UINT8	action_type;
    HUPU_INT32	error_id;
	HUPU_UINT16 enable_flag_tmp;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
    switch (action_type)
    {
    case NAC_SHOW:
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_ret_show_result(cmd_id, "asc_eable");
		break;

	case NAC_ADD:
		while(cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "ascEnable")))
			{
				xml_tag_szKey = xmlNodeGetContent(cur_node);
				enable_flag_tmp = atoi((HUPU_CHAR*)xml_tag_szKey);
				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->enable_flag=%d\n",
							__FUNCTION__, enable_flag_tmp);
				xmlFree(xml_tag_szKey);
				break;
			}
			cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);

		error_id = nac_sys_enable_or_disable_asc(enable_flag_tmp);
		if (error_id == HUPU_ERR)
		{
			error_id = NAC_SYS_ERROR_ENABLE_OR_DISABLE_ASC_FAIL;
		}

		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

/*
xmlDocPtr nac_sys_parse_connect_switch_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	xmlDocPtr nac_doc = HUPU_NULL;
    NAC_SYSTEM_SWITCH st_switch;
    nac_system_switch_create_thread(&st_switch);
	return nac_doc;
}
*/

HUPU_INT32 nac_sys_parse_web_xmlmsg(HUPU_INT32 sock_fd, xmlDocPtr tmpdoc, HUPU_UINT16 command_id)
{
	xmlDocPtr Ret_doc = HUPU_NULL;
	HUPU_UINT8 deal_action = 0;
	HUPU_CHAR escape_tmp_buf[BUFF_LEN];

	/*HUPU_UINT8 action_type;*/
	switch (command_id)
	{
	case SYS_WEBUI_ACCESS_MODE:
        Ret_doc = nac_system_parse_access_mode(tmpdoc, command_id);
        break;

	case SYS_WEBUI_REDIRECT_URL:
		Ret_doc = nac_xml_parse_redirect_url(tmpdoc, command_id);
		break;

	case SYS_WEBUI_VLANTAG_MAP:
		Ret_doc = nac_xml_parse_vlantag_map(tmpdoc, command_id, &deal_action);
		break;

    case SYS_WEBUI_USER_AUTH:
        Ret_doc =  nac_sys_parse_user_xml(tmpdoc, command_id);
        break;

    case SYS_WEBUI_NETAPP_CHECK:
		Ret_doc = nac_sys_parse_netapp_config(tmpdoc, command_id);
        break;

    case SYS_WEBUI_EXCEPT_TERMINAL: //105
        Ret_doc = nac_system_parse_iprange_policy_xml(tmpdoc, command_id, NAC_APP_EXCEPT_TERMINAL, "exceptTerminal");
		break;

    case SYS_WEBUI_EXCEPT_SERVER: //106
        Ret_doc = nac_system_parse_iprange_policy_xml(tmpdoc, command_id, NAC_APP_EXCEPT_SERVER, "exceptServer");
        break;

    case SYS_WEBUI_EXCEPT_DOMAIN://107
        Ret_doc =  nac_system_parse_domain_policy_xml(tmpdoc, command_id,  NAC_APP_EXCEPT_DOMAIN, "exceptDomain");
		break;

    //case SYS_WEBUI_NAT_DETECT: //108

    case SYS_WEBUI_DEAL_SYS_CONFIG: //109
        Ret_doc = nac_sys_parse_deal_sys_config_xml(tmpdoc, command_id, &deal_action);
        break;

    case SYS_WEBUI_GET_HARDWARE_ID: //110
        Ret_doc = nac_sys_parse_get_hardwareId_xml(tmpdoc, command_id);
        break;

    case SYS_WEBUI_SET_IFCONFIG: //111
        Ret_doc = nac_sys_parse_net_device(tmpdoc, command_id);
        break;

    case SYS_WEBUI_SET_GATEWAY: //112
        Ret_doc = nac_sys_parse_net_gateway(tmpdoc, command_id);
        break;

    case SYS_WEBUI_SET_DNS: //113
        Ret_doc = nac_sys_parse_net_dnserver(tmpdoc, command_id);
        break;

    case SYS_WEBUI_SHUT_OR_BOOT: //114
        Ret_doc = nac_sys_parse_shut_or_boot(tmpdoc, command_id, &deal_action);
        break;

    case SYS_WEBUI_PBR_SET_ONEIN_ONEOUT: //115
        Ret_doc = nac_sys_parse_pbr_advance_setup(tmpdoc, command_id);
        break;

    case SYS_WEBUI_PBR_GET_NEXTHOP_MAC: //116
        Ret_doc = nac_sys_parse_pbr_get_nexthop_mac(tmpdoc, command_id);
        break;

	case SYS_WEBUI_GET_CONTROLLER_LINK_STATUS: //117
		//Ret_doc = nac_sys_parse_get_controller_link_status(tmpdoc, command_id);
		Ret_doc = nac_sys_parse_set_remote_server_info(tmpdoc, command_id);
		break;

	case SYS_WEBUI_SET_SAFE_ZONE: //118
        Ret_doc = nac_system_parse_iprange_policy_xml(tmpdoc, command_id, NAC_APP_SAFE_IPZONE, "safeIpzone");
        break;

	case SYS_WEBUI_SET_ISOLATE_IPZONE: //119
        Ret_doc = nac_system_parse_iprange_policy_xml(tmpdoc, command_id, NAC_APP_ISOLATE_IPZONE, "isolateIpzone");
        break;

	case SYS_WEBUI_SET_ISOLATE_DOMAINZONE: //120
        Ret_doc = nac_system_parse_domain_policy_xml(tmpdoc, command_id,  NAC_APP_ISOLATE_DOMAIN, "isolateDomainzone");
        break;

	case SYS_WEBUI_SET_SYS_TIME: //121
		Ret_doc = nac_sys_parse_set_systime_xml(tmpdoc, command_id);
		break;

	case SYS_WEBUI_GET_SYS_STATUS: //122
		Ret_doc = nac_sys_parse_get_sys_status_xml(tmpdoc, command_id);
		break;

	case SYS_WEBUI_SET_SYS_LANG:  //123
		Ret_doc = nac_sys_parse_set_system_language(tmpdoc, command_id);
		break;

	case SYS_WEBUI_USER_NETAPP_STATUS: //124
		Ret_doc = nac_sys_parse_get_user_netapp_status(tmpdoc, command_id);
		break;

	case SYS_WEBUI_SET_SWITCH_CONTROL: //125
		Ret_doc = nac_sys_parse_set_switch_control(tmpdoc,	command_id);
		break;

	case SYS_WEBUI_SET_ARP_MONITOR_PORT: //126
		Ret_doc = nac_sys_parse_set_arp_monitor(tmpdoc, command_id);
		break;

	case SYS_WEBUI_DEAL_LICENSE_INFO:  //127
		Ret_doc = nac_sys_parse_deal_license_info(tmpdoc, command_id);
		break;

	case SYS_WEBUI_SET_ASC_ENABLE_FLAG: //128
		Ret_doc = nac_sys_parse_set_asc_enable_flag(tmpdoc, command_id);
		break;

	case SYS_WEBUI_ADVANCED_DEBUG_SWITCH: //129
		Ret_doc = nac_sys_parse_debug_switch(tmpdoc, command_id);
		break;

	case SYS_WEBUI_WARN_LOG_CONFIG: //130
		Ret_doc = nac_sys_parse_warn_log_config(tmpdoc, command_id);
		break;

	case SYS_WEBUI_ESCAPE_ENABLE_FLAG: //132
		Ret_doc = nac_sys_parse_escape_enable_flag(tmpdoc, command_id, &deal_action);
        send_redis_pub_command("escape_status");
		break;
	case SYS_WEBUI_NAT_MANAGE_CONFIG://134
		Ret_doc = nac_system_parse_nat_manage_config(tmpdoc, command_id);
		break;
	case SYS_WEBUI_NAT_MANAGE_LIST: //135
		Ret_doc = nac_system_parse_nat_manage_list(tmpdoc, command_id);
		break;
    case SYS_WEBUI_EXCEPTAPP_CONFIG: //136
		Ret_doc = nac_system_parse_exceptapp_config(tmpdoc, command_id);
		break;
	case SYS_WEBUI_DHCP_MANAGE_CONFIG: //137
		Ret_doc = nac_system_parse_dhcp_manage_config(tmpdoc, command_id);
		break;
    case SYS_WEBUI_HA_BACKUP_CONFIG: //138
		Ret_doc = nac_system_parse_ha_backup_config(tmpdoc, command_id);
        break;
/*
    case SYS_WEBUI_HA_BACKUP_SYNC:  //139
        Ret_doc = nac_system_parse_ha_backup_sync(tmpdoc, command_id);
        break;
*/
    case SYS_WEBUI_EXCEPT_MAC: //141
        Ret_doc = nac_system_parse_except_mac_config(tmpdoc, command_id, NAC_APP_EXCEPT_MAC, "exceptMac");
        break;
    case SYS_WEBUI_DEBUG_CONFIG: //142
        Ret_doc = nac_system_parse_debug_config(tmpdoc, command_id);
        break;
    case SYS_WEBUI_NET_TRAFFIC: //143
    	Ret_doc = nac_system_parse_net_traffic(tmpdoc, command_id);
    	break;
    case SYS_WEBUI_OS_CHECK_CONFIG://144
        Ret_doc = nac_system_parse_os_check(tmpdoc, command_id);
        break;
    default:
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid command_id\n", __FUNCTION__);
        nac_free_xmlDoc(tmpdoc);
        break;

	};

    if (Ret_doc != NULL)
    {
        nac_sys_send_xmldoc_to_webserver(sock_fd, Ret_doc, command_id);
        if (command_id == SYS_WEBUI_VLANTAG_MAP && deal_action >= NAC_ADD)
        {
            send_redis_pub_command("vlan_map");
        }

		if (command_id == SYS_WEBUI_ESCAPE_ENABLE_FLAG
			&& deal_action == NAC_ADD)
		{
			memset(escape_tmp_buf, '\0', sizeof(escape_tmp_buf));
			nac_system_pack_escape_reason(HUPU_FALSE, escape_tmp_buf, &g_asc_running_mode);

			if (g_asc_escape_enable_flag == HUPU_DISABLE)
			{
				g_asc_running_mode = ASC_NORMAL_MODE;
			}

			if (sock_fd > 0)
			{
				nac_system_upload_escape_msg(sock_fd, escape_tmp_buf);
			}
		}

		if (command_id == SYS_WEBUI_DEAL_SYS_CONFIG)
		{
			if (deal_action == NAC_RESET_SYS_CONFIG)
			{
				if (gst_nac_warn_config_status.factory == 1)
				{
					nac_system_send_warn_info_to_server(gi_link_fd, NAC_FACTORY_WARN, 0);
				}
				nac_sys_reset_to_factory_config();
			}
			else if (deal_action == NAC_INPUT_SYS_CONFIG)
			{

        		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->begin-->nac_sys_update_current_system_config\n", __FUNCTION__);
				nac_sys_update_current_system_config();
				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->end-->nac_sys_update_current_system_config\n", __FUNCTION__);
			}

		}
        else if (command_id == SYS_WEBUI_SHUT_OR_BOOT)
        {
            if (deal_action == SYS_REBOOT)
            {
            	if (gst_nac_warn_config_status.reboot == 1)
            	{
            		nac_system_send_warn_info_to_server(gi_link_fd, NAC_REBOOT_WARN, 0);
            	}
				sleep(3);
                nac_exec_system("sync && reboot");
            }
            else if (deal_action == SYS_SHUTDOWN)
            {
            	if (gst_nac_warn_config_status.shutdown == 1)
            	{
            		nac_system_send_warn_info_to_server(gi_link_fd, NAC_SHUTDOWN_WARN, 0);
            	}
				sleep(3);
                nac_exec_system("sync && shutdown -h now");
            }
        }
    }

	return HUPU_OK;
}
