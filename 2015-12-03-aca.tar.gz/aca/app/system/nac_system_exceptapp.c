/*
 *
 * Part:        nac except app.
 *
 * Author:      cxk
 *
 */

#include "nac_system_exceptapp.h"

static O_EXCEPT_APP except_app;

//get except config data
HUPU_INT32 get_list_exceptapp_value(HUPU_CHAR (*p_list)[MAX_LEN], P_EXCEPT_APP_DATA p_data, HUPU_INT32 num)
{
    HUPU_INT32 i = 0;
    HUPU_INT32 max = num > MAX_ITEM?MAX_ITEM:num;
    for(i=0; i<max; i++)
    {
        HUPU_CHAR *p = (HUPU_CHAR *)&p_list[i];
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "get except list text--value=%s\n",p);
        sscanf(p, "%d;%d;%[a-z];%[0-9.];%[^;]",&p_data[i].status,&p_data[i].port,p_data[i].proto,p_data[i].ip,p_data[i].comment);
        //printf("%d %d %s %s %s\n", p_data[i].status,p_data[i].port,p_data[i].proto,p_data[i].ip,p_data[i].comment);
    }
    return 0;
}

// get except app config data form config file
HUPU_INT32 get_exceptapp_data_form_configure(const HUPU_CHAR *file_path)
{
    HUPU_CHAR buffer[1024*1024] = {0};
    HUPU_CHAR content[1024*10] = {0};
    HUPU_INT32 fd = 0;
    HUPU_CHAR  *p_value = NULL;
    P_EXCEPT_APP p_ex = get_expect_struct_point();
    memset(p_ex, 0, sizeof(O_EXCEPT_APP));
    fd = open(file_path, O_RDONLY);
    read(fd, buffer, 1024*1024);
    close(fd);
    memset(content, 0, sizeof(content));
    if(get_content(buffer, content, "except_app_config") < 0)
        goto GO_EXIT;
    p_value = each_line_search(content,  "enable");
    p_ex->enable = atoi(p_value);
    p_value = each_line_search(content,  "item_num");
    p_ex->num    = atoi(p_value);
    if(p_ex->num == 0)
        goto GO_EXIT;
    P_EXCEPT_APP_DATA pExceptData = (P_EXCEPT_APP_DATA)malloc(p_ex->num * sizeof(O_EXCEPT_APP_DATA));
    p_ex->pData = pExceptData;
    memset(pExceptData, 0, p_ex->num * sizeof(O_EXCEPT_APP_DATA));
    memset(buffer, 0, sizeof(buffer));
    memcpy(buffer, content, sizeof(content));
    memset(content, 0, sizeof(content));
    get_content(buffer, content, "item_list");
    HUPU_CHAR list[MAX_ITEM][MAX_LEN];
    memset(list, 0, sizeof(list));
    get_list(content, list);
    get_list_exceptapp_value(list, pExceptData, p_ex->num);
    nac_system_set_exceptapp_data_to_kernel(p_ex);
    return 0;
    GO_EXIT:
        nac_system_set_exceptapp_data_to_kernel(p_ex);
        return -1;
}

//write except app data to config file
HUPU_INT32 write_exceptapp_data_to_configure(FILE* fp)
{
    P_EXCEPT_APP p_ex = get_expect_struct_point();
    HUPU_CHAR content[1024*10] = {0};
    HUPU_CHAR buffer[512]={0};
    strcat(content, "except_app_config\n{\n");
    sprintf(buffer,"    enable=%d\n    item_num=%d\n", p_ex->enable, p_ex->num);
    strcat(content, buffer);
    if(p_ex->num > 0)
    {
	    strcat(content, "    item_list\n    {\n");
	    HUPU_INT32 i;
	    for(i = 0;i<p_ex->num; i++)
	    {
	        memset(buffer, 0, sizeof(buffer));
	        sprintf(buffer,"        %d;%d;%s;%s;%s\n",p_ex->pData[i].status,p_ex->pData[i].port, \
	        p_ex->pData[i].proto,p_ex->pData[i].ip ,p_ex->pData[i].comment);
	        strcat(content, buffer);
	    }
	    strcat(content, "    }\n");
    }
    strcat(content, "}\n\n");
    fprintf(fp, "%s", content);
    return 0;

}
P_EXCEPT_APP get_expect_struct_point(void)
{
    return &except_app;
}

//flash except config data
HUPU_INT32 nac_sys_flush_except_app_config(void)
{
    except_app.enable = 0;
    except_app.num    = 0;
    if(except_app.pData)
    {
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "----free(pData->pData)----");
        free(except_app.pData);
        except_app.pData = NULL;

    }
    nac_set_data_to_knl(NAC_CMD_PORT_IP_FLUSH, 0, NULL, 0);
    return 0;
}

//returen xml result to web
xmlDocPtr nac_sys_return_exceptapp_result(HUPU_INT32 action_type, P_EXCEPT_APP pData)
{
    xmlDocPtr doc;
    xmlNodePtr root_node;
    HUPU_CHAR cmd_str[256] = {0};
    //HUPU_CHAR nac_send_buffer[SEND_BUFFER_LEN] = "";

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);
    memset(cmd_str, '\0', sizeof(cmd_str));
    sprintf(cmd_str, "%d", (SYS_WEBUI_EXCEPTAPP_CONFIG + Ret_cmd_offset));
    xmlNewChild (root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_str);

    memset(cmd_str, '\0', sizeof(cmd_str));
    sprintf(cmd_str, "%d", action_type);
    xmlNewChild (root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST cmd_str);
    memset(cmd_str, '\0', sizeof(cmd_str));
    sprintf(cmd_str, "%d", pData->enable);
    xmlNewChild (root_node, HUPU_NULL, BAD_CAST "exceptAppSwitch", BAD_CAST cmd_str);
    memset(cmd_str, '\0', sizeof(cmd_str));
    if(action_type == EXCEPT_APP_FLUSH)
    {
        sprintf(cmd_str, "%d", 1);
        xmlNewChild (root_node, HUPU_NULL, BAD_CAST "deleteAllExAppResult", BAD_CAST cmd_str);
        return doc;
    }
    sprintf(cmd_str, "%d", pData->num);
    xmlNewChild (root_node, HUPU_NULL, BAD_CAST "exceptAppItemNum", BAD_CAST cmd_str);
    int i;
    for(i=0; i < pData->num; i++)
    {
        memset(cmd_str, '\0', sizeof(cmd_str));
        if(action_type == 0)
        {
            if(pData->pData[i].status == 1)
                sprintf(cmd_str, "%d;%s;%s;%s",pData->pData[i].port,pData->pData[i].proto,pData->pData[i].ip, pData->pData[i].comment);
        }
        else
        {
            sprintf(cmd_str, "%d;%d;%s;%s;%s", pData->pData[i].status,pData->pData[i].port, pData->pData[i].proto, pData->pData[i].ip,  pData->pData[i].comment);
        }
        xmlNewChild (root_node, HUPU_NULL, BAD_CAST "exceptAppItem", BAD_CAST cmd_str);
    }
    return doc;
}

// parse data from xml that come form web
HUPU_INT32 nac_sys_parse_exceptapp_result(xmlNodePtr cur_node, P_EXCEPT_APP pData, HUPU_UINT8 action_type)
{
    xmlNodePtr node = cur_node;
    HUPU_INT32 num = 0;
    xmlChar   *xml_value;
    for(;node;)
    {
        if (!(xmlStrcmp(node->name, BAD_CAST "exceptAppSwitch")))
        {
            xml_value = xmlNodeGetContent(node);
			pData->enable = atoi((HUPU_CHAR*)xml_value);
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "exceptAppSwitch----%d-- xml_value=%s\n", pData->enable, xml_value);
		    xmlFree(xml_value);
        }

        if (!(xmlStrcmp(node->name, BAD_CAST "exceptAppItem")))
            num++;
        node = node->next;
    }
    pData->num = num;
    if(action_type == EXCEPT_APP_FLUSH)
    {
        if(pData->pData)
        {
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "----free(pData->pData)---- %ld\n", pData->pData);
            free(pData->pData);
            pData->pData = NULL;
        }
        pData->num = 0;
        return 0;
    }
    P_EXCEPT_APP_DATA pExceptData = (P_EXCEPT_APP_DATA)malloc(num * sizeof(O_EXCEPT_APP_DATA));
    memset(pExceptData, 0, num * sizeof(O_EXCEPT_APP_DATA));
    if (pExceptData == NULL)
    {
        return -1;
    }
    HUPU_INT32 i = 0;
    node = cur_node;
    for(i=0;i < num;)
    {
        if (!(xmlStrcmp(node->name, BAD_CAST "exceptAppItem")))
        {
             pExceptData[i].status = 1;
             xml_value = xmlNodeGetContent(node);
             SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "exceptAppItem----%s----\n",xml_value);
             if(strlen((HUPU_CHAR*)xml_value) >= MAX_LEN)
             {
                xml_value[MAX_LEN-1] = '\0';
             }
             sscanf((HUPU_CHAR*)xml_value, "%d;%[a-z];%[0-9.];%[^;]",&pExceptData[i].port,pExceptData[i].proto,pExceptData[i].ip, pExceptData[i].comment);
             SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "port=%d proto=%s ip=%s comment= %s\n",pExceptData[i].port, pExceptData[i].proto, pExceptData[i].ip,pExceptData[i].comment);
             i++;
             xmlFree(xml_value);
        }
        node = node->next;
    }
    if(pData->pData)
    {
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "----free(pData->pData)----%ld\n", pData->pData);
        free(pData->pData);
        pData->pData = NULL;
    }
    pData->pData = pExceptData;
    return 0;

}
//config except app data to kernel
HUPU_INT32 nac_system_set_exceptapp_data_to_kernel(P_EXCEPT_APP pData)
{
    HUPU_INT32 status = 0;
    HUPU_INT32 iRet;
    NAC_KNL_PORT_IP st_port_ip;
    status = nac_set_data_to_knl(NAC_CMD_PORT_IP_FLUSH, 0, NULL, 0);
    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "knl_nat flush--status=%d\n", status);
    int i = 0;
    for(i = 0;i < pData->num && pData->enable == 1 && pData->num != 0; i++)
    {
        memset(&st_port_ip, 0, sizeof(NAC_KNL_PORT_IP));
        if(strcmp(pData->pData[i].ip, "0") == 0)
        {
            st_port_ip.protocol = 0;
        }
        else
        {
            struct in_addr inp;
            if(inet_aton(pData->pData[i].ip, &inp))
            {
                st_port_ip.ip = ntohl((HUPU_UINT32)inet_addr(pData->pData[i].ip));
            }
            else
            {
               pData->pData[i].status = 0;
               continue;
            }
        }
        if(!strcmp(pData->pData[i].proto, "tcp"))
        {
            st_port_ip.protocol = IPPROTO_TCP;
        }
        else if(!strcmp(pData->pData[i].proto, "udp"))
        {
            st_port_ip.protocol = IPPROTO_UDP;
        }
        else
        {
            st_port_ip.protocol = IPPROTO_TCP_UDP;
        }
        if(pData->pData[i].port > 0 && pData->pData[i].port < 65536)
        {
            st_port_ip.port = pData->pData[i].port;
        }
        else
        {
            pData->pData[i].status = 0;
            continue;
        }
        iRet = nac_set_data_to_knl(NAC_CMD_PORT_IP_INS, 0, &st_port_ip, sizeof(NAC_KNL_PORT_IP));
        if (iRet != HUPU_OK)
        {
           SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl--status = %d\n", iRet);
           pData->pData[i].status = 0;
        }

    }
    return status;
}
//except app handle function
xmlDocPtr nac_system_parse_exceptapp_config(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_UINT8 action_type;
    xmlNodePtr cur_node = NULL;
    xmlDocPtr re_doc;
    cur_node = nac_xml_parse_get_action(doc, &action_type);
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "into handle cmd_id = %d action type = %d \n", cmd_id,action_type);
    if(action_type == EXCEPT_APP_SHOW)
    {
        re_doc = nac_sys_return_exceptapp_result(action_type,&except_app);
    }
    else if(action_type == EXCEPT_APP_UPDATE)
    {
       nac_sys_parse_exceptapp_result(cur_node, &except_app, action_type);
       nac_system_set_exceptapp_data_to_kernel(&except_app);
       re_doc =  nac_sys_return_exceptapp_result(action_type, &except_app);
    }
    else if(action_type == EXCEPT_APP_FLUSH)
    {
       nac_sys_parse_exceptapp_result(cur_node, &except_app, action_type);
       nac_system_set_exceptapp_data_to_kernel(&except_app);
       re_doc =  nac_sys_return_exceptapp_result(action_type,&except_app);
    }
    nac_free_xmlDoc(doc);
    return re_doc;
}


