#ifndef NAC_SYSTEM_ASC_REGISTER_H
#define NAC_SYSTEM_ASC_REGISTER_H
#include "nac_system_common_lib.h"
HUPU_INT32 nac_system_send_asc_register_msg_to_server(HUPU_INT32 ui_sock_fd);

#endif
