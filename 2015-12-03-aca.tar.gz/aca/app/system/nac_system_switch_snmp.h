#ifndef NAC_SYSTEM_SWITCH_SNMP_H
#define NAC_SYSTEM_SWITCH_SNMP_H

xmlDocPtr nac_system_test_switch_snmp_control(NAC_SYSTEM_SWITCH* pst_switch);
HUPU_INT32 nac_system_add_switch_snmp_control(NAC_SYSTEM_SWITCH* pst_switch);
HUPU_INT32 nac_system_modify_switch_snmp_control(NAC_SYSTEM_SWITCH* pst_switch);

HUPU_INT32 nac_system_scan_switch_hlist_for_each_snmp(HUPU_UINT32 ui_sock_fd);//for nac_system_main.c
HUPU_VOID nac_system_switch_snmp_walk_thread_enter(HUPU_CHAR *pc_buf);

#endif // end of NAC_SYSTEM_SWITCH_SNMP_H
