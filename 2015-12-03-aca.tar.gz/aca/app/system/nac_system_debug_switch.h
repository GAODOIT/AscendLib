#ifndef NAC_SYSTEM_DEBUG_SWITCH_H
#define NAC_SYSTEM_DEBUG_SWITCH_H

#include "nac_system_common_lib.h"

#define NAC_WARN_CPU		1
#define NAC_WARN_MEM		2
#define NAC_WARN_DISK		4
#define NAC_WARN_REBOOT		8
#define NAC_WARN_SHUTDOWN	16
#define NAC_WARN_FACTORY	32

typedef struct __NAC_SYS_WARN_CONFIG_STRU
{
	HUPU_BOOL 	cpu;
	HUPU_BOOL 	mem;
	HUPU_BOOL 	disk;
	HUPU_BOOL	reboot;
	HUPU_BOOL	shutdown;
	HUPU_BOOL	factory;
}NAC_SYS_WARN_CONFIG_ST;
extern NAC_SYS_WARN_CONFIG_ST gst_nac_warn_config_status;

typedef struct object_warn_value_struct
{
	HUPU_INT32 cpu;
	HUPU_INT32 mem;
	HUPU_INT32 disk;
}OBJECT_WARN_VALUE_ST;
extern OBJECT_WARN_VALUE_ST gst_nac_warn_value;

//tmp
typedef struct object_warn_float_value_struct
{
	HUPU_FLOAT32 cpu;
	HUPU_FLOAT32 mem;
	HUPU_FLOAT32 disk;
}OBJECT_WARN_FLOAT_VALUE_ST;

enum
{
	NAC_CPU_WARN = 0,
	NAC_MEM_WARN = 1,
	NAC_DISK_WARN = 2,
	NAC_START_WARN = 3,
	NAC_SHUTDOWN_WARN = 4,
	NAC_REBOOT_WARN = 5,
	NAC_FACTORY_WARN = 6,
};


HUPU_UINT32 nac_sys_init_warn_config_status(HUPU_VOID);
xmlDocPtr nac_system_parse_debug_config(xmlDocPtr doc, HUPU_UINT16 cmd_id);
xmlDocPtr nac_sys_parse_warn_log_config(xmlDocPtr doc, HUPU_UINT16 cmd_id);
HUPU_INT32 nac_system_check_sys_run_status(HUPU_UINT32 ui_sock_fd);
HUPU_INT32 nac_system_send_warn_info_to_server(HUPU_UINT32 ui_sockfd,
									HUPU_BOOL warn_type, HUPU_UINT32 warn_value);
xmlDocPtr nac_sys_parse_debug_switch(xmlDocPtr doc, HUPU_UINT16 cmd_id);


#endif //endif nac_system_debug_switch.h
