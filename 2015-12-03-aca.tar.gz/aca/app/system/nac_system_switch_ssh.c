#include "nac_precomp.h" //nac_list.h
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_common_lib.h"
#include "nac_system_errorlog.h"
#include "nac_system_switch_main.h"
#include "nac_system_switch_ssh.h"

xmlDocPtr nac_system_test_switch_ssh_control(NAC_SYSTEM_SWITCH* pst_switch)
{
	xmlDocPtr doc = HUPU_NULL;
	return doc;
}

HUPU_INT32 nac_system_add_switch_ssh_control(NAC_SYSTEM_SWITCH* pst_switch)
{
	return HUPU_OK;
}

HUPU_INT32 nac_system_modify_switch_ssh_control(NAC_SYSTEM_SWITCH* pst_switch)
{

	return HUPU_OK;
}




