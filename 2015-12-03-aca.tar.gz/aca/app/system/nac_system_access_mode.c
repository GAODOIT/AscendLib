#include "nac_system_access_mode.h"

/*
knl/nac_knl_policy.h
typedef enum
{
    NAC_MVG_MODE = 1,
    NAC_PBR_MODE,
    NAC_BRIDGE_MODE,
    NAC_8021X_MODE,
    NAC_NULL_MODE,
}NAC_MODE;
*/

/*default app nacmode <nac_knl_policy.h>*/
HUPU_UINT16 asc_access_mode = NAC_PBR_MODE;

HUPU_INT32 convert_access_mode_to_str(char *buffer)
{
    switch (asc_access_mode)
    {
    case NAC_MVG_MODE:
        memcpy(buffer, "mvg", strlen("mvg"));
        break;

    case NAC_PBR_MODE:
        memcpy(buffer, "pbr", strlen("pbr"));
        break;

    case NAC_BRIDGE_MODE:
        memcpy(buffer, "bridge", strlen("bridge"));
        break;

    case NAC_8021X_MODE:
        memcpy(buffer, "8021x", strlen("8021x"));
        break;

    default:
        memcpy(buffer, "NULL", strlen("NULL"));
        break;
    }
    return 0;
}

HUPU_INT32 convert_str_to_access_mode(char *buffer)
{
    HUPU_INT32 iRet;

    if (buffer == NULL)
    {
        return -1;
    }

    if (strstr(buffer, "mvg") != NULL)
    {
        iRet = NAC_MVG_MODE;
    }
    else if (strstr(buffer, "pbr") != NULL)
    {
        iRet = NAC_PBR_MODE;
    }
    else if (strstr(buffer, "bridge") != NULL)
    {
        iRet = NAC_BRIDGE_MODE;
    }
    else if (strstr(buffer, "8021x") != NULL)
    {
        iRet = NAC_8021X_MODE;
    }
    else
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "mode_name = %s err\n", buffer);
        iRet = NAC_NULL_MODE;
    }

    return iRet;
}

HUPU_INT32 nac_system_set_asc_access_mode(HUPU_UINT16 access_mode)
{
	HUPU_INT32 iRet;

    nac_exec_system("/sbin/radiusd stop >/dev/null 2>&1");

	iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_MODE, access_mode, NULL, 0);
	if (iRet != HUPU_OK)
	{
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl-->NAC_CMD_SYS_SET_MODE error, iRet=%d\n", iRet);
		return HUPU_ERR;
	}

    if (access_mode == NAC_8021X_MODE)
    {
        nac_exec_system("/sbin/radiusd start >/dev/null 2>&1");
    }

	nac_app_get_sys_in_and_out_eth(&gst_in_out_eth);
	iRet = nac_app_set_knl_in_and_out_eth(&gst_in_out_eth);
	if (iRet != HUPU_OK)
	{
		return HUPU_ERR;
	}

	nac_sys_net_set_promisc(access_mode, &gst_in_out_eth);

	return HUPU_OK;
}

HUPU_INT32 nac_system_deal_access_mode_setup(HUPU_UINT16 mode)
{
    HUPU_INT32 err = 0;

    if (asc_access_mode != mode)
    {
        nac_app_flush_all_system_config();

        nac_exec_system("/sbin/radiusd stop >/dev/null 2>&1");
        err = nac_set_data_to_knl(NAC_CMD_SYS_SET_MODE, mode, NULL, 0);
        if (err != HUPU_OK)
        {
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl--err = %d\n", err);
            err = NAC_KNL_ERROR_CHANGE_NACMODE_FAIL;
            goto FUNC_EXIT;
        }

        nac_app_get_sys_in_and_out_eth(&gst_in_out_eth);
        nac_app_set_knl_in_and_out_eth(&gst_in_out_eth);
        nac_sys_net_set_promisc(mode, &gst_in_out_eth);

        nac_sys_set_knl_redirect_manager_ip(&gst_redirect_manager_ip);
        nac_sys_init_safe_ipzone_config(nac_sys_cfg_file);
        asc_access_mode = mode;

        if (asc_access_mode == NAC_8021X_MODE)
        {
            nac_exec_system("/sbin/radiusd start >/dev/null 2>&1");
        }

        send_redis_pub_command("nac_mode");
    }
FUNC_EXIT:
    return err;
}



static xmlDocPtr nac_sys_return_access_mode_setup_result(HUPU_INT32 action_type, HUPU_UINT32 errorid)
{
	xmlDocPtr  doc;
    xmlNodePtr root_node;
    HUPU_CHAR cmd_str[256] = {0};
    create_xml_doc(&doc, &root_node);
   	if(action_type == NAC_SHOW)
	{
        insert_number_xml_new_child(root_node, "commandID", (SYS_WEBUI_ACCESS_MODE + Ret_cmd_offset));
        insert_number_xml_new_child(root_node, "actionType", action_type);
        insert_number_xml_new_child(root_node, "accessMode", asc_access_mode);
	}
	else if (action_type == NAC_ADD)
	{
        insert_number_xml_new_child(root_node, "commandID", (SYS_WEBUI_ACCESS_MODE + Ret_cmd_offset));
        insert_number_xml_new_child(root_node, "actionType", action_type);
        if (errorid == 0)
        {
            insert_number_xml_new_child(root_node, "result", 1); //result=1-->success;result=0-->fault
        }
        else if (errorid > 0)
        {
            sprintf(cmd_str, "0;%s", nac_sys_get_error_log(errorid));
            insert_string_xml_new_child(root_node, "result", cmd_str);
        }
        insert_number_xml_new_child(root_node, "accessMode", asc_access_mode);
	}
	return doc;
}


static HUPU_INT32 nac_sys_parse_access_mode_result(xmlNodePtr cur_node, HUPU_UINT16 *pdata, HUPU_UINT8 action_type)
{
    xmlNodePtr node = cur_node;
    xmlChar *xml_value;
    //xmlChar *xml_attr;
    for(;node;)
    {
        if (!(xmlStrcmp(node->name, BAD_CAST "accessMode")))
        {
            xml_value = xmlNodeGetContent(node);
			*pdata = atoi((HUPU_CHAR*)xml_value);
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "OSCheckSwit----%d--xml_value=%s\n", pdata, xml_value);
		    xmlFree(xml_value);
            break;
        }
        node = node->next;
    }
    return 0;
}

xmlDocPtr nac_system_parse_access_mode(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_INT32 error_id;
    HUPU_UINT16 asc_mode_tmp;
    xmlDocPtr re_doc;
    HUPU_UINT8 action_type;
    xmlNodePtr cur_node = NULL;
    cur_node = nac_xml_parse_get_action(doc, &action_type);
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "into handle cmd_id = %d action type = %d \n", cmd_id, action_type);

    error_id = 0;
    if(action_type == NAC_SHOW)
    {
        re_doc = nac_sys_return_access_mode_setup_result(action_type, error_id);

    }
    else if (action_type == NAC_ADD)
    {
        asc_mode_tmp = 0;
        nac_sys_parse_access_mode_result(cur_node, &asc_mode_tmp, action_type);
        error_id = nac_system_deal_access_mode_setup(asc_mode_tmp);
        re_doc = nac_sys_return_access_mode_setup_result(action_type, error_id);
    }
    nac_free_xmlDoc(doc);
    return re_doc;
}

//write access_mode to config file
HUPU_INT32 nac_sys_write_access_mode_to_configure(FILE* fp)
{
    HUPU_CHAR content[1024*10] = {0};
    HUPU_CHAR buffer[512]={0};
    HUPU_CHAR tmp_buffer[16] ={0};
    strcat(content, "access_mode_config\n{\n");
    convert_access_mode_to_str(tmp_buffer);
    sprintf(buffer,"    access_mode=%s\n", tmp_buffer);
    strcat(content, buffer);
    strcat(content, "}\n\n");
    fprintf(fp, "%s", content);
    return 0;
}

HUPU_INT32 nac_sys_get_access_mode_from_configure(const HUPU_CHAR *file_path)
{
    HUPU_INT32 iRet;
    HUPU_CHAR buffer[1024*1024] = {0};
    HUPU_CHAR content[1024*10] = {0};
    HUPU_INT32 fd = 0;
    HUPU_CHAR  *p_value = NULL;

    fd = open(file_path, O_RDONLY);
    read(fd, buffer, 1024*1024);
    close(fd);

    memset(content, 0, sizeof(content));
    if(get_content(buffer, content, "access_mode_config") < 0)
    {
        goto GO_EXIT;
    }

    p_value = each_line_search(content, "access_mode");
    if (strlen(p_value) <= 0)
    {
        goto GO_EXIT;
    }

    iRet = convert_str_to_access_mode(p_value);
    if (iRet == -1)
    {
        goto GO_EXIT;
    }

    asc_access_mode = iRet;
    nac_system_set_asc_access_mode(asc_access_mode);

    return 0;
    GO_EXIT:
        return -1;
}

