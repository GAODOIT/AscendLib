#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_errorlog.h"
#include "nac_system_xml.h"
#include "nac_system_net.h"
#include "nac_system_arp_monitor.h"
#include <pcap.h>

struct nac_hlist_head nac_device_hlist_by_mac[NAC_DEVICE_MAC_HASH_SIZE];
struct arp_monitor_config_struct gst_arp_monitor_config;
pcap_t *nac_pt = HUPU_NULL;
struct bpf_program nac_bpf_fp;
HUPU_CHAR nac_filter_rule[] = "arp"; //"dst 10.10.2.76 and tcp";

pthread_mutex_t nac_sys_device_info_mutex = PTHREAD_MUTEX_INITIALIZER;

HUPU_VOID nac_system_device_info_lock(HUPU_VOID)
{
	pthread_mutex_lock(&nac_sys_device_info_mutex);
}

HUPU_VOID nac_system_device_info_unlock(HUPU_VOID)
{
	pthread_mutex_unlock(&nac_sys_device_info_mutex);
}

static inline HUPU_UINT32 nac_system_device_get_hash_by_ip(HUPU_UINT32 ip)
{
	return ip&(NAC_DEVICE_IP_HASH_SIZE - 1);
}

HUPU_UINT32 nac_system_device_get_hash_by_mac(char *mac)
{
	unsigned long x;
	x = mac[0];
	x = (x << 2) ^ mac[1];
	x = (x << 2) ^ mac[2];
	x = (x << 2) ^ mac[3];
	x = (x << 2) ^ mac[4];
	x = (x << 2) ^ mac[5];

	x ^= x >> 8;

	return (x & (NAC_DEVICE_MAC_HASH_SIZE - 1));
}

void nac_system_init_device_info_hlist(void)
{
	HUPU_INT32 i;

	for(i = 0; i < NAC_DEVICE_MAC_HASH_SIZE; i++)
	{
		NAC_INIT_HLIST_HEAD(&nac_device_hlist_by_mac[i]);
	}

	pthread_mutex_init(&nac_sys_device_info_mutex, HUPU_NULL);

	return;
}

HUPU_INT32 nac_system_device_info_insert(NAC_SYS_DEVICE_INFO_ST* pst_device_st)
{
	HUPU_UINT32 hash_mac;
	NAC_SYS_DEVICE_INFO_ST *pst_device_tmp;

	hash_mac = nac_system_device_get_hash_by_mac(pst_device_st->mac);

	pst_device_tmp = (NAC_SYS_DEVICE_INFO_ST*)malloc(sizeof(NAC_SYS_DEVICE_INFO_ST));
	if (pst_device_tmp == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->malloc error\n", __FUNCTION__);
		return HUPU_ERR;
	}

	memset(pst_device_tmp, '\0', sizeof(NAC_SYS_DEVICE_INFO_ST));
	memcpy(pst_device_tmp, pst_device_st, sizeof(NAC_SYS_DEVICE_INFO_ST));

	nac_system_device_info_lock();
	nac_hlist_add_head(&pst_device_tmp->mac_node, &nac_device_hlist_by_mac[hash_mac]);
	nac_system_device_info_unlock();

	/*
	time_t current_time = 0;
	time(&current_time);
	pst_device_tmp->last_time = (HUPU_ULONG32)current_time;
	pst_device_tmp->ip = pst_device_st->ip;
	memcpy(pst_device_tmp->mac, pst_device_st->mac, ETH_ALEN);
	pst_device_tmp->send_status = HUPU_FALSE;
	*/

	return HUPU_OK;
}

static HUPU_INT32 nac_system_device_info_update(NAC_SYS_DEVICE_INFO_ST* pst_device_st)
{
	HUPU_UINT32 hash;
	HUPU_UINT16 data_type;
	struct	nac_hlist_node *pos, *n;
	NAC_SYS_DEVICE_INFO_ST *u = HUPU_NULL;
	NAC_SYS_DEVICE_INFO_ST *pst_device_tmp = HUPU_NULL;

	hash = nac_system_device_get_hash_by_mac(pst_device_st->mac);

	nac_system_device_info_lock();
	nac_hlist_for_each_entry_safe(u, pos, n, &nac_device_hlist_by_mac[hash], mac_node)
	{
        if(memcmp(u->mac, pst_device_st->mac, ETH_ALEN) == HUPU_OK)
        {
			u->ip 		 = pst_device_st->ip;
			u->last_time = pst_device_st->last_time;

			data_type = HUPU_TRUE;
			SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
						"%s-->hlist_for_each-->%02X-%02X-%02X-%02X-%02X-%02X, u=%p, hash = %d\n",
						__FUNCTION__, MAC_FORMAT(pst_device_st->mac), u, hash);

			nac_system_device_info_unlock();
			goto FOUND;
        }
	}
	nac_system_device_info_unlock();


	pst_device_tmp = (NAC_SYS_DEVICE_INFO_ST*)malloc(sizeof(NAC_SYS_DEVICE_INFO_ST));
	if (pst_device_tmp == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->malloc error\n", __FUNCTION__);
		return HUPU_ERR;
	}
	memset(pst_device_tmp, '\0', sizeof(NAC_SYS_DEVICE_INFO_ST));
	memcpy(pst_device_tmp, pst_device_st, sizeof(NAC_SYS_DEVICE_INFO_ST));

	nac_system_device_info_lock();
	data_type = HUPU_FALSE;
	nac_hlist_add_head(&pst_device_tmp->mac_node, &nac_device_hlist_by_mac[hash]);
	nac_system_device_info_unlock();

FOUND:
	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
				"%s-->%02X-%02X-%02X-%02X-%02X-%02X, hash = %d, u = %p-->%s.\n",
				__FUNCTION__, MAC_FORMAT(pst_device_st->mac), hash, u,
				(data_type > 0)?("update"):("insert"));

	return HUPU_OK;
}

HUPU_VOID nac_system_free_device_info_hlist_time_out_node(HUPU_UINT32 ageing_time_interval)
{
    HUPU_UINT32 hash;
    time_t now_time;
    struct nac_hlist_node *pos, *n;
    NAC_SYS_DEVICE_INFO_ST *u = HUPU_NULL;

    time(&now_time);
    nac_system_device_info_lock();
    for(hash = 0; hash < NAC_DEVICE_MAC_HASH_SIZE; hash++)
    {
        nac_hlist_for_each_entry_safe(u, pos, n, &nac_device_hlist_by_mac[hash], mac_node)
        {
            if (now_time - u->last_time >= ageing_time_interval)
            {
                nac_hlist_del(&u->mac_node);
                free(u);
            }
        }
    }
    nac_system_device_info_unlock();

    return;
}

HUPU_VOID nac_system_free_device_info_hlist(HUPU_VOID)
{
    HUPU_UINT32 hash;
    struct nac_hlist_node *pos, *n;
    NAC_SYS_DEVICE_INFO_ST *u = HUPU_NULL;

    nac_system_device_info_lock();
    for(hash = 0; hash < NAC_DEVICE_MAC_HASH_SIZE; hash++)
    {
        nac_hlist_for_each_entry_safe(u, pos, n, &nac_device_hlist_by_mac[hash], mac_node)
        {
			nac_hlist_del(&u->mac_node);
			free(u);
        }
    }
    nac_system_device_info_unlock();

    return;
}

static HUPU_INT32 nac_system_send_device_info_sum(HUPU_VOID)
{
	HUPU_UINT32 hash, sum;
	struct nac_hlist_node *pos, *n;
	NAC_SYS_DEVICE_INFO_ST *u = HUPU_NULL;

	sum = 0;
	nac_system_device_info_lock();
	for(hash = 0; hash < NAC_DEVICE_MAC_HASH_SIZE; hash++)
	{
		nac_hlist_for_each_entry_safe(u, pos, n, &nac_device_hlist_by_mac[hash], mac_node)
		{
			if (u->send_status == HUPU_FALSE)
			{
				sum = sum + 1;
			}
		}
	}
	nac_system_device_info_unlock();

	return sum;
}

HUPU_VOID __nac_system_show_device_info_hlist(HUPU_VOID)
{
	HUPU_UINT32 hash, count;
    struct nac_hlist_node *pos, *n;
    NAC_SYS_DEVICE_INFO_ST *u = HUPU_NULL;

	count = 0;
    nac_system_device_info_lock();
    for(hash = 0; hash < NAC_DEVICE_MAC_HASH_SIZE; hash++)
    {
        nac_hlist_for_each_entry_safe(u, pos, n, &nac_device_hlist_by_mac[hash], mac_node)
        {
			SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
			"%s-->device_info_hlist-->%u.%u.%u.%u--%02X-%02X-%02X-%02X-%02X-%02X--%d--%d--%ld\n",
            __FUNCTION__, LIPQUAD(u->ip), MAC_FORMAT(u->mac), u->vlan_tag, u->send_status, u->last_time);
			count = count + 1;
        }
    }
    nac_system_device_info_unlock();

	if (count == 0)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_device_hlist_by_mac is empty\n", __FUNCTION__);
	}
	return;

}


HUPU_INT32 nac_system_arp_monitor_arp_table_to_server(HUPU_UINT32 ui_sockfd)
{
	HUPU_INT32 iRet;
	xmlDocPtr doc;
    xmlNodePtr root_node;
	HUPU_INT16 manager_ifindex;
	HUPU_CHAR controller_mac[18] = "";

	HUPU_CHAR get_buffer[SEND_BUFFER_LEN] = "";
	HUPU_UINT16 command_id = SYS_WEBUI_ASC_IMPORT_DEVICE_INFO;
	HUPU_CHAR cmd_buffer[IP_STR_LEN]  = "";

	HUPU_UINT32 hash;
	struct nac_hlist_node *pos, *n;
	NAC_SYS_DEVICE_INFO_ST *u = HUPU_NULL;

	iRet = nac_system_send_device_info_sum();
	if (iRet == HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_system_send_device_info_sum= 0\n", __FUNCTION__);
		return HUPU_OK;
	}
	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_system_send_device_info_sum= %d\n", __FUNCTION__, iRet);

	doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

	sprintf(cmd_buffer, "%d", command_id);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_buffer);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "1");

	manager_ifindex = nac_app_get_eth0_ifindex();
    nac_get_netdev_mac(nac_sys_ifname[manager_ifindex], controller_mac, sizeof(controller_mac));
	xmlNewChild(root_node, HUPU_NULL, BAD_CAST "ascMac", BAD_CAST controller_mac);

	nac_system_device_info_lock();
	for(hash = 0; hash < NAC_DEVICE_MAC_HASH_SIZE; hash++)
	{
		nac_hlist_for_each_entry_safe(u, pos, n, &nac_device_hlist_by_mac[hash], mac_node)
		{
			memset(get_buffer, '\0', sizeof(get_buffer));
			sprintf(get_buffer, "%u.%u.%u.%u;%02X:%02X:%02X:%02X:%02X:%02X;%d",
					LIPQUAD(u->ip), MAC_FORMAT(u->mac), u->vlan_tag);
			u->send_status = HUPU_TRUE;
			xmlNewChild(root_node, HUPU_NULL, BAD_CAST "arpTable", BAD_CAST get_buffer);
		}
	}
	nac_system_device_info_unlock();

	if (ui_sockfd > 0)
    {
       	iRet = nac_sys_send_xmldoc_to_webserver(ui_sockfd, doc, command_id);
    }
    else
    {
        nac_free_xmlDoc(doc);
    }

	return HUPU_OK;
}

static void nac_pcap_analyse_packet(unsigned char *arg,
									const struct pcap_pkthdr *pkthdr,
									const unsigned char *packet)
{
	unsigned short vlan_id = 0;
	char ip_str_tmp[IP_STR_LEN] = "";
	time_t current_time = 0;
	NAC_SYS_DEVICE_INFO_ST device_info_tmp;

	struct nac_ethhdr   *pst_ethhdr = NULL;
	struct nac_vlan_hdr *pst_vlan_hdr = NULL;
	struct nac_arphdr	*pst_arphdr	= NULL;

	pst_ethhdr = (struct nac_ethhdr*)packet;

	/*
	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS,
				"%s--len=%d--eth_proto=0x%04x--src_mac=%02x-%02x-%02x-%02x-%02x-%02x-->dst_mac=%02x-%02x-%02x-%02x-%02x-%02x\n",
				__FUNCTION__, pkthdr->len, ntohs(pst_ethhdr->h_proto), MAC_FORMAT(pst_ethhdr->h_source), MAC_FORMAT(pst_ethhdr->h_dest));
	*/

	memset(&device_info_tmp, '\0', sizeof(NAC_SYS_DEVICE_INFO_ST));

	switch(ntohs(pst_ethhdr->h_proto))
	{
	case 0x0806://ETH_P_ARP
		pst_arphdr = (struct nac_arphdr*)(pst_ethhdr->eth_payload);
		break;

	case 0x8100://ETH_P_8021Q:
		pst_vlan_hdr = (struct nac_vlan_hdr*)(pst_ethhdr->eth_payload);
		vlan_id = ntohs(pst_vlan_hdr->h_vlan_TCI)&NAC_VLAN_VID_MASK;
		if (ntohs(pst_vlan_hdr->h_vlan_encapsulated_proto) == 0x0806)
		{
			pst_arphdr = (struct nac_arphdr*)(pst_vlan_hdr->vlan_payload);
		}
		break;

	default:
		break;
	}

	if (pst_arphdr != NULL && ntohs(pst_arphdr->ar_op) == NAC_ARPOP_REPLY)
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->%04x-->%d-->%02x-%02x-%02x-%02x-%02x-%02x-->%u.%u.%u.%u--end.\n",
				__FUNCTION__, ntohs(pst_arphdr->ar_op), vlan_id, MAC_FORMAT(pst_arphdr->ar_tha),
				pst_arphdr->ar_tip[0], pst_arphdr->ar_tip[1], pst_arphdr->ar_tip[2], pst_arphdr->ar_tip[3]);

		if (pst_arphdr->ar_tha[2] == 0x00 && pst_arphdr->ar_tha[3] == 0x00
			&& pst_arphdr->ar_tha[4] == 0x00 && pst_arphdr->ar_tha[5] == 0x00)
		{
			return;
		}
		else if (pst_arphdr->ar_tha[2] == 0xFF && pst_arphdr->ar_tha[3] == 0xFF
			&& pst_arphdr->ar_tha[4] == 0xFF && pst_arphdr->ar_tha[5] == 0xFF)

		{
			return;
		}
		else
		{
			sprintf(ip_str_tmp, "%u.%u.%u.%u", pst_arphdr->ar_tip[0],
					pst_arphdr->ar_tip[1], pst_arphdr->ar_tip[2],
					pst_arphdr->ar_tip[3]);

			device_info_tmp.ip  = inet_network(ip_str_tmp);//host_byte;
			memcpy(device_info_tmp.mac, pst_arphdr->ar_tha, ETH_ALEN);
			device_info_tmp.send_status = HUPU_FALSE;
			time(&current_time);
			device_info_tmp.last_time = (HUPU_ULONG32)current_time;
			device_info_tmp.vlan_tag  = vlan_id;
			nac_system_device_info_update(&device_info_tmp);
		}
	}

	return;
}

HUPU_VOID nac_system_free_dev_pcap_t(HUPU_VOID)
{
	if (nac_pt != HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->pcap_breakloop pcap_handle.\n", __FUNCTION__);
		pcap_breakloop(nac_pt);
	}

	return;
}

HUPU_VOID *nac_system_arp_monitor_thread_enter(HUPU_VOID *arg)
{
	HUPU_INT32 iRet;
	HUPU_CHAR errbuf[PCAP_ERRBUF_LEN];
	bpf_u_int32 netp;
	bpf_u_int32 maskp;
	char *dev = NULL;

	while(1)
	{
		sleep(5);

		if (gst_arp_monitor_config.enable != HUPU_TRUE)
		{
			/*SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->arp monitor config status: unable\n", __FUNCTION__);*/
			continue;
		}

		/*
 		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->arp monitor config status: enable\n", __FUNCTION__);
		*/

		dev = gst_arp_monitor_config.monitor_port;
		iRet = nac_app_get_netdev_enable_link_status(dev);
		if (iRet != HUPU_TRUE)
		{
			SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->netdev %s enable or link status: down.\n", __FUNCTION__, dev);
			gst_arp_monitor_config.test_flag = HUPU_FALSE;
			continue;
		}
		else
		{
			SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->netdev %s enable or link status: on.\n", __FUNCTION__, dev);
			gst_arp_monitor_config.test_flag = HUPU_TRUE;
		}

		iRet = pcap_lookupnet(dev, &netp, &maskp, errbuf);
		if(iRet == HUPU_ERR)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->Error to get %s net_ip and net_mask:%s\n",
						__FUNCTION__, dev, errbuf);
			continue;
		}

		/*
 		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->dev=%s-net=%u.%u.%u.%u-mask=%u.%u.%u.%u\n",
					__FUNCTION__, dev, NIPQUAD(netp), NIPQUAD(maskp));
		*/

		/* open capture device */
		nac_pt = pcap_open_live(dev, PCAP_PKT_BUF_LEN, 1, PCAP_SNAP_TIME_OUT, errbuf);
		if(nac_pt == HUPU_NULL)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
						"%s-->open %s error:%s\n", __FUNCTION__, dev, errbuf);
			continue;
		}

		if(pcap_compile(nac_pt, &nac_bpf_fp, nac_filter_rule, 0, maskp) == -1)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
						"%s-->compile filter rule error\n", __FUNCTION__);
			pcap_close(nac_pt);
			nac_pt = HUPU_NULL;
			continue;
		}

		if(pcap_setfilter(nac_pt, &nac_bpf_fp) == -1)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
						"%s-->pcap_setfilter error\n", __FUNCTION__);

			pcap_close(nac_pt);
			nac_pt = HUPU_NULL;
			continue;
		}

		pcap_loop(nac_pt, -1, nac_pcap_analyse_packet, HUPU_NULL);

		pcap_close(nac_pt);
		nac_pt = HUPU_NULL;
	}

	pthread_detach(pthread_self());
	return HUPU_NULL;

}

xmlDocPtr nac_sys_parse_set_arp_monitor(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_INT32 iRet, error_id;
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlChar *enable_szKey;
	xmlChar *cnt_szKey;
    xmlNodePtr cur_node;
    HUPU_UINT8 action_type;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
    switch (action_type)
    {
    case NAC_SHOW:
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_ret_show_result(cmd_id, "arp_monitor");
        break;

	case NAC_ADD:
		while(cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "enable")))
            {
                enable_szKey = xmlNodeGetContent(cur_node);
				gst_arp_monitor_config.enable = atoi((HUPU_CHAR*)enable_szKey);
				xmlFree(enable_szKey);
				if (gst_arp_monitor_config.enable == HUPU_FALSE)
				{
					SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->arp_monitor-->close\n", __FUNCTION__);
					break;
				}
            }
			else if (!(xmlStrcmp(cur_node->name, BAD_CAST "cycleTime")))
			{
				cnt_szKey = xmlNodeGetContent(cur_node);
				gst_arp_monitor_config.cycle_time = atoi((HUPU_CHAR*)cnt_szKey);
				xmlFree(cnt_szKey);
			}
			else if (!(xmlStrcmp(cur_node->name, BAD_CAST "arpMonitor")))
			{
				cnt_szKey = xmlNodeGetContent(cur_node);
				memset(gst_arp_monitor_config.monitor_port, '\0', IFNAMSIZE);
				memset(gst_arp_monitor_config.port_attr, '\0', IFNAMSIZE);
				iRet = sscanf((HUPU_CHAR*)cnt_szKey, "%[^;];%s",
						gst_arp_monitor_config.monitor_port,
						gst_arp_monitor_config.port_attr);

				xmlFree(cnt_szKey);
			}
            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);

		if (gst_arp_monitor_config.enable == HUPU_TRUE)
		{
			gst_arp_monitor_config.test_flag = HUPU_FALSE;
			iRet = nac_app_get_netdev_enable_link_status(gst_arp_monitor_config.monitor_port);

			if (iRet == HUPU_TRUE)
			{
				gst_arp_monitor_config.test_flag = HUPU_TRUE;
			}
			else
			{
				nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->test is unup or unlink\n", __FUNCTION__);
				error_id = NAC_SYS_ERROR_MONITOR_PORT_UNABLE;
				gst_arp_monitor_config.test_flag = HUPU_FALSE;
			}
		}

		//close the last arp_monitor
		nac_system_free_dev_pcap_t();
        nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    case NAC_DEL:
    case NAC_MODIFY:
    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}
