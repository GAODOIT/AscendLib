#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_net.h"
#include "nac_system_vlanmap.h"
#include "nac_system_set_remote_server.h"
#include "nac_system_redirect_manager_ip.h"
#include "nac_system_escape_deal.h"
#include "nac_system_ha_backup.h"
#include "nac_system_access_mode.h"
#include "nac_system_redis_subscribe.h"



/*
const HUPU_CHAR *set_vlan_cmd = "ifconfig %s up && vconfig add %s %d && ifconfig %s.%d 0.0.0.0 up";
const HUPU_CHAR *del_vlan_cmd = "vconfig rem %s.%d";
const HUPU_CHAR *del_dnserver =  "> /etc/resolv.conf";
const HUPU_CHAR *append_dnserver ="echo nameserver %s >> /etc/resolv.conf";
const HUPU_CHAR *add_gateway = "ip route add default via %s";
const HUPU_CHAR *del_gateway = "ip route del default via %s";
const HUPU_CHAR *del_default_gateway = "ip route del default";
const HUPU_CHAR *up_ifconfig_thr = "ifconfig %s %s netmask %s up";
const HUPU_CHAR *up_ifconfig_two = "ifconfig %s %s up";
*/

//ifconfig, gateway and dns
HUPU_UINT16 gi_netdev_count = 0;
HUPU_CHAR nac_sys_ifname[IFMAXNUM][IFNAMSIZE];
NAC_NET_DEVICE g_nac_net_device[IFMAXNUM];
HUPU_CHAR g_manager_mac_addr[ETH_ALEN];
HUPU_CHAR g_default_gateway[IP_STR_LEN] = "";
HUPU_CHAR g_manager_eth_name[IFNAMSIZE] = "";
NAC_DNS_SERVER gst_dns_server;
nac_knl_in_out_eth gst_in_out_eth;

/*-1:error; 1:link up; 0:link down*/
int get_netdev_link_status(const char *if_name)
{
    int sock_fd;
    struct ifreq ifr;
    struct ethtool_value edata;

    edata.cmd = ETHTOOL_GLINK;
    edata.data = 0;

    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, if_name, sizeof(ifr.ifr_name)-1);
    ifr.ifr_data =(char *) &edata;

    if (getuid() != 0)
    {
        fprintf(stderr,"Netlink Status Check Need Root Power.\n");
        return -1;
    }

    if ((sock_fd = socket(AF_INET, SOCK_DGRAM, 0 )) < 0)
    {
        fprintf(stderr, "create sock failed.\n");
        return -1;
    }

    if (ioctl(sock_fd, SIOCETHTOOL, &ifr ) == -1)
    {
        perror("ETHTOOL_GLINK failed");
        close(sock_fd);
        return -1;
    }

    close(sock_fd);
    return edata.data;
}

/*
 unsigned int cpu[4];get_cpu_id(cpu);
 sprintf(cpu_id_str, "%u-%u-%u-%u", cpu[0], cpu[1], cpu[2], cpu[3]);
*/
void get_cpu_id(unsigned int *buf)
{

    unsigned eax,ebx,ecx,edx;

    __asm__ ("pushl %%ebx      \n\t"
             "cpuid            \n\t"
             "movl %%ebx, %1   \n\t"
             "popl %%ebx       \n\t"
             : "=a"(eax), "=r"(ebx), "=c"(ecx), "=d"(edx)
             : "a"(1)//"a"(0)_old
             : "cc");



    buf[0]=eax;
    buf[1]=ebx;
    buf[2]=edx;
    buf[3]=ecx;
}

/*
char buf[35] = ""
0: Get vendor ID
1: Processor Info and Feature Bits,
3: Processor Serial Number
http://en.wikipedia.org/wiki/CPUID
*/
void get_cpu_id_str(char* buf)
{
    unsigned int cpu_id[4];
    unsigned int eax,ebx,ecx,edx;

    __asm__ ("pushl %%ebx      \n\t"
             "cpuid            \n\t"
             "movl %%ebx, %1   \n\t"
             "popl %%ebx       \n\t"
             : "=a"(eax), "=r"(ebx), "=c"(ecx), "=d"(edx)
             : "a"(1)
             : "cc");

    cpu_id[0]=eax;
    cpu_id[1]=ebx;
    cpu_id[2]=edx;
    cpu_id[3]=ecx;

    sprintf(buf, "%08x%08x%08x%08x", cpu_id[0], cpu_id[1], cpu_id[2], cpu_id[3]);
}


/*char mac[32] = "";*/
int nac_get_netdev_mac(const char* ifname, char* mac, int mac_size)
{
    struct ifreq ifreq;
    int sock_fd = 0;
    if (ifname == NULL)
    {
        return -1;
    }

    sock_fd = socket(AF_INET,SOCK_STREAM,0);
    if(sock_fd < 0)
    {
        perror("error sock");
        return -1;
    }

    strcpy(ifreq.ifr_name, ifname);
    if (ioctl(sock_fd,SIOCGIFHWADDR,&ifreq) < 0)
    {
        perror("error ioctl");
        close(sock_fd);
		return -1;
    }

    if (mac_size == ETH_ALEN)
    {
        memcpy(mac, ifreq.ifr_hwaddr.sa_data, ETH_ALEN);
    }
    else
    {
        sprintf(mac, MAC_MYFMT, MAC_FORMAT(ifreq.ifr_hwaddr.sa_data));
    }

	close(sock_fd);

    return 0;
}

HUPU_INT32 nac_app_get_netdev_all_status(HUPU_UINT16 index)
{
	HUPU_UINT8 must_link_flag;

	//update the link_status and enable_status
	nac_app_get_netdev_link_and_enable_status(nac_sys_ifname[index],
		&g_nac_net_device[index].if_link, &g_nac_net_device[index].if_enable);

	if (memcmp(g_nac_net_device[index].if_label, "manager", strlen("manager")) == 0
		|| memcmp(g_nac_net_device[index].if_label, "untrust", strlen("untrust")) == 0)
	{
		must_link_flag = 1;
	}
	else if (memcmp(g_nac_net_device[index].if_label, "trust", strlen("trust")) == 0)
	{
		if (asc_access_mode== NAC_PBR_MODE && nac_pbr_onein_oneout_flag == 0)
		{
			must_link_flag = 0;
		}
		else
		{
			must_link_flag = 1;
		}
	}
	else
	{
		must_link_flag = 0;
	}

	return must_link_flag;
}

HUPU_VOID nac_sys_save_ifconfig(FILE* fp)
{
    HUPU_UINT16 i;
    for (i = 0; i < gi_netdev_count; i++)
    {
        //get eth link_status and enable_status
        nac_app_get_netdev_link_and_enable_status(nac_sys_ifname[i],
       		&g_nac_net_device[i].if_link, &g_nac_net_device[i].if_enable);

        fprintf(fp, "%d %s %s %s %s %d\n", i, nac_sys_ifname[i], g_nac_net_device[i].if_label,
                g_nac_net_device[i].if_ip, g_nac_net_device[i].if_mask, g_nac_net_device[i].if_enable);
    }
}

HUPU_VOID nac_sys_save_ifconfig_status(FILE* fp)
{
    HUPU_UINT16 i, must_link_flag;
    fputs("index name attr ip mask enbale link must_link-------\n", fp);
    for (i = 0; i < gi_netdev_count; i++)
    {
		must_link_flag = nac_app_get_netdev_all_status(i);

        fprintf(fp, "%d\t%s\t%s\t%s\t%s\t%d\t%d\t%d\n", i, nac_sys_ifname[i],
            g_nac_net_device[i].if_label, g_nac_net_device[i].if_ip,
            g_nac_net_device[i].if_mask, g_nac_net_device[i].if_enable,
            g_nac_net_device[i].if_link, must_link_flag);
    }
}

HUPU_INT32 nac_sys_net_set_promisc(NAC_MODE mode, nac_knl_in_out_eth* pst_in_out_eth)
{
	HUPU_CHAR exec_promisc_cmd[80];

    if (mode == NAC_PBR_MODE)
    {
		if (nac_pbr_onein_oneout_flag == 1) // pbr open one_in_one_out flag.
		{
			memset(exec_promisc_cmd, '\0', sizeof(exec_promisc_cmd));
        	sprintf(exec_promisc_cmd, "ifconfig %s up && ifconfig %s promisc",
					pst_in_out_eth->ac_out_eth, pst_in_out_eth->ac_out_eth);
        	nac_exec_system(exec_promisc_cmd);
		}

		memset(exec_promisc_cmd, '\0', sizeof(exec_promisc_cmd));
        sprintf(exec_promisc_cmd, "ifconfig %s up && ifconfig %s promisc",
                pst_in_out_eth->ac_in_eth, pst_in_out_eth->ac_in_eth);
        nac_exec_system(exec_promisc_cmd);
    }
	else
	{
		//if (mode == NAC_MVG_MODE || mode == NAC_BRIDGE_MODE)
		memset(exec_promisc_cmd, '\0', sizeof(exec_promisc_cmd));
		sprintf(exec_promisc_cmd, "ifconfig %s up && ifconfig %s promisc",
				pst_in_out_eth->ac_in_eth, pst_in_out_eth->ac_in_eth);
		nac_exec_system(exec_promisc_cmd);

		memset(exec_promisc_cmd, '\0', sizeof(exec_promisc_cmd));
		sprintf(exec_promisc_cmd, "ifconfig %s up && ifconfig %s promisc",
				pst_in_out_eth->ac_out_eth, pst_in_out_eth->ac_out_eth);
		nac_exec_system(exec_promisc_cmd);
    }

    return HUPU_OK;
}

HUPU_INT32 nac_sys_net_enable_eth_device(HUPU_CHAR *eth_name, HUPU_BOOL flag)
{
	HUPU_CHAR *enable_eth_cmd  = "/sbin/ifconfig %s up";
	HUPU_CHAR *disable_eth_cmd = "/sbin/ifconfig %s down";
	HUPU_CHAR exec_cmd[64] = "";

	if (flag == HUPU_TRUE)
	{
		sprintf(exec_cmd, enable_eth_cmd, eth_name);
	}
	else
	{
		sprintf(exec_cmd, disable_eth_cmd, eth_name);
	}

	nac_exec_system(exec_cmd);
	return HUPU_OK;
}

//get the eth0_mac for asc_id
HUPU_INT32 nac_app_get_eth0_ifindex(HUPU_VOID)
{
	HUPU_INT32 iRet;
	iRet = 0;
	return iRet;
}

/*unfind manager_eth, default return 0(eth0)*/
HUPU_INT32 nac_app_get_manager_ifindex(HUPU_VOID)
{
	HUPU_INT16 i, iRet = 0;

	for (i = 0; i < IFMAXNUM; i++)
	{
		if (strcmp(g_nac_net_device[i].if_label, "manager") == 0)
		{
			iRet = i;
			break;
		}
	}

	return iRet;
}

HUPU_INT32 nac_app_get_special_ifindex(HUPU_CHAR *eth_label)
{
    HUPU_INT16 i, iRet = 0;

    for (i = 0; i < IFMAXNUM; i++)
    {
        if (memcmp(g_nac_net_device[i].if_label, eth_label, strlen(eth_label)) == 0)
        {
            iRet = i;
            break;
        }
    }

    return iRet;
}

HUPU_INT32 nac_app_get_special_ifaddr_by_label(HUPU_CHAR *eth_label, HUPU_CHAR *eth_addr)
{
    HUPU_INT16 i, iRet = 0;

    for (i = 0; i < IFMAXNUM; i++)
    {
        if (memcmp(g_nac_net_device[i].if_label, eth_label, strlen(eth_label)) == 0)
        {
            iRet = i;
            memcpy(eth_addr, g_nac_net_device[i].if_ip, IP_STR_LEN);
            break;
        }
    }

    return iRet;
}


HUPU_INT32 nac_app_clear_if_promisc_mode(HUPU_VOID)
{
	HUPU_UINT16 i;
	HUPU_CHAR* nac_clear_promisc_cmd = "ifconfig %s -promisc";
	HUPU_CHAR exec_cmd[64] = "";

    for (i = 0; i < gi_netdev_count; i++)
    {
		if (strlen(nac_sys_ifname[i]) > 0)
		{
			memset(exec_cmd, '\0', strlen(exec_cmd));
			sprintf(exec_cmd, nac_clear_promisc_cmd, nac_sys_ifname[i]);
			nac_exec_system(exec_cmd);
		}
    }

	return HUPU_OK;
}

HUPU_INT32 nac_app_get_sys_in_and_out_eth(nac_knl_in_out_eth* in_out_eth)
{
	HUPU_UINT16 i;

	memset(in_out_eth, '\0', sizeof(nac_knl_in_out_eth));
	for (i = 0; i < gi_netdev_count; i++)
    {
		if (memcmp(g_nac_net_device[i].if_label, "untrust", strlen("untrust")) == 0)
        {
			strcpy(in_out_eth->ac_in_eth, nac_sys_ifname[i]);
        }
		else if (memcmp(g_nac_net_device[i].if_label, "trust", strlen("trust")) == 0)
		{
			strcpy(in_out_eth->ac_out_eth, nac_sys_ifname[i]);
		}
    }
	return HUPU_OK;
}

HUPU_INT32 nac_app_set_knl_in_and_out_eth(nac_knl_in_out_eth* in_out_eth)
{
	HUPU_INT32 iRet;

	iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_IN_OUT_ETH, 0, in_out_eth, sizeof(nac_knl_in_out_eth));
    if (iRet != HUPU_OK)
    {
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->set knl in_eth and out_eth port error!\n", __FUNCTION__);
        return HUPU_ERR;
    }

	return HUPU_OK;
}

static HUPU_INT32 nac_sys_net_clear_default_gateway(HUPU_VOID)
{
	HUPU_CHAR *del_default_gw_cmd = "ip route del default";
	nac_exec_system(del_default_gw_cmd);
	return HUPU_OK;
}

static HUPU_INT32 nac_system_net_modify_default_gateway(HUPU_CHAR* gateway)
{
	HUPU_INT32 err = 0;
	memset(g_default_gateway, '\0', sizeof(g_default_gateway));
	if (strcmp(gateway, "NULL") != 0)
	{
		memcpy(g_default_gateway, gateway, strlen(gateway));
	}

	return err;
}

static HUPU_INT32 nac_sys_net_add_default_gateway(HUPU_CHAR* gateway, HUPU_CHAR* manager_eth)
{
	HUPU_INT32 iRet;
	HUPU_CHAR *add_gateway_cmd = "ip route add default via %s dev %s";
	HUPU_CHAR  exec_cmd[100];

    if (nac_preg_match_ip(gateway) != HUPU_OK)
	{
		return HUPU_ERR;
    }

	memset(exec_cmd, '\0', sizeof(exec_cmd));
	sprintf(exec_cmd, add_gateway_cmd, gateway, manager_eth);
	iRet = nac_exec_system(exec_cmd);
	if (iRet != HUPU_OK)
	{
		return HUPU_ERR;
	}

	//gateway change
	if (strcmp(g_default_gateway, gateway) != HUPU_OK)
	{
		memset(g_default_gateway, '\0', IP_STR_LEN);
		memcpy(g_default_gateway, gateway, strlen(gateway));
	}

	return HUPU_OK;
}

HUPU_INT32 nac_sys_net_set_default_gateway(HUPU_CHAR* gateway_str)
{
	HUPU_INT32 iRet;
	nac_sys_net_clear_default_gateway();
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->gateway_str=%s-->g_manager_eth_name=%s\n",
                __FUNCTION__, gateway_str, g_manager_eth_name);

    if (strcmp(gateway_str, "NULL") == 0)
    {
        memset(g_default_gateway, '\0', sizeof(g_default_gateway));
        iRet = HUPU_OK;
        goto OUT;
    }

	iRet = nac_sys_net_add_default_gateway(gateway_str, g_manager_eth_name);
OUT:
	return iRet;
}

HUPU_INT32 nac_sys_net_set_dnserver(NAC_DNS_SERVER* dns_server_st)
{
	HUPU_CHAR *del_dnserver =  "> /etc/resolv.conf";
	HUPU_CHAR *append_dnserver ="echo nameserver %s >> /etc/resolv.conf";

	HUPU_CHAR exec_cmd[80];
	memset(&gst_dns_server, '\0', sizeof(NAC_DNS_SERVER));
    memcpy(&gst_dns_server, dns_server_st, sizeof(NAC_DNS_SERVER));

	nac_exec_system(del_dnserver);
	memset(exec_cmd, '\0', sizeof(exec_cmd));

	if (nac_preg_match_ip(gst_dns_server.nameserver1) == HUPU_OK)
	{
		sprintf(exec_cmd, append_dnserver, gst_dns_server.nameserver1);
		nac_exec_system(exec_cmd);
	}

	if (nac_preg_match_ip(gst_dns_server.nameserver2) == HUPU_OK)
	{
		sprintf(exec_cmd, append_dnserver, gst_dns_server.nameserver2);
		nac_exec_system(exec_cmd);
	}

	return HUPU_OK;
}

HUPU_INT32 nac_sys_net_set_ifconfig(NAC_NET_DEVICE* if_st)
{
	HUPU_UINT32 iRet, index;
	HUPU_CHAR *up_ifconfig_thr = "ifconfig %s %s netmask %s up";
	HUPU_CHAR *up_ifconfig_two = "ifconfig %s %s up";
	HUPU_CHAR exec_cmd[80] = "";

	index = if_st->if_index;
    SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->index=%d-->label=%s-->ip=%s-->mask=%s\n",
				__FUNCTION__, if_st->if_index, if_st->if_label, if_st->if_ip, if_st->if_mask);

    /*网卡启动的情况下,(label,ip,mask,enable),(label,ip,enable), (label,enable) 才会设置生效*/
	if (if_st->if_enable == HUPU_TRUE)
	{
		if (nac_preg_match_ip(if_st->if_ip) == HUPU_OK)
		{
			if (nac_preg_match_ip(if_st->if_mask) == HUPU_OK)
			{
				sprintf(exec_cmd, up_ifconfig_thr, nac_sys_ifname[index],
						if_st->if_ip, if_st->if_mask);
			}
			else
			{
				sprintf(exec_cmd, up_ifconfig_two, nac_sys_ifname[index],
						if_st->if_ip);
			}
		}
		else
		{
			sprintf(exec_cmd, up_ifconfig_two, nac_sys_ifname[index], "0.0.0.0");
		}

		g_nac_net_device[index].if_enable = if_st->if_enable;
    }

	iRet = nac_exec_system(exec_cmd);
	if (iRet != HUPU_OK)
	{
    	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_exec_system=%s-->iRet=%d-->errno = %d,error info = %s.\n",
                    __FUNCTION__, exec_cmd, iRet, errno, strerror(errno));

		return HUPU_ERR;
	}

	g_nac_net_device[index].if_index = index;
    memset(g_nac_net_device[index].if_label, '\0', IFNAMSIZE);
    memcpy(g_nac_net_device[index].if_label, if_st->if_label, strlen(if_st->if_label));
    memset(g_nac_net_device[index].if_ip, '\0', IP_STR_LEN);
    memcpy(g_nac_net_device[index].if_ip, if_st->if_ip, strlen(if_st->if_ip));
    memset(g_nac_net_device[index].if_mask, '\0', IP_STR_LEN);

	if (nac_preg_match_ip(if_st->if_mask) == HUPU_OK)
	{
    	memcpy(g_nac_net_device[index].if_mask, if_st->if_mask, strlen(if_st->if_mask));
	}
	else
	{
		nac_sys_get_netdev_netmask(nac_sys_ifname[index], g_nac_net_device[index].if_mask);
	}

	//if eth_manager ip change, update ac_redirect_ip, ac_control_manager_ip;
	if (strcmp(g_nac_net_device[index].if_label, "manager") == 0)
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->manager_eth change from %s to %s.\n",
					__FUNCTION__, g_manager_eth_name, nac_sys_ifname[index]);

		//manager_eth have change
		nac_sys_net_clear_default_gateway();
		if (strcmp(g_manager_eth_name, nac_sys_ifname[index]) != 0)
		{
			nac_sys_net_enable_eth_device(g_manager_eth_name, HUPU_FALSE);
			nac_sys_net_add_default_gateway(g_default_gateway, nac_sys_ifname[index]);
			nac_sys_net_enable_eth_device(g_manager_eth_name, HUPU_TRUE);
		}
		else
		{
			nac_sys_net_add_default_gateway(g_default_gateway, nac_sys_ifname[index]);
		}

		memset(g_manager_eth_name, '\0', sizeof(g_manager_eth_name));
		memcpy(g_manager_eth_name, nac_sys_ifname[index], strlen(nac_sys_ifname[index]));

		// update knl redirect_addr and control_manager_addr;
		if (strcmp(gst_redirect_manager_ip.ac_control_manager_ip, g_nac_net_device[index].if_ip) != HUPU_OK)
		{
			memset(gst_redirect_manager_ip.ac_redirect_ip, '\0', 16);
			memset(gst_redirect_manager_ip.ac_control_manager_ip, '\0', 16);
			memcpy(gst_redirect_manager_ip.ac_redirect_ip, g_nac_net_device[index].if_ip, 15);
			memcpy(gst_redirect_manager_ip.ac_control_manager_ip, g_nac_net_device[index].if_ip, 15);
			nac_system_destroy_tcp_long_sockfd();//manager_address has change, reconnect.
		}
	}
    else if (strcmp(g_nac_net_device[index].if_label, "untrust") == 0)
	{
        memset(gst_redirect_manager_ip.ac_control_untrust_ip, '\0', 16);
        memcpy(gst_redirect_manager_ip.ac_control_untrust_ip, g_nac_net_device[index].if_ip, 15);
    }
    else if (strcmp(g_nac_net_device[index].if_label, "trust") == 0)
    {
        memset(gst_redirect_manager_ip.ac_control_trust_ip, '\0', 16);
        memcpy(gst_redirect_manager_ip.ac_control_trust_ip, g_nac_net_device[index].if_ip, 15);
    }
    return HUPU_OK;
}

xmlDocPtr nac_sys_parse_net_device(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_INT32 iRet, error_id;
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    xmlChar *szKey;
    HUPU_UINT8 action_type;

    NAC_NET_DEVICE st_netdev_tmp;
	nac_knl_in_out_eth in_out_eth_tmp;
	HUPU_UINT32 manager_ip_tmp;
    HUPU_CHAR cmd_str[100] = "";
	HUPU_CHAR gateway_tmp[IP_STR_LEN] = "";
	NAC_DNS_SERVER name_server_st;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
    switch (action_type)
    {
    case NAC_SHOW:
        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_ret_show_result(cmd_id, "if_interface");
        break;

    case NAC_ADD:
        while(cur_node != HUPU_NULL)
        {
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "gateway")))
			{
				szKey = xmlNodeGetContent(cur_node);
				memcpy(gateway_tmp, (HUPU_CHAR*)szKey, strlen((HUPU_CHAR*)szKey));
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->gateway-->%s\n", __FUNCTION__, (HUPU_CHAR*)szKey);
				nac_system_net_modify_default_gateway(gateway_tmp);
				xmlFree(szKey);
			}
			else if (!(xmlStrcmp(cur_node->name, BAD_CAST "nameServer")))
			{
				memset(&name_server_st, '\0', sizeof(NAC_DNS_SERVER));
				szKey = xmlNodeGetContent(cur_node);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->nameServer-->%s\n", __FUNCTION__, (HUPU_CHAR*)szKey);
				if (sscanf((HUPU_CHAR*)szKey, "%[^;];%s",
					name_server_st.nameserver1,
					name_server_st.nameserver2) == 2)
				{
					nac_sys_net_set_dnserver(&name_server_st);
				}
				xmlFree(szKey);
			}
            else if (!(xmlStrcmp(cur_node->name, BAD_CAST "netDevice")))
            {
                memset(&st_netdev_tmp, '\0', sizeof(NAC_NET_DEVICE));
                szKey = xmlNodeGetContent(cur_node);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->netDevice-->%s\n", __FUNCTION__, (HUPU_CHAR*)szKey);
                if (sscanf((HUPU_CHAR*)szKey, "%hd;%[^;];%[^;];%[^;];%hhd",
                    &st_netdev_tmp.if_index, st_netdev_tmp.if_label,
                    st_netdev_tmp.if_ip, st_netdev_tmp.if_mask,
                    &st_netdev_tmp.if_enable) != 5)
                {
                    xmlFree(szKey);
                    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->netdevice format error!\n", __FUNCTION__);
                    error_id = NAC_SYS_ERROR_SET_IFCONFIG_FAIL;
                    break;
                }
                xmlFree(szKey);

                iRet = nac_sys_net_set_ifconfig(&st_netdev_tmp);
                if (iRet == HUPU_ERR)
                {
                    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_net_set_if_interface-->ifconfig error!\n", __FUNCTION__);
					error_id = NAC_SYS_ERROR_SET_IFCONFIG_FAIL;
                    break;
                }

				//if modify asc manager_eth_ip, do this;
				HUPU_UINT16 index = st_netdev_tmp.if_index;
				if (strcmp(st_netdev_tmp.if_label, "manager") == 0)
				{
                    nac_system_update_ha_backup_config("manager_interface", nac_sys_ifname[index]);
                    sprintf(cmd_str, "/nac/script/manager_ip_change.sh %s", st_netdev_tmp.if_ip);
                    nac_exec_system(cmd_str);
					manager_ip_tmp = inet_network(st_netdev_tmp.if_ip);
					nac_sys_set_controller_manager_ip(manager_ip_tmp);
				}
                else if (strcmp(st_netdev_tmp.if_label, "ha") == 0)
                {
                      nac_system_update_ha_backup_config("ha_interface", nac_sys_ifname[index]);
                }

            }
            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);

		//update the knl in_out_forward_eth
		nac_sys_set_knl_redirect_manager_ip(&gst_redirect_manager_ip);
		nac_app_get_sys_in_and_out_eth(&in_out_eth_tmp);
		if (strcmp(gst_in_out_eth.ac_in_eth, in_out_eth_tmp.ac_in_eth) != 0
			|| strcmp(gst_in_out_eth.ac_out_eth, in_out_eth_tmp.ac_out_eth)!= 0)
		{
			nac_app_clear_if_promisc_mode();
			nac_app_get_sys_in_and_out_eth(&gst_in_out_eth);
			nac_app_set_knl_in_and_out_eth(&gst_in_out_eth);
			nac_sys_net_set_promisc(asc_access_mode, &gst_in_out_eth);
		}
		nac_update_escape_check_event();
        send_redis_pub_command("iface_name");
        send_redis_pub_command("iface_status");
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

xmlDocPtr nac_sys_parse_net_gateway(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    xmlChar *szKey;
    HUPU_UINT8 action_type;
    HUPU_INT32 iRet;
    HUPU_INT16 error_id = 0;
    HUPU_CHAR gateway_str[IP_STR_LEN] = "";

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

    switch (action_type)
    {
    case NAC_SHOW:
        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_ret_show_result(cmd_id, "net_gateway");
        break;

    case NAC_ADD:
        while(cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "gateway")))
            {
                szKey = xmlNodeGetContent(cur_node);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->gateway-->%s\n", __FUNCTION__, (HUPU_CHAR*)szKey);
                memcpy(gateway_str, (HUPU_CHAR*)szKey, strlen((HUPU_CHAR*)szKey));
                xmlFree(szKey);
                break;
            }
            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);

        if (strlen(gateway_str) > 0)
        {
            iRet = nac_sys_net_set_default_gateway(gateway_str);
            if (iRet == HUPU_ERR)
            {
                error_id = NAC_SYS_ERROR_SET_GATEWAY_FAIL;
                nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->%s\n", __FUNCTION__, nac_sys_get_error_log(error_id));
            }
        }
        else
        {
            error_id = NAC_SYS_ERROR_SET_GATEWAY_FAIL;
        }
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    case NAC_DEL:
    case NAC_MODIFY:
    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

xmlDocPtr nac_sys_parse_net_dnserver(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_INT32 iRet;
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    xmlChar *szKey;
    HUPU_UINT8 action_type;
    HUPU_INT16 error_id = 0;
	NAC_DNS_SERVER nameserver_st;
    memset(&nameserver_st, '\0', sizeof(NAC_DNS_SERVER));

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

    switch (action_type)
    {
    case NAC_SHOW:
        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_ret_show_result(cmd_id, "nameserver");
        break;

    case NAC_ADD:
        while(cur_node != HUPU_NULL)
        {
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "nameServer1")))
			{
				szKey = xmlNodeGetContent(cur_node);
				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->nameServer1-->%s\n", __FUNCTION__, (HUPU_CHAR*)szKey);
				memcpy(nameserver_st.nameserver1, (HUPU_CHAR*)szKey, strlen((HUPU_CHAR*)szKey));
				xmlFree(szKey);
			}
			else if (!(xmlStrcmp(cur_node->name, BAD_CAST "nameServer2")))
			{
				szKey = xmlNodeGetContent(cur_node);
				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->nameServer2-->%s\n", __FUNCTION__, (HUPU_CHAR*)szKey);
				memcpy(nameserver_st.nameserver2, (HUPU_CHAR*)szKey, strlen((HUPU_CHAR*)szKey));
				xmlFree(szKey);
                break;
			}
            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);

		if ((strlen(nameserver_st.nameserver1) > 0) || (strlen(nameserver_st.nameserver2) > 0))
		{
			iRet = nac_sys_net_set_dnserver(&nameserver_st);
			if (iRet == HUPU_ERR)
			{
				error_id = NAC_SYS_ERROR_SET_NAMESERVER_FAIL;
				nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->%s-->error\n", __FUNCTION__, nac_sys_get_error_log(error_id));
			}
		}
        else
        {
            error_id = NAC_SYS_ERROR_SET_NAMESERVER_FAIL;
        }
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    case NAC_DEL:
    case NAC_MODIFY:
    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

xmlDocPtr nac_sys_parse_shut_or_boot(xmlDocPtr doc, HUPU_UINT16 cmd_id, HUPU_UINT8 *opt_action)
{
	HUPU_INT32 error_id;
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    xmlChar *szKey;
    HUPU_UINT8 action_type;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
    switch (action_type)
    {
    case NAC_ADD:
        while(cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "sysOpt")))
            {
                szKey = xmlNodeGetContent(cur_node);
                SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->sysOpt-->%s\n", __FUNCTION__, (HUPU_CHAR*)szKey);
                if (memcmp((HUPU_CHAR*)szKey, "reboot", strlen("reboot")) == 0)
                {
                    *opt_action = SYS_REBOOT;
                }
                else if(memcmp((HUPU_CHAR*)szKey, "shutdown", strlen("shutdown")) == 0)
                {
                    *opt_action = SYS_SHUTDOWN;
                }
                else
                {
                    *opt_action  = SYS_NOBOOT;
                    error_id = NAC_SYS_ERROR_UNEXIST_OPERATE;
					break;
                }
                xmlFree(szKey);
            }

            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
		error_id = NAC_SYS_ERROR_UNEXIST_OPERATE;
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;
    }

    return nac_doc;
}


HUPU_INT32 nac_system_enable_all_eth_dev(HUPU_VOID)
{
	HUPU_INT32 iRet;
	HUPU_UINT16 i;
	HUPU_CHAR	enable_netdev_cmd[] = "ifconfig %s up";
	HUPU_CHAR	cmd_buffer[64];

	for (i = 0; i < gi_netdev_count; i++)
	{
		memset(cmd_buffer, '\0', sizeof(cmd_buffer));
		sprintf(cmd_buffer, enable_netdev_cmd, nac_sys_ifname[i]);
		g_nac_net_device[i].if_enable = 1;
		iRet = nac_exec_system(cmd_buffer);
	}

	return HUPU_OK;
}

HUPU_INT32 nac_system_init_network_ifconfig(HUPU_VOID)
{
	HUPU_INT32 iRet;
	HUPU_UINT16 i;
	HUPU_CHAR   enable_netdev_cmd[] = "ifconfig %s up";
    HUPU_CHAR   cmd_buffer[64];

	//netdev_name:nac_sys_ifname[IFMAXNUM][IFNAMSIZE];
	for (i = 0; i < IFMAXNUM; i++)
	{
        memset(nac_sys_ifname[i], '\0', IFNAMSIZE);
        sprintf(nac_sys_ifname[i], "eth%d", i);
	}

	gi_netdev_count = nac_get_netdev_count();

	for (i = 0; i < gi_netdev_count; i++)
	{
		g_nac_net_device[i].if_index = i;
		memset(g_nac_net_device[i].if_label, '\0', IFNAMSIZE);
		memset(g_nac_net_device[i].if_ip, '\0', IP_STR_LEN);
		memset(g_nac_net_device[i].if_mask, '\0', IP_STR_LEN);
		g_nac_net_device[i].if_link = 0;
		g_nac_net_device[i].if_enable = 1;

		memset(cmd_buffer, '\0', sizeof(cmd_buffer));
        sprintf(cmd_buffer, enable_netdev_cmd, nac_sys_ifname[i]);
        nac_exec_system(cmd_buffer);

		if (i == 0)
		{
			memcpy(g_nac_net_device[i].if_label, "manager", strlen("manager"));
		}
		else if (i == 1)
		{
			memcpy(g_nac_net_device[i].if_label, "ha", strlen("ha"));

			/*
			memcpy(g_nac_net_device[i].if_ip, "192.168.1.100", strlen("192.168.1.100"));
            memcpy(g_nac_net_device[i].if_mask, "255.255.255.0", strlen("255.255.255.0"));
			*/
		}
		else if (i == 2)
		{
			memcpy(g_nac_net_device[i].if_label, "untrust", strlen("untrust"));
		}
		else if (i == 3)
		{
			memcpy(g_nac_net_device[i].if_label, "trust", strlen("trust"));
		}
		else
		{
			memcpy(g_nac_net_device[i].if_label, "other", strlen("other"));
		}

		nac_app_get_system_netcard_info(nac_sys_ifname[i], &g_nac_net_device[i]);
	}

	for (i = 0; i < gi_netdev_count; i++)
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->%hd;%s;%s;%s;%hhd;%hhd\n", __FUNCTION__,
			g_nac_net_device[i].if_index, g_nac_net_device[i].if_label, g_nac_net_device[i].if_ip,
			g_nac_net_device[i].if_mask, g_nac_net_device[i].if_enable, g_nac_net_device[i].if_link);
	}

	//default_gateway
	iRet = nac_app_get_system_default_gateway(g_default_gateway);
	if (iRet == HUPU_ERR)
	{
		memset(g_default_gateway, '\0', strlen(g_default_gateway));
    	memcpy(g_default_gateway, "NULL", strlen("NULL"));
	}

    //dns server
    memset(&gst_dns_server, '\0', sizeof(NAC_DNS_SERVER));
	iRet = nac_app_get_system_resolv_conf("/etc/resolv.conf", &gst_dns_server);
 	if (iRet == HUPU_ERR)
	{
 		memcpy(gst_dns_server.nameserver1, "114.114.114.114", strlen("114.114.114.114"));
    	memcpy(gst_dns_server.nameserver2, "8.8.4.4", strlen("8.8.4.4"));
		nac_sys_net_set_dnserver(&gst_dns_server);
	}

    return HUPU_OK;
}

#if 0
HUPU_VOID nac_sys_net_clr_ifconfig(HUPU_VOID)
{
    HUPU_UINT16 i;
    HUPU_CHAR exec_cmd[80] = "";
	HUPU_CHAR *clr_ifconfig = "ifconfig %s 0.0.0.0 down";

    for (i = 0; i < gi_netdev_count; i++)
    {
        memset(exec_cmd, '\0', 80);
        sprintf(exec_cmd, clr_ifconfig, nac_sys_ifname[i]);
        nac_exec_system(exec_cmd);
    }
}

/*
#route add default gw 121.248.201.111
#route del default gw 121.248.201.254
#ip route add default via 192.168.4.1
#ip route del default via 192.168.4.1
#ip route del default
#ip route show table main | grep "default" |awk '{system("ip route del default via "$3" table main")}'
*/

HUPU_INT32 nac_sys_net_clear_default_gateway(HUPU_VOID)
{
	HUPU_CHAR *del_gateway_cmd		= "ip route del default via %s dev %s";
	HUPU_CHAR *del_default_gw_cmd 	= "ip route del default";
	HUPU_CHAR exec_cmd[100] = "";

	memset(exec_cmd, '\0', sizeof(exec_cmd));
	if (nac_preg_match_ip(g_default_gateway) == HUPU_OK)
	{
		sprintf(exec_cmd, del_gateway_cmd, g_default_gateway, g_manager_eth_name);
		nac_exec_system(exec_cmd);
	}
	else
	{
		nac_exec_system(del_default_gw_cmd);
	}

	return HUPU_OK;
}
#endif

