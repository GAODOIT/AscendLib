#ifndef NAC_SYSTEM_VLANMAP_H
#define NAC_SYSTEM_VLANMAP_H

#define NAC_SYS_VLANMAP_HASH_SIZE   128

typedef struct _NAC_APP_VLANMAP_STRU
{
    struct nac_hlist_node node;
    HUPU_UINT32 id;
    HUPU_UINT16 isolate_vlantag;
    HUPU_UINT16 normal_vlantag;
    HUPU_CHAR  comment[MAX_COMMENT_LEN];
} NAC_APP_VLANMAP;

extern HUPU_UINT16 g_vlanmap_index;
extern struct nac_hlist_head nac_vlanmap_hash[];

/*return old sys_vlan count_num*/
int nac_app_rem_all_old_vconfig(void);
HUPU_INT32 nac_sys_net_setvlan(NAC_SET_ACTION flag,
							nac_knl_policy_vlap* vlanmap_st,
							nac_knl_in_out_eth* pst_inout_eth);
HUPU_VOID nac_system_init_vlanmap(HUPU_VOID);
HUPU_VOID destroy_entire_vlanmap_hlist(HUPU_VOID);
HUPU_VOID nac_app_set_all_hlist_vlanmap(HUPU_VOID);

/*add success: return HUPU_OK; add failure: return HUPU_ERR*/
HUPU_INT32 nac_sys_add_vlanmap(NAC_APP_VLANMAP* st_vlanmap);

/*return xmlDoc*/
xmlDocPtr nac_xml_parse_vlantag_map(xmlDocPtr doc, HUPU_UINT16 cmd_id, HUPU_UINT8 *opt_type);
//xmlDocPtr nac_xml_parse_vlantag_map(xmlDocPtr doc, HUPU_UINT16 cmd_id);

#endif // end of NAC_SYSTEM_VLANMAP_H
