#ifndef NAC_SYSTEM_REDIS_SUBSCRIBE_H
#define NAC_SYSTEM_REDIS_SUBSCRIBE_H

#include <locale.h>
#include "json.h"
#include "hiredis.h"
#include "nac_system_common_lib.h"


#define HOSTNAME "127.0.0.1"
#define REDISPORT 6999

typedef int (*CallBackFun)(json_t* node);

typedef struct KEY_FUNC_MAP_ST
{
    char key[64];
    CallBackFun method;

}KEY_FUNC_MAP;

int send_redis_pub_command(char *key);
void *nac_sys_monitor_redis_sub_pthread(void *data);
#endif
