#ifndef NAC_SYSTEM_HA_BACKUP_H
#define NAC_SYSTEM_HA_BACKUP_H

#include "nac_system_user.h"
#include "nac_system_common_lib.h"


#define NAC_HA_BACKUP_LISTEN_PORT      6005

enum
{
    HA_DISABLE = 0,
    HA_ENABLE,
};

enum
{
    HA_NULL_MODE,
    HA_MASTER_MODE,
    HA_BACKUP_MODE,
};


enum
{
    HA_NULL_STATUS    = 0,
    HA_FAULT_STATUS   = 1,
    HA_BACKUP_STATUS  = 2,
    HA_MASTER_STATUS  = 3,
};

enum
{
    HA_SYNC_NULL = 0,
    HA_SYNC_START,
    HA_SYNC_FINISH,
    HA_SYNC_LOCK,
    HA_SYNC_UNLOCK,
    HA_SYNC_ERROR,
};

struct ETH_ADDR_ST
{
    HUPU_UINT32 ipaddr;
    HUPU_UINT32 netmask;
};

typedef struct NAC_HA_BACKUP_CONFIG_STRU
{
    HUPU_UINT8 ha_switch;
    HUPU_UINT8 init_status;//retain
    HUPU_UINT8 run_status;
    HUPU_UINT8 sync_status;
    HUPU_UINT16 priority;
    HUPU_CHAR  ha_eth[IFNAMSIZE];
    HUPU_CHAR  local_mac[ETH_ALEN];
    HUPU_CHAR  vtl_mac[ETH_ALEN];
    struct ETH_ADDR_ST local_ha_addr;
    struct ETH_ADDR_ST other_ha_addr;
    struct ETH_ADDR_ST vip_addr;
}NAC_HA_BACKUP_CONFIG;

typedef struct NAC_USER_STRUCT
{
    HUPU_UINT16 user_type;
    HUPU_UINT16 dep_id;
    HUPU_UINT32 user_id;
    HUPU_UINT32 status;
    HUPU_CHAR   ip[16];
    HUPU_CHAR   mac[18];
    HUPU_CHAR   isolate_id[128];
} NAC_USER_ST;

typedef struct HA_SYNC_MSG_STRU
{
    HUPU_UINT16 us_cmd;
    HUPU_UINT16 reserve;
    HUPU_UINT32	ui_len;
    HUPU_UINT32 ip_addr;
    HUPU_CHAR   sync_msg[18];
} HA_SYNC_MSG;

HUPU_VOID nac_system_catch_siguser1(HUPU_INT32 sig);
HUPU_VOID nac_system_catch_siguser2(HUPU_INT32 sig);
HUPU_VOID nac_system_catch_sigrtmin(HUPU_INT32 sig);


extern NAC_HA_BACKUP_CONFIG gst_ha_backup_config;
HUPU_INT32 nac_sys_write_ha_backup_config_to_configure(FILE* fp);
HUPU_INT32 nac_sys_get_ha_backup_config_form_configure(const HUPU_CHAR *file_path);
HUPU_INT32 nac_system_init_ha_backup(HUPU_VOID);
HUPU_INT32 nac_system_modify_asc_device_id(HUPU_CHAR* mac);
HUPU_INT32 nac_system_update_ha_backup_config(HUPU_CHAR* key, HUPU_CHAR* value);
HUPU_INT32 nac_system_ha_sync_dynamic_config(xmlDocPtr doc, NAC_WEB_MSG* pst_config_msg);
xmlDocPtr nac_system_parse_ha_backup_config(xmlDocPtr doc, HUPU_UINT16 cmd_id);
HUPU_INT32 nac_system_ha_deal_sync_msg(NAC_WEB_MSG* pst_web_msg, HUPU_INT32 sock_fd);
HUPU_INT32 ha_backup_sync_knl_timeout_user(NAC_SYS_USER *user);
HUPU_VOID nac_app_debug_ha_backup_config(NAC_HA_BACKUP_CONFIG *pst_config, FILE *fp);


#endif
