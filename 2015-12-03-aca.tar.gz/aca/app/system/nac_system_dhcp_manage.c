/*
 *
 * Part:        nac except app.
 *
 * Author:      cxk
 *
 */


#include "nac_system_dhcp_manage.h"

static O_MANAGE_DHCP_DATA dhcp_data;

P_MANAGE_DHCP_DATA nac_sys_get_dhcp_manage_struct_point(void)
{
    return &dhcp_data;
}
// flush dhcp config data
HUPU_INT32 nac_sys_flush_dhcp_manage_config(void)
{
    dhcp_data.enable = 0;
    dhcp_data.num    = 0;
    if(dhcp_data.pData)
    {
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "----free(pData->pData)----");
        free(dhcp_data.pData);
        dhcp_data.pData = NULL;

    }
    nac_set_data_to_knl(NAC_CMD_PORT_IP_FLUSH, 0, NULL, 0);
    return 0;
}

// get dhcp manage value from config file content
HUPU_INT32 get_list_dhcp_manage_value(HUPU_CHAR (*p_list)[MAX_LEN], P_MANAGE_DHCP p_data,HUPU_INT32 num)

{
    HUPU_INT32 i = 0;
    HUPU_INT32 max = num > MAX_ITEM?MAX_ITEM:num;
    for(i=0; i<max; i++)
    {
        HUPU_CHAR *p = (HUPU_CHAR *)&p_list[i];
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "get dhcp manage list text--value=%s\n",p);
        //printf( "get dhcp manage text--value=%s i = %d\n",p, i);
        sscanf(p, "%d;%[0-9.];%[^;]",&p_data[i].status,p_data[i].ip,p_data[i].comment);
    }
    return 0;
}
// write dhcp manage data to config file
HUPU_INT32 nac_sys_write_dhcp_manage_data_to_configure(FILE* fp)
{
    P_MANAGE_DHCP_DATA p_ex = nac_sys_get_dhcp_manage_struct_point();
    HUPU_CHAR content[1024*10] = {0};
    HUPU_CHAR buffer[512]={0};
    strcat(content, "dhcp_manage_config\n{\n");
    sprintf(buffer,"    enable=%d\n    type=%d\n    item_num=%d\n", p_ex->enable, p_ex->type, p_ex->num);
    strcat(content, buffer);
    if(p_ex->num > 0)
    {
	    strcat(content, "    item_list\n    {\n");
	    HUPU_INT32 i;
	    for(i = 0;i<p_ex->num; i++)
	    {
	        memset(buffer, 0, sizeof(buffer));
	        sprintf(buffer,"        %d;%s;%s\n",p_ex->pData[i].status,p_ex->pData[i].ip ,p_ex->pData[i].comment);
	        strcat(content, buffer);
	    }
	    strcat(content, "    }\n");
    }
    strcat(content, "}\n\n");
    fprintf(fp, "%s", content);
    return 0;

}

// read dhcp manage data from config file
HUPU_INT32  nac_sys_get_dhcp_manage_data_form_configure(const HUPU_CHAR *file_path)
{
    HUPU_CHAR buffer[1024*1024] = {0};
    HUPU_CHAR content[1024*10] = {0};
    HUPU_INT32 fd = 0;
    HUPU_CHAR  *p_value = NULL;
    P_MANAGE_DHCP_DATA p_ex = nac_sys_get_dhcp_manage_struct_point();
    memset(p_ex, 0, sizeof(O_MANAGE_DHCP_DATA));
    fd = open(file_path, O_RDONLY);
    read(fd, buffer, 1024*1024);
    close(fd);
    memset(content, 0, sizeof(content));
    if(get_content(buffer, content, "dhcp_manage_config") < 0)
        goto GO_EXIT;
    p_value = each_line_search(content,  "enable");
    p_ex->enable = atoi(p_value);
    p_value = each_line_search(content,  "type");
    p_ex->type= atoi(p_value);
    p_value = each_line_search(content,  "item_num");
    p_ex->num    = atoi(p_value);
    if(p_ex->num == 0)
        goto GO_EXIT;
    P_MANAGE_DHCP pDhcpData = (P_MANAGE_DHCP)malloc(p_ex->num * sizeof(O_MANAGE_DHCP));
    p_ex->pData = pDhcpData;
    memset(pDhcpData, 0, p_ex->num * sizeof(O_MANAGE_DHCP));
    memset(buffer, 0, sizeof(buffer));
    memcpy(buffer, content, sizeof(content));
    memset(content, 0, sizeof(content));
    get_content(buffer, content, "item_list");
    HUPU_CHAR list[MAX_ITEM][MAX_LEN];
    memset(list, 0, sizeof(list));
    get_list(content, list);
    get_list_dhcp_manage_value(list, pDhcpData, p_ex->num);
    nac_system_set_dhcp_manage_data_to_kernel(p_ex);
    return 0;
    GO_EXIT:
        nac_system_set_dhcp_manage_data_to_kernel(p_ex);
        return -1;
}

//return web result
xmlDocPtr nac_sys_return_dhcp_manage_result(HUPU_INT32 action_type, P_MANAGE_DHCP_DATA pData)
{
	xmlDocPtr doc;
    xmlNodePtr root_node;
    HUPU_CHAR cmd_str[256] = {0};
    HUPU_INT32 i = 0;
    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);
    memset(cmd_str, '\0', sizeof(cmd_str));
    sprintf(cmd_str, "%d", (SYS_WEBUI_DHCP_MANAGE_CONFIG + Ret_cmd_offset));
    xmlNewChild (root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_str);
    memset(cmd_str, '\0', sizeof(cmd_str));
    sprintf(cmd_str, "%d", action_type);
    xmlNewChild (root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST cmd_str);
    memset(cmd_str, '\0', sizeof(cmd_str));
    sprintf(cmd_str, "%d;%d", pData->enable, pData->type);
    xmlNewChild (root_node, HUPU_NULL, BAD_CAST "dhcpManage", BAD_CAST cmd_str);
	if(action_type == BULK_SHOW)
	{
		if(pData->pData)
		{
			for(i = 0; i < pData->num && pData->pData[i].status == 1; i++)
			{
				memset(cmd_str, '\0', sizeof(cmd_str));
    			sprintf(cmd_str, "%s;%s", pData->pData[i].ip, pData->pData[i].comment);
    			xmlNewChild (root_node, HUPU_NULL, BAD_CAST "dhcpItem", BAD_CAST cmd_str);
			}
		}
	}
	else if(action_type == BULK_UPDATE)
	{
		if(pData->pData)
		{
			for(i = 0; i < pData->num; i++)
			{
				memset(cmd_str, '\0', sizeof(cmd_str));
    			sprintf(cmd_str, "%d;%s;%s", pData->pData[i].status,pData->pData[i].ip, pData->pData[i].comment);
    			xmlNewChild (root_node, HUPU_NULL, BAD_CAST "dhcpItem", BAD_CAST cmd_str);
			}
		}
	}
	else if(action_type == BULK_FLUSH)
	{
		memset(cmd_str, '\0', sizeof(cmd_str));
    	sprintf(cmd_str, "1");
    	xmlNewChild (root_node, HUPU_NULL, BAD_CAST "dhcpDeleteAllResult", BAD_CAST cmd_str);
	}
	else
	{
		SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "unknown actiontype----%d----\n",action_type);
	}
	return doc;
}

//parse web xml msg
HUPU_INT32 nac_sys_parse_dhcp_manage_result(xmlNodePtr cur_node, P_MANAGE_DHCP_DATA pData, HUPU_UINT8 action_type)
{
	xmlNodePtr node = cur_node;
    HUPU_INT32 num = 0;
    xmlChar   *xml_value;
    for(;node;)
    {
        if (!(xmlStrcmp(node->name, BAD_CAST "dhcpManage")))
        {
            xml_value = xmlNodeGetContent(node);
            sscanf((HUPU_CHAR*)xml_value, "%d;%d", &pData->enable, &pData->type);
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "dhcpManage = %s\n", (HUPU_CHAR*)xml_value);
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "dhcp_manage----enable = %d, type = %d\n", pData->enable,  pData->type);
		    xmlFree(xml_value);
        }

        if (!(xmlStrcmp(node->name, BAD_CAST "dhcpItem")))
            num++;
        node = node->next;
    }
    if(action_type == BULK_FLUSH)
    {
        if(pData->pData)
        {
        	pData->num = 0;
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "----free(pData->pData)---- %ld\n", pData->pData);
            free(pData->pData);
            pData->pData = NULL;
        }
        pData->num = 0;
        return 0;
    }
    P_MANAGE_DHCP pDhcpData = (P_MANAGE_DHCP)malloc(num * sizeof(O_MANAGE_DHCP));
    memset(pDhcpData, 0, num * sizeof(O_MANAGE_DHCP));
    if (pDhcpData == NULL)
    {
        return -1;
    }
    HUPU_INT32 i = 0;
    node = cur_node;
    for(i=0;i < num;)
    {
        if (!(xmlStrcmp(node->name, BAD_CAST "dhcpItem")))
        {
             pDhcpData[i].status = 1;
             xml_value = xmlNodeGetContent(node);
             SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "dhcpItem----%s----\n",xml_value);
             if(strlen((HUPU_CHAR*)xml_value) >= MAX_LEN)
             {
                xml_value[MAX_LEN-1] = '\0';
             }
             HUPU_CHAR *p[2] ={0};
             p[0] =  pDhcpData[i].ip;
             p[1] =  pDhcpData[i].comment;
             split_string((HUPU_CHAR*)xml_value,";",2,p);
             //sscanf((HUPU_CHAR*)xml_value, "%[0-9.];%[^;]", pDhcpData[i].ip, pDhcpData[i].comment);
             SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "ip=%s comment= %s\n", pDhcpData[i].ip, pDhcpData[i].comment);
             i++;
             xmlFree(xml_value);
        }
        node = node->next;
    }
    pData->num = num;
    if(pData->pData)
    {
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "----free(pData->pData)----%ld\n", pData->pData);
        free(pData->pData);
        pData->pData = NULL;
    }
    pData->pData = pDhcpData;
    return 0;
}
//set dhcp manage data to kernel
HUPU_INT32 nac_system_set_dhcp_manage_data_to_kernel(P_MANAGE_DHCP_DATA pData)
{
	NAC_KNL_DHCP_CONFIG st_dhcp;
	struct nac_knl_rbtree_entry nac_ety;
	st_dhcp.status = DHCP_CLOSE;
	st_dhcp.switc  = DHCP_DISABLE;
	if(pData->enable)
		st_dhcp.status = DHCP_OPEN;
	if(pData->type)
		st_dhcp.switc  = DHCP_ENABLE;
	//printf("%s pData->enable = %d pData->type =%d\n", __FUNCTION__, pData->enable, pData->type);
	nac_set_data_to_knl(NAC_CMD_DHCP_SET_SWIT, 0, &st_dhcp, sizeof(NAC_KNL_DHCP_CONFIG));
	nac_set_data_to_knl(NAC_CMD_RBTREE_FLUSH, NAC_KNL_RBTREE_DHCP_SERVER, NULL, 0);

	int i;
	for(i=0; i < pData->num && st_dhcp.status == DHCP_OPEN; i++)
	{
		HUPU_INT32 iRet;
		memset(&nac_ety, 0, sizeof(struct nac_knl_rbtree_entry));
		nac_ety.type = NAC_KNL_RBTREE_DHCP_SERVER;
		struct in_addr inp;
        if(inet_aton(pData->pData[i].ip, &inp))
        {
            nac_ety.union_rbtree.port.ip_addr = ntohl((HUPU_UINT32)inet_addr(pData->pData[i].ip));
            //printf("%s pData->pData[%d].ip = %s\n", __FUNCTION__, i, pData->pData[i].ip);
        }
        else
        {
            pData->pData[i].status = 0;
            SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "error ip = %s\n", pData->pData[i].ip);
            continue;
        }
        iRet = nac_set_data_to_knl(NAC_CMD_RBTREE_INS, 0, &nac_ety, sizeof(struct nac_knl_rbtree_entry));

		if (iRet != HUPU_OK)
		{
			SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "set to kernel failed ip = %s\n", pData->pData[i].ip);
			pData->pData[i].status = 0;
		}


	}


	return HUPU_OK;
}
// dhcp manage handle
xmlDocPtr nac_system_parse_dhcp_manage_config(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_UINT8 action_type;
    xmlNodePtr cur_node = NULL;
    xmlDocPtr re_doc;
    cur_node = nac_xml_parse_get_action(doc, &action_type);
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "into handle cmd_id = %d action type = %d \n", cmd_id,action_type);
    switch(action_type)
    {
    	case BULK_SHOW:
    		re_doc = nac_sys_return_dhcp_manage_result(action_type, &dhcp_data);
    		break;
    	case BULK_UPDATE:
    	case BULK_FLUSH:
    		nac_sys_parse_dhcp_manage_result(cur_node, &dhcp_data, action_type);
    		re_doc = nac_sys_return_dhcp_manage_result(action_type, &dhcp_data);
    		nac_system_set_dhcp_manage_data_to_kernel(&dhcp_data);
    		break;
    	default:
    		SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "unknown actiontype----%d----\n",action_type);
    		break;

    }
    nac_free_xmlDoc(doc);
    return re_doc;
}

