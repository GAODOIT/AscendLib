#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_save_sysconfig.h"      //call nac_sys_save_vlanmap();
#include "nac_system_redirect_manager_ip.h" //call gst_redirect_manager_ip;
#include "nac_system_set_remote_server.h"
#include "nac_system_debug_sysconfig.h"
#include "nac_system_netapp_check.h"
#include "nac_system_arp_monitor.h"
#include "nac_system_time.h"
#include "nac_system_vlanmap.h" //nac_app_rem_all_old_vconfig &&destroy_entire_vlanmap_hlist
#include "nac_system_iprange_policy.h"
#include "nac_system_domain_policy.h"
#include "nac_system_net.h"
#include "nac_system_exceptapp.h"
#include "nac_system_deal_sysconfig.h"
#include "nac_system_nat_manage.h"
#include "nac_system_dhcp_manage.h"
#include "nac_system_except_mac.h"

HUPU_CHAR  *nac_factory_cfg_file        = "/nac/config/nac_factory.conf";
HUPU_CHAR  *nac_input_cfg_file          = "/nac/config/nac_update.conf";
HUPU_CHAR  *ruby_switch_prog_cfg_file   = "/var/tmp/ruby_switch.conf";

static HUPU_INT32 nac_sys_create_ruby_switch_config(const HUPU_CHAR* filename, HUPU_INT32 server_ip, HUPU_UINT16 flag, HUPU_CHAR *mac)
{
	HUPU_CHAR cmd_buffer[BUFF_LEN] = "";
    HUPU_CHAR eth_addr_tmp[IP_STR_LEN] = "";

	memset(cmd_buffer, '\0', BUFF_LEN);
	sprintf(cmd_buffer, "echo \"ascEable=%s\" > %s",
			(flag == 1)? ("true"):("flase"), filename);
	nac_exec_system(cmd_buffer);

    memset(cmd_buffer, '\0', BUFF_LEN);
	sprintf(cmd_buffer, "echo \"serverAddr=%u.%u.%u.%u\" >> %s", LIPQUAD(server_ip), filename);
	nac_exec_system(cmd_buffer);

    memset(cmd_buffer, '\0', BUFF_LEN);
    nac_app_get_special_ifaddr_by_label("manager", eth_addr_tmp);
	sprintf(cmd_buffer, "echo \"mgIp=%s\" >> %s", eth_addr_tmp, filename);
	nac_exec_system(cmd_buffer);

    memset(cmd_buffer, '\0', BUFF_LEN);
    sprintf(cmd_buffer, "echo \"ascID=%02x-%02x-%02x-%02x-%02x-%02x\" >> %s", MAC_FORMAT_2(mac), filename);
	nac_exec_system(cmd_buffer);

	return HUPU_OK;
}

HUPU_INT32 nac_sys_send_ruby_switch_usr1(HUPU_VOID)
{
	HUPU_INT32 iRet;
	HUPU_CHAR get_ruby_switch_pid_cmd[] = "pgrep main_switch";
	HUPU_CHAR send_usr1_signal_cmd[]    = "kill -USR1 %d";
	FILE *popen_fp;
	HUPU_CHAR szLine[BUFF_LEN] = "";
	HUPU_UINT32 ruby_switch_pid = 0;

	nac_sys_get_knl_pass_switch(&g_nac_asc_enable_flag);
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "server_ip=%u.%u.%u.%u--mac_addr=%02x-%02x-%02x-%02x-%02x-%02x\n",
                        LIPQUAD(gi_link_server_ip), MAC_FORMAT(g_manager_mac_addr));
	nac_sys_create_ruby_switch_config(ruby_switch_prog_cfg_file, gi_link_server_ip,
                                    g_nac_asc_enable_flag, g_manager_mac_addr);
    popen_fp = popen(get_ruby_switch_pid_cmd, "r");
	if (popen_fp == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->popen error!\n", __FUNCTION__);
		return HUPU_ERR;
	}

	if (fgets(szLine, BUFF_LEN, popen_fp) == HUPU_NULL)
	{
		pclose(popen_fp);
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->fgets error!\n", __FUNCTION__);
		return HUPU_ERR;
	}
	pclose(popen_fp);

	HUPU_UINT32 length = strlen(szLine);
	szLine[length-1] = '\0';
	if (sscanf(szLine, "%d", &ruby_switch_pid) != 1)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->sscanf error!\n", __FUNCTION__);
		return HUPU_ERR;
	}
	memset(szLine, '\0', BUFF_LEN);
	sprintf(szLine, send_usr1_signal_cmd, ruby_switch_pid);
	iRet = nac_exec_system(szLine);
	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s--send_usr1_signal_cmd = %s--%d\n", __FUNCTION__, szLine, iRet);

	return HUPU_OK;
}

/*no_fclose*/
static HUPU_INT32 nac_sys_check_out_update_config_file(const HUPU_CHAR* filename)
{
	FILE *nac_read_fp;
	HUPU_CHAR szLine[BUFF_LEN] = "";

	if ((nac_read_fp = fopen(filename, "r")) == HUPU_NULL)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->read open %s error\n", __FUNCTION__, filename);

        return HUPU_ERR;
    }

	if (fgets(szLine, BUFF_LEN, nac_read_fp) == HUPU_NULL)
	{
		fclose(nac_read_fp);
		return HUPU_ERR;
	}

	fclose(nac_read_fp);
	if (strstr(szLine, "HUPU_NAC configuration") != HUPU_NULL)
	{
		return HUPU_OK;
	}

	return HUPU_ERR;
}


//mysql -h localhost -uroot -proot -Dhupunac < /nac/web/nac_factory/hupunac.sql
static HUPU_INT32 nac_sys_reset_webserver_and_datebase_config(HUPU_VOID)
{
	HUPU_CHAR nac_reset_web_factory_script[] = "/nac/script/nac_web_reset_factory.sh";

	if (access(nac_reset_web_factory_script,  X_OK) == HUPU_OK) // /nac/script/nac_web_reset_factory.sh
	{
		nac_exec_system(nac_reset_web_factory_script);
	}
	else
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->%s non_executable permission\n", __FUNCTION__, nac_reset_web_factory_script);
		nac_exec_system("rm -rf /nac/web/web_user_login/*");
		nac_exec_system("rm -rf /nac/web/softwareupload/*");
		nac_exec_system("rm -rf /bak/mysql/*");

		nac_exec_system("cd /var/log/tomcat && rm -rf `ls | grep -v \"^catalina.out$\"|grep -v \"^nac.log$\"`");
		nac_exec_system("> /var/log/tomcat/catalina.out");
		nac_exec_system("> /var/log/tomcat/nac.log");
		nac_exec_system("rm -rf /nac/web/cloud_config/*");
		nac_exec_system("mysql -h localhost -uroot -phupu12iman! -Dhupunac < /nac/web/nac_factory/hupunac.sql");
	}

	return HUPU_OK;
}

HUPU_INT32 nac_sys_reset_to_factory_config(HUPU_VOID)
{
	nac_app_flush_all_system_config();
	nac_exec_system("rm -f /var/log/nac_asc/nac_sys_*.log*");
	//clear_nac_license companyId and serverIp;
	nac_exec_system("sed -i '/^companyId/d' /nac/config/nac_license");
	nac_exec_system("sed -i '/^serverIp/d' /nac/config/nac_license");
	nac_exec_system("echo \"companyId=\" >> /nac/config/nac_license");
	nac_exec_system("echo \"serverIp=\" >> /nac/config/nac_license");

	nac_system_destroy_tcp_long_sockfd();
	nac_app_read_sys_config_from_file(nac_factory_cfg_file, 0);
    //nac_exec_system("rm -f /nac/config/nac_sys.conf");
    nac_exec_system("\\cp -f /nac/config/nac_factory.conf /nac/config/nac_sys.conf");
	nac_sys_reset_webserver_and_datebase_config();

	return HUPU_OK;
}

//nac_app_read_sys_config_from_file(nac_input_cfg_file);
HUPU_INT32 nac_sys_update_current_system_config(HUPU_VOID)
{
	HUPU_INT32 iRet;
	nac_app_flush_all_system_config();
	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_app_flush_all_system_config.\n", __FUNCTION__);

	nac_system_destroy_tcp_long_sockfd();
	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_system_destroy_tcp_long_sockfd.\n", __FUNCTION__);


	iRet = nac_sys_check_out_update_config_file(nac_sys_cfg_file);
	if (iRet == HUPU_OK)
	{
		nac_app_read_sys_config_from_file(nac_sys_cfg_file, 0);
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_app_read_sys_config_from_file.\n", __FUNCTION__);
	}

	return HUPU_OK;
}

xmlDocPtr nac_sys_parse_deal_sys_config_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id, HUPU_UINT8 *cmd_action)
{
	HUPU_INT32 iRet, error_id;
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    HUPU_UINT8 action_type;

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	*cmd_action = action_type;
	error_id = 0;
	switch (action_type)
    {
    case NAC_SAVE_SYS_CONFIG:
        nac_free_xmlDoc(doc);
        iRet = nac_app_save_sys_config_to_file(nac_sys_cfg_file);
        if (iRet == HUPU_ERR)
        {
            nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->save-->nac_app_save_sys_config_to_file error\n", __FUNCTION__);
			error_id =  NAC_SYS_ERROR_SAVE_SYS_CONFIG_FAIL;
        }
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

	case NAC_OUTPUT_SYS_CONFIG:
        nac_free_xmlDoc(doc);
        nac_app_save_sys_config_to_file(nac_sys_cfg_file);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

	case NAC_INPUT_SYS_CONFIG:
		nac_free_xmlDoc(doc);
		/*
		if (access(nac_input_cfg_file,	F_OK) != HUPU_OK) //nac_update.conf unexist!
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->%s is unexist\n",
							__FUNCTION__, nac_input_cfg_file);

			error_id = NAC_SYS_ERROR_INPUT_CONFIG_UNEXIST;
		}
		*/
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

	case NAC_RESET_SYS_CONFIG:
		nac_free_xmlDoc(doc);
		if (access(nac_factory_cfg_file, F_OK) != HUPU_OK) //nac_factory.conf unexist!
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->%s is unexist\n",
							__FUNCTION__, nac_factory_cfg_file);
			error_id = NAC_SYS_ERROR_FACTORY_CONFIG_UNEXIST;
		}
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->invalid action_type\n", __FUNCTION__);
		error_id = NAC_SYS_ERROR_UNEXIST_OPERATE;
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);

        break;
    }

    return nac_doc;
}

HUPU_INT32 nac_app_flush_all_system_config(HUPU_VOID)
{
	HUPU_INT32 iRet;

	/*NAC_CMD_POLICY_FLUSH = flush vlan_map.*/
    iRet = nac_set_data_to_knl(NAC_CMD_POLICY_FLUSH, 0, NULL, 0);
    if (iRet != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl-->NAC_CMD_POLICY_FLUSH is error, iRet = %d\n", iRet);
        return HUPU_ERR;
    }
		destroy_entire_vlanmap_hlist();
	/*init close pbr onein_oneout switch*/
    iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_PBR_2_ETH_SWITCH, HUPU_FALSE, NULL, 0);
    if (iRet != HUPU_OK)
    {
       SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl-->close pbr onein_oneout error, iRet = %d\n", iRet);
       return HUPU_ERR;
    }

	nac_pbr_onein_oneout_flag = 0;
	pbr_advance_setup.nexthop_ip = 0;
	memset(pbr_advance_setup.nexthop_mac, '\0', ETH_ALEN);
    memset(pbr_advance_setup.trust_mac, '\0', ETH_ALEN);

	/*flush knl user*/
    iRet = nac_set_data_to_knl(NAC_CMD_USER_FLUSH, 0, NULL, 0);
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_set_data_to_knl-->NAC_CMD_USER_FLUSH is error, iRet = %d\n", __FUNCTION__, iRet);
        return HUPU_ERR;
    }

    /*flush netapp*/
	nac_sys_knl_flush_enable_netapp_config();
    nac_sys_flush_netapp_config_hlist();

    /*flush  nat_config*/
    nac_app_knl_nat_manage_flush();
    nac_app_nat_manage_flush();

	/*arp_monitor_config*/
	memset(&gst_arp_monitor_config, '\0', sizeof(struct arp_monitor_config_struct));
	gst_arp_monitor_config.enable = 0;
	gst_arp_monitor_config.test_flag = 0;
	gst_arp_monitor_config.cycle_time = 0;
	nac_system_free_device_info_hlist();

	/*ntp_auto_time_server_config*/
	memset(&gst_nac_ntp_server, '\0', sizeof(struct nac_ntp_server_struct));
	gst_nac_ntp_server.self_sync_enable = 0;

    nac_sys_flush_policy_iprange_config(NAC_APP_EXCEPT_TERMINAL);
    nac_sys_flush_policy_iprange_config(NAC_APP_EXCEPT_SERVER);
    nac_sys_flush_policy_iprange_config(NAC_APP_SAFE_IPZONE);
    nac_sys_flush_policy_iprange_config(NAC_APP_ISOLATE_IPZONE);
    nac_sys_flush_except_mac_config();

	/*except server/terminal except_mac safe_zone and isolate_zone ip_range hlist*/
	nac_system_destroy_app_policy_pool();

    /*isolate_domain zone hlist*/
    nac_sys_flush_knl_domain_policy();
	nac_system_destroy_domain_policy_pool();

	//flush except app config
	nac_sys_flush_except_app_config();
	//flush dhcp manage config
	nac_sys_flush_dhcp_manage_config();

	return HUPU_OK;
}

HUPU_INT32 nac_app_init_flush_knl_config(HUPU_VOID)
{
	HUPU_INT32 iRet;

	/*NAC_CMD_POLICY_FLUSH == flush knl nac_mode, vlantag_map*/
	nac_app_clear_if_promisc_mode();
    iRet = nac_set_data_to_knl(NAC_CMD_POLICY_FLUSH, 0, NULL, 0);
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_set_data_to_knl-->NAC_CMD_POLICY_FLUSH is error, iRet = %d\n", __FUNCTION__, iRet);
        return HUPU_ERR;
    }
	/*init flush system vconfig*/

    /*init close pbr onein_oneout switch*/
    nac_pbr_onein_oneout_flag = 0;
    pbr_advance_setup.nexthop_ip = 0;
    memset(pbr_advance_setup.nexthop_mac, '\0', ETH_ALEN);
    memset(pbr_advance_setup.trust_mac, '\0', ETH_ALEN);
    iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_PBR_2_ETH_SWITCH, HUPU_FALSE, NULL, 0);
    if (iRet != HUPU_OK)
    {
       nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->close pbr onein_oneout error, iRet = %d\n", __FUNCTION__, iRet);
       return HUPU_ERR;
    }


    /*flush knl user*/
    iRet = nac_set_data_to_knl(NAC_CMD_USER_FLUSH, 0, NULL, 0);
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_set_data_to_knl-->NAC_CMD_USER_FLUSH is error, iRet = %d\n", __FUNCTION__, iRet);
        return HUPU_ERR;
    }

    /*flush netapp*/
	nac_sys_knl_flush_enable_netapp_config();

    /*flush knl nat_config*/
    nac_app_knl_nat_manage_flush();

    /*flush knl safe_zone iprange*/
    iRet = nac_set_data_to_knl(NAC_CMD_RBTREE_FLUSH, NAC_KNL_RBTREE_IP_RANGE, NULL, 0);
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_set_data_to_knl-->NAC_KNL_RBTREE_IP_RANGE is error, iRet = %d\n", __FUNCTION__, iRet);
        return HUPU_ERR;
    }

    /*flush knl isolate_zone iprange/domain zone*/
    iRet = nac_set_data_to_knl(NAC_CMD_RBTREE_FLUSH, NAC_KNL_RBTREE_ISOLATION_ZONE, NULL, 0);
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_set_data_to_knl-->NAC_KNL_RBTREE_ISOLATION_ZONE is error, iRet = %d\n", __FUNCTION__, iRet);
        return HUPU_ERR;
    }

    /*flush knl except_terminal*/
    iRet = nac_set_data_to_knl(NAC_CMD_RBTREE_FLUSH, NAC_KNL_RBTREE_EXCEPT_TERMINAL, NULL, 0);
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_set_data_to_knl-->NAC_KNL_RBTREE_EXCEPT_TERMINAL is error, iRet = %d\n", __FUNCTION__, iRet);
        return HUPU_ERR;
    }

    /*flush knl except_server*/
    iRet = nac_set_data_to_knl(NAC_CMD_RBTREE_FLUSH, NAC_KNL_RBTREE_EXCEPT_SERVER, NULL, 0);
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_set_data_to_knl-->NAC_KNL_RBTREE_EXCEPT_SERVER is error, iRet = %d\n", __FUNCTION__, iRet);
        return HUPU_ERR;
    }

    /*flush knl except_domain*/
    iRet = nac_set_data_to_knl(NAC_CMD_URL_FLUSH, 0, NULL, 0);
    if (iRet != HUPU_OK)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_set_data_to_knl-->NAC_CMD_URL_FLUSH is error, iRet = %d\n", __FUNCTION__, iRet);
        return HUPU_ERR;
    }

	return HUPU_OK;
}


