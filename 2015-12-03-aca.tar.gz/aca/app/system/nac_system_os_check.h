/*
 *
 * Part:        nac os_check swit.
 *
 * Author:      gdd
 *
 */
#ifndef __NAC_SYSTEM_OS_CHECK_H__
#define __NAC_SYSTEM_OS_CHECK_H__

#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_common_lib.h"
#include "nac_system_errorlog.h"
#include "nac_system_net_traffic.h"

/*
enum OS_CHECK_ACTION_TYPE
{
    APP_SHOW,
    APP_UPDATE
};
*/
extern unsigned int nac_app_os_check_swit;
HUPU_VOID nac_system_init_user_agent(HUPU_VOID);
HUPU_INT32 nac_system_debug_os_check_status(FILE* fp);
HUPU_INT32 nac_sys_write_os_check_swit_to_configure(FILE* fp);
HUPU_INT32 nac_sys_get_os_check_swit_from_configure(const HUPU_CHAR *file_path);
xmlDocPtr nac_system_parse_os_check(xmlDocPtr doc, HUPU_UINT16 cmd_id);
#endif
