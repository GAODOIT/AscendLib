#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_errorlog.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_get_sys_status.h"

/*
const char *get_load_average_cmd = "uptime | awk -F \"load average: \" '{print $2}'";
const char *get_memory_status_cmd = "free -m|grep \"Mem:\"|awk '{print $2 \";\" $3}'";
const char *get_total_memory_cmd = "free -m|grep \"Mem:\"|awk '{print $2 \";\"}'";
const char *get_used_memory_cmd  = "free -m|grep \"buffers/cache:\"|awk '{print $3}'";
const char *get_cpu_status_cmd = "/nac/script/app_cpu_rate.sh";
const char *get_disk_status_cmd = "df -ml | egrep \"/\" | awk '{total+= $2;used+=$3};END {print total \";\" used}'";
const char *get_data_partition_status_cmd = "df -ml |egrep \"/data\"|awk '{printf \"%s;%s\",$2,$3}'";
*/

//memory_status, disk_status, data_partition_status, --M
int nac_get_system_load_average_status(char *status_str)
{
    FILE *popen_fp;
	char *get_load_average_cmd = "uptime | awk -F \"load average: \" '{print $2}'";
	HUPU_CHAR buffer[BUFF_LEN] = "";

    popen_fp = popen(get_load_average_cmd, "r");
    fgets(buffer, BUFF_LEN, popen_fp);

    /*clean the line and '\n'*/
    clean_newline_character(buffer);
    memcpy(status_str, buffer, strlen(buffer));

    pclose(popen_fp);
    //SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->%s\n", __FUNCTION__, status_str);
    return HUPU_OK;
}

int nac_get_system_memory_status(char *status_str)
{
    FILE *total_fp, *used_fp;
	char *get_total_memory_cmd = "free -m|grep \"Mem:\"|awk '{print $2 \";\"}'";
	char *get_used_memory_cmd  = "free -m|grep \"buffers/cache:\"|awk '{print $3}'";
    HUPU_CHAR buffer[BUFF_LEN] = "";

	//get the total_memory;
    total_fp = popen(get_total_memory_cmd, "r");
    fgets(buffer, BUFF_LEN, total_fp);
    /*clean the line and '\n'*/
    clean_newline_character(buffer);
    memcpy(status_str, buffer, strlen(buffer));
	pclose(total_fp);

	//get the used_memory;
	memset(buffer, '\0', sizeof(buffer));
	used_fp = popen(get_used_memory_cmd, "r");
    fgets(buffer, BUFF_LEN, used_fp);
	/*clean the line and '\n'*/
    clean_newline_character(buffer);
	strncat(status_str, buffer, strlen(buffer));
    pclose(used_fp);

    return HUPU_OK;
}

int nac_get_system_cpu_status(char *status_str)
{
    FILE *popen_fp;
	char *get_cpu_status_cmd = "/nac/script/app_cpu_rate.sh";
    HUPU_CHAR buffer[BUFF_LEN] = "";

    popen_fp = popen(get_cpu_status_cmd, "r");
	if (popen_fp == NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->%s\n", __FUNCTION__, strerror(errno));
		return HUPU_ERR;
	}

    fgets(buffer, BUFF_LEN, popen_fp);
    /*clean the line and '\n'*/
    clean_newline_character(buffer);
    memcpy(status_str, buffer, strlen(buffer));

    pclose(popen_fp);

	return HUPU_OK;
}

int nac_get_system_disk_status(char *status_str)
{
    FILE *popen_fp;
	char *get_disk_status_cmd = "df -ml | egrep \"/\" | awk '{total+= $2;used+=$3};END {print total \";\" used}'";
    HUPU_CHAR buffer[BUFF_LEN] = "";

    popen_fp = popen(get_disk_status_cmd, "r");
    fgets(buffer, BUFF_LEN, popen_fp);

    /*clean the line and '\n'*/
    clean_newline_character(buffer);
    memcpy(status_str, buffer, strlen(buffer));

    pclose(popen_fp);
    return HUPU_OK;
}

int nac_get_system_data_partition_status(char *status_str)
{
    FILE *popen_fp;
	char *get_data_partition_status_cmd = "df -ml |egrep \"/data\"|awk '{printf \"%s;%s\",$2,$3}'";
    HUPU_CHAR buffer[BUFF_LEN] = "";

    popen_fp = popen(get_data_partition_status_cmd, "r");
    fgets(buffer, BUFF_LEN, popen_fp);

    /*clean the line and '\n'*/
    clean_newline_character(buffer);
    memcpy(status_str, buffer, strlen(buffer));

    pclose(popen_fp);
    return HUPU_OK;
}

xmlDocPtr nac_sys_parse_get_sys_status_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	//HUPU_INT32 iRet, error_id = 0;
	xmlDocPtr nac_doc = HUPU_NULL;
	xmlNodePtr cur_node;
	//xmlChar *szKey;
	HUPU_UINT8 action_type;

	cur_node = nac_xml_parse_get_action(doc, &action_type);
	if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	nac_free_xmlDoc(doc);
	switch (action_type)
	{
	case NAC_SHOW:
		nac_doc = nac_sys_ret_show_result(cmd_id, "get_sys_status");
		break;

	default:
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
	}

	return nac_doc;
}
