#include "include/precomp.h"

static struct kmem_cache *nac_knl_nat_cachep = NULL;
static struct hlist_head nat_hash_by_ip[NAT_HASH_MAP_SIZE];
LIST_HEAD(g_nac_knl_nat_list_head);

unsigned char nat_swit = NAT_DISABLE;

unsigned int nat_ip_num = 0;


void nac_knl_nat_set_swit(unsigned char swit)
{
	nat_swit = swit;
}

static inline int nac_knl_nat_get_hash_by_ip(unsigned long ip)
{
	return ip&(NAT_HASH_MAP_SIZE - 1);
}

NAC_KNL_NAT * __nac_knl_nat_find(unsigned long ip)
{
	struct hlist_node *n;
	NAC_KNL_NAT *u = NULL;
	int hash;

	hash = nac_knl_nat_get_hash_by_ip(ip);
	hlist_for_each_entry_rcu(u, n, &nat_hash_by_ip[hash], nat_ip)
	{
		if(ip == u->src_ip)
		{
            goto FOUND;
		}
	}

	u = NULL;
FOUND:
	return u;
}

int __nac_knl_nat_add(NAC_KNL_NAT *pst_nac_knl_nat)
{
    int hash_ip;

	hash_ip = nac_knl_nat_get_hash_by_ip(pst_nac_knl_nat->src_ip);
    hlist_add_head_rcu(&pst_nac_knl_nat->nat_ip, &nat_hash_by_ip[hash_ip]);
    list_add_tail_rcu(&pst_nac_knl_nat->nat_list, &g_nac_knl_nat_list_head);
    nat_ip_num++;
    return NAC_KNL_OK;
}

void nac_knl_nat_free_rcu(struct rcu_head *head)
{
	NAC_KNL_NAT *dying;

	dying = container_of(head, NAC_KNL_NAT, nat_rcu);

    nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_free_rcu-->delete :%d.%d.%d.%d\n",NIPQUAD(dying->src_ip));

	kmem_cache_free(nac_knl_nat_cachep, dying);
}


static inline void nac_knl_nat_put(NAC_KNL_NAT *u)
{
    call_rcu(&u->nat_rcu, nac_knl_nat_free_rcu);
}

int __nac_knl_nat_del(unsigned long src_ip, NAC_KNL_NAT *pst_nac_knl_nat_tmp)
{
    NAC_KNL_NAT *pst_nac_knl_nat;
    if(src_ip)
    {
        pst_nac_knl_nat = __nac_knl_nat_find(src_ip);
    }
    else
    {
        pst_nac_knl_nat = pst_nac_knl_nat_tmp;
    }

	if(!pst_nac_knl_nat)
	{
		goto OUT ;
	}
    nat_ip_num--;
	hlist_del_rcu(&pst_nac_knl_nat->nat_ip);
    list_del_rcu(&pst_nac_knl_nat->nat_list);

	nac_knl_nat_put(pst_nac_knl_nat);

OUT:
	return NAC_KNL_OK;
}
int nac_knl_nat_del(const NAC_KNL_NAT *pst_nac_knl_nat, int len)
{
    if(sizeof(NAC_KNL_NAT) != len)
    {
        printk("nac_knl_nat_del error\n");
        return -EINVAL;
    }
    //nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_del-->ip:%d.%d.%d.%d\n", NIPQUAD(pst_nac_knl_nat->src_ip));
    nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_del-->src_ip:%d.%d.%d.%d\n", NIPQUAD(pst_nac_knl_nat->src_ip));
	mutex_lock(&nac_knl_app_mutex);
    __nac_knl_nat_del(pst_nac_knl_nat->src_ip, NULL);
	mutex_unlock(&nac_knl_app_mutex);
	return NAC_KNL_OK;
}

int nac_knl_nat_add(NAC_KNL_NAT *pst_nac_knl_nat, int len)
{
	NAC_KNL_NAT *pst_nat_tmp;
	int err = 0;

	if(len != sizeof(*pst_nat_tmp))
	{
        printk("nac_knl_nat_add error\n");
		return -EINVAL;
	}

	mutex_lock(&nac_knl_app_mutex);

	err = -ENOMEM;
	pst_nat_tmp = kmem_cache_alloc(nac_knl_nat_cachep, GFP_KERNEL);
	if(!pst_nat_tmp)
	{
		goto DONE;
	}

	if (0 != copy_from_user(pst_nat_tmp, pst_nac_knl_nat, len))
    {
		err = -EACCES;
ERR:
		kmem_cache_free(nac_knl_nat_cachep, pst_nat_tmp);
		goto DONE;
	}

    nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_add-->src_ip:%d.%d.%d.%d\n", NIPQUAD(pst_nat_tmp->src_ip));
    __nac_knl_nat_del(pst_nat_tmp->src_ip, NULL);

	err = -ENOMEM;
	if(0 > __nac_knl_nat_add(pst_nat_tmp))
	{
		goto ERR;
	}

	err = 0;
DONE:
	mutex_unlock(&nac_knl_app_mutex);
	return err;
}

void nac_tcp_parse_options(struct sk_buff *skb, struct options_received_tcp *opt_rx,
                           u8 **hvpp, int estab, unsigned long *timestamp, char *shift)
{
    unsigned char *ptr;

    struct iphdr *iph = ip_hdr(skb);
    int hlen          = iph->ihl * 4;
    struct tcphdr *th = (struct tcphdr *)((char *)iph + hlen);//tcp_hdr(skb);
    int length        = (th->doff * 4) - sizeof(struct tcphdr);

    ptr = (unsigned char *)(th + 1);
    opt_rx->saw_tstamp = 0;
    while (length > 0)
    {
        int opcode = *ptr++;
        int opsize;
        switch (opcode)
        {
        case TCPOPT_EOL:
            return;
        case TCPOPT_NOP:    /* Ref: RFC 793 section 3.1 */
            length--;
            continue;
        default:
            opsize = *ptr++;
            if (opsize < 2) /* "silly options" */
                return;
            if (opsize > length)
                return; /* don't parse partial options */
            switch (opcode)
            {
            case TCPOPT_MSS:
                break;
            case TCPOPT_WINDOW:
                *shift = *ptr;
                break;
            case TCPOPT_TIMESTAMP:
                *timestamp = get_unaligned_be32(ptr);
                break;
            case TCPOPT_SACK_PERM:
                break;

            case TCPOPT_SACK:
                if ((opsize >= (TCPOLEN_SACK_BASE + TCPOLEN_SACK_PERBLOCK)) &&
                   !((opsize - TCPOLEN_SACK_BASE) % TCPOLEN_SACK_PERBLOCK) &&
                   opt_rx->sack_ok)
                {
                    TCP_SKB_CB(skb)->sacked = (ptr - 2) - (unsigned char *)th;
                }
                break;
#ifdef CONFIG_TCP_MD5SIG
            case TCPOPT_MD5SIG:
                /*
                 * The MD5 Hash has already been
                 * checked (see tcp_v{4,6}_do_rcv()).
                 */
                break;
#endif
            case TCPOPT_COOKIE:
                /* This option is variable length.
                 */
                switch (opsize)
                {
                case TCPOLEN_COOKIE_BASE:
                    /* not yet implemented */
                    break;
                case TCPOLEN_COOKIE_PAIR:
                    /* not yet implemented */
                    break;
                case TCPOLEN_COOKIE_MIN+0:
                case TCPOLEN_COOKIE_MIN+2:
                case TCPOLEN_COOKIE_MIN+4:
                case TCPOLEN_COOKIE_MIN+6:
                case TCPOLEN_COOKIE_MAX:
                    /* 16-bit multiple */
                    opt_rx->cookie_plus = opsize;
                    *hvpp = ptr;
                    break;
                default:
                    /* ignore option */
                    break;
                }
                break;
            }

            ptr += opsize-2;
            length -= opsize;
        }
    }
}

int nac_knl_isalnum(char ch)
{
    return ((ch <= '9' && ch >= '0')
            ||(ch <= 'z' && ch >= 'a')
            ||(ch <='Z' && ch >= 'A'));
}

int nac_knl_is_ch(char ch)
{
    //ch == ')'
    return (ch == '\r'
            || ch == '\n');
}

int nac_knl_nat_check_user_agent(char *payload, unsigned int ip)
{
    char ac_os[512] = "";
    int iRet = NAC_KNL_ERR;
    int pos_start = -1, len = 0;
    char *pc_start = NULL, *pc_end = NULL, *pc_tmp = NULL;
    pos_start = nac_knl_looup_string(payload + 5, USER_AGENT_KEY_WORD, user_agent);
    if(pos_start < 0)
    {
        return NAC_KNL_ERR;
    }
    pc_start = payload + 5 + pos_start + strlen(USER_AGENT_KEY_WORD);
    pc_tmp   = pc_start;
    while(pc_tmp != '\n')
    {
        if(nac_knl_is_ch(*pc_tmp))
        {
            break;
        }
        pc_tmp++;
    }
    len = pc_tmp - pc_start;
    if(len <= 0
        || len >= sizeof(ac_os))
    {
        return NAC_KNL_ERR;
    }
    memset(ac_os, '\0', sizeof(ac_os));
    memcpy(ac_os, pc_start, len);

    /*
    if(strstr(ac_os, ".NET"))
    {
        return NAC_KNL_ERR;
    }
    */

    iRet = nac_knl_wm_search(ac_os, pst_user_agent_wm, nac_knl_user_agent_wm, "user_agent");
    nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_check_user_agent-->src_ip = %d.%d.%d.%d, ac_os=%s, user_agent=%d\n", NIPQUAD(ip), ac_os, iRet);
    if(iRet <= 0)
    {
        return NAC_KNL_ERR;
    }
    return iRet;
}

void nac_knl_nat_check(struct sk_buff *skb, char is_agent_flag, unsigned int *agent_cls)
{
	struct iphdr *iph   = ip_hdr(skb);
    struct tcphdr *tcph = NULL;
    char *pc_tcp_option = NULL, *pc_tmp = NULL;

    int plen = 0, hlen = 0, length, cls = 0, iRet = 0;
    char *payload = NULL;
    char flag = 0;

    unsigned long tmp       = 0;
    unsigned long timestamp = 0;
    unsigned short window   = 0;

    char shift = -1;

    NAC_KNL_NAT *pst_nac_knl_nat_tmp = NULL;
    NAC_KNL_NAT st_nac_knl_nat_tmp;
    unsigned long now_time = get_seconds();

    u8 *hash_location;
    struct options_received_tcp tcp_opt;

    hlen = iph->ihl * 4;
    if(IPPROTO_TCP == iph->protocol)
    {
        tcph = (struct tcphdr *)((char *)iph + hlen);

        if(tcph->syn == 1)
        {
            window = tcph->window;
            nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_check-->%d.%d.%d.%d===>%d.%d.%d.%d, window = %d\n", NIPQUAD(iph->saddr), NIPQUAD(iph->daddr), ntohs(window));
        }

        plen = ntohs(iph->tot_len) - hlen - (tcph->doff * 4);
        payload = (unsigned char *)tcph + tcph->doff*4;
        if(plen >= 100
            && ((memcmp(payload, "GET ", 4) == 0)
                ||(memcmp(payload, "POST ", 5) == 0)))
        {
            flag = 1;
        }
    }
    if(is_agent_flag)
    {
        if(flag)
        {
            cls = nac_knl_nat_check_user_agent(payload, iph->saddr);
            if(cls <= 0)
            {
                cls = 0;
            }
            *agent_cls = cls;
        }
        return;
    }

    pst_nac_knl_nat_tmp = __nac_knl_nat_find(iph->saddr);
    if(pst_nac_knl_nat_tmp)
    {
        pst_nac_knl_nat_tmp->last_time = now_time;

        if(pst_nac_knl_nat_tmp->is_nat)
        {
            return;
        }

        if(IPPROTO_TCP == iph->protocol)
        {
            if(!pst_nac_knl_nat_tmp->ttl)
            {
    			pst_nac_knl_nat_tmp->ttl = iph->ttl;
            }
            else
            {
                if(pst_nac_knl_nat_tmp->ttl != iph->ttl)
                {
                    nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_check-->ttl found, %d.%d.%d.%d===>%d.%d.%d.%d, protocol = %d, old ttl = %d, new ttl = %d\n", NIPQUAD(iph->saddr), NIPQUAD(iph->daddr), iph->protocol, pst_nac_knl_nat_tmp->ttl, iph->ttl);
                    pst_nac_knl_nat_tmp->ttl = iph->ttl;
                    if(pst_nac_knl_nat_tmp->ttl_count < 10)
                    {
						pst_nac_knl_nat_tmp->ttl_count++;
                        if(pst_nac_knl_nat_tmp->ttl_count == 1)
                        {
                            pst_nac_knl_nat_tmp->ttl_time = now_time;
                        }
                    }
                    else
                    {
                        return;
                    }
                }
            }
        }
        /*
        if(nac_mode == NAC_MVG_MODE)
        {
            if(iph->ttl != 64
               && iph->ttl != 128
               && iph->ttl != 255)
            {
                pst_nac_knl_nat_tmp->ttl_count = 3;
                pst_nac_knl_nat_tmp->is_nat    = 1;
                nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_check-->ttl found, %d.%d.%d.%d===>%d.%d.%d.%d, ttl = %d, protocol = %d\n", NIPQUAD(iph->saddr), NIPQUAD(iph->daddr), iph->ttl, iph->protocol);
                return;
            }
        }
        */

        if(IPPROTO_TCP == iph->protocol
           && tcph->syn == 1)
        {
            nac_tcp_parse_options(skb, &tcp_opt, &hash_location, 0, &timestamp, &shift);
			/*
            if(shift != -1
                && pst_nac_knl_nat_tmp->shift != shift)
            {
                pst_nac_knl_nat_tmp->shift = shift;
                if(pst_nac_knl_nat_tmp->shift_count < 2)
                {
                    pst_nac_knl_nat_tmp->shift_count++;
                    if(pst_nac_knl_nat_tmp->shift_count == 1)
                    {
                        pst_nac_knl_nat_tmp->shift_time = now_time;
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
			*/

            if(window && timestamp)
            {
                if(pst_nac_knl_nat_tmp->window)
                {
                    pst_nac_knl_nat_tmp->window = window;
                }
                else if(window != pst_nac_knl_nat_tmp->window)
                {
                    pst_nac_knl_nat_tmp->window = window;
                    if(pst_nac_knl_nat_tmp->window_count < 2)
                    {
                        pst_nac_knl_nat_tmp->window_count++;
                        if(pst_nac_knl_nat_tmp->window_count == 1)
                        {
                            pst_nac_knl_nat_tmp->window_time = now_time;
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        return;
                    }
                }
            }

            if(pst_nac_knl_nat_tmp->time_count == 3)
            {
                pst_nac_knl_nat_tmp->timestamp  = timestamp;
                pst_nac_knl_nat_tmp->time_count = 0;
            }
            else
            {
                if((pst_nac_knl_nat_tmp->timestamp == 0 && timestamp != 0)
                    || (pst_nac_knl_nat_tmp->timestamp != 0 && timestamp == 0))
                {
					pst_nac_knl_nat_tmp->timestamp = timestamp;
                    if(pst_nac_knl_nat_tmp->time_count < 2)
                    {
                        pst_nac_knl_nat_tmp->time_count++;
                        if(pst_nac_knl_nat_tmp->time_count == 1)
                        {
                            pst_nac_knl_nat_tmp->timestamp_time = now_time;
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        return;
                    }
                }
                else if(pst_nac_knl_nat_tmp->timestamp > 0
                        && timestamp > 0)
                {
                     tmp = (nac_mode == NAC_MVG_MODE?100000:200000);

                    if(time_after(pst_nac_knl_nat_tmp->timestamp, tmp + timestamp)
                        || time_after(timestamp, tmp + pst_nac_knl_nat_tmp->timestamp))
                    {
    					pst_nac_knl_nat_tmp->timestamp = timestamp;
                        if(pst_nac_knl_nat_tmp->time_count < 2)
                        {
                            pst_nac_knl_nat_tmp->time_count++;
                            if(pst_nac_knl_nat_tmp->time_count == 1)
                            {
                                pst_nac_knl_nat_tmp->timestamp_time = now_time;
                            }
                            else
                            {
                                return;
                            }
                        }
                        else
                        {
                            return;
                        }
                    }
                }
            }
            pst_nac_knl_nat_tmp->timestamp = timestamp;
        }
/*
		if(flag)
        {
            cls = nac_knl_nat_check_user_agent(payload, iph->saddr);
            if(cls > 0)
            {
                if(!pst_nac_knl_nat_tmp->agent)
                {
                    pst_nac_knl_nat_tmp->agent = cls;
                }
                if((cls < WINDOWSNT && pst_nac_knl_nat_tmp->timestamp == 0)
                    || pst_nac_knl_nat_tmp->agent != cls)
                {
                    pst_nac_knl_nat_tmp->agent = cls;
                    if(pst_nac_knl_nat_tmp->agent_count < 2)
                    {
                        pst_nac_knl_nat_tmp->agent_count++;
                        if(pst_nac_knl_nat_tmp->agent_count == 1)
                        {
                            pst_nac_knl_nat_tmp->agent_time = now_time;
                        }
                        else
                        {
                            nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_check-->user-agent found, %d.%d.%d.%d===>%d.%d.%d.%d, old cls = %d, new cls = %d, pst_nac_knl_nat_tmp->timestamp = %u\n", NIPQUAD(iph->saddr), NIPQUAD(iph->daddr), pst_nac_knl_nat_tmp->agent, cls, pst_nac_knl_nat_tmp->timestamp);
                            return;
                        }
                    }
                }
            }
        }
*/

/*
        if((iph->ttl) > 120)
        {
            if((pst_nac_knl_nat_tmp->id + 1) != iph->id)
            {
                if(pst_nac_knl_nat_tmp->id_count < 3)
                {
                    pst_nac_knl_nat_tmp->id_count++;
                    if(pst_nac_knl_nat_tmp->id_count == 1)
                    {
                       pst_nac_knl_nat_tmp->id_find_time_first = now_time;
                    }
                }
                else
                {
                    return;
                }
                pst_nac_knl_nat_tmp->id = iph->id;
            }
        }
*/
    }

    else
    {
        NAC_KNL_USER_MSG st_user_new;
        st_user_new.src_ip  = iph->saddr;
        //st_user_new.result  = iph->id;
        st_user_new.vlan_id = (IPPROTO_ICMP != iph->protocol?iph->ttl:0);
        st_user_new.dept_id = now_time;
        st_user_new.tmp_id  = 0;
        st_user_new.user_type = 3; //init time_count

        nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_check-->src_ip = %d.%d.%d.%d, protocol = %d, ttl = %d\n", NIPQUAD(iph->saddr), iph->protocol, iph->ttl);
        nac_knl_netlink_user_send(&st_user_new, sizeof(NAC_KNL_USER_MSG), NAC_NETLINK_NAT_NEW);
    }
}

void nac_knl_nat_timeout(unsigned long now, char *pc_time)
{
	NAC_KNL_NAT *pst_nat;
    NAC_KNL_USER_MSG st_user_new;

	if(now & 1)
	{
		return;
	}
    nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_timeout-->0\n");
    rcu_read_lock();
    list_for_each_entry_rcu(pst_nat, &g_nac_knl_nat_list_head, nat_list)
    {
        if(time_before((unsigned long)300 + pst_nat->last_time, now))
        {
            st_user_new.src_ip = pst_nat->src_ip;
            nac_knl_netlink_user_send(&st_user_new, sizeof(NAC_KNL_USER_MSG), NAC_NETLINK_NAT_TIMEOUT);
            nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_timeout-->src_ip = %d.%d.%d.%d\n", NIPQUAD(pst_nat->src_ip));
            continue;
        }
/*
        if(pst_nat->first_timestamp)
        {
            if(pst_nat->time_count == 1)
            {
                pst_nat->is_nat = 1;
                nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_timeout-->found share by timestamp, src_ip = %d.%d.%d.%d\n", NIPQUAD(pst_nat->src_ip));
            }
        }
*/
        if(pst_nat->ttl_count == 10)
        {
            if(time_before(now, pst_nat->ttl_time + (unsigned long)NAT_TIME))
            {
                pst_nat->is_nat = 1;
                nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_timeout-->found share by ttl, src_ip = %d.%d.%d.%d\n", NIPQUAD(pst_nat->src_ip));
            }
            else
            {
                pst_nat->ttl_count = 0;
            }
        }


        if(pst_nat->time_count == 2)
        {
            if(time_before(now, pst_nat->timestamp_time + (unsigned long)NAT_TIME))
            {
                pst_nat->is_nat = 1;
                nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_timeout-->found share by timestamp, src_ip = %d.%d.%d.%d\n", NIPQUAD(pst_nat->src_ip));
            }
            else
            {
                pst_nat->time_count = 0;
            }
        }

        if(pst_nat->agent_count == 2)
        {
            if(time_before(now, pst_nat->agent_time + (unsigned long)NAT_TIME))
            {
                pst_nat->is_nat = 1;
                nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_timeout-->found share by agent, src_ip = %d.%d.%d.%d\n", NIPQUAD(pst_nat->src_ip));
            }
            else
            {
                pst_nat->agent_count = 0;
            }
        }

        if(pst_nat->window_count == 2)
        {
            if(time_before(now, pst_nat->window_time + (unsigned long)NAT_TIME))
            {
                pst_nat->is_nat = 1;
                nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_timeout-->found share by window, src_ip = %d.%d.%d.%d\n", NIPQUAD(pst_nat->src_ip));
            }
            else
            {
                pst_nat->window_count = 0;
            }
        }

        if(pst_nat->shift_count == 2)
        {
            if(time_before(now, pst_nat->shift_time + (unsigned long)NAT_TIME))
            {
                pst_nat->is_nat = 1;
                nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_timeout-->found share by shift, src_ip = %d.%d.%d.%d\n", NIPQUAD(pst_nat->src_ip));
            }
            else
            {
                pst_nat->shift_count = 0;
            }
        }
/*
        if(pst_nat->id_count == 3)
        {
            if(time_before(now, (unsigned long)20 + pst_nat->id_find_time_first))//20 in
            {
                pst_nat->is_nat = 1;
                nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_timeout-->found share by id, src_ip = %d.%d.%d.%d\n", NIPQUAD(pst_nat->src_ip));
            }
            else
            {
                pst_nat->id_count           = 0;
                pst_nat->id_find_time_first = 0;
                pst_nat->is_nat             = 0;
                //continue;
            }
        }
*/
        if(pst_nat->is_nat == 1)
        {
            if(time_after(now, (unsigned long)NAT_TIME + pst_nat->time))
            {
                st_user_new.src_ip = ntohl(pst_nat->src_ip);
                nac_knl_netlink_user_send(&st_user_new, sizeof(NAC_KNL_USER_MSG), NAC_NETLINK_NAT_FOUND);
                pst_nat->time       = now;
                //pst_nat->id_flag    = 0;
                pst_nat->agent_count = 0;
                pst_nat->window_count = 0;
                pst_nat->shift_count  = 0;
                pst_nat->time_count = 0;
                pst_nat->ttl_count  = 0;
                pst_nat->is_nat     = 0;
                //pst_nat->id_find_time_first = 0;
                nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_nat_timeout-->send message found src_ip = %d.%d.%d.%d\n", NIPQUAD(pst_nat->src_ip));
            }
        }
    }
	rcu_read_unlock();
}


int nac_knl_nat_init(void)
{
    int i;
    for(i = 0; i < NAT_HASH_MAP_SIZE; i++)
	{
		INIT_HLIST_HEAD(&nat_hash_by_ip[i]);
	}

    nac_knl_nat_cachep = kmem_cache_create("nac_knl_nat_cachep", sizeof(NAC_KNL_NAT), 0, 0, NULL);
    if (!nac_knl_nat_cachep)
	{
		return NAC_KNL_ERR;
	}
    printk("nac_knl_nat_init->Cache object size is %d\n", kmem_cache_size(nac_knl_nat_cachep));

	return NAC_KNL_OK;
}

int nac_knl_nat_flush(void)
{
	NAC_KNL_NAT *dying, *tmp;

    mutex_lock(&nac_knl_app_mutex);

	list_for_each_entry_safe(dying, tmp, &g_nac_knl_nat_list_head, nat_list)
    {
        __nac_knl_nat_del(0, dying);
	}
    mutex_unlock(&nac_knl_app_mutex);
	return 0;
}

void nac_knl_nat_exit(void)
{
    nac_knl_nat_flush();
    synchronize_rcu();
    if(nac_knl_nat_cachep)
    {
		kmem_cache_destroy(nac_knl_nat_cachep);
    }
	nac_knl_nat_cachep = NULL;
}

