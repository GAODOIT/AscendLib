/*
 *
 * Part:        nac framwork.
 *
 * Author:      ydh
 *
 */

#include "include/precomp.h"

unsigned short vlan_ago_after_map_table[VLAN_MAX_RANGE]; //vlan_ago_after_map_table[0] no use

unsigned char vlan_in_index[VLAN_MAX_RANGE];
unsigned char vlan_out_index[VLAN_MAX_RANGE];

int nac_knl_mvg(struct sk_buff *skb, unsigned short vlan_id)
{
    int nac_ret = NAC_KNL_ERR;
    struct net_device *vlan_dev;

    if(!skb
        || !skb->dev
        || vlan_ago_after_map_table[vlan_id] == 0)
    {
        return NAC_KNL_ERR;
    }

    if(skb->dev->ifindex == st_in_out_eth.us_in_index
        && vlan_in_index[vlan_id] == 0)
    {
        return NAC_KNL_ERR;
    }
    else if(skb->dev->ifindex == st_in_out_eth.us_out_index
            && vlan_out_index[vlan_id] == 0)
    {
        return NAC_KNL_ERR;
    }
    else
    {

    }

    nac_ret = nac_mvg_pbr_check(skb, vlan_id);
    if(nac_ret == NAC_FORWARD)
    {
        if(skb->dev->ifindex == st_in_out_eth.us_in_index
            && pst_out_interface[0])
        {
            skb->dev = pst_out_interface[0];
        }
        else if(skb->dev->ifindex == st_in_out_eth.us_out_index
                && pst_in_interface[0])
        {
            skb->dev = pst_in_interface[0];
        }
        else
        {
            return NAC_KNL_ERR;
        }
        skb->vlan_tci = vlan_ago_after_map_table[vlan_id] | VLAN_TAG_PRESENT;
        if(!skb->dev)
        {
           return NAC_KNL_ERR;
        }
        nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_knl_mvg-->forward, vlan_id = %u, skb->dev->name = %s\n", vlan_id, skb->dev->name);

        skb_forward_csum(skb);
        skb_push(skb, ETH_HLEN);
        dev_queue_xmit(skb);
        return NAC_KNL_OK;
    }

    if(nac_ret == NAC_REDIRECT)
    {
        return NAC_KNL_OK;
    }
    return NAC_KNL_ERR;
}



int nac_knl_mvg_init(void)
{
    int i;

    spin_lock_bh(&nac_knl_vlan_map);
    for(i = 0; i < VLAN_MAX_RANGE; i++)
    {
        vlan_ago_after_map_table[i] = 0;
        vlan_in_index[i]  = 0;
        vlan_out_index[i] = 0;
    }
    spin_unlock_bh(&nac_knl_vlan_map);
	return NAC_KNL_OK;
}

void nac_knl_mvg_exit(void)
{

}


