#ifndef	__NAC_KNL_USER_H__
#define	__NAC_KNL_USER_H__

extern struct mutex nac_knl_app_mutex;

#define	USER_HASH_MAP_SIZE (2 * 1024)

#define NAC_MAC_HASH_BITS 10
#define NAC_MAC_HASH_SIZE (2 << NAC_MAC_HASH_BITS)


/* user state */
#define USER_STATE_NETAPP_CHECK           1
#define USER_STATE_IS_NETAPP 	          2
#define USER_STATE_IS_ISOLATION_AUTH_FAIL 4
#define USER_STATE_IS_ISOLATION           8
#define USER_STATE_IS_NETAPP_EXCEPT       16

/*Usr Auth Type*/
typedef enum
{
    NAC_KNL_USR_TMP = 0,
	NAC_KNL_USR_WEB = 1,
	NAC_KNL_USR_GUEST,
	NAC_KNL_USR_CLIENT,
	NAC_KNL_USR_SSLVPN,
	NAC_KNL_USR_AUTO,
	NAC_KNL_USR_VPN,
	NAC_KNL_USR_IOS_VPN,
	NAC_KNL_USR_IPAD_IPHONE,
	NAC_KNL_USR_ANDROID,
	NAC_KNL_USR_ANDROID_VPN,
}NAC_KNL_USR_AUTH_TYPE;

////////////////
/*typedef enum
{
	NAC_KNL_USR_TIME_OUT = 1,
	NAC_KNL_USR_NO_NETAPP,
	NAC_KNL_USR_TIME_OUT_TMP,
}NAC_KNL_USR_DELETE_ENUM;
*/
////////////////

typedef enum
{
	NAC_KNL_NETAPP_SET_EXCEPT_STATUS = 1,
	NAC_KNL_NETAPP_CLR_EXCEPT_STATUS,
}NAC_KNL_NETAPP_STATUS_TYPE;

/*State */
enum
{
	NAC_KNL_USR_F_INIT = 1,
	NAC_KNL_USR_F_CERT,
	NAC_KNL_USR_F_NOCERT,
	NAC_KNL_USR_F_CERT6006,
	NAC_KNL_USR_F_VALID,
	NAC_KNL_USR_F_DYING,   	/* kick out of online list */
	NAC_KNL_USR_F_BRK, /* tpn_user died */
	NAC_KNL_USR_F_SYNC,
	NAC_KNL_USR_F_NULL,
};

typedef struct NAC_KNL_USER_OBJECT_STRU
{
	struct list_head  user_list;
	struct hlist_node user_ip;
    struct hlist_node user_id;
    struct hlist_node user_mac;
	struct rcu_head   user_rcu;

	atomic_t refcnt;

	/* Common information */
	unsigned long	ip;				    // identied by ip
	unsigned long	id;				    // id context
	unsigned long	gid;				// group id context

	unsigned long state:16, other:16;	// flags
	unsigned long tpnct_max_tcp;
    unsigned long tpnct_max_udp;
	unsigned short tc_mark[2];		    /*tc class object id*/

	unsigned long nr_tpnct_udp;		    // current  udp conntracks
    unsigned short tmp_count;		    //
    unsigned short net_app_check;        /* 1-->check  0-->no check */

    unsigned short user_type;           //tmp=0,web=1,guest=2.
    unsigned short os_type;             //0-6
	char mac[6];

	unsigned long last_time;		// last visit timestamp
	unsigned long net_app_time;		//last net_app packet visit timestamp
	unsigned long login_time;

    unsigned int isolation_num;
    unsigned int isolation_zone[16]; //max 16
}NAC_KNL_USER_OBJECT;

typedef struct NAC_KNL_USER_MSG_STRU
{
    unsigned int    cmd;
	unsigned long	src_ip;		/* IP��ַ1 */
	unsigned long	dst_ip;		/* IP��ַ2 */
	unsigned char	src_mac[6];	/* MAC��ַ1 */
	unsigned char	dst_mac[6];	/* MAC��ַ2 */
	int			    tmp_id;		/* ��ʱ�û�ID��Ӧ�ò��豣���ֵ*/
    unsigned int	dept_id;    /* ��ID */
    unsigned short  result;     //NAC_KNL_USR_DELETE_ENUM
    unsigned short  vlan_id;
    unsigned short  user_type;
    unsigned short  os_type;
}NAC_KNL_USER_MSG;

extern struct list_head g_nac_knl_user_list_head;
extern int usertimeout;

int nac_knl_user_add(const NAC_KNL_USER_OBJECT *pst_usr, int len);
int nac_knl_user_flush(void);
int nac_knl_user_del(const NAC_KNL_USER_OBJECT *pst_usr, int len);
int nac_knl_user_set_status(const NAC_KNL_USER_OBJECT *pst_usr, int len, int flag);
int nac_knl_user_clear_netapp_except_status(void);
void nac_knl_user_timeout(unsigned long now, char *pc_time);
void nac_knl_user_os_type_check(NAC_KNL_USER_OBJECT *pst_usr, char flag);
int nac_knl_user_get_hash_by_mac(const unsigned char *mac);
NAC_KNL_USER_OBJECT * __nac_knl_user_find(unsigned long ip, unsigned long ip2, unsigned char flag);
NAC_KNL_USER_OBJECT * __nac_knl_user_find_by_mac(const unsigned char *mac, unsigned char flag);

int nac_knl_user_init(void);
void nac_knl_user_exit(void);

#endif

