#ifndef	__NAC_KNL_PROC_H__
#define	__NAC_KNL_PROC_H__

extern int nac_knl_debug_modules;
extern int nac_knl_audit_memsize;
extern int nac_knl_pass_switch;
extern int nac_knl_switch;



#define __nac_list_for_each_rcu(pos, head) \
	for (pos = rcu_dereference((head)->next); \
		pos != (head); \
		pos = rcu_dereference(pos->next))


int nac_knl_proc_init(void);
void nac_knl_proc_exit(void);

#endif

