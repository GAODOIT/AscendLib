/*
 *
 * Part:        nac framwork.
 *
 * Author:      ydh
 *
 */

#include "include/precomp.h"


int nac_knl_debug_modules __read_mostly = 0;
int nac_knl_audit_memsize __read_mostly = 67108864;
int nac_knl_pass_switch   __read_mostly = 0;
int nac_knl_switch   __read_mostly      = 0;

static unsigned short user_number = 0;

static ctl_table nac_knl_proc_table[] =
{
	{
		.procname	= "nac_knl_debug_flags",
		.data		= &nac_knl_debug_modules,
		.maxlen		= sizeof(int),
		.mode		= 0644,
		.proc_handler	= proc_dointvec,
	},
	{
		.procname	= "nac_knl_audit_memsize",
		.data		= &nac_knl_audit_memsize,
		.maxlen		= sizeof(int),
		.mode		= 0644,
		.proc_handler	= proc_dointvec,
	},
	{
		.procname	= "nac_knl_switch_flags",
		.data		= &nac_knl_switch,
		.maxlen		= sizeof(int),
		.mode		= 0644,
		.proc_handler	= proc_dointvec,
	},
	{
		.procname	= "nac_knl_pass_switch_flags",
		.data		= &nac_knl_pass_switch,
		.maxlen		= sizeof(int),
		.mode		= 0644,
		.proc_handler	= proc_dointvec,
	},
	{
		.procname	= "nac_knl_user_timeout",
		.data		= &usertimeout,
		.maxlen		= sizeof(int),
		.mode		= 0644,
		.proc_handler	= proc_dointvec,
	},

	{	},
};

static struct ctl_path nac_proc_path[] = {
	{ .procname = "net"},
	{ }
};
static struct ctl_table_header *nac_sysctl_header;

struct list_head *nac_knl_user_list_start(struct list_head *head, loff_t pos)
{
	struct list_head *lh;
	__nac_list_for_each_rcu(lh, head)
	if (pos-- == 0)
	{
		return lh;
	}

	return NULL;
}

static struct list_head *nac_knl_get_idx(struct seq_file *seq, loff_t pos, struct list_head *head)
{
	return nac_knl_user_list_start(head, pos);
}

static void *nac_knl_user_seq_start(struct seq_file *seq, loff_t *pos)
__acquires(RCU)
{
    rcu_read_lock();
    if(*pos == 0)
    {
        return SEQ_START_TOKEN;
    }
	return nac_knl_get_idx(seq, *pos, &g_nac_knl_user_list_head);
}

static void *nac_knl_user_seq_next(struct seq_file *s, void *v, loff_t *pos)
{
    if(v != SEQ_START_TOKEN)
    {
        (*pos)++;
    }
	return nac_knl_get_idx(s, *pos, &g_nac_knl_user_list_head);
}

static void nac_knl_user_seq_stop(struct seq_file *seq, void *v)
__releases(RCU)
{
    if(!v)
    {
        seq_printf(seq, "number = %u\t\n", user_number);
    }

	rcu_read_unlock();
}
static int nac_knl_user_seq_show(struct seq_file *seq, void *v)
{
	NAC_KNL_USER_OBJECT *user;
    char net_app_flag = 0;
    unsigned long ip_tmp;

    if(v == SEQ_START_TOKEN)
    {
        seq_printf(seq, "os_type \t user_type \t user_id \t dept_id \t user_ip \t     user_mac \t\t hash \t status \t isolation_num \t\t\t net_app \t net_app_time \t  login_time \t last_time \t\n");
        user_number  = 0;
        seq->private = v;
        return NAC_KNL_OK;
    }
	if(seq->private != v)
    {
        user_number++;
    }
    seq->private = v;
	user = list_entry((struct list_head *)v, typeof(*user), user_list);
    ip_tmp = htonl(user->ip);
    net_app_flag = (user->state & USER_STATE_IS_NETAPP?1:0);
    int hash = nac_knl_user_get_hash_by_mac(user->mac);
	seq_printf(seq,
            "%5d \t %5d \t %12lu \t %12u \t %8d.%d.%d.%d \t %02X-%02X-%02X-%02X-%02X-%02X \t %d \t %3lu \t %u(%u;%u;%u;%u;%u;%u;%u;%u;%u;%u;%u;%u;%u;%u;%u;%u) \t %4d \t %19u \t %5u \t %u \t\n",
            user->os_type,
            user->user_type,
            user->id,
            user->gid,
			NIPQUAD(ip_tmp),
			MAC_FORMAT(user->mac),
			hash,
			user->state,
            user->isolation_num, user->isolation_zone[0], user->isolation_zone[1], user->isolation_zone[2], user->isolation_zone[3],
    		user->isolation_zone[4], user->isolation_zone[5], user->isolation_zone[6], user->isolation_zone[7],user->isolation_zone[8],
    		user->isolation_zone[9], user->isolation_zone[10], user->isolation_zone[11],user->isolation_zone[12], user->isolation_zone[13],
    		user->isolation_zone[14], user->isolation_zone[15],
            net_app_flag,
            user->net_app_time,
			user->login_time,
			user->last_time);
/*
    int aa;
    char str1[100] = "";
    char str2[100] = "";
    char user_str[100] = "1:00-21-85-09-fb-82:33-21-99-09-fb-82";
    sscanf(user_str, "%d:%[^:]:%[^:]", &aa, str1,str2);
    printf("------------------%d %s %s\n", aa, str1, str2);
*/
	return NAC_KNL_OK;
}


static const struct seq_operations nac_knl_user_seq_ops =
{
	.start  = nac_knl_user_seq_start,
	.next   = nac_knl_user_seq_next,
	.stop   = nac_knl_user_seq_stop,
	.show   = nac_knl_user_seq_show,
};

static int nac_knl_user_seq_open(struct inode *inode, struct file *file)
{
	return seq_open(file, &nac_knl_user_seq_ops);
}

static const struct file_operations nac_knl_user_seq_fops =
{
	.owner		= THIS_MODULE,
	.open		= nac_knl_user_seq_open,
	.read		= seq_read,
	.llseek		= seq_lseek,
	.release	= seq_release,
};

static int nac_knl_show_info(char *page, char **start, off_t off,
				             int count, int *eof, void *data)
{
	nac_knl_policy_show();
	return NAC_KNL_OK;
}

static int nac_knl_create_procfs(void)
{
	struct proc_dir_entry *proc_nac_root = NULL;
	struct proc_dir_entry *ent;

	proc_nac_root = proc_mkdir("nac", 0);
	if(!proc_nac_root)
	{
		return NAC_KNL_ERR;
	}

	ent = proc_create("nac_knl_user_online", S_IFREG|S_IRUGO, proc_nac_root, &nac_knl_user_seq_fops);
	if(!ent)
	{
		return NAC_KNL_ERR;
	}
    ent = create_proc_read_entry("nac_knl_show_policy", S_IRUGO, proc_nac_root, nac_knl_show_info, NULL);
    if(!ent)
	{
		return NAC_KNL_ERR;
	}
	return NAC_KNL_OK;
}

int nac_knl_proc_init(void)
{
    if(nac_knl_create_procfs() < 0)
    {
		return NAC_KNL_ERR;
	}
	nac_sysctl_header = register_sysctl_paths(nac_proc_path, nac_knl_proc_table);
	if(nac_sysctl_header == NULL)
    {
		printk(KERN_WARNING "ktpn_sysctl: can't register to sysctl.\n");
		return -ENOMEM;
	}

	return NAC_KNL_OK;
}

void nac_knl_proc_exit(void)
{
    printk("nac_knl_proc_exit\n");
	unregister_sysctl_table(nac_sysctl_header);
    remove_proc_entry("nac/nac_knl_user_online", NULL);
    remove_proc_entry("nac/nac_knl_show_policy", NULL);
    remove_proc_entry("nac", NULL);
}

