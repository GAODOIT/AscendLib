/*
 *
 * Part:        nac framwork.
 *
 * Author:      ydh
 *
 */

#include "include/precomp.h"

static struct kmem_cache *nac_knl_domain_cachep = NULL;

static DEFINE_SPINLOCK(nac_knl_domain_spinlock);

LIST_HEAD(g_nac_knl_domain_list_head);
static struct hlist_head domain_hash_online_by_ip[DOMAIN_HASH_MAP_SIZE];

atomic_t g_domain_number = {0};


static unsigned int mac_salt;
int nac_knl_domain_get_hash_by_mac(const unsigned char *mac) //br_mac_hash
{
	unsigned int key = get_unaligned((unsigned int *)(mac + 2));
	return jhash_1word(key, mac_salt) & (NAC_MAC_HASH_SIZE - 1);
}

void nac_knl_domain_timeout(unsigned long now, char *pc_time)
{
	NAC_KNL_DOMAIN_OBJECT *pst_domain;
    NAC_KNL_USER_MSG st_user_new;
	int  rate, ubytes = 0, dbytes = 0;
    unsigned long i, j;

	if(now & 1)
	{
		return;
	}
    nac_knl_debug(NAC_KNL_MODULE_DOMAIN, "nac_knl_domain_timeout-->0\n");
    rcu_read_lock();
    list_for_each_entry_rcu(pst_domain, &g_nac_knl_domain_list_head, domain_list)
    {
        if(time_before((unsigned long)5 + pst_domain->last_time, now))
        {
            st_user_new.src_ip  = pst_domain->src_ip;
            st_user_new.result  = pst_domain->src_port;
            nac_knl_netlink_user_send(&st_user_new, sizeof(NAC_KNL_USER_MSG), NAC_NETLINK_DOMAIN_TIMEOUT);
            nac_knl_debug(NAC_KNL_MODULE_DOMAIN, "nac_knl_domain_timeout-->src_ip = %d.%d.%d.%d, src_port = %d\n",  NIPQUAD(pst_domain->src_ip), pst_domain->src_port);
        }
    }
	rcu_read_unlock();
}

static inline int nac_knl_domain_get_hash_by_ip(unsigned long ip)
{
	return ip&(DOMAIN_HASH_MAP_SIZE - 1);
}


static int nac_knl_domain_insert(NAC_KNL_DOMAIN_OBJECT *pst_domain)
{
	int hash_ip, hash_mac;

	hash_ip  = nac_knl_domain_get_hash_by_ip(pst_domain->src_ip);
	pst_domain->last_time  = get_seconds();
    atomic_set(&pst_domain->refcnt, 1);


	hlist_add_head_rcu(&pst_domain->domain_ip, &domain_hash_online_by_ip[hash_ip]);
	list_add_tail_rcu(&pst_domain->domain_list, &g_nac_knl_domain_list_head);
    /*
    nac_knl_debug(NAC_KNL_MODULE_DOMAIN,
                 "nac_knl_domain_insert-->add a domain %d.%d.%d.%d(%d, %lu, %lu, %lu, %lu, %lu, usType=%u, osType=%u), hash_mac = %d\n",
			     NIPQUAD(pst_user->ip), pst_user->state, pst_user->other, pst_user->id, pst_user->gid,
	             pst_user->tpnct_max_tcp, pst_user->tpnct_max_udp, pst_user->user_type, pst_user->os_type, hash_mac);
	*/
    atomic_inc(&g_domain_number);
	return NAC_KNL_OK;
}


int nac_knl_domain_init(void)
{
    int i;

	for(i = 0; i < DOMAIN_HASH_MAP_SIZE; i++)
	{
		INIT_HLIST_HEAD(&domain_hash_online_by_ip[i]);
	}

   nac_knl_domain_cachep = kmem_cache_create("nac_knl_domain_cache", sizeof(NAC_KNL_DOMAIN_OBJECT), 0, 0, NULL);
   if (!nac_knl_domain_cachep)
	{
		return NAC_KNL_ERR;
	}

   //printk( "Cache name is %s\n", kmem_cache_name(nac_knl_usr_cachep));

   printk( "nac_knl_domain_init size is %d\n", sizeof(NAC_KNL_DOMAIN_OBJECT));
   printk( "nac_knl_domain_init Cache->object size is %d\n", kmem_cache_size(nac_knl_domain_cachep));

	return NAC_KNL_OK;
}

void nac_knl_domain_free_rcu(struct rcu_head *head)
{
	NAC_KNL_DOMAIN_OBJECT *dying;

	dying = container_of(head, NAC_KNL_DOMAIN_OBJECT, domain_rcu);

    nac_knl_debug(NAC_KNL_MODULE_DOMAIN, "nac_knl_domain_free_rcu-->delete domain:%d.%d.%d.%d(%u)\n",NIPQUAD(dying->src_ip), dying->src_port);

	kmem_cache_free(nac_knl_domain_cachep, dying);
}


static inline void nac_knl_domain_put(NAC_KNL_DOMAIN_OBJECT *u)
{
	if(atomic_dec_and_test(&u->refcnt))
	{
		call_rcu(&u->domain_rcu, nac_knl_domain_free_rcu);
	}
}

NAC_KNL_DOMAIN_OBJECT * __nac_knl_domain_find_by_ip(unsigned long ip, unsigned short sport, unsigned short dport)
{
	struct hlist_node *n;
	NAC_KNL_DOMAIN_OBJECT *u = NULL;
	int hash;

	hash = nac_knl_domain_get_hash_by_ip(ip);
	hlist_for_each_entry_rcu(u, n, &domain_hash_online_by_ip[hash], domain_ip)
	{
		if(ip == u->src_ip
            && sport == u->src_port)
		{
            goto FOUND;
		}
	}

	u = NULL;

FOUND:
	return u;
}
NAC_KNL_DOMAIN_OBJECT * __nac_knl_domain_find(unsigned long ip, unsigned short sport, unsigned short dport)
{
    NAC_KNL_DOMAIN_OBJECT * pst_domain = NULL;

    pst_domain = __nac_knl_domain_find_by_ip(ip, sport, dport);
	if(pst_domain)
    {
        pst_domain->last_time = get_seconds();
    }
    return pst_domain;
}

static int __nac_knl_domain_del(NAC_KNL_DOMAIN_OBJECT *pst_domain, char flag)
{
    NAC_KNL_DOMAIN_OBJECT *u = NULL;
	if(flag == 0
        && !(u = __nac_knl_domain_find_by_ip(pst_domain->src_ip, pst_domain->src_port, 0)))
	{
		goto OUT ;
	}

	list_del_rcu(&u->domain_list);
	hlist_del_rcu(&u->domain_ip);
	nac_knl_domain_put(u);
    atomic_dec(&g_domain_number);
OUT:
	return NAC_KNL_OK;
}

int nac_knl_domain_del(const NAC_KNL_DOMAIN_OBJECT *pst_domain, int len)
{
    if(sizeof(NAC_KNL_DOMAIN_OBJECT) != len)
    {
        printk("nac_knl_domain_del error\n");
        return -EINVAL;
    }
    nac_knl_debug(NAC_KNL_MODULE_DOMAIN, "nac_knl_domain_del-->ip:%d.%d.%d.%d:%d\n", NIPQUAD(pst_domain->src_ip), pst_domain->src_port);
	mutex_lock(&nac_knl_app_mutex);
    __nac_knl_domain_del(pst_domain, 0);
	mutex_unlock(&nac_knl_app_mutex);
	return NAC_KNL_OK;
}

int nac_knl_domain_add(const NAC_KNL_DOMAIN_OBJECT *pst_domain, int len)
{
	NAC_KNL_DOMAIN_OBJECT *pst_domain_tmp;
	int err = 0;

	if(len != sizeof(*pst_domain))
	{
        printk("nac_knl_domain_add error\n");
		return -EINVAL;
	}

    if(atomic_read(&g_domain_number) >= 100000)
    {
        printk("nac_knl_domain_add-->domain too much\n");
        return -EINVAL;
    }

	mutex_lock(&nac_knl_app_mutex);

	err = -ENOMEM;
	pst_domain_tmp = kmem_cache_alloc(nac_knl_domain_cachep, GFP_KERNEL);
	if (!pst_domain_tmp)
	{
		goto DONE;
	}

	if (0 != copy_from_user(pst_domain_tmp, pst_domain, len))
    {
		err = -EACCES;
ERR:
		kmem_cache_free(nac_knl_domain_cachep, pst_domain_tmp);
		goto DONE;
	}

    nac_knl_debug(NAC_KNL_MODULE_DOMAIN, "nac_knl_domain_add-->src_ip:%d.%d.%d.%d  %d\n", NIPQUAD(pst_domain_tmp->src_ip), pst_domain_tmp->src_port);

	err = -ENOMEM;
	if(0 > nac_knl_domain_insert(pst_domain_tmp))
	{
		goto ERR;
	}

	err = 0;
DONE:
	mutex_unlock(&nac_knl_app_mutex);
	return err;
}


int nac_knl_domain_flush(void)
{
	NAC_KNL_DOMAIN_OBJECT *dying, *tmp;

	mutex_lock(&nac_knl_app_mutex);
	list_for_each_entry_safe(dying, tmp, &g_nac_knl_domain_list_head, domain_list)
    {
		__nac_knl_domain_del(dying, 1);
	}
	mutex_unlock(&nac_knl_app_mutex);
    atomic_set(&g_domain_number, 0);
	return 0;
}


void nac_knl_domain_exit(void)
{
    NAC_KNL_DOMAIN_OBJECT *u, *tmp;

	printk("nac_knl_domain_exit\n");
    nac_knl_domain_flush();
    synchronize_rcu();
    if(nac_knl_domain_cachep)
    {
		kmem_cache_destroy(nac_knl_domain_cachep);
    }
	nac_knl_domain_cachep = NULL;
}

