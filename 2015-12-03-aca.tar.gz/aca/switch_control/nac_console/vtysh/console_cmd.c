#include "console_cmd.h"

//#define SERVER "127.0.0.1"
#define SERVER "127.0.0.1"

#define BUFLEN (1024 * 64)  //Max length of buffer
#define PORT 6800   //The port on which to send data
#define transfer_sync(send, receive)  msg_transfer(send, receive, 3, 0)
#define transfer_async(send)  msg_transfer(send, NULL, 0, 2)
#define transfer_rev(receive)    msg_transfer(NULL, receive, 1, 1)
#define transfer_close()           msg_transfer(NULL,NULL,0, -1)
char server_ip[32] = {0};
static int mark_socket;
typedef struct __t_msg__
{
    int len;
    char msg[BUFLEN];
} TMSG;
typedef int (*HANDLE_FUNC)(TMSG *msg);
typedef struct __HANDLE__
{
	int value;
	HANDLE_FUNC do_msg;
	
} HANDLE_S;
int do_msg_func(HANDLE_S *handle_value, TMSG *args,int flag)
{
	static HANDLE_S handle_s[64];
	int ret = 0;
	if (!flag)
	{
		memset(handle_s, 0, sizeof(handle_s));
		int i = 0;
		for(i = 0; i < 64; i++)
		{
			int value = 1000 + i;
			handle_s[i].value = value;
			handle_s[i].do_msg = NULL;
		}
	}
	else if (flag == 1)
	{
		int j;
		for(j = 0; j < 64; j++)
		{
			if(handle_s[j].value == handle_value->value)
			{
				handle_s[j].do_msg = handle_value->do_msg;
				break;
			}
		}
	}
	else if (flag == 2)
	{
		json_t *root = NULL;
		json_parse_document(&root, args->msg);
		json_t *label  = json_find_first_label(root, "cmd");
		int cmd = atoi(label->child->text);
		int k = 0;
		for(k =0; k < 64; k++)
		{
			if(handle_s[k].value == cmd)
			{
				ret = handle_s[k].do_msg(args);
			}
		}
		json_free_value(&root);	
	}
	return ret;
	
}
static int msg_transfer(TMSG *p_sd, TMSG *p_rv, int sec, int type)
{
    struct sockaddr_in si_other;
    static int s, i;
    static int slen = sizeof(si_other);
    int retval = -1;
    //printf("mark_socket = %d  line =  %d\n", mark_socket, __LINE__);
    if (mark_socket == 0)
    {
        if ((s=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
        {
            perror("creat socket failed\n");
            return -1;
        }
        mark_socket = 1;
    }
    if(type == -1 && mark_socket)
    {
    	mark_socket = 0;
        close(s);
    }
    memset((char *)&si_other, 0, sizeof(si_other));
    si_other.sin_family = AF_INET;
    si_other.sin_port = htons(PORT);

    if(inet_aton(server_ip, &si_other.sin_addr) == 0)
    {
        fprintf(stderr, "inet_aton error\n");
        return -1;
    }
    if(type == 0 || type == 2)
    {
        retval = sendto(s, p_sd->msg, p_sd->len, 0, (struct sockaddr *)&si_other, slen);
        if (retval < 0)
        {
            perror("sendto failed\n");
            return -1;
        }
        //printf("send msg = %s, msg len = %d\n", p_sd->msg, p_sd->len);
    }
   
    if(type == 0 || type == 1)
    {
        struct timeval timeout;
        if (sec)
            timeout.tv_sec = sec;
        else
            timeout.tv_sec = 3;
        timeout.tv_usec = 0;
        fd_set set;
        FD_ZERO(&set);
        FD_SET(s, &set);
        retval = select(s+1, &set, NULL, NULL, &timeout);
        if(retval == -1)
        {
            perror("select failed\n");
            return -2;
        }
        else if (retval)
        {
            if(FD_ISSET(s, &set))
            {
                retval = recvfrom(s, p_rv->msg, BUFLEN, 0, (struct sockaddr *) &si_other, &slen);
                if (retval == -1)
                {
                    perror("recvfrom()\n");
                    return -2;
                }
                p_rv->len = retval;
                do_msg_func(NULL, p_rv, 2);
                //fprintf(stderr, "rev msg = %s\n", p_rv->msg);
            }
        }
        else
        {
            //fprintf(stderr,"wait msg time out\n");
            return -3;
        }
        //printf("mark_socket = %d retval= %d line =  %d\n", mark_socket, retval ,__LINE__);
    }
    return retval;
}

DEFUN (send_test,
        send_test_cmd,
        "test msg",
        "test function\n"
        "send test msg\n"
)
{
    TMSG s_msg;
    TMSG r_msg;
    memset(&s_msg, 0, sizeof(s_msg));
    memset(&r_msg, 0, sizeof(r_msg));
    char *test = "hello world\n";
    strcpy(s_msg.msg, test);
    s_msg.len = strlen(test);
    if(transfer_sync(&s_msg, &r_msg) > 0)
    {
        vty_out(vty,"rev msg = %s\n", r_msg.msg);
        vty_out(vty, "transfer_sync success\n");
    }
    transfer_async(&s_msg);
    vty_out(vty, "transfer_async success\n");
    int i = 0;
    for(;i < 30; i++)
    {
        memset(&r_msg,0, sizeof(r_msg));
        transfer_rev(&r_msg);
        vty_out(vty,"rev msg = %s\n", r_msg.msg);
        
    }
    return CMD_SUCCESS;
}
int get_switch_status(TMSG *msg)
{
	json_t *root = NULL;
	json_parse_document(&root, msg->msg);
	json_t *label = json_find_first_label(root, "value");
	if (label)
	{
		label = label->child->child;
		int i = 0;
		for(;;i++)
		{
			json_t *label_1 = json_find_first_label(label, "ip");
			//vty_out(vty, "ip = %s\n", label_1->child->text);
			char *p = NULL;
			json_tree_to_string(label, &p);
			vty_out(vty, "switch_%d: %s\n",i,p);
			label = label->next;
			//label = label->child->next;
			if (!label)
				break;	
		}
	}
	json_free_value(&root);
	return 0;
}
int display_switch_log(TMSG *msg)
{
	json_t *root = NULL;
	json_parse_document(&root, msg->msg);
	json_t *label = json_find_first_label(root, "value");
	if (label)
		vty_out(vty, "%s\n", label->child->text);
	json_free_value(&root);
	return 0;
}
static int log_flag;
int display_log_open(void)
{
	log_flag++;
	return 0;
}
int display_log_init(void)
{
	log_flag = 0;
	return 0;
}
int switch_log_thread(void)
{
	pthread_detach(pthread_self());
	if(log_flag > 1)
		return 0;
	for(;;)
	{
		if (!log_flag)
			break;
		TMSG r_msg;
		memset(&r_msg, 0 ,sizeof(r_msg));
		transfer_rev(&r_msg);
	}
	return 0;
}
DEFUN
(
    show_switch_status,
    show_switch_status_cmd,
    "switch status",
    "switch information\n"
    "show switch status\n"
)
{
    //json={cmd:100}
    json_t *root, *label, *value;
    char *text = NULL;
    TMSG s_msg;
    TMSG r_msg;
    memset(&s_msg, 0, sizeof(s_msg));
    memset(&r_msg, 0, sizeof(r_msg));
    setlocale (LC_ALL, "");
    root = json_new_object();
    label = json_new_string("cmd");
    value = json_new_number("1000");
    json_insert_child(label, value);
    json_insert_child(root, label);

    json_tree_to_string(root, &text);
    //vty_out(vty, "json = %s\n", text);
    strcpy(s_msg.msg, text);
	json_free_value(&root);
    s_msg.len = strlen(text);
    HANDLE_S hand_obj;
    hand_obj.value = 1000;
    hand_obj.do_msg = get_switch_status;
    do_msg_func(&hand_obj, NULL, 1);
    if(transfer_sync(&s_msg, &r_msg) < 0)
    {
        /*//vty_out(vty,"rev msg = %s\n", r_msg.msg);
		json_parse_document(&root, r_msg.msg);
		label = json_find_first_label(root, "value");
		if (label)
		{
			label = label->child->child;
			int i = 0;
			for(;;i++)
			{
				json_t *label_1 = json_find_first_label(label, "ip");
				//vty_out(vty, "ip = %s\n", label_1->child->text);
				char *p = NULL;
				json_tree_to_string(label, &p);
				vty_out(vty, "switch_%d: %s\n",i,p);
				label = label->next;
				//label = label->child->next;
				if (!label)
					break;
				
			}
			json_free_value(&root);
		}
        //vty_out(vty, "transfer_sync success\n");*/
        vty_out(vty, "failed\n");
    }
    else
    	vty_out(vty, "success\n");
    free(text);
	transfer_close();
    return CMD_SUCCESS; 
}

DEFUN
(
    open_switch_log,
    open_switch_log_cmd,
    "switch log (display|off)",
    "config switch\n"
    "switch log\n"
    "open switch log display\n"
    "close switch log display\n"
)
{
    //json={cmd:100}
    json_t *root, *label, *value;
    char *text = NULL;
    TMSG s_msg;
    TMSG r_msg;
    memset(&s_msg, 0, sizeof(s_msg));
    memset(&r_msg, 0, sizeof(r_msg));
    setlocale (LC_ALL, "");
    if (strcmp(argv[0], "off") == 0)
    {
    	root = json_new_object();
	    label = json_new_string("cmd");
	    value = json_new_number("1002");
	    json_insert_child(label, value);
	    json_insert_child(root, label);

	    json_tree_to_string(root, &text);
	    //vty_out(vty, "json = %s\n", text);
	    strcpy(s_msg.msg, text);
	    s_msg.len = strlen(text);
		transfer_async(&s_msg);
		display_log_init();
		json_free_value(&root);
		free(text);
		vty_out(vty, "success\n");
		return CMD_SUCCESS; 
    }
    root = json_new_object();
    label = json_new_string("cmd");
    value = json_new_number("1001");
    json_insert_child(label, value);
    json_insert_child(root, label);

    json_tree_to_string(root, &text);
    //vty_out(vty, "json = %s\n", text);
    strcpy(s_msg.msg, text);
	json_free_value(&root);
    s_msg.len = strlen(text);
    HANDLE_S hand_obj;
    hand_obj.value = 1001;
    hand_obj.do_msg = display_switch_log;
    do_msg_func(&hand_obj, NULL, 1);
    display_log_init();
    display_log_open();
    transfer_async(&s_msg);
    pthread_t log_thread_id;
    pthread_create(&log_thread_id, NULL, switch_log_thread, NULL);
    /*if(transfer_sync(&s_msg, &r_msg) > 0)
    {
    	vty_out(vty,"rev msg = %s\n", r_msg.msg);
		//json_parse_document(&root, r_msg.msg);
		//label = json_find_first_label(root, "status");
    }
    int i = 0;
    for(i=0; i < 10; i++)
    {
    	transfer_rev(&r_msg);
    	vty_out(vty,"rev msg = %s\n", r_msg.msg);
    	memset(&r_msg, 0, sizeof(r_msg));
    }
    free(text);
    //json_free_value(&root);
	transfer_close();*/
	free(text);
    return CMD_SUCCESS; 
}
DEFUN
(
    switch_log_level,
    switch_log_level_cmd,
    "switch log_level (debug|info|warn|error)",
    "config switch\n"
    "config switch log\n"
    "set switch log level debug\n"
    "set switch log level info\n"
    "set switch log level warn\n"
    "set switch log level error\n"
)
{
	json_t *root, *label, *value;
    char *text = NULL;
    TMSG s_msg;
    TMSG r_msg;
    memset(&s_msg, 0, sizeof(s_msg));
    memset(&r_msg, 0, sizeof(r_msg));
    setlocale (LC_ALL, "");
    root = json_new_object();
    label = json_new_string("cmd");
    value = json_new_number("1003");
    json_insert_child(label, value);
    json_insert_child(root, label);
    label = json_new_string("level");
    value = json_new_string(argv[0]);
    json_insert_child(label, value);
    json_insert_child(root, label);

    json_tree_to_string(root, &text);
    //vty_out(vty, "json = %s\n", text);
    strcpy(s_msg.msg, text);
    s_msg.len = strlen(text);
    transfer_async(&s_msg);
    vty_out(vty, "success\n");
    json_free_value(&root);
    free(text);
    return CMD_SUCCESS;
}
DEFUN
(
    set_remote_switch,
    set_remote_switch_cmd,
    "switch remote (local|A.B.C.D)",
    "config switch\n"
    "remote switch\n"
    "link to localhost\n"
    "link to remote ip address\n"
)
{
	memset(server_ip, 0, sizeof(server_ip));
	if(strcmp(argv[0], "local")== 0)
		strcpy(server_ip, SERVER);
	else
		strcpy(server_ip, argv[0]);
	vty_out(vty, "success\n");
	return CMD_SUCCESS;
}

void console_init()
{
	strcpy(server_ip, SERVER);
	do_msg_func(NULL, NULL,0);
    //install_element (VIEW_NODE, &send_test_cmd);
    install_element (VIEW_NODE, &show_switch_status_cmd);
    install_element (VIEW_NODE, &open_switch_log_cmd);
    install_element (VIEW_NODE, &switch_log_level_cmd);
    install_element (VIEW_NODE, &set_remote_switch_cmd);
}
