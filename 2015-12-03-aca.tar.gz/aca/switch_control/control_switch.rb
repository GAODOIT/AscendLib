#######################################################################
#### Author: chenxiaokang                                           ###
#### Date: 2015.1.13												###
#### Description: switch controll  function							###	
#### Modify reason:													###
#### Version: 1.0													###
#### bugs report to hp104@hupu.net									###
#######################################################################
require 'net/telnet'
require 'logger'
module Switch
	class ControlSwitch
		attr_accessor :telnet, :user, :password, :switch
		attr_accessor :super_pwd
		attr_accessor :sw_model, :sw, :err, :screen
		attr_accessor :tag, :con_mark, :con_status
		def initialize(switch_model)
			#@sw_log        = Switch.sw_log
			self.sw        = switch_model.switch
			self.err       = switch_model.err_tag
			self.screen    = switch_model.screen_set
			self.tag       = switch_model.switch_tag
			#self.user      = sw["sw_user"]
			#self.password  = sw["sw_pwd"]
			#self.switch    = sw["sw_host"]
			#self.super_pwd = sw["sw_supwd"]
			@sp_characate  = ["]", "/"]
			@con_mark = -1
			@con_status = false
		end
		def connect_switch
			Log.info "ip             = #{self.switch}"
			Log.info "user           = #{self.user}"
			Log.info "password       = #{self.password}"
			Log.info "super password = #{self.super_pwd}"
			Log.info "con_mark       = #{@con_mark}"
			re_mark = 0
			if self.user == ""
				Log.warn "not define switch user"
			end

			if self.password == ""
				Log.warn "not define switch password"
			end
			if self.switch == nil
				Log.error "not define switch ip"
			end
			if self.switch != nil && @con_mark == -1
				begin
					self.telnet = Net::Telnet.new("Host" => self.switch, "Timeout"=> 3, "Waittime" => 0.2)
					Log.debug self.telnet
					Log.debug self.telnet.class
				rescue => error_msg
					Log.error "telnet connect error, #{error_msg}"
					re_mark = -203
				end
			end
			if re_mark == 0 && @con_mark == -1
				echo_text = ""
				if self.user != "" && self.password != ""
					#self.cmd("String" => "", "Match" => /\w*:|\w*>|\w*#|\w*\]/){|user_text| echo_text << user_text}
					self.telnet.print("")
					self.telnet.waitfor("Match"=>/\w*/){|user_text| echo_text << user_text}
					Log.debug "display switch echo: #{echo_text}"
					echo_text = ""
					re_mark = self.cmd("String" => self.user, "Match" => /\w*:|#{err["pwd_err"]}/) {|user_text| echo_text << user_text}
					Log.debug "display switch echo: #{echo_text}"
					if /#{err["pwd_err"]}/ =~ echo_text || re_mark < 0
						Log.error "input user name wrong"
						Log.error echo_text
						Log.error sw["pwd_err"]
						re_mark = -205
						return re_mark
					end
					echo_text = ""
					re_mark = self.cmd("String" => self.password, "Match" => /\w*>|\w*#{sw["view_tag"]}|\w*#{sw["super_tag"]}|#{err["pwd_err"]}/) {|passwd_text| echo_text << passwd_text}
					Log.debug "display switch echo: #{echo_text}"
					if /#{err["pwd_err"]}/ =~ echo_text || re_mark < 0
						Log.error "input password wrong"
						Log.error echo_text
						Log.error err["pwd_err"]
						re_mark = -206
						return re_mark
					else
						Log.info "input password success"
					end
				elsif self.user != "" && self.password == ""
					echo_text = ""
					#self.cmd("String" => "", "Match" => /\w*:|\w*>|\w*#|\w*\]/){|txt| echo_txt << txt}
					self.telnet.print("")
					self.telnet.waitfor("Match"=>/\w*/){|user_text| echo_text << user_text}
					re_mark = self.cmd("String"=> self.user, "Match" => /\w*#{sw["view_tag"]}|\w*#{sw["super_tag"]}|#{err["pwd_err"]}/) {|user_text| echo_text << user_text}
					Log.debug "display switch echo: #{echo_text}"
					if (/#{err["pwd_err"]}/ =~ echo_text) || re_mark < 0
						Log.error "input user name wrong"
						Log.error echo_text
						Log.error err["pwd_err"]
						re_mark = -205
						return re_mark
					end
					echo_text = ""
					self.cmd("String" => " ", "Match" => /\w*:|\w*>|\w*#|\w*\]/){|txt| echo_txt << txt}
				elsif self.user == "" && self.password != ""
					echo_text = ""
					#self.cmd("String" => "", "Match" => /\w*:|\w*>|\w*#|\w*\]\w+/){|txt| echo_text << txt}
					self.telnet.print("")
					self.telnet.waitfor("Match"=>/\w*/){|user_text| echo_text << user_text}
					Log.debug "display switch echo: #{echo_text}"
					re_mark = self.cmd("String"=> self.password, "Match" => /\w*#{sw["view_tag"]}|\w*#{sw["super_tag"]}|#{err["pwd_err"]}/) {|passwd_text| echo_text << passwd_text}
					Log.debug "display switch echo: #{echo_text}"
					if (/#{err["pwd_err"]}/ =~ echo_text) || re_mark < 0
						Log.error "input password wrong"
						Log.error "echo_text= #{echo_text} re_mark = #{re_mark}"
						Log.error err["pwd_err"]
						re_mark = -206
						return re_mark
					else
						Log.info "input password success"
					end
				elsif self.user == "" && self.password == ""
					re_mark = self.cmd("String" => "", "Match" => /\w*>|\w*#|\]/){|txt| echo_text << txt}
					Log.debug "display switch echo: #{echo_text}"
					if re_mark < 0
						re_mark = -205
						return re_mark
					end
				end
				echo_text = ""
				if self.super_pwd != nil && self.super_pwd != ""
					 re_mark = self.cmd("String"=> sw["super_cmd"], "Match" => /\w*:|\w*#{sw["super_tag"]}/) {|s_text| echo_text << s_text}
					 Log.debug "display switch echo: #{echo_text}"
					if /#{err["supwd_err"]}/ =~ echo_text || re_mark < 0
						Log.error "input super passwd wrong"
						Log.error echo_text
						Log.error err["pwd_err"]
						re_mark = -208
						return re_mark
					end
					if /\w*:/ =~ echo_text
						 echo_text = ""
						 re_mark = self.cmd("String"=> self.super_pwd, "Match" => /#{err["supwd_err"]}|\w*#{sw["super_tag"]}/) {|s_text| echo_text << s_text}
						 Log.debug "display switch echo: #{echo_text}"
						 if /#{err["supwd_err"]}/ =~ echo_text || re_mark < 0
							Log.error "input super passwd wrong"
							Log.error echo_text
							Log.error err["pwd_err"]
							re_mark = -208
							return re_mark
						 else
							 Log.info "input super password success"
						 end

					end
				end
				echo_text = ""
				self.cmd("String"=>"    ", "Match" => /.\w*#{sw["super_tag"]}|.\w*#{sw["view_tag"]}/) {|s_text| echo_text << s_text}
				Log.debug "display echo #{echo_text}"
				unless /.\w*#{sw["super_tag"]}/ =~ echo_text
					Log.debug "super permission echo #{echo_text}"
					re_mark = -207
					return re_mark
				end
				self.screen.keys.each do |screen_key|
					Log.debug "screen seting #{self.screen[screen_key]}"
					self.cmd("String"=>self.screen[screen_key], "Match" => /#{err["supwd_err"]}|.\w*#|.\w>|.\w\]/) {|s_text| echo_text << s_text}
					Log.debug "display switch echo: #{echo_text}"
				end
				echo_text = ""
				if sw.has_key?("version")
					re_mark = self.cmd("String"=>sw["version"]["command"], "Match" => /.\w*#{sw["super_tag"]}|.\w*#{sw["view_tag"]}/) {|s_text| echo_text << s_text}
					Log.debug "version check: #{echo_text}"
					if !(/\w*#{sw["version"]["text"]}/ =~ echo_text) || re_mark < 0
						re_mark = -211
						return re_mark
					end
				end
			end
			@con_mark = 10 if re_mark == 0
			return re_mark
		end
		def cmd(option, &block)
			re_mark = 0
			hash_dic = {}
			if option.kind_of? (Hash)
			   option["FailEOF"] = true
			   option["Timeout"] = 4
			   hash_dic["FailEOF"] = option["FailEOF"]
			   hash_dic["Timeout"] = option["Timeout"]
			   hash_dic["Match"]   = option["Match"]
			   hash_dic["Waittime"] = 0.5
			   hash_dic["Waittime"] = option["Waittime"] if option["Waittime"]
			end
			begin
				self.telnet.puts option["String"]
				Log.info "#{option} con_mark = #{@con_mark}"
				self.telnet.waitfor(hash_dic) {|str_line| block.call(str_line) if block_given?}
				# self.telnet.cmd(option){|str_line| block.call(str_line) if block != nil}
				@con_mark = 7
			rescue EOFError
				@con_mark = -1
			rescue => err
			# rescue  Timeout
				Log.error "error: #{err}"
				re_mark = -1
			end
			if re_mark == -1
				Log.error "run command failed: #{option}"
				#exit -1
			end
			return re_mark
		end
		# 200=>success 201=> failed 202=> switch not exist 203=> connect failed
		# 204=>method error 205=>user name error 206=>password error 207=>super permission error
		# 208=>supper password error  209=> args error 210 =>switch not support
		# 211=> switch type not match 212=> off line add switch success
		# run telnet command, and build telnet command
		def run_method(task, args = nil)
			method = task["method"]
			commands = sw[method]
			Log.info "run method: #{method}"
			Log.info "method commands array= #{commands}"
			result = {}
			cmd_status = 200
			#if self.connect_switch < 0
			#	cmd_status = 203
			#end
			cmd_build = Proc.new do |cmd_key, args_dic|
				cmd_arry = sw[cmd_key]["command"].split
				args_key = args_dic.keys
				if !args_key.include?(cmd_key)
					args_key.delete(cmd_key) && args_key.delete("key")
					if args_key.size > 0
						args_key.each do |arg_key|
							i_index = cmd_arry.index(arg_key)
							if i_index
								cmd_arry[i_index] = args_dic[arg_key]
							end
						end
					end
				else
					cmd_arry << args_dic[cmd_key]
				end
				cmd_text = ""
				cmd_arry.each{|str_txt| cmd_text += " #{str_txt}"}
				cmd_text.strip
			end
			if commands.kind_of?(Array) && cmd_status != 203
				commands.each do |sw_cmd|
					cmd_ret = ""
					Log.info "run method = #{method} switch command = #{sw[sw_cmd]}"
					cmd_string	   = sw[sw_cmd]["command"]
					cmd_tag		   = sw[sw_cmd]["cmd_tag"]
					command_tag	   = tag[cmd_tag]
					if @sp_characate.include? command_tag
						command_tag = "\\#{command_tag}"
					end
					if args != nil
						cmd_string = cmd_build.call(sw_cmd, args)
=begin
						if args.has_key?(sw_cmd)
							if cmd_string == ""
								cmd_string += "#{args[sw_cmd]}"
							else
								cmd_string += " #{args[sw_cmd]}"
							end
							result["#{sw_cmd}_arg"]  = "#{args[sw_cmd]}"
						end
=end
					end
					#cmd("String" => cmd_string, "Match" => /.\w*#{sw["super_tag"]}/){|ret| cmd_ret << ret}
					result["#{sw_cmd}_command"] = "#{cmd_string}"
					cmd_status = self.cmd("String" => cmd_string, "Match" => /\w*#{command_tag}/){|ret| cmd_ret << ret}
				    Log.debug "switch return msg:#{cmd_ret}"
					validation_status = validation_error(cmd_ret)
					if validation_status < 0 || cmd_status < 0
						cmd_status = -1
						Log.error "run command #{cmd_string} error  #{validation_status}"
						break
					else
						result[sw_cmd] = cmd_ret
						cmd_status = 200
					end

				end
				#self.close
			end
			cmd_result = {}
			if args != nil && args.has_key?("key")
				cmd_result["target"] = args["key"]
			end
			cmd_result["ip"]   = self.switch
			cmd_result["status"] = cmd_status < 0 ? 201:cmd_status
			cmd_result["method"] = method
			cmd_result["result"] = result
			if task["type"] == 1 || task["type"] == 3
				cmd_result["key"] = task["key"]
				cmd_result["count"] = task["count"]
			end
			cmd_result["type"] = task["type"]
			#sleep(0.2)
			return cmd_result
		end
		# run telnet command,get telnet result
		def do_method(task)
			method = task["method"]
			args = task.has_key?("args") ? task["args"]:nil
			Log.debug "do_method method = #{method} args = #{args}"
			results = []
			fruit = {}
			fruit["status"] = 200
			fruit["ip"]   = self.switch
			fruit["method"] = method
			fruit["type"]   = task["type"]
			fruit["sw_type"] = @sw["sw_type"]
			begin
				close if @con_mark >-1 && @con_mark < 2
				con_status = self.connect_switch
				if con_status < 0
					fruit["status"] = con_status.abs
					fruit["result"] = nil
					self.close
					return fruit
				end
				@con_status = true
				if args.kind_of?(Array)
					args.each do |arg|
						result_tmp = self.run_method(task, arg)
						results << result_tmp
					end
					fruit["result"] = results
				else
					result = nil
					result = self.run_method(task, args)
					fruit = result
					fruit["sw_type"] = @sw["sw_type"]
				end

				# self.close
				fruit["do_function"] = task["do_function"] if task.has_key?("do_function")
			rescue => err_msg
				Log.error "#{err_msg}"
			ensure
				@con_status = false
			end

			return fruit
		end
		def validation_error(text)
			error_code = 0
			error_keys = err.keys
			index_array = Array(1..error_keys.length)
			index_array.each do |i|
				if /#{err[error_keys[i-1]]}/ =~ text
					error_code = 0 - i
					Log.error "#{error_code} error key: #{error_keys[i-1]} text: #{text}"
					break;
				end
			end
			#if /#{err["cmd_err_tag"]}/ =~ text
			#	Log.error "command error"
			#	error_code = -1
			#elsif /#{err["unknow_cmd"]}/ =~ text
			#	Log.error "unknow command error"
			#	error_code = -2
			#elsif /#{err["ambiguous_cmd"]}/ =~ text
			#	Log.error "ambiguous_cmd error"
			#	error_code = -3
			#elsif /#{err["input_err"]}/ =~ text
			#	Log.error "input error"
			#	error_code = -4
			#end
			return error_code
		end
		def close
			begin
			#self.telnet.puts("exit")
			#self.telnet.puts("exit")
			Log.info("close telnet success  #{self.telnet.respond_to?(:close)}")
			self.telnet.close if self.telnet.respond_to?(:close)
			rescue => err
			Log.error err
			ensure
				@con_mark = -1
			end
			#Log.close
		end 
		def test_raise
			Log.info "begin raise"
			raise "test raise raised"
		end
	end
	class SwitchModel
		@@methods = ["TestSwitch", "AddSwitch", "ModifySwitch", "ChangePortVlan", "UploadSwitchInfo", \
		 "SetPortTrunk", "DelPortTrunk", "GetSwitchInfo" ,"GetVlan", "BackupSwitchConfig", \
		  "RestoreSwitchConfig", "GetVlanInside", "SetVlanTrunkInside"]
		attr_accessor :switch, :err_tag, :telnet, :fetch, :screen_set
		attr_accessor :switch_tag
		def SwitchModel.get_methods
			@@methods
		end
		def initialize(options = {})
			self.switch = {}
			self.switch = options["attribute"]
			self.switch["sw_pwd"]			= nil unless self.switch.has_key?("sw_pwd")
			self.switch["sw_supwd"]			= nil unless self.switch.has_key?("sw_supwd")
			self.switch["sw_user"]			= nil unless self.switch.has_key?("sw_user")
			self.switch["sw_host"]			= nil unless self.switch.has_key?("sw_host")
			self.switch["sw_cmd"]			= nil unless self.switch.has_key?("sw_cmd")
			self.switch["sw_type"]			= nil unless self.switch.has_key?("sw_type")
			self.switch["sw_process"]		= nil unless self.switch.has_key?("sw_process")
			self.switch["sw_ip"]			= nil unless self.switch.has_key?("sw_ip")
			self.switch["sw_echo"]			= nil unless self.switch.has_key?("sw_echo")
			self.switch["sw_status"]		= nil unless self.switch.has_key?("sw_status")
			self.switch["view_tag"]			= nil unless self.switch.has_key?("view_tag") 
			self.switch["super_tag"]		= nil unless self.switch.has_key?("super_tag") 
			self.switch["super_cmd"]		= nil unless self.switch.has_key?("super_cmd") 
			self.switch["switch"]			= nil unless self.switch.has_key?("switch")
			self.switch["telnet"]			= nil unless self.switch.has_key?("telnet")
            self.switch["version"]          = options["version"] if options.has_key?("version")
			self.err_tag = {}
			self.err_tag = options["err_code"]
			self.err_tag["pwd_err"]			= nil unless self.err_tag.has_key?("pwd_err") 
			self.err_tag["supwd_err"]		= nil unless self.err_tag.has_key?("supwd_err") 
			self.err_tag["cmd_err_tag"]		= nil unless self.err_tag.has_key?("cmd_err_tag") 
			self.err_tag["unknow_cmd"]		= nil unless self.err_tag.has_key?("unknow_cmd") 
			self.err_tag["ambiguous_cmd"]	= nil unless self.err_tag.has_key?("ambiguous_cmd") 
			self.err_tag["input_err"]		= nil unless self.err_tag.has_key?("input_err") 
			@@methods.each do |method|
				if options.has_key?(method)
					self.switch[method] = options[method]
					if self.switch[method].kind_of? Array
						self.switch[method].each do |command|
							switch[command] = options[command]
							#Log.debug switch[command]
						end
					end
				end
			end
			self.fetch = options["fetch"]
			self.screen_set = options["screen"]
			self.switch_tag = options["switch_tag"]
		end
		def set_value(options = {})
			options_keys = options.keys
			#Log.info options_keys
			options_keys.each do |options_key|
				if self.switch.has_key? options_key
				   self.switch[options_key] = options[options_key]
				else
					Log.err("input key #{options_key} error")
				end
			end

		end
	end
end

