#!/usr/bin/env ruby
#encoding: utf-8
########################################################################
##### Author: chenxiaokang                                           ###
##### Date: 2015.1.13                                                ###
##### Description: switch controll main function                     ### 
##### Modify reason:                                                 ###
##### Version: 1.0                                                   ###
##### bugs report to hp104@hupu.net                                  ###
########################################################################
path = File.absolute_path(__FILE__)
path = File.dirname(path)
path = File.split(path)[0]+ "/"
puts path
$LOAD_PATH.unshift(path)
require "switch"
require "test/switch_text"

#arp_txt = SwitchText.new("h3c_5510")
arp_txt = SwitchText.new("h3c_5120")
p arp_txt.arp
puts "#######################"
#p arp_txt.interface
puts "#######################"
#p arp_txt.mac
h3c = ParseH3c.new
mac_dic =  h3c.get_mac(arp_txt.mac)
puts "mac = #{mac_dic}"
puts "########################"
arp_dic =  h3c.get_arp(arp_txt.arp)
puts "arp = #{arp_dic}"
puts "########################"
if_dic =  h3c.get_interface(arp_txt.interface)
puts "iface = #{if_dic}"
puts "########################"
#txt ={}
#txt["arp"] = arp_txt.arp
#txt["mac"] = arp_txt.mac
#txt["interface"] = arp_txt.interface
#info_dic =  h3c.get_info(txt)
#puts "info = #{info_dic}"
