#!/usr/bin/env ruby
#encoding: utf-8
########################################################################
##### Author: chenxiaokang                                           ###
##### Date: 2015.1.13                                                ###
##### Description: switch controll main function                     ### 
##### Modify reason:                                                 ###
##### Version: 1.0                                                   ###
##### bugs report to hp104@hupu.net                                  ###
########################################################################
path = File.absolute_path(__FILE__)
path = File.dirname(path)
path = File.split(path)[0]+ "/"
puts path
$LOAD_PATH.unshift(path)
require "switch"
require "test/switch_text"

arp_txt = SwitchText.new("huawei_5700")
#puts arp_txt.arp

huawei = ParseHuawei.new
arp_arry = huawei.get_arp(arp_txt.arp)
puts "arp_arry = #{arp_arry}"
puts "########################################################"
mac_dic = huawei.get_mac(arp_txt.mac)
puts "mac_dic = #{mac_dic}"
puts "########################################################"
#puts "interface = #{arp_txt.interface}"
interface_dic = huawei.get_interface(arp_txt.interface)
puts "interface_dic = #{interface_dic}"
puts "########################################################"
config_dic = huawei.get_config(arp_txt.config)
puts "config_dic = #{config_dic}"


text = {}
text["arp"] = arp_txt.arp
text["mac"] = arp_txt.mac
text["interface"] = arp_txt.interface
text["config"]    = arp_txt.config
switch_info = huawei.get_info(text)
puts "########################################################"
puts "switch_info = #{switch_info}"
