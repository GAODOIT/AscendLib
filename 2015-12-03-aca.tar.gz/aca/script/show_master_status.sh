#!/bin/bash

mysql -uroot -phupu12iman!<<!
show master status;
!
exit 0
