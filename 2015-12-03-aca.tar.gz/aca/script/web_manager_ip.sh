#!/bin/bash
#set -x
#2014-8-18 13:26:15 cody.guo first release


cat /nac/config/nac_sys.conf | grep "manager">>/dev/null
if [ $? == 0 ];then
	ETH=`cat /nac/config/nac_sys.conf | grep "manager"|awk '{print $2}'`
else
	ETH="eth0"
fi
ifconfig $ETH|egrep "inet addr:"|cut -d ":" -f2|awk '{print $1}'
