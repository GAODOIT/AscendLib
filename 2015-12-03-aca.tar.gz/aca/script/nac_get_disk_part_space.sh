#!/bin/sh
# set -x
# History:
# create by gaodong at 2014-10-14 14:28:41
# update by gaodong at 2014-10-20 14:45:36
# echo -e "Time:`date "+%F %k:%M:%S"`"


function print_usage()
{

cat<<HELP
please input the part_name;
HELP

}

if [ $# -lt 1 ];then
        print_usage
        exit 0
fi

if [ "$1" == "data" ];then
	part_name="/data"
else
	part_name="/bak"
fi

part_space=`df -m $part_name | grep $part_name | awk '{ print $4 }'`

echo $part_space
