#!/bin/bash
# set -x
# History:
# create by gaodong at 2014-10-14 14:28:41
# update by gaodong at 2014-10-20 14:45:36
# echo -e "Time:`date "+%F %k:%M:%S"`"

function print_usage()
{
cat<<HELP
please input the operate you need
close:	close the system and poweroff;
restart: restart the system;
HELP
}

if [ $# -lt 1 ];then
	print_usage
	exit 0
fi

function nac_close_system()
{
	/bin/sync && /sbin/shutdown -h now
}

function nac_restart_system()
{
	/bin/sync && /sbin/reboot
}

#main

case "$1" in
	"close" | "CLOSE")
		nac_close_system
		;;
	"restart" | "RESTART")
		nac_restart_system
		;;
	*)
		echo "You input wrong,Please retry"
		print_usage
		;;
esac
#end

