#!/bin/bash
#History:
#2014-6-18 11:24:57 cody.guo first release
#2014-10-21 11:46:33 cody.guo two release

#set -x

time=`date "+%Y-%m-%d %H:%M:%S"`

getchar() {
    stty cbreak -echo
    dd if=/dev/tty bs=1 count=1 2> /dev/null
    stty -cbreak echo
}

printf "Please input passwd: "

while : ; do
	name=`getchar`
    	if [ x"$name" =  x ]; then
        	echo
        	break
    	fi
    	echo $name | grep ^[A-Za-z] >/dev/null
    	if [ $? == 0 ]; then
        	passwd="$passwd$name"
         	printf "*"
	fi
done

if [ "$passwd" != "cody" ];then
	echo -e "--The administrator name input errors.--\n"
	exit 1
fi

#while tre
#do
#	stty -echo
#       echo -ne "Please enter your name:"
#       read name
#       if [ "$name" == "cody" ];then
#                break
#       else
#               echo -e "--The administrator name input errors.--\n"
#       fi
#done
#stty echo

#kill nac_system
cd /nac/bin
killall -9 nac_system >/dev/null 2>&1
echo -e "--Cody.guo--linux app stop!--\n"

#rmmod knl
rmmod nac_knl.ko >/dev/null 2>&1
echo -e "--Cody.guo--linux knl stop!--\n"

#clear out
rm -rf /nac/out/*

#update knl files
while true
do
        knl='/nac/out/nac.tar.gz'
        if [ ! -f $knl  ];then
                echo -e "--Cody.guo--Please upload your nac.tar.gz--\n"
                cd /nac/out
                rz
                sleep 3

        else
                break

        fi
done

cd /nac/bin
rm -rf nac_knl.ko nac_system nac_user nac_app_show_config nac_decrypt_debug_log >/dev/null 2>&1
rm -rf /usr/lib/libnac_app_knl_lib.so >/dev/null 2>&1
rm -rf /nac/config/nac_factory.conf >/dev/null 2>&1

cd /nac/out
tar zxf nac.tar.gz > /dev/null 2>&1
mv nac_* /nac/bin/ >/dev/null 2>&1
mv libnac_app_knl_lib.so /usr/lib/ >/dev/null 2>&1

tar zxf script.tar.gz >/dev/null 2>&1
cd /nac/out/script
mv nac_app_show_config nac_decrypt_debug_log /nac/bin/ >/dev/null 2>&1
mv nac_factory.conf /nac/config/ >/dev/null 2>&1
\cp -rf *.sh /nac/script/ >/dev/null 2>&1
\cp -rf *.py /nac/script/ >/dev/null 2>&1
\cp -rf *.db /nac/script/ >/dev/null 2>&1

#start linux knl
cd /nac/bin
insmod nac_knl.ko >/dev/null 2>&1
sleep 2
lsmod |grep nac_knl >/dev/null 2>&1
if [ $? == 0 ];then
        echo -e "--Cody.guo--linux knl is running!--\n"
        rm -rf /nac/out/* >/dev/null 2>&1
else
        echo -e "--Cody.guo--linux knl start faile!--\n"
fi

#start linux app
nac_system & 
sleep 2
ps aux|grep "nac_system"|grep -v "grep" >/dev/null 2>&1
if [ $? == 0 ];then
	echo ""
	echo -e "--Cody.guo--linux app is running!--\n"
else
	echo -e "--Cody.guo--linux app start faile!--\n"
fi

#clear update file
rm -rf /nac/out/*

#log
who_ip=`who am i|cut -d "(" -f2|cut -d ")" -f1`
printf "%-11s%-9s%-12s%s\n" $time $who_ip "is update the linux app and knl." >>/var/log/nac_app_knl.log
echo "'--Cody.guo--$who_ip is update the linux app and knl.--'"|xargs -0 wall


#end
