#!/bin/bash
#History:
#2014-6-18 11:24:57 cody.guo first release

#set -x
source /etc/profile
INPUT_PROCESS_NAME=$1

killall -9 $INPUT_PROCESS_NAME >/dev/null 2>&1

case "$INPUT_PROCESS_NAME" in 
	tomcat)
		ps aux|grep service|grep -v "grep" >/dev/null 2>&1
		if [ $? != 0 ];then
			service tomcat restart
			time=`date "+%Y-%m-%d %H:%M:%S"` >/dev/null
			who_ip=`who am i|cut -d "(" -f2|cut -d ")" -f1`
			printf "%-11s%-9s%s\n" $time" Watchdog to restart tomcat." >/var/log/tomcat/start_time.log
		else
			exit 0
		fi
		;;
	nac_system)
		nac_system & 
		;;	
	mysql)
		service mysqld start 
		;;		
	*)
		$INPUT_PROCESS_NAME 1>&2 2>/dev/null & 
		exit 1
esac 













