#!/bin/bash
#set -x
#History:
#       2014-6-27 16:39:52 cody.guo first release
#       2015-1-27 cody.guo
#支持python清理数据库

if [ "$1" == "web" ];then
    sh /nac/script/web_update.sh
elif [ "$1" = "sql" ];then
    sh /nac/script/sql_update.sh $2 $3
elif [ "$1" = "linux" ];then 
    sh /nac/script/linux_update.sh
elif [ "$1" == "all" ];then
    sh /nac/script/web_update.sh
    sh /nac/script/linux_update.sh
else
    echo "--Cody.guo--commands:"
    echo "  nacupdate all          use update web and linux app knl"
    echo "  nacupdate web          use update hupunac.war"
    echo "  nacupdate sql          use update hupunac.sql"
    echo "  nacupdate linux        use linux linux app knl"
fi
