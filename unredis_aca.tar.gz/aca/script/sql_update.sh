#!/bin/bash
#set -x
#History:
#		2014-9-18 11:53:00 cody.guo first release
#		2014-9-26 10:56:43 cody.guo two release
#		2014-9-30 11:17:56 cody.guo three release
#		2014-9-30 17:11:15 cody.guo four release
#自动备份10.10.2.230的数据库
#		2014-10-10 13:15:58 cody.guo five release
#需要安装dos2unix
#		2014-11-6 10:43:12 cody.guo six release
#		增加存储过程的备份

#		2014-11-25 19:07:00 cody.guo seven release
#		优化了密码加密的过滤
#解决数据被更新bug
#		2015-1-27 19:07:00 cody.guo
#		替换shell使用python清理数据库

SQL_TEMP="/nac/out"
TIME=`date "+%Y%m%d-%H%M%S"`
BAK="/bak/mysql"
NAC_VERSION="/nac/config/nac.version"
#CLEAR_SQL="/nac/script/sql_clear.sh"
CLEAR_SQL="/nac/script/sql_clear.py"
HOST="10.10.2.230"
MYSQL="/usr/local/mysql5.1.72/bin/mysql"
MYSQLDUMP="/usr/local/mysql5.1.72/bin/mysqldump"

function Getchar() {
	stty cbreak -echo
	dd if=/dev/tty bs=1 count=1 2> /dev/null
	stty -cbreak echo
}


#查看当前服务器版本
function Version()
{
	#nac.version not exsit
	if [ ! -f $NAC_VERSION ];then
		echo "iMan X3000">$NAC_VERSION
		echo "3.6.08">>$NAC_VERSION
	fi
	#nac.version
	V1=`cat $NAC_VERSION |sed -n '2p'|cut -d "." -f1`
	V2=`cat $NAC_VERSION |sed -n '2p'|cut -d "." -f2`
	V3=`cat $NAC_VERSION |sed -n '2p'|cut -d "." -f3`
	IMAN_VERSION=`echo $V1$V2$V3`
}

#还原数据库函数
function Hupu_sql()
{
	dos2unix $2 >>/dev/null 2>&1
	service mysqld status >>/dev/null 2>&1
	if [ $? != 0 ];then
		service mysqld restart >>/dev/null 2>&1
	fi
	$MYSQL -u$USER -p$LPASSWD hupunac <$2 >>/dev/null 2>&1
	echo $LPASSWD
	if [ $? == 0 ];then
		echo -e "--Cody.guo--mysql $1 ok!--\n"
		service mysqld restart
		
		#backup hupunac.sql
		if [ -f $2 ];then
			Version
			\cp -rf $2 $BAK/backup-update_sql-$IMAN_VERSION.sql
		fi
		
		while true
		do
			read -p "Will restart tomcat,Please input Y/N :" input
			case "$input" in
				"Y" | "y")
					service tomcat restart
					exit 0
					;;
				"N" | "n")
					exit 0
					;;
				*)
					;;
			esac
		done
	else
		echo -e "--Cody.guo--mysql $1 faild,Please retry again!--\n"
		exit 1
	fi
}

#rz上传的方式
function Fsql_rz()
{
	while true
	do
		#rm hupunac.sql
		rm -rf $SQL_TEMP/*.sql >/dev/null 2>&1
		
		echo -e "\n--Cody.guo--Please upload your hupunac.sql--\n"
		#echo -e "\n--Cody.guo--Please wait for mysqldump $HOST.--\n"
		cd $SQL_TEMP
		#mysqldump -h $HOST -u$USER -p$PASSWD hupunac >hupunac.sql
		rz
		SQL_NUM=`ls $SQL_TEMP/ |egrep "*.sql" | wc -l`
		if [ "$SQL_NUM" == "1" ];then
			HP_SQL=`ls $SQL_TEMP/ |egrep "*.sql"`
			break
		fi
		sleep 3
		#HP_SQL=`ls $SQL_TEMP/ |egrep "*.sql"`
		#if [ ! -n "$HP_SQL"  ];then
		#	echo -e "--Cody.guo--Please upload your hupunac.sql--\n"
		#	cd $SQL_TEMP
		#	rz
		#	sleep 3
		#else
		#	break
		#fi
	done

}

#直接拉去服务器上的数据库
function Fmysqldump()
{
	while true
	do
		#rm hupunac.sql
		rm -rf $SQL_TEMP/*.sql >/dev/null 2>&1
		
		#echo -e "\n--Cody.guo--Please upload your hupunac.sql--\n"
		echo -e "\n--Cody.guo--Please wait for mysqldump $HOST.--\n"
		cd $SQL_TEMP
		$MYSQLDUMP -h $HOST -R -u$USER -p$RPASSWD hupunac >hupunac.sql
		if [ $? != 0 ];then
			echo -e "\n--Cody.guo--Remote host mysql passwd error,Please retry.--\n"
			exit 1
		fi
		#rz
		SQL_NUM=`ls $SQL_TEMP/ |egrep "*.sql" | wc -l`
		if [ "$SQL_NUM" == "1" ];then
			HP_SQL=`ls $SQL_TEMP/ |egrep "*.sql"`
			break
		fi
		sleep 3
		#HP_SQL=`ls $SQL_TEMP/ |egrep "*.sql"`
		#if [ ! -n "$HP_SQL"  ];then
		#	echo -e "--Cody.guo--Please upload your hupunac.sql--\n"
		#	cd $SQL_TEMP
		#	rz
		#	sleep 3
		#else
		#	break
		#fi
	done
}

#登录mysql
function Rpasswd()
{
    while true
    do
	    read -p "Please input mysql user: " USER
	    if [ "$USER" != "" ];then
		    break
	    fi
    done

	#remote passwd
	while true
	do
		printf "Please input remote mysql passwd: "
		
		while true
		do
			t_passwd=`Getchar`
				if [ x"$t_passwd" = x ]; then
					echo
					break
				fi
			echo $t_passwd | grep ^[A-Za-z0-9!] >/dev/null
			if [ $? == 0 ]; then
				RPASSWD="$RPASSWD$t_passwd"
				printf "*"
			fi
		done
		
		if [ "$RPASSWD" != "" ];then
			break
		fi
	done
	#localhost passwd
}

function Lpasswd()
{
    while true
    do
	    read -p "Please input mysql user: " USER
	    if [ "$USER" != "" ];then
		    break
	    fi
    done

	while true
	do
		printf "Please input localhost mysql passwd: "
		
		while true
		do
			t_passwd=`Getchar`
				if [ x"$t_passwd" = x ]; then
					echo
					break
				fi
			echo $t_passwd | grep ^[A-Za-z0-9!] >/dev/null
			if [ $? == 0 ]; then
				LPASSWD="$LPASSWD$t_passwd"
				printf "*"
			fi
		done
		
		if [ "$LPASSWD" != "" ];then
			break
		fi
	done
}


#rz or mysqldump hupunac.sql

case "$1" in
	"rz" | "RZ")
		Lpasswd
		Fsql_rz
		;;
	"rec" | "REC")
		Lpasswd
		;;
	"clear" | "CLEAR")
		;;
	*)
		Rpasswd
		Lpasswd
		Fmysqldump
		;;
esac


#还原备份的数据库
if [ "$1" == "rec" -o "$1" == "REC" ];then
	echo -e "\n--Cody.guo--Please wait for recovery hupunac.sql.--\n"
	Version
	RECOVERY="$BAK/backup-update_sql-$IMAN_VERSION.sql"
	if [ -f $RECOVERY ];then
		Hupu_sql recovery "$RECOVERY"
		exit 0
	else
		echo -e "--Cody.guo--bak_sql not exsit.--\n"
		exit 1
	fi
fi

#清空数据库
if [ "$1" == "clear" -o "$1" == "CLEAR" ];then
	echo -e "\n--Cody.guo--Please wait for clear DB.--\n"
	python $CLEAR_SQL $2
    #sh $CLEAR_SQL $USER $LPASSWD
	if [ $? == 0 ];then
		echo -e "--Cody.guo--clear DB OK.--\n"
		exit 0
	else
		echo -e "--Cody.guo--clear DB faild.--\n"
		exit 1
	fi
fi


# rename hupunac.sql

if [ "$HP_SQL" != "hupunac.sql" ];then
	mv $SQL_TEMP/$HP_SQL $SQL_TEMP/hupunac.sql
fi

#导入数据库

$MYSQL -u $USER -p$LPASSWD <<EOF
DROP database hupunac;
CREATE database hupunac;
quit
EOF

echo -e "\n--Cody.guo--mysql updating,Please wait!--\n"
UPDATE_SQL="$SQL_TEMP/hupunac.sql"
Hupu_sql update "$UPDATE_SQL"

#end
