#!/bin/bash
app_status=`pgrep nac_system`
#echo "nac_system $app_status"
ruby_status=`pgrep main_switch`
#echo "main_switch $ruby_status"
mysql_status=`pgrep mysqld | sed '1d'`
#echo "mysqld $mysql_status"
tomcat_status=`netstat -anp | egrep "0.0.0.0:80\s"|awk '{print $7}'`
#echo "tomcat $tomcat_status"

if [ -z $app_status ];then
	echo "nac_system is unexist" >>/var/log/ha_status
	exit 1
elif [ -z $ruby_status ];then	
	echo "main_switch is unexist" >>/var/log/ha_status
	exit 1
elif [ -z $mysql_status ];then	
	echo "mysql daemon is unexist" >>/var/log/ha_status
	exit 1
elif [ -z $tomcat_status ];then	
	echo "tomcat daemon is unexist" >>/var/log/ha_status
	exit 1
else
	exit 0
fi
