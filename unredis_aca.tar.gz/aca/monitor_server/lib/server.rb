require 'logger'
require 'packet'
require 'thread'
module EventMaping
	def _callbacks
		@_callbacks ||= Hash.new {|h, k| h[k] = [] }
	end
	def on(type, &blk)
		_callbacks[type] << blk
		self
	end
	def omit(type, *args)
		_callbacks[type].each do |blk|
			blk.(args)
		end
	end
end

module MsgTransfer
    class Log
        $debug_log = nil
        $log_describe = {}
        class << self
            def debug(msg=nil, name=nil)
                #puts "Log debug##################3"
                log_value(msg, "#{name} DEBUG ", 0)
                #puts "msg = #{msg}"
                $debug_log.add(Logger::DEBUG, msg, name)
                # log_txt = ''
                # msg.to_s.each_byte do |char_ord|
                # 	if char_ord == 10 || (char_ord >31 && char_ord <127)
                # 		log_txt += char_ord.chr
                # 	end
                # end
                # $debug_log.add(Logger::DEBUG, log_txt, name)
            end
            def info(msg=nil, name=nil)
                log_value(msg, "#{name} INFO ", 1)
                $debug_log.add(Logger::INFO, msg, name)
                # log_txt = ''
                # msg.to_s.each_byte do |char_ord|
                # 	if char_ord == 10 || (char_ord >31 && char_ord <127)
                # 		log_txt += char_ord.chr
                # 	end
                # end
                # $debug_log.add(Logger::INFO, log_txt, name)
            end
            def warn(msg=nil, name=nil)
                log_value(msg, "#{name} WARN ", 2)
                $debug_log.add(Logger::WARN, msg, name)
            end
            def error(msg=nil, name=nil)
                log_value(msg, "#{name} ERROR ", 3)
                $debug_log.add(Logger::ERROR, msg, name)
                # log_txt = ''
                # msg.to_s.each_byte do |char_ord|
                # 	if char_ord == 10 || (char_ord >31 && char_ord <127)
                # 		log_txt += char_ord.chr
                # 	end
                # end
                # $debug_log.add(Logger::ERROR, log_txt, name)
            end
            def log_value(msg = nil,name = nil, level = 0)
                $log_describe.each do |key, value|
                    value.call("#{DateTime.now.to_time.to_s}[#{name}]--#{msg}") if $debug_log.level <= level
                end
                if !$debug_log
                    $debug_log = Logger.new(STDERR)
                    $debug_log = Logger.new('/var/log/moniter.log', 2, 1024000*25)
                    $debug_log.level = Logger::DEBUG
                    # $debug_log.level = Logger::INFO
                    #$debug_log.level = Logger::ERROR
                    $debug_log.datetime_format = '%Y-%m-%d %H:%M:%S'
                end
                $debug_log
            end
            def log_level_set(level = nil)
                case level
                    when "debug"
                        $debug_log.level = Logger::DEBUG
                    when "info"
                        $debug_log.level = Logger::INFO
                    when "warn"
                        $debug_log.level = Logger::WARN
                    when "error"
                        $debug_log.level = Logger::ERROR
                    else
                        error("log level args error")
                end
            end
        end
    end
	class Stream
		include EventMaping
        include Message
        attr_accessor :client_id
        attr_accessor :status, :heart_timer
		def initialize(stream)
			@io = stream
			@s_addrinfos = {}
			@client_id = "0"
			@status = true
			@msg_parse = MsgTransfer::ParseMsg.new
            @heart_timer = -1
            @mutex = Mutex.new
		end
		def handle_receive
			begin
				# puts "in handle_receive"
				msg = @io.readpartial(1024*1024)
				packets = @msg_parse.parse(msg)
				# packets = msg
				omit(:data, packets, self)
			rescue => error
				puts error
				@status = false
                delete
				Thread.exit
			end
		end

        def send_msg(msg, method)
            return if method == "ErrorMethod"
            @mutex.synchronize do
                msg_info = {}
                msg_info["method"] = method
                msg_info["client_id"] = @client_id
                packet = msg_package(msg, msg_info)
                Log.debug "send to client msg:\n #{packet}"
                begin
                    @io.write(packet)
                rescue
                    @status = false
                end
            end
        end
        def delete
            begin
                @io.close
            rescue => error
                Log.error "#{error}"
            end
        end
	end
	class MsgServer
		include EventMaping
		attr_accessor :streams
		def initialize(port, addr)
			@streams = []
			@threads = []
			@port = port
			@addr = addr
			@queue = Queue.new
			@thread_dic = {}
			@thread_dic[:msgs] = []
            on(:th_check) do |th_st|
                case th_st.status
                    when "aborting"
                        Log.error "thread key = #{th_key} aborting"
                    when false
                        Log.warn "thread key = #{th_key} thread is terminated normally"
                    when nil
                        Log.error "thread key = #{th_key} terminated with an exception"
                end
            end
            on(:netstream) do
                speed_dic = {}
                uptime = `cat /proc/uptime`
                speed_dic[:uptime] = uptime.split[0].to_i.to_s
                traffic = `ifconfig eth0`
                rx_data = /RX bytes:\d+/.match(traffic).to_s.split(":")[1]
                rx_data = rx_data.to_i/1024
                speed_dic[:rx_data] = rx_data.to_s
                tx_data = /TX bytes:\d+/.match(traffic).to_s.split(":")[1]
                tx_data = tx_data.to_i/1024
                speed_dic[:tx_data] = tx_data.to_s
                netspeed = `vnstat -i eth0 -tr 2 -ru`
                speed_arry = netspeed.split("\n")
                speed_arry.each do |txt|
                    txt_arry = txt.split
                    if /\A\s+rx/ =~ txt
                        speed_dic[:rx] = txt_arry[1]
                        speed_dic[:rx_unit] = txt_arry[2]
                    elsif /\A\s+tx/ =~ txt
                        speed_dic[:tx] = txt_arry[1]
                        speed_dic[:tx_unit] = txt_arry[2]
                    end
                end
                if speed_dic[:tx_unit] == "MiB/s"
                    speed_dic[:tx] =  speed_dic[:tx].to_i * 1000
                    speed_dic[:tx] = speed_dic[:tx].to_s
                    speed_dic[:tx_unit] = "KiB/s"
                else
                    speed_dic[:tx] = speed_dic[:tx].to_i.to_s
                end
                if speed_dic[:rx_unit] == "MiB/s"
                    speed_dic[:rx] =  speed_dic[:tx].to_i * 1000
                    speed_dic[:rx] =  speed_dic[:rx].to_s
                    speed_dic[:rx_unit] = "KiB/s"
                else
                    speed_dic[:rx] = speed_dic[:rx].to_i.to_s
                end
                speed_dic[:time] = Time.now.to_i.to_s
                puts speed_dic.to_json
                speed_dic
            end
        end
        # server init status, and listen socket
		def server_init
			socket = Socket.new(:INET, :STREAM, 0)
			socket_addr = Socket.sockaddr_in(@port, @addr)
            socket.setsockopt(Socket::SOL_SOCKET, Socket::SO_REUSEADDR, true)
            begin
			    socket.bind(socket_addr)
            rescue Errno::EADDRINUSE
                sleep(5)
                retry
            end
			socket.listen(10)
			@thread_dic[:accecpt] = Thread.new do
				loop do
					client, addrinfo = socket.accept
                    Log.debug "#{addrinfo.ip_unpack}   socket = #{client.to_s}"
					stream = Stream.new(client)
					stream.on(:close) do
						client.close
					end
					stream.on(:data) do |msg, stream|
						Log.debug "client said\n#{msg}"
						args = []
						args << msg
						args << stream
						@queue << args
					end
					@streams << stream
					#@socket_addrinfo[client.to_s] =  addrinfo
					@thread_dic[:msgs] << Thread.new do
						loop do
							stream.handle_receive
						end
					end
				end
			end
			do_thread
        end
        def server_send(msg, method)
            @streams.each do |stream|
                stream.send_msg(msg, method)
            end
        end

        # start thread method
        def do_thread
            @thread_dic[:handle] = Thread.new do
                loop do
                    packet, stream = @queue.pop
                    omit(:handle, packet, stream)
                end
            end
            @thread_dic[:timer] = Thread.new do
                @timer_1 = 0
                loop do
                    if @timer_1 > 9
                        @streams.each do |stream|
                            if stream.status
                                stream.send_msg(nil, "HeartBeat") if stream.client_id != "0"
                                @timer_1 = 0
                                Log.debug "send heart beat success"
                                #TO DO send heart beat
                            else
                                @streams.delete(stream)
                            end
                        end
                    end
                    sleep(1)
                    @timer_1 += 1
                    # Log.debug "timer_1 = #{@timer_1}"
                    # @thread_dic.each do |th_key, thread_st|
                    #     if thread_st.kind_of? Array
                    #         thread_st.each do |th_st|
                    #             omit(:th_check,th_st)
                    #         end
                    #     else
                    #         th_check.(:th_check,thread_st)
                    #
                    #     end
                    # end
                end
            end
            @thread_dic[:netstream] = Thread.new do
                loop do
                    begin
                    # info = omit(:netstream)
                    omit(:net_info)
                    # puts "info = #{info}"
                    rescue => error_msg
                        Log.debug "netstream error #{error_msg}"
                    end
                end
            end
        end
		def start
			server_init
		end
	end
end
