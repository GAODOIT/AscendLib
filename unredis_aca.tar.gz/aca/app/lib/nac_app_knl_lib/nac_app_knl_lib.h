#ifndef __NAC_APP_KNL_LIB_H__
#define __NAC_APP_KNL_LIB_H__


#ifdef __cplusplus
extern "C" {
#endif
//����ͷ�ļ�
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <linux/if_ether.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <stdarg.h>
#include <pthread.h>
#include <signal.h>
#include <netinet/in.h>
#include <asm/types.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <sys/time.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <netinet/ip_icmp.h>
#include <netinet/tcp.h>
#include <curl/curl.h>

// ϵͳ�����ļ�
#include "nac_knl_def.h"
#include "nac_precomp.h"
#include "nac_app_knl_log.h"
#include "nac_app_knl_ioctl.h"
#include "nac_app_knl_netlink.h"
#include "nac_app_knl_tcp.h"
#include "nac_app_knl_udp.h"

#ifdef __cplusplus
}
#endif

#endif
