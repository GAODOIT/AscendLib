#include "nac_app_knl_lib.h"


HUPU_UINT32 nac_app_netlink_create(HUPU_UINT32 type)
{
	struct sockaddr_nl	app_addr;
	HUPU_UINT32			sock_fd;

	//����netlinkͨ��
	if((sock_fd = socket(PF_NETLINK, SOCK_RAW, NAC_KNL_NETLINK_PROTO))<0)
	{
		return HUPU_ERR;
	}

	//��ʼ��Դ��ַ
	memset(&app_addr, 0, sizeof(struct sockaddr_nl));
	app_addr.nl_family	= AF_NETLINK;
	app_addr.nl_pid		= getpid();
	app_addr.nl_groups	= 0;

    //�󶨵�Դ��ַ
	if((bind(sock_fd, (struct sockaddr*)&app_addr, sizeof(app_addr)))<0)
	{
		return HUPU_ERR;
	}

	// ֪ͨ�ں˼̳�PID
	nac_app_netlink_cmd(sock_fd, type);
    return sock_fd;
}


HUPU_UINT32 nac_app_netlink_destroy(HUPU_UINT32 sock_fd, HUPU_UINT32 type)
{
	if(sock_fd < 0)
    {
        return HUPU_ERR;
	}

	// ��֪�ں�Ӧ�ò�netlink��Ҫ�ر�
	nac_app_netlink_cmd(sock_fd, type);

	close(sock_fd);
	return HUPU_OK;
}


HUPU_UINT32 nac_app_netlink_recv(HUPU_UINT32 sock_fd, HUPU_CHAR *buffer, HUPU_UINT32 length)
{
    int iRet;
	struct sockaddr_nl	knl_addr;
	socklen_t			addr_len = sizeof(struct sockaddr_nl);

	// ��ʼ���ں˵�ַ
	memset(&knl_addr, 0, sizeof(struct sockaddr_nl));
	knl_addr.nl_family	= AF_NETLINK;
	knl_addr.nl_pid		= 0;
	knl_addr.nl_groups	= 0;

    //����ϵͳ���������ں���Ϣ
	iRet = recvfrom(sock_fd, buffer, length, 0, (struct sockaddr*)&knl_addr, &addr_len);
	return iRet;
}


HUPU_UINT32 nac_app_netlink_cmd(HUPU_UINT32	sock_fd, HUPU_UINT32 msg_type)
{
	struct msghdr	msg;
	struct iovec	iov;
	struct nlmsghdr	nlh;

	//���netlink��Ϣͷ
	nlh.nlmsg_len	= NLMSG_SPACE(0);
	nlh.nlmsg_pid	= getpid();
	nlh.nlmsg_type	= msg_type;
	nlh.nlmsg_flags	= 0;

	//����netlink��Ϣͷ
	iov.iov_base = (void *)&nlh;
	iov.iov_len	 = nlh.nlmsg_len;

	//��ʼ����Ϣ��
    memset(&msg, 0, sizeof(msg));
	msg.msg_iov		= &iov;
	msg.msg_iovlen	= 1;

	//������Ϣ���ں�
	if(sendmsg(sock_fd, &msg, 0) < 0)
    {
		return HUPU_ERR;
	}
    return HUPU_OK;
}



