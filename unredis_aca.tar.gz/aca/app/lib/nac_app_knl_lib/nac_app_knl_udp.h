#ifndef	__NAC_APP_KNL_UDP_H__
#define	__NAC_APP_KNL_UDP_H__



/////////////////////////////////////////////////////
#define NAC_APP_UDP_PORT 6004
/////////////////////////////////////////////////////

HUPU_INT32 nac_udp_crt_svr(const HUPU_UINT16 port);

HUPU_INT32 nac_udp_crt_cli(HUPU_VOID);

HUPU_INT32 nac_udp_destroy(const HUPU_INT32 sock_fd);

HUPU_INT32 nac_udp_sendto(const HUPU_INT32 sock_fd,
                          const HUPU_ULONG32 dst_ip,
                          const HUPU_UINT16 dst_port,
                          const HUPU_VOID	 *msgbuf,
                          const HUPU_INT32 msglen);

HUPU_INT32 nac_udp_recvfrom(const HUPU_INT32 sock_fd,
                            HUPU_ULONG32 *dst_ip,
                            HUPU_UINT16	*dst_port,
                            HUPU_VOID *msgbuf,
                            const HUPU_INT32 msglen);

#endif
