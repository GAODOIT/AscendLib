#ifndef NAC_PRECOMP_H
#define NAC_PRECOMP_H

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <sys/errno.h>
#include <sys/ipc.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "HUPU.h"
#include "nac_app_cmd_define.h"
#include "nac_list.h"

#endif//end of NAC_PRECOMP_H
