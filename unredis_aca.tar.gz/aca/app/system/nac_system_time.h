#ifndef NAC_SYSTEM_TIME_H
#define NAC_SYSTEM_TIME_H

struct nac_ntp_server_struct
{
	struct nac_list_head list_node;
	HUPU_UINT16	self_sync_enable;
	HUPU_CHAR	ntp_server[MAX_DOMAIN_LEN];
};
extern struct nac_ntp_server_struct gst_nac_ntp_server;

/*-1:ntpdate timeout; 0: ntpdate success*/
HUPU_INT32 nac_ntpdate_time_server(const HUPU_CHAR* ntpserver);

/*
 * return HUPU_OK, success; return HUPU_ERR, fault;
 * date -s "2007-08-03 14:15:00" && hwclock -w
 */
//int nac_set_system_time(const char* time_str);


/* get system current time
 * 2014-04-08 10:37:33 =strlen=20
 */
int nac_get_system_current_time(char* now_time);

/* get system start time
 * 2014-03-27 13:36:44 =strlen=20
 */
int nac_get_system_start_time(char* start_time);

/* get system last running time
 * 1000天21小时0分钟49秒 =strlen=100
 */
int nac_get_system_last_run_time(char* last_time);


xmlDocPtr nac_sys_parse_set_systime_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id);
#endif
