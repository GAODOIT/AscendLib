#include "nac_precomp.h"
#include "nac_app_knl_lib.h"
#include "nac_system_errorlog.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_common_lib.h"
#include "nac_system_time.h"

const char *ntpdate_timeserver_cmd = "ntpdate -u -t 1 %s";
const char *get_sys_current_time_cmd = "date \"+%F %H:%M:%S\"";
const char *get_sys_start_time_cmd = "date -d \"$(awk -F. '{print $1}' /proc/uptime) second ago\" +\"%Y-%m-%d %H:%M:%S\"";

const char *get_sys_last_run_time_cmd = "cat /proc/uptime|awk -F. '{run_days=$1/86400;run_hour=($1%86400)/3600;run_minute=($1%3600)/60;run_second=$1%60;printf(\"%d天%d小时%d分钟%d秒\",run_days,run_hour,run_minute,run_second)}'";

const char *set_systime_cmd = "date -s \"%s\"";
const char *set_systohc_cmd = "hwclock -w &";

/*
lock or not, it is a important!
struct nac_ntp_server_struct gst_ntp_server_config;//for best!
*/
struct nac_ntp_server_struct gst_nac_ntp_server;

/*2014-11-03 11:55:17
int nac_get_system_current_time(char* current_time)
{
    FILE* popen_fp;
	HUPU_CHAR buffer[BUFF_LEN];

	memset(buffer, '\0', BUFF_LEN);
    popen_fp = popen(get_sys_current_time_cmd, "r");
    if (popen_fp == NULL)
	{
		return HUPU_ERR;
	}

    fgets(buffer, BUFF_LEN, popen_fp);

	//clean the line end '\n'
	clean_newline_character(buffer);
	memcpy(current_time, buffer, strlen(buffer));

    pclose(popen_fp);
    SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->system current time=%s\n", __FUNCTION__, current_time);
    return 0;
}
*/

/*2014-11-03 14:21:02*/
int nac_get_system_current_time(char* now_time)
{
	time_t			timep;
	struct tm       st_tm;
	time(&timep);
 	localtime_r(&timep, &st_tm);
	sprintf(now_time, "%02d-%02d-%02d %02d:%02d:%02d",
			(1900 + st_tm.tm_year),
			(1 + st_tm.tm_mon),
			st_tm.tm_mday,
			st_tm.tm_hour,
			st_tm.tm_min,
			st_tm.tm_sec);

    return 0;
}

/*no_fclose*/
int nac_get_system_start_time(char *start_time)
{
	FILE *popen_fp;
	HUPU_CHAR buffer[BUFF_LEN] = "";

	popen_fp = popen(get_sys_start_time_cmd, "r");
	if (popen_fp == HUPU_NULL)
	{
		return HUPU_ERR;
	}
	fgets(buffer, BUFF_LEN, popen_fp);
	/*clean the line end '\n'*/
	clean_newline_character(buffer);
	memcpy(start_time, buffer, strlen(buffer));

	pclose(popen_fp);
	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->system start time=%s\n", __FUNCTION__, start_time);
    return HUPU_OK;
}

int nac_get_system_last_run_time(char *last_time)
{
	FILE *popen_fp;
	HUPU_CHAR buffer[BUFF_LEN] = "";

	popen_fp = popen(get_sys_last_run_time_cmd, "r");
	if (popen_fp == HUPU_NULL)
	{
		return HUPU_ERR;
	}

	fgets(buffer, BUFF_LEN, popen_fp);

	/*clean the line and '\n'*/
	clean_newline_character(buffer);
	memcpy(last_time, buffer, strlen(buffer));

	pclose(popen_fp);
	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->system last runing time=%s\n", __FUNCTION__, last_time);

	return HUPU_OK;
}

static int nac_set_system_time(const char* time_str)
{
    char exec_cmd[100];
    memset(exec_cmd, '\0', sizeof(exec_cmd));
    sprintf(exec_cmd, set_systime_cmd, time_str);
    SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->exec_cmd=%s\n", __FUNCTION__, exec_cmd);
	nac_exec_system(exec_cmd);
	//hwclock -w &
	nac_exec_system(set_systohc_cmd);
	return HUPU_OK;
}


/*
0: ntpdate success;
(popen_fgets_ok  )popen.len > 0;
16 Jun 14:03:02 ntpdate[16241]:
adjust time server 129.6.15.28 offset 0.070613 sec
-1: ntpdate timeout;
(popen_fgets_error)popen.len = 0;
16 Jun 14:01:54 ntpdate[16237]:
no server suitable for synchronization found
*/

HUPU_INT32 nac_ntpdate_time_server(const HUPU_CHAR* ntpserver)
{
	FILE* popen_fp;
	HUPU_CHAR  buffer[BUFF_LEN] = "";
	HUPU_CHAR  exec_cmd[100];

	if (strlen(ntpserver) == HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->error: ntpdate_server = null.\n", __FUNCTION__);
		return HUPU_ERR;
	}

	memset(exec_cmd, '\0', sizeof(exec_cmd));
	sprintf(exec_cmd, ntpdate_timeserver_cmd, ntpserver);

    popen_fp = popen(exec_cmd, "r");
	if (HUPU_NULL == popen_fp)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "error:%s-->exec_cmd=%s\n", __FUNCTION__, exec_cmd);
		return HUPU_ERR;
	}

	if (fgets(buffer, BUFF_LEN, popen_fp) == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "error:%s-->exec_cmd=%s-->buffer=%s\n",
						__FUNCTION__, exec_cmd, buffer);

		pclose(popen_fp);
		return HUPU_ERR;
	}

	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->exec_cmd=%s-->buffer=%s\n",
				__FUNCTION__, exec_cmd, buffer);

	pclose(popen_fp);
	return HUPU_OK;
}

static HUPU_INT32 nac_system_set_ntpserver_self_sync(struct nac_ntp_server_struct* pst_sync_ntpserver)
{
	// must update the gst_ntpserver;
	memset(&gst_nac_ntp_server, '\0', sizeof(struct nac_ntp_server_struct));
	gst_nac_ntp_server.self_sync_enable = pst_sync_ntpserver->self_sync_enable;
	memcpy(gst_nac_ntp_server.ntp_server, pst_sync_ntpserver->ntp_server, strlen(pst_sync_ntpserver->ntp_server));
	//memcpy(&gst_nac_ntp_server, pst_sync_ntpserver, sizeof(struct nac_ntp_server_struct));

	return HUPU_OK;
}

xmlDocPtr nac_sys_parse_set_systime_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
	HUPU_INT32 iRet, error_id;
	xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
	xmlChar *szKey;
    HUPU_UINT8 action_type, match_command_flag, time_type = 1;
	HUPU_CHAR time_buffer[BUFF_LEN];
	struct nac_ntp_server_struct st_ntp_server_tmp;

	cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
	match_command_flag = 0;
	switch (action_type)
    {
    case NAC_SHOW:
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "timeType")))
			{
				szKey = xmlNodeGetContent(cur_node);
				time_type = atoi((HUPU_CHAR*)szKey);
				xmlFree(szKey);
				break;
			}
			cur_node = cur_node->next;
		}
        nac_free_xmlDoc(doc);


		//1111::ntpserver:lastTime:startTime:currentTime
		if (time_type == 1)//001
		{
			nac_doc = nac_sys_ret_show_result(cmd_id, "current_time");
		}
		else if (time_type == 7) //111
		{
			nac_doc = nac_sys_ret_show_result(cmd_id, "all_time");
		}
		else if (time_type == 8)//1000
		{
			nac_doc = nac_sys_ret_show_result(cmd_id, "ntp_server");
		}
		break;

	case NAC_ADD:
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "currentTime")))
			{
				szKey = xmlNodeGetContent(cur_node);
        		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->currentTime-->%s\n", __FUNCTION__, (HUPU_CHAR*)szKey);
				memset(time_buffer, '\0', sizeof(time_buffer));
				mymemcpy(time_buffer, sizeof(time_buffer), (HUPU_CHAR*)szKey, strlen((HUPU_CHAR*)szKey));
				xmlFree(szKey);
				match_command_flag = 1;
				break;
			}
			cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);

		if (match_command_flag == 0)
		{
			error_id = NAC_SYS_ERROR_SET_SYSTIME_FAIL;
		}
		else
		{
			iRet = nac_set_system_time(time_buffer);
			if (iRet != HUPU_OK)
			{
				error_id = NAC_SYS_ERROR_SET_SYSTIME_FAIL;
			}
		}

		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

	case NAC_DEL:
		memset(&st_ntp_server_tmp, '\0', sizeof(struct nac_ntp_server_struct));
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "ntpServer")))
			{
				szKey = xmlNodeGetContent(cur_node);
        		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->ntpServer-->%s\n", __FUNCTION__, (HUPU_CHAR*)szKey);
				mymemcpy(st_ntp_server_tmp.ntp_server, sizeof(st_ntp_server_tmp.ntp_server),
						(HUPU_CHAR*)szKey, strlen((HUPU_CHAR*)szKey));
				xmlFree(szKey);
				break;
			}
			cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);

		if (memcmp(gst_nac_ntp_server.ntp_server, st_ntp_server_tmp.ntp_server,
			strlen(st_ntp_server_tmp.ntp_server)) == HUPU_OK)
		{
			memset(&gst_nac_ntp_server, '\0', sizeof(struct nac_ntp_server_struct));
		}
		else
		{
			error_id = NAC_SYS_ERROR_DELETE_NTPSERVER_UNEXIST;
		}

		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

    case NAC_MODIFY:
		memset(&st_ntp_server_tmp, '\0', sizeof(struct nac_ntp_server_struct));
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST "selfSync")))
			{
				szKey = xmlNodeGetContent(cur_node);
				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->selfSync-->%s\n", __FUNCTION__, (HUPU_CHAR*)szKey);
				st_ntp_server_tmp.self_sync_enable = atoi((HUPU_CHAR*)szKey);
				xmlFree(szKey);
			}
			else if (!(xmlStrcmp(cur_node->name, BAD_CAST "ntpServer")))
			{
				szKey = xmlNodeGetContent(cur_node);
        		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"%s-->ntpServer-->%s\n", __FUNCTION__, (HUPU_CHAR*)szKey);
				mymemcpy(st_ntp_server_tmp.ntp_server, sizeof(st_ntp_server_tmp.ntp_server),
						(HUPU_CHAR*)szKey, strlen((HUPU_CHAR*)szKey));
				xmlFree(szKey);
				break;
			}
			cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);

		iRet = nac_ntpdate_time_server(st_ntp_server_tmp.ntp_server);
		if (iRet != HUPU_OK)
		{
			error_id = NAC_SYS_ERROR_NTPDATE_TIMEOUT;
		}
		else
		{
			nac_system_set_ntpserver_self_sync(&st_ntp_server_tmp);
		}

		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
		error_id = NAC_SYS_ERROR_UNEXIST_OPERATE;
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;
	}

	return nac_doc;
}
