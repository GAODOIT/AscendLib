#ifndef NAC_SYSTEM_ESCAPE_DEAL_H
#define NAC_SYSTEM_ESCAPE_DEAL_H

#include "nac_system_common_lib.h"

#define ASC_NORMAL_MODE		1
#define ASC_ESCAPE_MODE		0

#define MSG_BUFFER_LEN		 1024
#define NAC_RSYSLOG_UDP_PORT 514

#include "nac_system_common_lib.h"

struct eth_detect_struct
{
	HUPU_CHAR name[IFNAMSIZE];
	HUPU_CHAR up_msg[BUFF_LEN];
	HUPU_CHAR down_msg[BUFF_LEN];
	HUPU_UINT8 link;
	HUPU_UINT8 enable;
	HUPU_UINT8 must;
};

/*
typedef struct delay_msg_struct
{
	struct nac_list_head msg_list;
	HUPU_UINT16 type;//cmd
	HUPU_UINT16 length;//xml_length + 4 + 1;
	HUPU_CHAR   *msg_body;
}DELAY_MSG_STRU;
*/

typedef struct delay_msg_struct
{
	struct nac_list_head msg_list;
	HUPU_UINT16 length;//cmd
	HUPU_UINT16 type;  //xml_length ;
	HUPU_CHAR   msg_body[0];
}DELAY_MSG_STRU;

HUPU_INT32 nac_app_init_delay_msg_list(HUPU_VOID);
HUPU_INT32 nac_app_add_delay_msg_list(HUPU_UINT16 length,
										HUPU_UINT16 cmd,
										HUPU_CHAR* xml_msg);
HUPU_INT32 nac_app_show_all_delay_msg(HUPU_VOID);
HUPU_INT32 nac_app_resend_delay_msg_list(HUPU_INT32	sock_fd);
HUPU_INT32 nac_app_get_asc_link_port_name(HUPU_CHAR* ports_name);

extern struct eth_detect_struct trust_eth_event;
extern struct eth_detect_struct manager_eth_event;
extern struct eth_detect_struct untrust_eth_event;

extern HUPU_UINT16 g_asc_escape_enable_flag;
extern HUPU_UINT16 g_asc_running_mode;
extern HUPU_CHAR   g_untrust_max_flow_speed[];


extern struct nac_list_head delay_msg_list_head;

//write escape_config to config file
HUPU_INT32 nac_sys_write_escape_config_to_configure(FILE* fp);
HUPU_INT32 nac_sys_get_escape_config_from_configure(const HUPU_CHAR *file_path);
HUPU_VOID *nac_system_escape_check_thread_enter(HUPU_VOID *arg);
HUPU_INT32 nac_sys_escape_config_deal(HUPU_UINT16 flag);
HUPU_INT32 nac_update_escape_check_event(HUPU_VOID);
HUPU_INT32 nac_system_upload_escape_msg(HUPU_INT32 ui_sock_fd, HUPU_CHAR* escape_info);
HUPU_INT32 nac_system_pack_escape_reason(HUPU_UINT16 detect_flag, HUPU_CHAR* escape_msg, HUPU_UINT16* run_status);

/*return xmlDoc*/
xmlDocPtr nac_sys_parse_escape_enable_flag(xmlDocPtr doc,
											HUPU_UINT16 cmd_id,
											HUPU_UINT8 *action);
#endif //end of NAC_SYSTEM_ESCAPE_DEAL_H
