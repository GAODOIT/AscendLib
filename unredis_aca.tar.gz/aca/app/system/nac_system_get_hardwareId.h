#ifndef NAC_SYSTEM_GET_HARDWAREID_H
#define NAC_SYSTEM_GET_HARDWAREID_H
#include "nac_system_common_lib.h"

// save controller_id to nac_device_id.conf for java switch.
HUPU_INT32 nac_sys_save_controller_id(const HUPU_CHAR* filename);

xmlDocPtr nac_sys_parse_get_hardwareId_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id);

#endif
