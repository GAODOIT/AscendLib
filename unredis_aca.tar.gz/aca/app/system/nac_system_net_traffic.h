/*
 *
 * Part:        nac net traffic app.
 *
 * Author:      cxk
 *
 */
 
#ifndef __NETTRAFFIC_HEAD__
#define __NETTRAFFIC_HEAD__

#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_common_lib.h"
#include "nac_system_errorlog.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "nac_system_redis_subscribe.h"


enum __ACTION_TYPE__
{
    APP_SHOW,
    APP_UPDATE
};
typedef struct __NET_TRAFFIC__
{
	char rx[32];
	char tx[32];
	char time[32];
	char rx_data[32];
	char tx_data[32];
	char uptime[32];
	char topN[512];
	
} NET_TRAFFIC;
typedef struct __NET_TRAFFIC_RESET__
{
	long long rx_data;
	long long tx_data;
	long long uptime;
} NET_TRAFFIC_RESET;


xmlDocPtr nac_system_parse_net_traffic(xmlDocPtr doc, HUPU_UINT16 cmd_id);

#endif

