#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_domain_policy.h"

//pthread_mutex_t nac_domain_policy_mutex = PTHREAD_MUTEX_INITIALIZER;

//except_domain and isolate_domain
struct nac_hlist_head nac_app_domain_hash[NAC_SYS_DOMAIN_HASH_SIZE];

HUPU_VOID nac_system_init_domain_policy(HUPU_VOID)
{
	HUPU_UINT16 i;

	for (i = 0; i < NAC_SYS_DOMAIN_HASH_SIZE; i++)
	{
        NAC_INIT_HLIST_HEAD(&nac_app_domain_hash[i]);
	}

	//pthread_mutex_init(&nac_domain_policy_mutex, HUPU_NULL);

	return;
}

HUPU_INT32 insert_domain_policy_hlist(NAC_APP_DOMAIN* domain_st)
{
	HUPU_UINT16 key;
	NAC_APP_DOMAIN* domain_ent = HUPU_NULL;

	key = (domain_st->id) % NAC_SYS_DOMAIN_HASH_SIZE;
	domain_ent = (NAC_APP_DOMAIN*)malloc(sizeof(NAC_APP_DOMAIN));
	if (domain_ent == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->malloc except_domain error\n", __FUNCTION__);
		return HUPU_ERR;
	}

	memset(domain_ent, '\0', sizeof(NAC_APP_DOMAIN));

	domain_ent->id   = domain_st->id;
	domain_ent->type = domain_st->type;
	memcpy(domain_ent->domain,	domain_st->domain,  strlen(domain_st->domain));
	memcpy(domain_ent->plyname, domain_st->plyname, strlen(domain_st->plyname));
	memcpy(domain_ent->comment, domain_st->comment, strlen(domain_st->comment));

	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s--%d--%d--%s--%s--%s\n", __FUNCTION__,
			domain_ent->id, domain_ent->type, domain_ent->domain, domain_ent->plyname,
			domain_ent->comment);

	nac_hlist_add_head(&domain_ent->node, &nac_app_domain_hash[key]);

	return HUPU_OK;
}

HUPU_INT32 remove_domain_policy_hlist(HUPU_UINT32 del_id)
{
    HUPU_UINT16 key;
    NAC_APP_DOMAIN *domain_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    key = del_id % NAC_SYS_DOMAIN_HASH_SIZE;

    if (!nac_hlist_empty(&nac_app_domain_hash[key]))
    {
        nac_hlist_for_each_entry_safe(domain_ent, pos, n, &nac_app_domain_hash[key], node)
        {
            if (del_id == domain_ent->id)
            {
                nac_hlist_del(&domain_ent->node);
                free(domain_ent);
            }
        }
    }
    return HUPU_OK;
}

NAC_APP_DOMAIN* find_domain_policy_hlist(HUPU_UINT32 find_id)
{
    HUPU_UINT16 key;
    NAC_APP_DOMAIN *domain_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    key = find_id % NAC_SYS_DOMAIN_HASH_SIZE;

    if (!nac_hlist_empty(&nac_app_domain_hash[key]))
    {
        nac_hlist_for_each_entry_safe(domain_ent, pos, n, &nac_app_domain_hash[key], node)
        {
            if (find_id == domain_ent->id)
            {
                return domain_ent;
            }
        }
    }

    return HUPU_NULL;
}

HUPU_INT32 modify_domain_policy_hlist(NAC_APP_DOMAIN* domain_st)
{
    HUPU_UINT16 key;
    NAC_APP_DOMAIN *domain_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    key = (domain_st->id) % NAC_SYS_DOMAIN_HASH_SIZE;

    if (!nac_hlist_empty(&nac_app_domain_hash[key]))
    {
        nac_hlist_for_each_entry_safe(domain_ent, pos, n, &nac_app_domain_hash[key], node)
        {
            //if (domain_st->id == domain_ent->id && domain_st->type == domain_ent->type)

            if (domain_st->id == domain_ent->id)
            {
				domain_ent->type = domain_st->type;

                memset(domain_ent->domain, '\0', sizeof(domain_ent->domain));
				memcpy(domain_ent->domain, domain_st->domain, strlen(domain_st->domain));

				if (strlen(domain_st->plyname) > 0)
				{
					memset(domain_ent->plyname, '\0', sizeof(domain_ent->plyname));
					memcpy(domain_ent->plyname, domain_st->plyname, strlen(domain_st->plyname));
				}

				if (strlen(domain_st->comment) > 0)
				{
					memset(domain_ent->comment, '\0', sizeof(domain_ent->comment));
					memcpy(domain_ent->comment, domain_st->comment, strlen(domain_st->comment));
				}
                return HUPU_OK;
            }
        }
    }
    return HUPU_ERR;
}

/*find it: return domain_policy_id; no find it: return HUPU_OK*/
HUPU_INT32 search_domain_policy_hlist(HUPU_CHAR* domain_buffer)
{
    HUPU_INT16 key;
    NAC_APP_DOMAIN *domain_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    for (key = 0; key < NAC_SYS_DOMAIN_HASH_SIZE; key++)
    {
        if (!nac_hlist_empty(&nac_app_domain_hash[key]))
        {
            nac_hlist_for_each_entry_safe(domain_ent, pos, n, &nac_app_domain_hash[key], node)
            {
            	//except_domain and isolate_domain cannot repeat;
                if ((strcmp(domain_buffer, domain_ent->domain) == HUPU_OK))
                {
		            nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->domain repeat to add error!\n", __FUNCTION__);
                    return domain_ent->id;
                }
            }
		}
    }

	return HUPU_OK;
}

HUPU_VOID nac_system_destroy_domain_policy_pool(HUPU_VOID)
{
    HUPU_INT16  key;
    NAC_APP_DOMAIN *domain_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    for (key = 0; key < NAC_SYS_DOMAIN_HASH_SIZE; key++)
    {
        nac_hlist_for_each_entry_safe(domain_ent, pos, n, &nac_app_domain_hash[key], node)
        {
            nac_hlist_del(&domain_ent->node);
            free(domain_ent);
        }
    }

}

HUPU_INT32 nac_sys_flush_knl_domain_policy(HUPU_VOID)
{
    HUPU_INT32 iRet;
    /*flush knl domian wm_struct; include except and isolate domain*/
    iRet = nac_set_data_to_knl(NAC_CMD_URL_FLUSH, 0, NULL, 0);
    if (iRet != HUPU_OK)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl flush_domain error, iRet=%d\n", iRet);
    }

    return HUPU_OK;
}

/*
  the except_domain and isolate_domain in knl cannot delete one by one;
  if need delete a knl domain,firstly wo flush all knl domain,
  secondly add all domain to knl.
  domain_ptype = NAC_APP_EXCEPT_DOMAIN;
  domain_ptype = NAC_APP_ISOLATE_DOMAIN;
  HUPU_INT32 nac_sys_insert_entire_except_domain_hlist(HUPU_UINT16 domain_ptype);

*/
HUPU_INT32 nac_system_set_all_domain_hlist_to_knl(HUPU_VOID)
{
    HUPU_INT32 iRet;
    HUPU_UINT16 key;
    NAC_APP_DOMAIN *domain_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    for (key = 0; key < NAC_SYS_DOMAIN_HASH_SIZE; key++)
    {
        if (!nac_hlist_empty(&nac_app_domain_hash[key]))
        {
            nac_hlist_for_each_entry_safe(domain_ent, pos, n, &nac_app_domain_hash[key], node)
            {

				if (domain_ent->type == NAC_APP_ISOLATE_DOMAIN)
				{
					iRet = nac_set_data_to_knl(NAC_CMD_URL_INS, domain_ent->id,
								domain_ent->domain, strlen(domain_ent->domain));
					if (iRet != HUPU_OK)
					{
						nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->isolate_domain error\n", __FUNCTION__);
						return HUPU_ERR;
					}
				}
				else if (domain_ent->type == NAC_APP_EXCEPT_DOMAIN)
				{
					iRet = nac_set_data_to_knl(NAC_CMD_URL_INS, GLOBAL_DOMAIN,
								domain_ent->domain, strlen(domain_ent->domain));
					if (iRet != HUPU_OK)
					{
						nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->except_domain error\n", __FUNCTION__);
						return HUPU_ERR;
					}
				}
				else
				{

				}
			}
        }
    }

    return HUPU_OK;
}


xmlDocPtr nac_system_get_domain_policy_hlist(HUPU_UINT16 command_id, const HUPU_CHAR* const_xml_plyname)
{
    xmlDocPtr doc;
    xmlNodePtr root_node;

    HUPU_UINT16 key, nac_domain_type;
    HUPU_CHAR get_buffer[BUFF_LEN] ="";
    NAC_APP_DOMAIN *domain_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    sprintf(get_buffer, "%d", (command_id + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST get_buffer);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");

	nac_domain_type = 0;
	if (command_id == SYS_WEBUI_EXCEPT_DOMAIN)
	{
		nac_domain_type = NAC_APP_EXCEPT_DOMAIN;
	}
	else if (command_id == SYS_WEBUI_SET_ISOLATE_DOMAINZONE)
	{
		nac_domain_type = NAC_APP_ISOLATE_DOMAIN;
	}
	else
	{
		return doc;
	}

	for (key = 0; key < NAC_SYS_DOMAIN_HASH_SIZE; key++)
	{
		if (!nac_hlist_empty(&nac_app_domain_hash[key]))
		{
			nac_hlist_for_each_entry_safe(domain_ent, pos, n, &nac_app_domain_hash[key], node)
			{
				if (nac_domain_type == domain_ent->type)
				{
					memset(get_buffer, '\0', sizeof(get_buffer));
					sprintf(get_buffer, "%d;%s;%s;%s", domain_ent->id, domain_ent->plyname,
						domain_ent->domain, domain_ent->comment);

					xmlNewChild(root_node, HUPU_NULL, BAD_CAST const_xml_plyname, BAD_CAST get_buffer);
				}
			}
		}
	}
    return doc;
}


HUPU_INT32 nac_system_add_domain_policy(NAC_APP_DOMAIN* domain_stru)
{
	HUPU_INT32 iRet;

    /*iRet = search_domain_policy_hlist(domain_stru->domain);
	if (iRet > HUPU_OK) //repeat
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->search_domain_policy_hlist repeat error\n", __FUNCTION__);
		return HUPU_ERR;
	}*/

	if (domain_stru->type == NAC_APP_ISOLATE_DOMAIN)
	{
		iRet = nac_set_data_to_knl(NAC_CMD_URL_INS, domain_stru->id,
								domain_stru->domain, strlen(domain_stru->domain));
		if (iRet != HUPU_OK)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->isolate_domain error\n", __FUNCTION__);
			return HUPU_ERR;
		}
	}
	else if (domain_stru->type == NAC_APP_EXCEPT_DOMAIN)
	{
		iRet = nac_set_data_to_knl(NAC_CMD_URL_INS, GLOBAL_DOMAIN,
								domain_stru->domain, strlen(domain_stru->domain));
		if (iRet != HUPU_OK)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->except_domain error\n", __FUNCTION__);
			return HUPU_ERR;
		}
	}

    iRet = insert_domain_policy_hlist(domain_stru);
	if (iRet == HUPU_ERR)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->insert_domain_policy_hlist insert error\n", __FUNCTION__);
		return HUPU_ERR;
	}

	return HUPU_OK;
}

HUPU_INT32 nac_system_delete_domain_policy(HUPU_UINT32 delete_id)
{
	HUPU_INT32 iRet;
	NAC_APP_DOMAIN* domain_ent = HUPU_NULL;
	NAC_APP_DOMAIN  st_domain_tmp;

	domain_ent = find_domain_policy_hlist(delete_id);
	if (domain_ent == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->find_domain_policy_hlist-->delete domain_id unexist error\n", __FUNCTION__);
		return HUPU_ERR;
	}

	memset(&st_domain_tmp, '\0', sizeof(NAC_APP_DOMAIN));
	memcpy(&st_domain_tmp, domain_ent, sizeof(NAC_APP_DOMAIN));

	/*
	if (app_domain_type == NAC_APP_ISOLATE_DOMAIN)
	if (app_domain_type == NAC_APP_EXCEPT_DOMAIN)
	*/
	iRet = nac_set_data_to_knl(NAC_CMD_URL_RMV, 0, st_domain_tmp.domain, strlen(st_domain_tmp.domain));
	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->NAC_CMD_URL_RMV error\n", __FUNCTION__);
		return HUPU_ERR;
	}

	remove_domain_policy_hlist(st_domain_tmp.id);

	return HUPU_OK;
}

HUPU_INT32 nac_system_modify_domain_policy(NAC_APP_DOMAIN* domain_stru)
{
	HUPU_INT32 iRet;
	NAC_APP_DOMAIN* domain_ent = HUPU_NULL;
	NAC_APP_DOMAIN  st_domain_tmp;

	//return domain_st->id
	domain_ent = find_domain_policy_hlist(domain_stru->id);
	if (domain_ent == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->find domain_poilcy by ID fail\n",
					__FUNCTION__);

		return HUPU_ERR;
	}

	memset(&st_domain_tmp, '\0', sizeof(NAC_APP_DOMAIN));
	memcpy(&st_domain_tmp, domain_ent, sizeof(NAC_APP_DOMAIN));

	if (strcmp(domain_stru->domain, st_domain_tmp.domain) == HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS,
					"%s-->only modify plyname or comment\n", __FUNCTION__);
		modify_domain_policy_hlist(domain_stru);
		return HUPU_OK;
	}

	//del knl before modify domain
	iRet = nac_set_data_to_knl(NAC_CMD_URL_RMV, 0, st_domain_tmp.domain,
							strlen(st_domain_tmp.domain));
	if (iRet != HUPU_OK)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,
					"%s-->nac_set_data_to_knl-->NAC_CMD_URL_RMV error\n",
					__FUNCTION__);
		return HUPU_ERR;
	}

	//insert knl after modify domain
	if (domain_stru->type == NAC_APP_ISOLATE_DOMAIN)
	{
		iRet = nac_set_data_to_knl(NAC_CMD_URL_INS, domain_stru->id,
								domain_stru->domain, strlen(domain_stru->domain));
		if (iRet != HUPU_OK)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->isolate_domain error\n", __FUNCTION__);
			return HUPU_ERR;
		}
	}
	else if (domain_stru->type == NAC_APP_EXCEPT_DOMAIN)
	{
		iRet = nac_set_data_to_knl(NAC_CMD_URL_INS, GLOBAL_DOMAIN,
								domain_stru->domain, strlen(domain_stru->domain));
		if (iRet != HUPU_OK)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_set_data_to_knl-->except_domain error\n", __FUNCTION__);
			return HUPU_ERR;
		}
	}

	//update modify_domain in domain_policy_pool
	modify_domain_policy_hlist(domain_stru);

	return HUPU_OK;
}

/*for example: const_xml_plyname=isolateDomainzone; g_policy_index*/
xmlDocPtr nac_system_parse_domain_policy_xml(xmlDocPtr doc,
						HUPU_UINT16 cmd_id,	HUPU_UINT16 enum_plytype,
						const HUPU_CHAR* const_xml_plyname)
{
	HUPU_INT32 iRet, error_id;
	xmlDocPtr nac_doc = HUPU_NULL;
	xmlNodePtr cur_node;
	xmlChar *szKey;
	xmlChar *szAttr;
	HUPU_UINT8 action_type;
	HUPU_UINT32 policy_id;
	NAC_APP_DOMAIN st_domain;

	cur_node = nac_xml_parse_get_action(doc, &action_type);
	if (cur_node == HUPU_NULL)
	{
		nac_free_xmlDoc(doc);
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
		return HUPU_NULL;
	}

    error_id = 0;
	switch(action_type)
	{
	case NAC_SHOW:
		nac_free_xmlDoc(doc);
		nac_doc = nac_system_get_domain_policy_hlist(cmd_id, const_xml_plyname);
		break;

	case NAC_ADD: //get a new id.
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST const_xml_plyname)))
			{
				memset(&st_domain, '\0',  sizeof(NAC_APP_DOMAIN));
                szKey = xmlNodeGetContent(cur_node);
                sscanf((HUPU_CHAR*)szKey, "%[^;];%[^;];%s", st_domain.plyname,
					st_domain.domain, st_domain.comment);
				xmlFree(szKey);

				SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "NAC_ADD-->plyname=%s-->domain=%s-->comment=%s\n",
                                   st_domain.plyname, st_domain.domain, st_domain.comment);

				if (strlen(st_domain.plyname) > 0 && strlen(st_domain.domain) > 0)
				{
					g_policy_index = g_policy_index + 1;
				}
				else
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->add domain policy error\n", __FUNCTION__);
					// NAC_SYS_ERROR_ILLEGAL_DOMAIN;
					error_id = NAC_SYS_ERROR_ADD_DOMAIN_FAIL;
					break;
				}

				st_domain.id = g_policy_index;
				st_domain.type = enum_plytype;

				SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
                                   "NAC_ADD--id=%d--type=%d--plyname=%s--domain=%s--comment=%s\n",
                                   st_domain.id, st_domain.type, st_domain.domain, st_domain.plyname, st_domain.comment);

			    iRet = nac_system_add_domain_policy(&st_domain);
				if (iRet != HUPU_OK)
				{
                    g_policy_index = g_policy_index - 1;
                    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_system_add_domain_policy error\n", __FUNCTION__);
					if (iRet == HUPU_ERR)
					{
						error_id = NAC_SYS_ERROR_ADD_DOMAIN_FAIL;//add_domain_error
					}
					else
					{
						error_id = iRet;
					}

					break;
				}
			}
			cur_node = cur_node->next;
		}

		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

	case NAC_DEL: //del the data of this id.
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST const_xml_plyname))
                && (xmlHasProp(cur_node, BAD_CAST "id")))
			{
				szAttr = xmlGetProp(cur_node, BAD_CAST "id");
				policy_id = atoi((HUPU_CHAR*)szAttr);
                xmlFree(szAttr);

				iRet = nac_system_delete_domain_policy(policy_id);
				if (iRet != HUPU_OK)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_delete_domain_policy error\n", __FUNCTION__);
                    if (iRet == HUPU_ERR)
					{
						error_id = NAC_SYS_ERROR_DEL_DOMAIN_FAIL;//del_domain_error
					}
					else
					{
						error_id = iRet;//NAC_SYS_ERROR_DOMAIN_RESOLVE_FAIL
					}
					break;
				}
			}
			cur_node = cur_node->next;
		}
		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

	case NAC_MODIFY: //only update the data, id is still.
		while (cur_node != HUPU_NULL)
		{
			if (!(xmlStrcmp(cur_node->name, BAD_CAST const_xml_plyname))
                && (xmlHasProp(cur_node, BAD_CAST "id")))
			{
                memset(&st_domain, '\0',  sizeof(NAC_APP_DOMAIN));
				szKey = xmlNodeGetContent(cur_node);
                sscanf((HUPU_CHAR*)szKey, "%[^;];%[^;];%s", st_domain.plyname,
					st_domain.domain, st_domain.comment);
				xmlFree(szKey);

				szAttr = xmlGetProp(cur_node, BAD_CAST "id");
				st_domain.id = atoi((HUPU_CHAR*)szAttr);
				xmlFree(szAttr);

				if (strlen(st_domain.plyname) == 0 || strlen(st_domain.domain) == 0)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->modify domain policy error\n", __FUNCTION__);
					error_id = NAC_SYS_ERROR_MODIFY_DOMAIN_FAIL;
					break;
				}

				st_domain.type = enum_plytype;

				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->NAC_MODIFY-->id=%d-->plyname=%s-->domain=%s-->comment=%s\n",
							__FUNCTION__, st_domain.id, st_domain.plyname, st_domain.domain, st_domain.comment);

                iRet = nac_system_modify_domain_policy(&st_domain);
				if (iRet != HUPU_OK)
				{
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_modify_domain_policy error\n", __FUNCTION__);
					if (iRet == HUPU_ERR)
					{
						error_id = NAC_SYS_ERROR_MODIFY_DOMAIN_FAIL;//modify_domain_error
					}
					else
					{
						error_id = iRet;//NAC_SYS_ERROR_DOMAIN_RESOLVE_FAIL
					}
					break;
				}
			}
			cur_node = cur_node->next;
		}

		nac_free_xmlDoc(doc);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
		break;

	default:
		nac_free_xmlDoc(doc);
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
		break;
	}

	return nac_doc;
}
