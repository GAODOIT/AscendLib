/*
 *LINUX APP 内存保存IP段链表中没有建立重复遍历检测机制。
*/
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_app_knl_port.h"
#include "nac_system_iprange_policy.h"

//except_terminal, except_server, safe_iprangezone, isolate_iprangezone, except_domain
HUPU_UINT16 g_policy_index  = 0;

//pthread_mutex_t nac_iprange_policy_mutex = PTHREAD_MUTEX_INITIALIZER;

struct nac_hlist_head nac_app_policy_hash[NAC_SYS_POLICY_HASH_SIZE];


HUPU_VOID nac_system_init_iprange_policy(HUPU_VOID)
{
	HUPU_UINT16 i;

	for (i = 0; i < NAC_SYS_POLICY_HASH_SIZE; i++)
    {
        NAC_INIT_HLIST_HEAD(&nac_app_policy_hash[i]);
    }

	//pthread_mutex_init(&nac_iprange_policy_mutex, HUPU_NULL);

	return;
}



HUPU_INT32 app_policy_debug_print(NAC_APP_POLICY* pst_policy)
{
    if (pst_policy->type == NAC_APP_EXCEPT_MAC)
    {
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "policy=%d--%d--%02X-%02X-%02X-%02X-%02X-%02X--%s--%s\n",
				pst_policy->id, pst_policy->type, MAC_FORMAT(pst_policy->union_ply.mac.ac_mac),
				pst_policy->plyname, pst_policy->comment);
    }
    else
    {
         SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "policy=%d--%d--%u.%u.%u.%u--%u.%u.%u.%u--%s--%s\n",
				pst_policy->id, pst_policy->type, LIPQUAD(pst_policy->union_ply.iprange.ip_min),
				LIPQUAD(pst_policy->union_ply.iprange.ip_max), pst_policy->plyname, pst_policy->comment);
    }
    return HUPU_OK;
}


HUPU_INT32 insert_app_policy_hlist(NAC_APP_POLICY* policy_st)
{
    HUPU_UINT16 key;
    NAC_APP_POLICY *policy_ent = HUPU_NULL;
    key = (policy_st->id) % NAC_SYS_POLICY_HASH_SIZE;

	policy_ent = (NAC_APP_POLICY*)malloc(sizeof(NAC_APP_POLICY));
    if (policy_ent == HUPU_NULL)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "malloc policy error!\n");
        return HUPU_ERR;
    }

	memset(policy_ent, '\0', sizeof(NAC_APP_POLICY));
    memcpy(policy_ent, policy_st, sizeof(NAC_APP_POLICY));

    nac_hlist_add_head(&policy_ent->node, &nac_app_policy_hash[key]);
    app_policy_debug_print(policy_ent);

    return HUPU_OK;
}

/*Ascend syscall; no matter, find the del_id policy or not, still return HUPU_OK*/
HUPU_INT32 remove_app_policy_hlist(HUPU_UINT32 del_id)//EM_POLICY_TYPE is or not need
{
    HUPU_UINT16 key;
    NAC_APP_POLICY *policy_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    key = del_id % NAC_SYS_POLICY_HASH_SIZE;

    nac_hlist_for_each_entry_safe(policy_ent, pos, n, &nac_app_policy_hash[key], node)
    {
        if (policy_ent->id == del_id)
        {
            nac_hlist_del(&policy_ent->node);
            free(policy_ent);
        }
    }

    return HUPU_OK;
}

/*return != HUPU_NULL, find the policy*/
NAC_APP_POLICY* find_app_policy_hlist(HUPU_UINT32 find_id, HUPU_UINT16 policy_type)
{
    HUPU_UINT16 key;
    NAC_APP_POLICY *policy_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    key = find_id % NAC_SYS_POLICY_HASH_SIZE;

    nac_hlist_for_each_entry_safe(policy_ent, pos, n, &nac_app_policy_hash[key], node)
    {
        if (policy_ent->id == find_id && policy_ent->type == policy_type)
        {
            return policy_ent;
        }
    }

    return HUPU_NULL;
}

//find it: return HUPU_ERR; no find it: return HUPU_OK;
//avoid repeat domain argument interface;
HUPU_INT32 search_app_policy_hlist(NAC_APP_POLICY* search_stru)
{
	HUPU_UINT16 key;
	NAC_APP_POLICY *policy_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

	for (key = 0; key < NAC_SYS_POLICY_HASH_SIZE; key++)
    {
        nac_hlist_for_each_entry_safe(policy_ent, pos, n, &nac_app_policy_hash[key], node)
        {
            if (search_stru->type == policy_ent->type)
            {
                if (search_stru->type == NAC_APP_EXCEPT_TERMINAL || search_stru->type == NAC_APP_EXCEPT_SERVER
                    || search_stru->type == NAC_APP_SAFE_IPZONE  || search_stru->type == NAC_APP_ISOLATE_IPZONE)
                {
                    if (search_stru->union_ply.iprange.ip_min == policy_ent->union_ply.iprange.ip_min
                            && search_stru->union_ply.iprange.ip_max == policy_ent->union_ply.iprange.ip_max)
                    {
                        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"iprange policy insert repeat error!\n");
                        return HUPU_ERR;
                    }
                }
                else if (search_stru->type == NAC_APP_EXCEPT_MAC)
                {
                    if (!memcmp(search_stru->union_ply.mac.ac_mac, policy_ent->union_ply.mac.ac_mac, ETH_ALEN))
                    {
                        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"except mac insert repeat error!\n");
                        return HUPU_ERR;
                    }
                }
            }
        }
    }
	return HUPU_OK;
}

HUPU_INT32 modify_app_policy_hlist(NAC_APP_POLICY* mod_stru)
{
    HUPU_UINT16 key;
    NAC_APP_POLICY *policy_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    key = (mod_stru->id) % NAC_SYS_POLICY_HASH_SIZE;
    nac_hlist_for_each_entry_safe(policy_ent, pos, n, &nac_app_policy_hash[key], node)
    {
	    if (mod_stru->id == policy_ent->id && mod_stru->type == policy_ent->type)
		{
            if (policy_ent->type == NAC_APP_EXCEPT_MAC)
            {
                memset(policy_ent->union_ply.mac.ac_mac, '\0', ETH_ALEN);
                memcpy(policy_ent->union_ply.mac.ac_mac, mod_stru->union_ply.mac.ac_mac, ETH_ALEN);
            }
		    else if (policy_ent->type == NAC_APP_EXCEPT_TERMINAL || policy_ent->type == NAC_APP_EXCEPT_SERVER
					|| policy_ent->type == NAC_APP_SAFE_IPZONE || policy_ent->type == NAC_APP_ISOLATE_IPZONE)
		    {
				policy_ent->union_ply.iprange.ip_min = mod_stru->union_ply.iprange.ip_min;
				policy_ent->union_ply.iprange.ip_max = mod_stru->union_ply.iprange.ip_max;
			}

		    if (strlen(mod_stru->plyname) > 0)
		    {
				memset(policy_ent->plyname, '\0', sizeof(policy_ent->plyname));
				memcpy(policy_ent->plyname, mod_stru->plyname, strlen(mod_stru->plyname));
			}

			if (strlen(mod_stru->comment) > 0)
			{
				memset(policy_ent->comment, '\0', sizeof(policy_ent->comment));
				memcpy(policy_ent->comment, mod_stru->comment, strlen(mod_stru->comment));
			}

			return HUPU_OK;
         }
    }
    return HUPU_ERR;
}

HUPU_INT32 nac_system_destroy_app_policy_pool(HUPU_VOID)
{
    HUPU_INT16  key;
    NAC_APP_POLICY *policy_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    for (key = 0; key < NAC_SYS_POLICY_HASH_SIZE; key++)
    {
        nac_hlist_for_each_entry_safe(policy_ent, pos, n, &nac_app_policy_hash[key], node)
        {
            nac_hlist_del(&policy_ent->node);
            free(policy_ent);
        }
    }

    return HUPU_OK;
}

HUPU_INT32 nac_sys_flush_knl_iprange_config(HUPU_INT16 type)
{
   HUPU_INT32 iRet;
   HUPU_INT16 policy_type = 0;
   if (type == NAC_APP_EXCEPT_TERMINAL)
   {
        policy_type = NAC_KNL_RBTREE_EXCEPT_TERMINAL;
   }
   else if (type == NAC_APP_EXCEPT_SERVER)
   {
        policy_type = NAC_KNL_RBTREE_EXCEPT_SERVER;
   }
   else if (type == NAC_APP_SAFE_IPZONE)
   {
        policy_type = NAC_KNL_RBTREE_IP_RANGE;
   }
   else if(type == NAC_APP_ISOLATE_IPZONE)
   {
        policy_type = NAC_KNL_RBTREE_ISOLATION_ZONE;
   }

   if (policy_type)
   {
        iRet = nac_set_data_to_knl(NAC_CMD_RBTREE_FLUSH, policy_type, NULL, 0);
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_set_data_to_knl flush %d, iRet = %d\n", type, iRet);
   }

   return HUPU_OK;
}


//exceptTerminal--exceptServer--safeIpzone--isolateIpzone
xmlDocPtr nac_sys_get_iprange_policy_hlist(HUPU_UINT16 command_id, const HUPU_CHAR* xml_tag)
{
    xmlDocPtr doc;
    xmlNodePtr root_node;

    HUPU_UINT16 key, nac_policy_type;
    HUPU_CHAR get_buffer[BUFF_LEN] = "";
    NAC_APP_POLICY *policy_ent = HUPU_NULL;
    struct nac_hlist_node *pos, *n;

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    sprintf(get_buffer, "%d", (command_id + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST get_buffer);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");

    if (command_id != SYS_WEBUI_EXCEPT_MAC)
    {
        xmlNewChild(root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");
    }

    nac_policy_type = 0;
    switch(command_id)
    {
    case SYS_WEBUI_EXCEPT_TERMINAL:
        nac_policy_type = NAC_APP_EXCEPT_TERMINAL;
        break;

    case SYS_WEBUI_EXCEPT_SERVER:
        nac_policy_type = NAC_APP_EXCEPT_SERVER;
        break;

    case SYS_WEBUI_SET_SAFE_ZONE:
        nac_policy_type = NAC_APP_SAFE_IPZONE;
        break;

    case SYS_WEBUI_SET_ISOLATE_IPZONE:
        nac_policy_type = NAC_APP_ISOLATE_IPZONE;
        break;

    case SYS_WEBUI_EXCEPT_MAC:
        nac_policy_type = NAC_APP_EXCEPT_MAC;
        break;

    default:
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid show command_id\n", __FUNCTION__);
        break;

    }

    for (key = 0; key < NAC_SYS_POLICY_HASH_SIZE; key++)
    {
        if (!nac_hlist_empty(&nac_app_policy_hash[key]))
        {
            nac_hlist_for_each_entry_safe(policy_ent, pos, n, &nac_app_policy_hash[key], node)
            {
                memset(get_buffer, '\0', sizeof(get_buffer));
                if (nac_policy_type == policy_ent->type)
                {
                    if (nac_policy_type == NAC_APP_EXCEPT_MAC)
                    {
                        sprintf(get_buffer, "%d;%s;%02X-%02X-%02X-%02X-%02X-%02X;%s", policy_ent->id,
                            policy_ent->plyname, MAC_FORMAT(policy_ent->union_ply.mac.ac_mac), policy_ent->comment);
                    }
                    else
                    {
                        sprintf(get_buffer, "%d;%s;%u.%u.%u.%u-%u.%u.%u.%u;%s", policy_ent->id, policy_ent->plyname,
							LIPQUAD(policy_ent->union_ply.iprange.ip_min), LIPQUAD(policy_ent->union_ply.iprange.ip_max),
							policy_ent->comment);
                    }
					xmlNewChild(root_node, HUPU_NULL, BAD_CAST xml_tag, BAD_CAST get_buffer);
                }
            }
        }
    }
    return doc;
}

HUPU_INT32 nac_system_add_iprange_policy(NAC_APP_POLICY* policy_st)
{
    HUPU_INT32 iRet;
    NAC_KNL_RBTREE_TYPE knl_rbtree_type;
    NAC_KNL_RBTREE_OP_CODE knl_rbtree_action;

	/*
	iRet = search_app_policy_hlist(policy_st);
	if (iRet == HUPU_ERR)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->iprange policy insert repeat error!\n", __FUNCTION__);
		return NAC_SYS_ERROR_REPEAT_IPRANGE;
	}
	*/

    if (policy_st->type == NAC_APP_EXCEPT_TERMINAL)
    {
        knl_rbtree_type = NAC_KNL_RBTREE_EXCEPT_TERMINAL;
    }
    else if (policy_st->type == NAC_APP_EXCEPT_SERVER)
    {
        knl_rbtree_type = NAC_KNL_RBTREE_EXCEPT_SERVER;
    }
	else if (policy_st->type == NAC_APP_SAFE_IPZONE)
	{
		knl_rbtree_type = NAC_KNL_RBTREE_IP_RANGE;
	}
	else if (policy_st->type == NAC_APP_ISOLATE_IPZONE)
	{
		knl_rbtree_type = NAC_KNL_RBTREE_ISOLATION_ZONE;
	}
	else
	{
		return HUPU_ERR;
	}

    knl_rbtree_action = NAC_CMD_RBTREE_INS;
	if (knl_rbtree_type == NAC_KNL_RBTREE_ISOLATION_ZONE)
	{
		iRet = nac_app_set_isolate_iprange_to_knl_rbtree(knl_rbtree_type, knl_rbtree_action,
				policy_st->union_ply.iprange.ip_min, policy_st->union_ply.iprange.ip_max, policy_st->id);
		if (iRet == HUPU_ERR)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_app_set_isolate_iprange_to_knl_rbtree is error, iRet = %d\n",
						__FUNCTION__, iRet);
			return NAC_KNL_ERROR_INSERT_ISOLATE_ZONE_FAIL;
		}
	}
	else
	{
		iRet = nac_sys_set_iprange_to_knl_rbtree(policy_st->union_ply.iprange.ip_min,
				policy_st->union_ply.iprange.ip_max, knl_rbtree_type, knl_rbtree_action);
		if (iRet == HUPU_ERR)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_set_iprange_to_knl_rbtree is error, iRet = %d\n",
						__FUNCTION__, iRet);
			return NAC_KNL_ERROR_INSERT_SAFE_ZONE_FAIL;
		}
	}

	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s--%d--%d--%08x--%08x--%s--%s\n", __FUNCTION__,
				policy_st->id, policy_st->type, policy_st->union_ply.iprange.ip_min,
				policy_st->union_ply.iprange.ip_max, policy_st->plyname, policy_st->comment);

	/*
	Ascend_dowell, or wo can copy this point to a tmp struct,then insert the hlist,
 	and in a new port, wo also need to sprint the data, when wo use it.
	*/
    iRet = insert_app_policy_hlist(policy_st);
    if (iRet == HUPU_ERR)
    {
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->insert_app_policy_hlist is error, iRet = %d\n", __FUNCTION__, iRet);
        return NAC_SYS_ERROR_ADD_IPRANGE_HLIST_FAIL;
    }

    return HUPU_OK;
}

static HUPU_INT32 nac_sys_delete_iprange_policy(HUPU_UINT16 app_policy_type, HUPU_UINT32 del_id)
{
    HUPU_INT32 iRet;
	NAC_APP_POLICY *policy_ent = HUPU_NULL;
    NAC_KNL_RBTREE_TYPE knl_rbtree_type;
    NAC_KNL_RBTREE_OP_CODE knl_rbtree_action;

	if (app_policy_type == NAC_APP_EXCEPT_TERMINAL)
    {
        knl_rbtree_type = NAC_KNL_RBTREE_EXCEPT_TERMINAL;
    }
    else if (app_policy_type == NAC_APP_EXCEPT_SERVER)
    {
        knl_rbtree_type = NAC_KNL_RBTREE_EXCEPT_SERVER;
    }
	else if (app_policy_type == NAC_APP_SAFE_IPZONE)
	{
		knl_rbtree_type = NAC_KNL_RBTREE_IP_RANGE;
	}
	else if (app_policy_type == NAC_APP_ISOLATE_IPZONE)
	{
		knl_rbtree_type = NAC_KNL_RBTREE_ISOLATION_ZONE;
	}
	else
	{
		return HUPU_ERR;
	}

    knl_rbtree_action = NAC_CMD_RBTREE_RMV;
	policy_ent = find_app_policy_hlist(del_id, app_policy_type);
	if (policy_ent == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->find_app_policy_hlist-->del_id iprange policy unexist\n", __FUNCTION__);
		return NAC_SYS_ERROR_DEL_IPRANGE_POLICY_UNEXIST;
	}

	/*
	if (knl_rbtree_type == NAC_KNL_RBTREE_EXCEPT_TERMINAL || knl_rbtree_type == NAC_KNL_RBTREE_EXCEPT_SERVER
		|| knl_rbtree_type == NAC_KNL_RBTREE_IP_RANGE || knl_rbtree_type == NAC_KNL_RBTREE_ISOLATION_ZONE)
	*/

	iRet = nac_sys_set_iprange_to_knl_rbtree(policy_ent->union_ply.iprange.ip_min,
		policy_ent->union_ply.iprange.ip_max, knl_rbtree_type, knl_rbtree_action);
	if (iRet == HUPU_ERR)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_set_iprange_to_knl_rbtree is error, iRet = %d\n", __FUNCTION__, iRet);
		return NAC_KNL_ERROR_REMOVE_IPRANGE_ZONE_FAIL;
	}

    remove_app_policy_hlist(del_id);
    return HUPU_OK;
}

static HUPU_INT32 nac_sys_modify_iprange_policy(NAC_APP_POLICY* policy_st)//policy_st->id--old modify id;
{
    HUPU_INT32 iRet;
    NAC_APP_POLICY* policy_ent = HUPU_NULL;
    NAC_KNL_RBTREE_TYPE knl_rbtree_type;
    NAC_KNL_RBTREE_OP_CODE knl_rbtree_action;

	if (policy_st->type == NAC_APP_EXCEPT_TERMINAL)
    {
        knl_rbtree_type = NAC_KNL_RBTREE_EXCEPT_TERMINAL;
    }
    else if (policy_st->type == NAC_APP_EXCEPT_SERVER)
    {
        knl_rbtree_type = NAC_KNL_RBTREE_EXCEPT_SERVER;
    }
	else if (policy_st->type == NAC_APP_SAFE_IPZONE)
	{
		knl_rbtree_type = NAC_KNL_RBTREE_IP_RANGE;
	}
	else if (policy_st->type == NAC_APP_ISOLATE_IPZONE)
	{
		knl_rbtree_type = NAC_KNL_RBTREE_ISOLATION_ZONE;
	}
	else
	{
		return HUPU_ERR;
	}

	/*
	iRet = search_except_policy_hlist(policy_st);
	if (iRet == HUPU_ERR)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->iprange policy insert repeat error!\n", __FUNCTION__);
		return NAC_SYS_ERROR_REPEAT_IPRANGE;
	}
	*/

	policy_ent = find_app_policy_hlist(policy_st->id, policy_st->type);
	if (policy_ent == HUPU_NULL)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->find_app_policy_hlist-->modify_id iprange policy unexist\n", __FUNCTION__);
		return NAC_SYS_ERROR_MODIFY_IPRANGE_POLICY_UNEXIST;
	}

	//2014-04-23-bug--ip_min and ip_max, if one have modify, must be modify.
	if (policy_ent->union_ply.iprange.ip_min == policy_st->union_ply.iprange.ip_min
		&& policy_ent->union_ply.iprange.ip_max == policy_st->union_ply.iprange.ip_max) //only modify plyname and comment
	{
		modify_app_policy_hlist(policy_st);
		return HUPU_OK;
	}

    /*del knl old policy*/
    knl_rbtree_action = NAC_CMD_RBTREE_RMV;
	SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "--%s--remove--old--%d.%d.%d.d-->%d.%d.%d.%d\n", __FUNCTION__,
			LIPQUAD(policy_ent->union_ply.iprange.ip_min), LIPQUAD(policy_ent->union_ply.iprange.ip_max));

	iRet = nac_sys_set_iprange_to_knl_rbtree(policy_ent->union_ply.iprange.ip_min,
		policy_ent->union_ply.iprange.ip_max, knl_rbtree_type, knl_rbtree_action);
	if (iRet == HUPU_ERR)
	{
		nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_set_iprange_to_knl_rbtree-->del old modify iprange error, iRet = %d\n", __FUNCTION__, iRet);
		return NAC_KNL_ERROR_REMOVE_IPRANGE_ZONE_FAIL;
	}

    /*in old policy_id position, insert new policy*/
    knl_rbtree_action = NAC_CMD_RBTREE_INS;
	if (knl_rbtree_type == NAC_KNL_RBTREE_ISOLATION_ZONE)
	{
		iRet = nac_app_set_isolate_iprange_to_knl_rbtree(knl_rbtree_type, knl_rbtree_action,
			policy_st->union_ply.iprange.ip_min, policy_st->union_ply.iprange.ip_max, policy_st->id);

		if (iRet == HUPU_ERR)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_app_set_isolate_iprange_to_knl_rbtree is error, iRet = %d\n",
							__FUNCTION__, iRet);
			return NAC_KNL_ERROR_INSERT_ISOLATE_ZONE_FAIL;
		}
	}
	else
	{
		SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "--%s--insert--new--%d.%d.%d.d-->%d.%d.%d.%d\n", __FUNCTION__,
					LIPQUAD(policy_st->union_ply.iprange.ip_min), LIPQUAD(policy_st->union_ply.iprange.ip_max));

		iRet = nac_sys_set_iprange_to_knl_rbtree(policy_st->union_ply.iprange.ip_min,
				policy_st->union_ply.iprange.ip_max, knl_rbtree_type, knl_rbtree_action);
		if (iRet == HUPU_ERR)
		{
			nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_set_iprange_to_knl_rbtree is error, iRet = %d\n",
							__FUNCTION__, iRet);
			return NAC_KNL_ERROR_INSERT_SAFE_ZONE_FAIL;
		}
	}

	/*modify insert into the nac_app_policy_hash*/
	modify_app_policy_hlist(policy_st);

	return HUPU_OK;
}

xmlDocPtr nac_system_parse_iprange_policy_xml(xmlDocPtr doc, HUPU_UINT16 cmd_id, HUPU_UINT16 enum_plytype, const HUPU_CHAR* const_xml_plyname)
{
    HUPU_INT32 iRet, error_id;
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    xmlChar *szKey, *szAttr;
    HUPU_UINT8 action_type;

	NAC_APP_POLICY xml_policy_st;//strlen(plyname)== strlen(comment) =12*3;
    HUPU_UINT32 policy_id;
    HUPU_CHAR ip_min_str[16];
    HUPU_CHAR ip_max_str[16];

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

    error_id = 0;
    switch(action_type)
    {
    case NAC_SHOW:
        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_get_iprange_policy_hlist(cmd_id, const_xml_plyname);
        break;

    case NAC_ADD: //get a new id.
        while (cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST const_xml_plyname)))
            {
				memset(&xml_policy_st, '\0', sizeof(NAC_APP_POLICY));
                szKey = xmlNodeGetContent(cur_node);
				sscanf((HUPU_CHAR*)szKey, "%[^;];%[^-]-%[^;];%s", xml_policy_st.plyname,
						ip_min_str, ip_max_str, xml_policy_st.comment);

				xmlFree(szKey);

				if (strlen(xml_policy_st.plyname) > 0 &&
					nac_app_preg_match_iprange(ip_min_str, ip_max_str) == HUPU_OK)
				{
					xml_policy_st.union_ply.iprange.ip_min = inet_network(ip_min_str);
                	xml_policy_st.union_ply.iprange.ip_max = inet_network(ip_max_str);
				}
				else
				{
                   	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->add ip_range format is error\n", __FUNCTION__);
					error_id = NAC_SYS_ERROR_ILLEGAL_IPRANGE;
                    break;
				}

                g_policy_index		= g_policy_index + 1;
				xml_policy_st.id	= g_policy_index;
                xml_policy_st.type  = enum_plytype;

				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->NAC_ADD-->%d--%d--%08x--%08x--%s--%s\n", __FUNCTION__,
                			xml_policy_st.id, xml_policy_st.type, xml_policy_st.union_ply.iprange.ip_min,
                			xml_policy_st.union_ply.iprange.ip_max, xml_policy_st.plyname, xml_policy_st.comment);

                iRet = nac_system_add_iprange_policy(&xml_policy_st);
                if (iRet != HUPU_OK)
                {
                    g_policy_index = g_policy_index - 1;
                    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_add_iprange_policy error\n", __FUNCTION__);
					if (iRet == HUPU_ERR)
					{
						error_id = NAC_SYS_ERROR_ADD_IPRANGE_FAIL; //add ip_range policy
					}
					else
					{
						error_id = iRet;
					}
                    break;
                }
            }
            cur_node = cur_node->next;
        }

        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    case NAC_DEL: //del the data of this id.
        while (cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST const_xml_plyname))
                && (xmlHasProp(cur_node, BAD_CAST "id")))
            {
                szAttr = xmlGetProp(cur_node, BAD_CAST "id");
                policy_id = atoi((HUPU_CHAR*)szAttr);
                xmlFree(szAttr);

                iRet = nac_sys_delete_iprange_policy(enum_plytype, policy_id);
                if (iRet != HUPU_OK)
                {
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->nac_sys_delete_iprange_policy error\n", __FUNCTION__);
                    if (iRet == HUPU_ERR)
					{
						error_id = NAC_SYS_ERROR_DEL_IPRANGE_FAIL; //del ip_range policy
					}
					else
					{
						error_id = iRet;
					}
                    break;
                }
            }
           cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    case NAC_MODIFY: //only update the data,id is still.
        while (cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST const_xml_plyname))
                && (xmlHasProp(cur_node, BAD_CAST "id")))
            {
				memset(&xml_policy_st, '\0', sizeof(NAC_APP_POLICY));

				szAttr = xmlGetProp(cur_node, BAD_CAST "id");
                xml_policy_st.id = atoi((HUPU_CHAR*)szAttr);
                xmlFree(szAttr);

                szKey = xmlNodeGetContent(cur_node);
				sscanf((HUPU_CHAR*)szKey, "%[^;];%[^-]-%[^;];%s", xml_policy_st.plyname,
						ip_min_str, ip_max_str, xml_policy_st.comment);
				xmlFree(szKey);


				if (xml_policy_st.id > 0 && strlen(xml_policy_st.plyname) > 0
					&& nac_app_preg_match_iprange(ip_min_str, ip_max_str) == HUPU_OK)
				{
					xml_policy_st.union_ply.iprange.ip_min = inet_network(ip_min_str);
                	xml_policy_st.union_ply.iprange.ip_max = inet_network(ip_max_str);
				}
				else
				{
                   	nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->modify ip_range format is error\n", __FUNCTION__);
					error_id = NAC_SYS_ERROR_ILLEGAL_IPRANGE;
                    break;
				}

                xml_policy_st.type = enum_plytype;

				SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "-->%s-->NAC_MODIFY--%d--%d--%08x--%08x--%s--%s\n", __FUNCTION__,
						xml_policy_st.id, xml_policy_st.type, xml_policy_st.union_ply.iprange.ip_min,
                		xml_policy_st.union_ply.iprange.ip_max, xml_policy_st.plyname, xml_policy_st.comment);

                iRet = nac_sys_modify_iprange_policy(&xml_policy_st);
                if (iRet != HUPU_OK)
                {
					nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_sys_modify_iprange_policy error\n", __FUNCTION__);
					if (iRet == HUPU_ERR)
					{
						error_id = NAC_SYS_ERROR_MODIFY_IPRANGE_FAIL; //modify ip_range policy;
					}
					else
					{
						error_id = iRet;
					}
                    break;
                }
            }
            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);
		nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        break;

    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }
    return nac_doc;
}

