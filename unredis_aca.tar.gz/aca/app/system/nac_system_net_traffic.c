/*
 *
 * Part:        nac net traffic app.
 *
 * Author:      cxk
 *
 */
#include "nac_system_net_traffic.h"
static NET_TRAFFIC net_traffic;
static NET_TRAFFIC_RESET traffic_reset;

int nac_traffic_popen_result(char* get_option_cmd, char* result)
{
    //int i, len;
    FILE *popen_fp;
    char szLine[256] = "";

    popen_fp = popen(get_option_cmd, "r");
    if (popen_fp == NULL)
    {
        return -1;
    }

    //while((fgets(szLine, 256, popen_fp)) != NULL)
    if (fgets(szLine, 256, popen_fp) != NULL)
    {
        strcpy(result, szLine);
        SYSTEM_INFO_PRINT(DEBUG_LOG_FOR_NAC_SYS, "result=%s\n", result);
    }

    fclose(popen_fp);
    return 0;
}

int run_redis_command(HUPU_CHAR *cmd, HUPU_CHAR *result)
{
    redisContext *c;
    redisReply *reply;
    char tmp_buf[128] = {0};

    struct timeval timeout = { 1, 500000 }; // 1.5 seconds
    c = redisConnectWithTimeout(HOSTNAME, REDISPORT, timeout);
    if (c == NULL || c->err)
    {
        if (c)
        {
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "Connection error: %s\n", c->errstr);
            redisFree(c);
        }
        else
        {
            SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "Connection error: can't allocate redis context\n");
        }
        return -1;
    }
    /* PING server */
    reply = redisCommand(c, "PING");
    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS,"traffic PING: %s\n", reply->str);
    freeReplyObject(reply);
    reply = redisCommand(c, "SELECT 6");
    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS,"traffic SELECT: %s\n", reply->str);
    freeReplyObject(reply);
	SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "run_redis_command cmd =%s \n", cmd);
    reply = (redisReply*)redisCommand(c,cmd);
     if(reply->type == REDIS_REPLY_ARRAY)
     {
     	SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "REDIS_REPLY_ARRAY elements =%d\n", reply->elements);
     	int i = 0;
     	for(i = 0; i< reply->elements &&  reply->element[i]->str; i++)
     	{
     		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS,"reply->element[%d]->str = %s len = %d\n", i, reply->element[i]->str, reply->element[i]->len);
     		memset(tmp_buf, 0, sizeof(tmp_buf));
     		if(i == 0)
     		{
     			sprintf(tmp_buf, "%s", reply->element[i]->str);
     			strcat(result, tmp_buf);
     		}
     		else
     		{
     			sprintf(tmp_buf, " %s", reply->element[i]->str);
     			strcat(result, tmp_buf);
     		}
     	}
     }
     else if(reply->type== REDIS_REPLY_STRING && reply->str != NULL)
     {
     	strcat(result, reply->str);
     }
     else if(reply->type== REDIS_REPLY_INTEGER)
     {
     	memset(tmp_buf, 0, sizeof(tmp_buf));
     	sprintf(tmp_buf, "%lld", reply->integer);
     	strcat(result, tmp_buf);
     }
     else
     {
     	SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS,"reply type error\n");
     }
    freeReplyObject(reply);
    redisFree(c);
    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "run_redis_command result =%s \n", result);
    return 0;
}
int get_net_traffic(NET_TRAFFIC *traffic_obj)
{
   HUPU_CHAR *cmd = "HMGET net_info tx rx time tx_data rx_data uptime";
   HUPU_CHAR result[512] = {0};
   run_redis_command(cmd, result);
   sscanf(result, "%[^ ] %[^ ] %[^ ] %[^ ] %[^ ] %s", traffic_obj->rx, traffic_obj->tx, traffic_obj->time, traffic_obj->tx_data,traffic_obj->rx_data, traffic_obj->uptime);
   SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "get redis result = %s\n", result);
   cmd = "GET trafficTop";
   memset(result, 0, sizeof(result));
   run_redis_command(cmd, result);
   memset(traffic_obj->topN, 0 , sizeof(traffic_obj->topN));
   sprintf(traffic_obj->topN, "%s", result);
   return 0;
}
int reset_net_traffic()
{
	traffic_reset.rx_data = atoll(net_traffic.rx_data);
	traffic_reset.tx_data = atoll(net_traffic.tx_data);
	traffic_reset.uptime  = atoll(net_traffic.uptime);
	HUPU_CHAR *cmd = "PUBLISH monitor.nacapp {\"msg_type\":\"reset_traffic\"}";
	HUPU_CHAR result[512] = {0};
	run_redis_command(cmd, result);
	return 0;
}

xmlDocPtr nac_sys_return_nettraffic_result(HUPU_INT32 action_type)
{
	xmlDocPtr doc;
    xmlNodePtr root_node;
    HUPU_CHAR cmd_str[256] = {0};

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
	if(action_type == APP_SHOW)
	{

		xmlDocSetRootElement(doc, root_node);
		memset(cmd_str, '\0', sizeof(cmd_str));
		sprintf(cmd_str, "%d", (SYS_WEBUI_NET_TRAFFIC + Ret_cmd_offset));
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_str);
		memset(cmd_str, '\0', sizeof(cmd_str));
		sprintf(cmd_str, "%d", action_type);
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST cmd_str);
		memset(cmd_str, '\0', sizeof(cmd_str));
		sprintf(cmd_str, "%s", net_traffic.rx);
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "rxSpeed", BAD_CAST cmd_str);
		memset(cmd_str, '\0', sizeof(cmd_str));
		sprintf(cmd_str, "%s", net_traffic.tx);
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "txSpeed", BAD_CAST cmd_str);
		memset(cmd_str, '\0', sizeof(cmd_str));
		sprintf(cmd_str, "%s", net_traffic.time);
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "timeStamp", BAD_CAST cmd_str);
		memset(cmd_str, '\0', sizeof(cmd_str));
		sprintf(cmd_str, "%s", net_traffic.topN);
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "topN", BAD_CAST cmd_str);
		long long tmp_traffic = atoll(net_traffic.rx_data) + atoll(net_traffic.tx_data) - traffic_reset.rx_data -traffic_reset.tx_data;
		memset(cmd_str, '\0', sizeof(cmd_str));
		sprintf(cmd_str, "%lld", tmp_traffic);
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "sumTraffic", BAD_CAST cmd_str);
		memset(cmd_str, '\0', sizeof(cmd_str));
		tmp_traffic = atoll(net_traffic.uptime) - traffic_reset.uptime;
		HUPU_CHAR cmd_tmp[1024] = {0};
		sprintf(cmd_tmp, "echo \"%lld\"", tmp_traffic);
		strcat(cmd_tmp, "|awk -F. '{run_days=$1/86400;run_hour=($1%86400)/3600;run_minute=($1%3600)/60;run_second=$1%60;printf(\"%d;%d;%d;%d\",run_days,run_hour,run_minute,run_second)}'");
		nac_traffic_popen_result(cmd_tmp, cmd_str);
		SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,"cmd= %s \n", cmd_tmp);
		SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "tmp_traffic_time = %lld  time_txt = %s\n", tmp_traffic, cmd_str);
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "sumTime", BAD_CAST cmd_str);

	}
	else if (action_type == APP_UPDATE)
	{
		xmlDocSetRootElement(doc, root_node);
		memset(cmd_str, '\0', sizeof(cmd_str));
		sprintf(cmd_str, "%d", (SYS_WEBUI_NET_TRAFFIC + Ret_cmd_offset));
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST cmd_str);
		memset(cmd_str, '\0', sizeof(cmd_str));
		sprintf(cmd_str, "%d", action_type);
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST cmd_str);
		memset(cmd_str, '\0', sizeof(cmd_str));
		sprintf(cmd_str, "1");
		xmlNewChild (root_node, HUPU_NULL, BAD_CAST "status", BAD_CAST cmd_str);
	}
	return doc;
}


 //traffic app handle function
xmlDocPtr nac_system_parse_net_traffic(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_UINT8 action_type;
    xmlNodePtr cur_node = NULL;
    xmlDocPtr re_doc;
    cur_node = nac_xml_parse_get_action(doc, &action_type);
    SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "into handle cmd_id = %d action type = %d \n", cmd_id,action_type);
    if(action_type == APP_SHOW)
    {
    	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "action_type = %d\n", action_type);
    	get_net_traffic(&net_traffic);
    	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,"get_net_traffic success\n");
        re_doc = nac_sys_return_nettraffic_result(action_type);
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,"nac_sys_return_nettraffic_result success\n");
    }
    else if(action_type == APP_UPDATE)
    {
    	reset_net_traffic();
       	re_doc =  nac_sys_return_nettraffic_result(action_type);
    }
    nac_free_xmlDoc(doc);
    return re_doc;
}

