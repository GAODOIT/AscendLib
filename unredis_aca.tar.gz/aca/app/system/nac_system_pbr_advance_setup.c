/*
    #define HUPU_TRUE 1
    #define HUPU_FALSE 0
*/
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_errorlog.h"
#include "nac_system_xml.h"
#include "nac_system_net.h"
#include "nac_system_redis_subscribe.h"
#include "nac_system_pbr_advance_setup.h"

#define ARPING_MAC_STR_LEN 20

const char *arping_get_mac = "arping -I %s -c 1 %s | grep \"Unicast reply from\" | grep %s | awk '{print $5}'";
extern HUPU_INT32 nac_pbr_onein_oneout_flag; //default close
extern NAC_PBR_ADVANCE_SETUP pbr_advance_setup;

static int nac_get_nexthop_mac(char* ip_str, char* mac)
{
    FILE* popen_fp;
    int iRet;
    char get_mac_cmd[100];
    char mac_str[ARPING_MAC_STR_LEN];

    iRet = nac_preg_match_ip(ip_str);
    if (iRet == -1)
    {
        return NAC_SYS_ERROR_ILLEGAL_IP;
    }

	iRet = nac_app_get_special_ifindex("trust");
    memset(get_mac_cmd, '\0', sizeof(get_mac_cmd));
    sprintf(get_mac_cmd, arping_get_mac, nac_sys_ifname[iRet], ip_str, ip_str);

    popen_fp = popen (get_mac_cmd, "r");

    memset(mac_str, '\0', ARPING_MAC_STR_LEN);
    fgets(mac_str, ARPING_MAC_STR_LEN, popen_fp);
    memcpy(mac, mac_str+1, ARPING_MAC_STR_LEN-3);

    pclose(popen_fp);

    SYSTEM_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->nexthop_mac=%s\n", __FUNCTION__, mac);
    return HUPU_OK;
}

static xmlDocPtr nac_sys_get_nexthop_mac(HUPU_UINT16 command_id, HUPU_CHAR* ip_str)
{
    HUPU_INT32 iRet = 0;
    xmlDocPtr doc;
    xmlNodePtr root_node;

    HUPU_CHAR get_buffer[32] ="";
    HUPU_CHAR nac_send_buffer[SEND_BUFFER_LEN] = "";

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    sprintf(get_buffer, "%d", (command_id + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST get_buffer);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");

    memset(get_buffer, '\0', sizeof(get_buffer));
    iRet = nac_get_nexthop_mac(ip_str, get_buffer);

    /*2014-02-20-big-bug if (iRet != HUPU_OK);{}*/
    if (iRet != HUPU_OK)
    {
        sprintf(nac_send_buffer, "-1:%s", nac_sys_get_error_log(iRet));
        xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST nac_send_buffer);
        return doc;
    }

    if (strlen(get_buffer) < 17)//00:21:85:09:fb:82=strlen=17
    {
        sprintf(nac_send_buffer, "-1:%s", nac_sys_get_error_log(NAC_SYS_ERROR_GET_NEXTHOP_MAC));
        xmlNewChild (root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST nac_send_buffer);
    }
    else
    {
        xmlNewChild(root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");
        xmlNewChild(root_node, HUPU_NULL, BAD_CAST "nexthopMac", BAD_CAST get_buffer);
    }

    return doc;
}

static xmlDocPtr nac_sys_get_pbr_advance_setup(HUPU_UINT16 command_id)
{
    xmlDocPtr doc = HUPU_NULL;
    xmlNodePtr root_node;
    HUPU_CHAR get_buffer[32] ="";

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    sprintf(get_buffer, "%d", (command_id + Ret_cmd_offset));
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "commandID", BAD_CAST get_buffer);
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "actionType", BAD_CAST "0");
    xmlNewChild(root_node, HUPU_NULL, BAD_CAST "result", BAD_CAST "0");

    if (nac_pbr_onein_oneout_flag == HUPU_FALSE)
    {
        xmlNewChild(root_node, HUPU_NULL, BAD_CAST "pbrSwitch", BAD_CAST "0");
    }
    else if (nac_pbr_onein_oneout_flag == HUPU_TRUE)
    {
        xmlNewChild(root_node, HUPU_NULL, BAD_CAST "pbrSwitch", BAD_CAST "1");

        memset(get_buffer, '\0', sizeof(get_buffer));
        sprintf(get_buffer, "%u.%u.%u.%u", LIPQUAD(pbr_advance_setup.nexthop_ip));
        xmlNewChild(root_node, HUPU_NULL, BAD_CAST "nexthopIp", BAD_CAST get_buffer);

        memset(get_buffer, '\0', sizeof(get_buffer));
        sprintf(get_buffer, COLON_LOWER_MACFMT, MAC_FORMAT(pbr_advance_setup.nexthop_mac));
        xmlNewChild(root_node, HUPU_NULL, BAD_CAST "nexthopMac", BAD_CAST get_buffer);
    }

    return doc;
}

HUPU_INT32 nac_sys_add_pbr_advance_setup(HUPU_INT32 pbr_flag, NAC_PBR_ADVANCE_SETUP* pbr_setup)
{
    HUPU_INT32 iRet;
    nac_knl_eth3_mac trust_nexthop;

    if (pbr_flag == HUPU_FALSE)
    {
        iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_PBR_2_ETH_SWITCH, HUPU_FALSE, NULL, 0);
        if (iRet != HUPU_OK)
        {
            nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->close pbr onein_oneout error\n", __FUNCTION__);
            return HUPU_ERR;
        }

    }
    else if (pbr_flag == HUPU_TRUE)
    {
        /*Ascend get trust eth3 mac*/
		iRet = nac_app_get_special_ifindex("trust");
        nac_get_netdev_mac(nac_sys_ifname[iRet], pbr_setup->trust_mac, ETH_ALEN);

        iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_PBR_2_ETH_SWITCH, HUPU_TRUE, NULL, 0);
        if (iRet != HUPU_OK)
        {
            nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->open pbr onein_oneout error\n", __FUNCTION__);
            return HUPU_ERR;
        }

        memset(&trust_nexthop, '\0', sizeof(nac_knl_eth3_mac));
        memcpy(trust_nexthop.ac_eth3_mac, pbr_setup->trust_mac, ETH_ALEN);
        memcpy(trust_nexthop.ac_eth3_sw_mac, pbr_setup->nexthop_mac, ETH_ALEN);

        iRet = nac_set_data_to_knl(NAC_CMD_SYS_SET_PBR_2_ETH_MAC, 0, &trust_nexthop, sizeof(nac_knl_eth3_mac));
        if (iRet != HUPU_OK)
        {
            nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->set pbr outport trust_mac error\n", __FUNCTION__);
            return HUPU_ERR;
        }
    }

    return HUPU_OK;
}

xmlDocPtr nac_sys_parse_pbr_advance_setup(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_INT32 iRet, error_id;
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    xmlChar *szKey;
    HUPU_UINT8 action_type;
    HUPU_CHAR mac_str[18];

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

    error_id = 0;
    switch(action_type)
    {
    case NAC_SHOW:
        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_get_pbr_advance_setup(cmd_id);
        break;

    case NAC_ADD:
        while (cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "pbrSwitch")))
            {
                szKey = xmlNodeGetContent(cur_node);
                nac_pbr_onein_oneout_flag = atoi((HUPU_CHAR*)szKey);
                xmlFree(szKey);

                if (nac_pbr_onein_oneout_flag == HUPU_FALSE)
                {
                    break;
                }

            }
            else if (!(xmlStrcmp(cur_node->name, BAD_CAST "nexthopIp")))
            {
                szKey = xmlNodeGetContent(cur_node);
                iRet = nac_preg_match_ip((HUPU_CHAR*)szKey);
                if (iRet != HUPU_OK)
                {
                    xmlFree(szKey);
                    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->set nexthop_ip format error\n", __FUNCTION__);
                    error_id = NAC_SYS_ERROR_ILLEGAL_IP;
                    break;
                }
                pbr_advance_setup.nexthop_ip = inet_network((HUPU_CHAR*)szKey);
                xmlFree(szKey);
            }
            else if (!(xmlStrcmp(cur_node->name, BAD_CAST "nexthopMac")))//00:90:7f:84:50:94
            {
                szKey = xmlNodeGetContent(cur_node);
                memset(mac_str, '\0', sizeof(mac_str));
                memcpy(mac_str, (HUPU_CHAR*)szKey, strlen((HUPU_CHAR*)szKey));
                xmlFree(szKey);

                //#define COLON_LOWER_MACFMT "%02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx" #define MAC_FORMAT(addr)
                if (sscanf(mac_str, COLON_LOWER_MACFMT, &(pbr_advance_setup.nexthop_mac[0]), &(pbr_advance_setup.nexthop_mac[1]),
                    &(pbr_advance_setup.nexthop_mac[2]), &(pbr_advance_setup.nexthop_mac[3]), &(pbr_advance_setup.nexthop_mac[4]),
                    &(pbr_advance_setup.nexthop_mac[5]) ) != ETH_ALEN)
                {
                    nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->set nexthop_mac format error\n", __FUNCTION__);
                    error_id = NAC_SYS_ERROR_ILLEGAL_MAC;
                    break;
                }

            }

            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);

        if (error_id != HUPU_OK)
        {
            nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        }
        else
        {
            //static xmlDocPtr nac_sys_add_pbr_advance_setup(HUPU_INT32 pbr_flag, NAC_PBR_ADVANCE_SETUP* pbr_setup);
            iRet = nac_sys_add_pbr_advance_setup(nac_pbr_onein_oneout_flag, &pbr_advance_setup);
            if (iRet == HUPU_ERR)
            {
                error_id = NAC_KNL_ERROR_SET_PBR_ONEIN_ONEOUT;
            }
			else
			{
				send_redis_pub_command("nac_mode");
                send_redis_pub_command("iface_status");
			}
            nac_doc = nac_sys_return_web_action_result(cmd_id, action_type, error_id);
        }
        break;

    case NAC_DEL:
    case NAC_MODIFY:
    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

xmlDocPtr nac_sys_parse_pbr_get_nexthop_mac(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    xmlDocPtr nac_doc = HUPU_NULL;
    xmlNodePtr cur_node;
    xmlChar *szKey;
    HUPU_UINT8 action_type;
    HUPU_CHAR next_ip[16] = "";

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

    switch(action_type)
    {
    case NAC_SHOW:
        while (cur_node != HUPU_NULL)
        {
            if (!(xmlStrcmp(cur_node->name, BAD_CAST "nexthopIp")))
            {
                szKey = xmlNodeGetContent(cur_node);
                memcpy(next_ip, (char*)szKey, strlen((char*)szKey));
                break;
            }
            cur_node = cur_node->next;
        }
        nac_free_xmlDoc(doc);
        nac_doc = nac_sys_get_nexthop_mac(cmd_id, next_ip);
        break;

    case NAC_ADD:
    case NAC_DEL:
    case NAC_MODIFY:
    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}
