#ifndef NAC_SYSTEM_NETAPP_USER_H
#define NAC_SYSTEM_NETAPP_USER_H

#include "nac_system_common_lib.h"

#define IP_HASH_KEY //ip_hash_key switch
#define NAC_NETAPP_USER_GTIME_OUT 5*60
#define NAC_NETAPP_USER_HASH_SIZE 1024
#define FIND_FALSE   0
#define FIND_TRUE    1
#define FIND_TIMEOUT 2

typedef struct NAC_SYSTEM_NETAPP_USER_STRU
{
    struct nac_hlist_node node;
    HUPU_UINT32 user_ip;
    HUPU_CHAR   user_mac[ETH_ALEN];
    HUPU_UINT32 status:16, other:16;
	HUPU_ULONG32 netapp_time;
    /*
    HUPU_UINT32 find:16, except:16;
    HUPU_INT32  user_type;
    HUPU_UINT16 user_id;
    HUPU_UINT16 group_id;
    */

}NAC_SYSTEM_NETAPP_USER;

extern struct nac_hlist_head nac_netapp_tmp_user_hash[];

HUPU_VOID  nac_system_init_netapp_user_hlist();
HUPU_VOID  nac_system_destroy_netapp_user_hlist(HUPU_VOID);
HUPU_INT32 nac_system_delete_netapp_user(HUPU_UINT32 ip, HUPU_CHAR *mac);
HUPU_INT32 nac_system_free_time_out_netapp_user(HUPU_UINT32 interval);


HUPU_INT32 __nac_system_show_netapp_user_hlist(HUPU_VOID);
HUPU_INT32 nac_system_debug_save_netapp_user(const HUPU_CHAR* file);
HUPU_INT32 nac_system_debug_netapp_user(FILE* fp);

HUPU_INT32 nac_sys_netlink_netapp_found(NAC_KNL_USER_MSG *nlk_usr_msg, HUPU_INT32 sock_fd);
xmlDocPtr nac_sys_parse_get_user_netapp_status(xmlDocPtr doc, HUPU_UINT16 cmd_id);


#endif
