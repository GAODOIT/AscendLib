#include "nac_precomp.h" //nac_list.h
#include "nac_app_knl_lib.h"
#include "nac_system_main.h"
#include "nac_system_xml.h"
#include "nac_system_errorlog.h"
#include "nac_system_netapp_check.h"
#include "nac_system_user.h"
#include "nac_system_netapp_user.h"

struct nac_hlist_head nac_netapp_tmp_user_hash[NAC_NETAPP_USER_HASH_SIZE];
pthread_mutex_t nac_netapp_user_mutex = PTHREAD_MUTEX_INITIALIZER;

HUPU_VOID nac_system_netapp_user_lock()
{
	pthread_mutex_lock(&nac_netapp_user_mutex);
	return;
}

HUPU_VOID nac_system_netapp_user_unlock()
{
	pthread_mutex_unlock(&nac_netapp_user_mutex);
	return;
}
static HUPU_INT32 nac_system_get_hash_by_ip(HUPU_UINT32 ipaddr)
{
	HUPU_INT32 ip_key = 0;

	#ifdef IP_HASH_KEY
		ip_key += ipaddr & 0x000000ff;
    	ip_key += ((ipaddr >> 8) & 0x000000ff);
    	ip_key += ((ipaddr >> 16) & 0x000000ff);
    	ip_key += (ipaddr  >> 24);
	#else
		ip_key = ipaddr;
	#endif

	return ip_key&(NAC_NETAPP_USER_HASH_SIZE - 1);
}

HUPU_VOID nac_system_init_netapp_user_hlist(void)
{
    int i;
    for(i = 0; i < NAC_NETAPP_USER_HASH_SIZE; i++)
    {
        NAC_INIT_HLIST_HEAD(&nac_netapp_tmp_user_hash[i]);
    }
	pthread_mutex_init(&nac_netapp_user_mutex, HUPU_NULL);

	return;
}

static HUPU_INT32 nac_app_insert_netapp_user(NAC_SYSTEM_NETAPP_USER *pst_user)
{
	HUPU_UINT16 hash_key;
	NAC_SYSTEM_NETAPP_USER *pst_user_tmp = HUPU_NULL;

	hash_key = nac_system_get_hash_by_ip(pst_user->user_ip);
	pst_user_tmp = (NAC_SYSTEM_NETAPP_USER*)malloc(sizeof(NAC_SYSTEM_NETAPP_USER));
	if (pst_user_tmp == HUPU_NULL)
	{
	    SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS ,"malloc error\n");
		return HUPU_ERR;
	}

	memset(pst_user_tmp, '\0',	sizeof(NAC_SYSTEM_NETAPP_USER));
	memcpy(pst_user_tmp, pst_user, sizeof(NAC_SYSTEM_NETAPP_USER));
	nac_system_netapp_user_lock();
	nac_hlist_add_head(&pst_user_tmp->node, &nac_netapp_tmp_user_hash[hash_key]);
	nac_system_netapp_user_unlock();

	return HUPU_OK;
}

// return 1 find; return 0 unfind;
static HUPU_INT32 nac_app_update_netapp_user(NAC_SYSTEM_NETAPP_USER *pst_user)
{
    HUPU_UINT32 find = FIND_FALSE;
    HUPU_UINT16 hash_key;
	struct nac_hlist_node  *pos, *n;
	NAC_SYSTEM_NETAPP_USER *pst_user_tmp;

	hash_key = nac_system_get_hash_by_ip(pst_user->user_ip);
	nac_system_netapp_user_lock();
	nac_hlist_for_each_entry_safe(pst_user_tmp, pos, n, &nac_netapp_tmp_user_hash[hash_key], node)
	{
		if (pst_user->user_ip == pst_user_tmp->user_ip
            && memcmp(pst_user->user_mac, pst_user_tmp->user_mac, ETH_ALEN) == HUPU_OK)
		{
           SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "lastime=%lu--nowtime=%lu\n",
                                pst_user_tmp->netapp_time, pst_user->netapp_time);
            if ((pst_user->netapp_time - pst_user_tmp->netapp_time) > 30)
            {
               find = FIND_TIMEOUT;
               pst_user_tmp->netapp_time = pst_user->netapp_time;
               pst_user_tmp->status = pst_user->status;
               break;
            }
            else
            {
                find = FIND_TRUE;
                break;
            }
		}
	}
    nac_system_netapp_user_unlock();
    return find;
}

HUPU_INT32 nac_system_delete_netapp_user(HUPU_UINT32 ip, HUPU_CHAR *mac)
{
	HUPU_UINT16 hash_key;
	struct nac_hlist_node *pos, *n;
	NAC_SYSTEM_NETAPP_USER *pst_user_tmp;

	hash_key = nac_system_get_hash_by_ip(ip);
	nac_system_netapp_user_lock();
	nac_hlist_for_each_entry_safe(pst_user_tmp, pos, n, &nac_netapp_tmp_user_hash[hash_key], node)
	{
		if (ip == pst_user_tmp->user_ip && memcpy(mac, pst_user_tmp->user_mac, ETH_ALEN) == 0)
		{
			nac_hlist_del(&pst_user_tmp->node);
			free(pst_user_tmp);
		}
	}
	nac_system_netapp_user_unlock();

	return HUPU_OK;
}

HUPU_INT32 nac_system_free_time_out_netapp_user(HUPU_UINT32 interval)
{
    HUPU_UINT32 key;
    time_t now_time;
    struct nac_hlist_node *pos, *n;
    NAC_SYSTEM_NETAPP_USER *pst_user_tmp;

    time(&now_time);
    nac_system_netapp_user_lock();
    for (key = 0; key < NAC_NETAPP_USER_HASH_SIZE; key++)
    {
        nac_hlist_for_each_entry_safe(pst_user_tmp, pos, n, &nac_netapp_tmp_user_hash[key], node)
        {
            if ((now_time - pst_user_tmp->netapp_time) >= interval)
            {
                nac_hlist_del(&pst_user_tmp->node);
                free(pst_user_tmp);
            }
        }
    }
    nac_system_netapp_user_unlock();

    return HUPU_OK;
}


HUPU_VOID nac_system_destroy_netapp_user_hlist(HUPU_VOID)
{
	HUPU_UINT32 key;
	struct nac_hlist_node *pos, *n;
	NAC_SYSTEM_NETAPP_USER *pst_user_tmp;

	nac_system_netapp_user_lock();
	for (key = 0; key < NAC_NETAPP_USER_HASH_SIZE; key++)
	{
		nac_hlist_for_each_entry_safe(pst_user_tmp, pos, n, &nac_netapp_tmp_user_hash[key], node)
		{
			nac_hlist_del(&pst_user_tmp->node);
			free(pst_user_tmp);
		}
	}
	nac_system_netapp_user_unlock();

	return;
}
/*
<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>124+100</commandID>
  <actionType>0</actionType>
  <netappName>weidun</netappName>
  <fixPath>aaaaaaaaaaaaaa</fixPath>
</nac>
#####################################
<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>124+100</commandID>
  <actionType>0</actionType>
</nac>
*/
static xmlDocPtr nac_app_get_netapp_check_status(HUPU_UINT16 cmd, HUPU_CHAR* ip_str, HUPU_CHAR* mac_str)
{
    HUPU_UINT16 action_type;
    xmlDocPtr  ret_doc = HUPU_NULL;
    xmlNodePtr root_node;
    NAC_APP_NETAPP_OBJECT* pst_netapp = HUPU_NULL;
    //HUPU_CHAR xml_min_cnt[MIN_BUFF_LEN] = "";
    //HUPU_CHAR xml_max_cnt[MID_BUFF_LEN] = "";
    ret_doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(ret_doc, root_node);

    insert_number_xml_new_child(root_node, "commandID", (cmd + Ret_cmd_offset));
    action_type = 0;
    insert_number_xml_new_child(root_node, "actionType", action_type);

    if (g_netapp_enable_id != 0)
    {
        pst_netapp = nac_app_get_netapp_by_id(g_netapp_enable_id);
        insert_string_xml_new_child(root_node, "netappName", pst_netapp->netapp_st.name);
        insert_string_xml_new_child(root_node, "fixPath", pst_netapp->netapp_st.fix_path);
    }

    return ret_doc;
}


/*
<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>124</commandID>
  <actionType>0</actionType>
  <checkItem>192.168.100.100;1A-2B-3C-4D-5E-6F</checkItem>
</nac>
*/
xmlDocPtr nac_sys_parse_get_user_netapp_status(xmlDocPtr doc, HUPU_UINT16 cmd_id)
{
    HUPU_INT32 error_id;
    xmlDocPtr nac_doc = HUPU_NULL;
	xmlChar   *szKey;
    xmlNodePtr cur_node;
	HUPU_UINT8 action_type;
	HUPU_CHAR ip_str[IP_STR_LEN];
    HUPU_CHAR mac_str[MAC_STR_LEN];

    cur_node = nac_xml_parse_get_action(doc, &action_type);
    if (cur_node == HUPU_NULL)
    {
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS ,"%s-->nac_xml_parse_get_action\n", __FUNCTION__);
        return HUPU_NULL;
    }

	error_id = 0;
    switch (action_type)
    {
	case NAC_SHOW:
        while(cur_node != HUPU_NULL)
        {
        	if (!(xmlStrcmp(cur_node->name, BAD_CAST "checkItem")))
            {
                memset(ip_str, 0,  IP_STR_LEN);
                memset(mac_str, 0, MAC_STR_LEN);
                szKey = xmlNodeGetContent(cur_node);
                SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "checkItem--user_info:%s\n", (HUPU_CHAR*)szKey);
				sscanf((HUPU_CHAR*)szKey, "%[^;];%s", ip_str, mac_str);
				xmlFree(szKey);
                error_id = 1;
				break;
			}
			cur_node = cur_node->next;
        }
		nac_free_xmlDoc(doc);
        if (error_id == 1)
        {
		    nac_doc = nac_app_get_netapp_check_status(cmd_id, ip_str, mac_str);
        }
        break;
    default:
        nac_free_xmlDoc(doc);
        nac_lib_debug(DEBUG_LOG_FOR_NAC_SYS, "%s-->invalid action_type\n", __FUNCTION__);
        break;
    }

    return nac_doc;
}

/*
<?xml version="1.0" encoding="UTF-8"?>
<nac>
  <commandID>104+100</commandID>
  <actionType>6(����Ӧ��״̬�ϱ�)</actionType>
  //ip;mac;found/except(NAC_NETLINK_NETAPP_FOUND,NAC_NETLINK_NETAPP_EXCEPT).
  <userItem>1A-2B-3C-4D-5E-6F;10.10.2.250;4/5</userItem>
</nac>
*/
//HUPU_INT32 nac_sys_netlink_netapp_except(NAC_KNL_USER_MSG *netlink_usr_msg, HUPU_INT32 sock_fd)
HUPU_INT32 nac_sys_netlink_netapp_found(NAC_KNL_USER_MSG *nlk_usr_msg, HUPU_INT32 sock_fd)
{
    xmlDocPtr doc;
    HUPU_UINT16 find, cmd;
    xmlNodePtr root_node;
    time_t cur_time  = 0;
	HUPU_CHAR xml_max_cnt[MID_BUFF_LEN];
    NAC_SYSTEM_NETAPP_USER tmp_user;

    find = HUPU_FALSE;
    cmd  = SYS_WEBUI_NETAPP_CHECK;
	memset(&tmp_user, 0, sizeof(NAC_SYSTEM_NETAPP_USER));

    tmp_user.user_ip = nlk_usr_msg->src_ip;
    memcpy(tmp_user.user_mac, nlk_usr_msg->src_mac, ETH_ALEN);
    tmp_user.status= nlk_usr_msg->cmd;
    time(&cur_time);
	tmp_user.netapp_time = cur_time;

	SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS,
                    "mac=%02x-%02x-%02x-%02x-%02x-%02x-->ip=%u.%u.%u.%u-->timeout_type=%d-->lastime=%lu\n",
                    MAC_FORMAT(tmp_user.user_mac), LIPQUAD(tmp_user.user_ip), tmp_user.status, tmp_user.netapp_time);
	if (sock_fd <= 0)
	{
		goto FUNC_OUT;
	}

    find = nac_app_update_netapp_user(&tmp_user);
    if (find == FIND_TRUE)
    {
        goto FUNC_OUT;
    }

    if (find == FIND_FALSE)
    {
        nac_app_insert_netapp_user(&tmp_user);
    }
    else if (find == FIND_TIMEOUT)
    {
        SYSTEM_DEBUG_PRINT(DEBUG_LOG_FOR_NAC_SYS, "just re_notify\n");
    }

    doc = xmlNewDoc(BAD_CAST "1.0");
    root_node = xmlNewNode(HUPU_NULL, BAD_CAST "nac");
    xmlDocSetRootElement(doc, root_node);

    insert_number_xml_new_child(root_node, "commandID", (cmd+Ret_cmd_offset));
    insert_number_xml_new_child(root_node, "actionType", NETAPP_USER_UPLOAD);

    memset(xml_max_cnt, '\0', strlen(xml_max_cnt));
	sprintf(xml_max_cnt, "%02X-%02X-%02X-%02X-%02X-%02X;%u.%u.%u.%u;%d",
            MAC_FORMAT(tmp_user.user_mac), LIPQUAD(tmp_user.user_ip), tmp_user.status);
    insert_string_xml_new_child(root_node, "userItem", xml_max_cnt);
    nac_sys_send_xmldoc_to_webserver(sock_fd, doc, cmd);
FUNC_OUT:
    return HUPU_OK;
}

HUPU_INT32 __nac_system_show_netapp_user_hlist(HUPU_VOID)
{
	HUPU_UINT32 key, count;
	struct nac_hlist_node *pos, *n;
	NAC_SYSTEM_NETAPP_USER *pst_user_tmp;
	count = 0;
	nac_system_netapp_user_lock();
	for (key = 0; key < NAC_NETAPP_USER_HASH_SIZE; key++)
	{
		nac_hlist_for_each_entry_safe(pst_user_tmp, pos, n, &nac_netapp_tmp_user_hash[key], node)
		{
			SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "user=%u.%u.%u.%u--%02X-%02X-%02X-%02X-%02X-%02X--%d--%ld\n",
                            LIPQUAD(pst_user_tmp->user_ip), MAC_FORMAT(pst_user_tmp->user_mac),
			                pst_user_tmp->status, pst_user_tmp->netapp_time);
			count = count + 1;

		}
	}
	nac_system_netapp_user_unlock();
	if (count == 0)
	{
		SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "nac_netapp_tmp_user_hash is empty\n");
	}

	return HUPU_OK;
}

HUPU_INT32 nac_system_debug_save_netapp_user(const HUPU_CHAR* file)
{
	FILE *nac_fp;
	HUPU_UINT32 key, count;
	struct nac_hlist_node *pos, *n;
	NAC_SYSTEM_NETAPP_USER *pst_user_tmp;

	if ((nac_fp = fopen(file, "w+")) == NULL)
    {
        SYSTEM_ERR_PRINT(DEBUG_LOG_FOR_NAC_SYS, "%s-->open %s error\n", file);
        return HUPU_ERR;
    }

	count = 0;
	fputs("netapp user status------------------\n", nac_fp);
	nac_system_netapp_user_lock();
	for (key = 0; key < NAC_NETAPP_USER_HASH_SIZE; key++)
	{
		nac_hlist_for_each_entry_safe(pst_user_tmp, pos, n, &nac_netapp_tmp_user_hash[key], node)
		{
			fprintf(nac_fp, "user=%u.%u.%u.%u--%02X-%02X-%02X-%02X-%02X-%02X--%d--%ld\n",
			        LIPQUAD(pst_user_tmp->user_ip), MAC_FORMAT(pst_user_tmp->user_mac),
			        pst_user_tmp->status, pst_user_tmp->netapp_time);
			count = count + 1;
		}
	}
	nac_system_netapp_user_unlock();
	fprintf(nac_fp, "end-----------------------------sum=%d\n", count);

    fclose(nac_fp);
    return HUPU_OK;
};

HUPU_INT32 nac_system_debug_netapp_user(FILE* fp)
{
	HUPU_UINT32 key, count;
	struct nac_hlist_node *pos, *n;
	NAC_SYSTEM_NETAPP_USER *pst_user_tmp;

	count = 0;
	fputs("netapp user status------------------\n", fp);
	nac_system_netapp_user_lock();
	for (key = 0; key < NAC_NETAPP_USER_HASH_SIZE; key++)
	{
		nac_hlist_for_each_entry_safe(pst_user_tmp, pos, n, &nac_netapp_tmp_user_hash[key], node)
		{
			fprintf(fp, "user=%u.%u.%u.%u--%02X-%02X-%02X-%02X-%02X-%02X--%d--%ld\n",
			        LIPQUAD(pst_user_tmp->user_ip), MAC_FORMAT(pst_user_tmp->user_mac),
			        pst_user_tmp->status, pst_user_tmp->netapp_time);
			count = count + 1;
		}
	}
	nac_system_netapp_user_unlock();
	fprintf(fp, "end-----------------------------sum=%d\n", count);
    return HUPU_OK;
};
