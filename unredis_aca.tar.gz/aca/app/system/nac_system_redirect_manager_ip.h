#ifndef NAC_SYSTEM_REDIRECT_MANAGER_IP_H
#define NAC_SYSTEM_REDIRECT_MANAGER_IP_H

#include "nac_system_common_lib.h"
extern struct nac_knl_ip_info gst_redirect_manager_ip;
extern HUPU_CHAR g_default_gateway[];

HUPU_VOID nac_sys_init_redirect_manager_ip_info(HUPU_VOID);
HUPU_INT32 nac_sys_set_redirect_ip(HUPU_CHAR* pst_redirect_ip);
HUPU_INT32 nac_sys_set_server_manager_ip(HUPU_UINT32 ui_remote_ip);
HUPU_INT32 nac_sys_set_controller_manager_ip(HUPU_UINT32 ui_controller_manager_ip);
HUPU_INT32 nac_sys_set_knl_redirect_manager_ip(struct nac_knl_ip_info* pst_redirect_manager_ip);
HUPU_INT32 nac_sys_write_redirect_config_to_configure(FILE* fp);
HUPU_INT32 nac_sys_get_redirect_config_from_configure(const HUPU_CHAR *file_path);

xmlDocPtr nac_xml_parse_redirect_url(xmlDocPtr doc, HUPU_UINT16 cmd_id);

#endif
