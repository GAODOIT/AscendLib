#ifndef NAC_SYSTEM_SWITCH_MAIN_H
#define NAC_SYSTEM_SWITCH_MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

extern HUPU_UINT16 g_nac_switch_index;
extern HUPU_UINT32 g_nac_switch_time_out;


#define NAC_SYSTEM_SWITCH_HASH_SIZE	16
#define NAC_SWITCH_PASSWORD_SIZE	16
#define	NAC_SWITCH_NAME_SIZE		48
#define FILE_LINE_SIZE    			256


typedef enum
{
   SWITCH_SHOW=0,
   SWITCH_ADD,
   SWITCH_DEL,
   SWITCH_MODIFY,
   SWITCH_TEST,
}NAC_SYSTEM_SWITCH_ACTION;

typedef enum
{
	NAC_SWITCH_SSH=1,
	NAC_SWITCH_SNMP,
	NAC_SWITCH_TELNET,
}NAC_SYSTEM_SWITCH_LOGIN;

typedef enum
{
	SNMP_UNABLE,
	SNMP_V1,
	SNMP_V2C,
}NAC_SNMP_VERSION;

typedef enum
{
	PASSWD_UNABLE, //0;
	PASSWD_NAME, //1;
	PASSWD_PASS, //2;
	PASSWD_NAME_PASS,//3;
	PASSWD_SUPERPASS,//4;
	PASSWD_NAME_SUPERPASS,//5;
	PASSWD_PASS_SUPERPASS,//6;
	PASSWD_NAME_PASS_SUPERPASS,//7;
}NAC_SWITCH_PASSWD;


typedef enum
{
    NAC_SYSTEM_SWITCH_CONNECT_ERROR,
    NAC_SYSTEM_SWITCH_CONNECT_CLOSE,
    NAC_SYSTEM_SWITCH_CONNECT_OK,    
    NAC_SYSTEM_SWITCH_NAME_OR_PASS_ERROR,
    NAC_SYSTEM_SWITCH_SUPER_PASS_ERROR,
} NAC_SYSTEM_SWITCH_STATUS;

//HUPU_UINT16 switch_itype;// all kind of switch must have itype to identify
typedef struct NAC_SYSTEM_SWITCH_STRU
{
    struct nac_hlist_node node;
	HUPU_UINT16 switch_id; //when add a switch success, get a ID to indentify a swith;
    HUPU_UINT32 switch_ip;
    HUPU_UINT16 connect_port;
	HUPU_CHAR	switch_factory[NAC_SWITCH_NAME_SIZE];
	HUPU_CHAR	switch_model[NAC_SWITCH_PASSWORD_SIZE];
	HUPU_CHAR 	switch_dename[NAC_SWITCH_NAME_SIZE];
	//HUPU_CHAR 	relate_control[ETH_ALEN];
	HUPU_UINT16 switch_fd;
	HUPU_ULONG32 pthread_id; //pthread_t tid; tid = pthread_self();
	HUPU_ULONG32 add_time;
	HUPU_UINT8	login_type;//SNMP--TELNET--SSH
	HUPU_UINT8  switch_status;
	
	union
	{
		struct
		{
			HUPU_UINT8 mode;
			HUPU_CHAR name[NAC_SWITCH_PASSWORD_SIZE];
			HUPU_CHAR pass[NAC_SWITCH_PASSWORD_SIZE];
			HUPU_CHAR super_pass[NAC_SWITCH_PASSWORD_SIZE];
		}passwd;//telnet+ssh
		
		struct
		{
			HUPU_UINT8 version;
			HUPU_CHAR  ro_community[NAC_SWITCH_PASSWORD_SIZE];
			HUPU_CHAR  rw_community[NAC_SWITCH_PASSWORD_SIZE];
		}snmp;

	}union_passwd;	
}NAC_SYSTEM_SWITCH;
extern struct nac_hlist_head nac_switch_hash_by_id[NAC_SYSTEM_SWITCH_HASH_SIZE];

typedef struct NAC_SYSTEM_SWITCH_LIST_STRU
{
	struct nac_list_head lnode;
	HUPU_UINT16 switch_itype;
	HUPU_CHAR	switch_factory[NAC_SWITCH_NAME_SIZE];
	HUPU_CHAR	switch_model[NAC_SWITCH_PASSWORD_SIZE];
}NAC_SYSTEM_SWITCH_LIST;

HUPU_VOID nac_system_switch_lock();
HUPU_VOID nac_system_switch_unlock();
HUPU_VOID nac_system_init_switch(HUPU_VOID);
HUPU_INT32 nac_system_add_switch(NAC_SYSTEM_SWITCH *pst_switch);
HUPU_INT32 nac_system_rmv_switch(HUPU_UINT32 switch_id);
HUPU_INT32 nac_system_search_switch(HUPU_UINT32 switch_id, NAC_SYSTEM_SWITCH *pst_tmp);
HUPU_INT32 nac_system_modify_switch_st(NAC_SYSTEM_SWITCH *pst_switch_st);
HUPU_INT32 nac_system_modify_switch_status(HUPU_UINT32 switch_id,
                                    HUPU_UINT32 switch_fd,
                                    NAC_SYSTEM_SWITCH_STATUS status);

HUPU_INT32 nac_system_switch_create_thread(NAC_SYSTEM_SWITCH *pst_switch);
xmlDocPtr nac_sys_parse_set_switch_control(xmlDocPtr doc, HUPU_UINT16 cmd_id);

#ifdef __cplusplus
}
#endif

#endif  // end of NAC_SYSTEM_SWITCH_MAIN_H

