#ifndef NAC_SYSTEM_NETAPP_CHECK_H
#define NAC_SYSTEM_NETAPP_CHECK_H

#include "nac_system_common_lib.h"

#define NETAPP_HASH_MAP_SIZE	1024

#define NETAPP_MODIFY_CONFIG	1
#define NETAPP_MODIFY_EXCEPT	2
#define NETAPP_MODIFY_ALL		3

#define NETAPP_CONFIG_ENABLE	4
#define NETAPP_CONFIG_DISABLE	8

enum
{
	CYCLE_UINT_SECOND = 1,
	CYCLE_UINT_MINUTE = 60,
	CYCLE_UINT_HOUR	  = 60*60,
	CYCLE_UINT_DAY	  = 60*60*24,
};

enum
{
    NETAPP_SHOW,
    NETAPP_ADD,
    NETAPP_DEL,
    NETAPP_MOD,
    NETAPP_ON_OFF,
    NETAPP_ON_GET,
    NETAPP_USER_UPLOAD,
};


typedef struct NETAPP_CONFIG_STRU
{
	HUPU_CHAR 	name[MAX_COMMENT_LEN];
	HUPU_UINT32 cycle_unit;//sec,min,hour
	HUPU_UINT16 cycle;//30-60s, 1-60m,1-24h.
	HUPU_UINT16 times;//1-5times
	HUPU_UINT16 protocol;
	HUPU_UINT16 port;
	HUPU_UINT32 server_group[5];
	HUPU_CHAR	fix_path[KB_BUFF_LEN];
}NETAPP_CONFIG;

/*
typedef struct NETAPP_EXCEPT_STRU
{
	//struct nac_list_head except_list;
	HUPU_UINT32 ip_min;
    HUPU_UINT32 ip_max;
}NETAPP_EXCEPT;
*/

typedef struct NETAPP_EXCEPT_STRU
{
	//struct nac_list_head except_list;
	HUPU_CHAR min[32];
    HUPU_CHAR max[32];
}NETAPP_EXCEPT;

typedef struct NAC_APP_NETAPP_OBJECT_STRU
{
	struct nac_hlist_node netapp_id;
	/*struct nac_list_head	netapp_except_list_head;*/
	struct NETAPP_CONFIG_STRU netapp_st;
	HUPU_UINT16 id;
	HUPU_UINT8 enable;
	HUPU_UINT8 sum;
	struct NETAPP_EXCEPT_STRU *except_list;
}NAC_APP_NETAPP_OBJECT;

extern struct nac_hlist_head netapp_hash_by_id[NETAPP_HASH_MAP_SIZE];
extern HUPU_UINT16 g_netapp_enable_id;
extern HUPU_UINT16 tmp_netapp_enable_id;
extern HUPU_UINT16 g_netapp_policy_index;

HUPU_INT32 nac_app_init_netapp_hlist(HUPU_VOID);
HUPU_INT32 nac_sys_flush_netapp_config_hlist(HUPU_VOID);
HUPU_INT32 nac_app_add_netapp_hlist(NAC_APP_NETAPP_OBJECT *netapp_tmp);
NAC_APP_NETAPP_OBJECT* nac_app_get_netapp_by_id(HUPU_UINT16 id);
HUPU_INT32 nac_sys_set_enable_netapp_config(HUPU_UINT16 policy_id);
HUPU_INT32 nac_sys_knl_flush_enable_netapp_config(HUPU_VOID);
HUPU_INT32 nac_app_get_netapp_name_by_id(HUPU_UINT16 id, HUPU_CHAR* name);
xmlDocPtr nac_sys_parse_netapp_config(xmlDocPtr doc, HUPU_UINT16 cmd_id);
#endif
