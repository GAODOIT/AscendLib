#ifndef NAC_SYSTEM_COMMON_LIB_H
#define NAC_SYSTEM_COMMON_LIB_H

#include <libxml/parser.h>
#include <libxml/tree.h>
#include <sys/types.h>
#include <regex.h>
#include "assert.h"

#define replace_max_num 10
#define ERRBUF  128

#define MAX_ITEM      512
#define MAX_LEN       256

extern char *get_dns_host_ipaddr;

int create_xml_doc(xmlDocPtr *doc, xmlNodePtr *root);
xmlAttrPtr insert_number_xml_new_prop(xmlNodePtr node, const char *tag, int value);
xmlAttrPtr insert_string_xml_new_prop(xmlNodePtr node, const char *tag, char *value);
xmlNodePtr insert_number_xml_new_child(xmlNodePtr node, const char *tag, int value);
xmlNodePtr insert_string_xml_new_child(xmlNodePtr node, const char *tag, char *value);
int nac_get_popen_cmd_result(char *cmd, char *result);

HUPU_INT32 get_content(HUPU_CHAR *buffer, HUPU_CHAR *out, HUPU_CHAR *item_name);
HUPU_CHAR *each_line_search(HUPU_CHAR *buffer,HUPU_CHAR *str);
HUPU_INT32 get_list(HUPU_CHAR *content, HUPU_CHAR (*out)[MAX_LEN]);
HUPU_INT32 split_string(HUPU_CHAR *src,HUPU_CHAR*delim,HUPU_INT32 num, HUPU_CHAR **p);

int nac_sys_get_netdev_netmask(char *szDevName, char *if_netmask);
HUPU_INT32 nac_system_check_app_repeat_start(HUPU_VOID);

/*
diy nac_memcpy, advoid overflow!
return dest addr, if dest_size <= src_len,copy_len = dest_len; or copy_len = src_len.
*/
void *mymemcpy(void *dest, size_t dest_size, const void *src, size_t src_len);

/*now no syscall; get domain host_ipaddress*/
int nac_app_get_domain_host_ip_address(char* domain_url);

/*clean '\n' or '\r' of str*/
int clean_newline_character(char *strSrc);

/*get the current time*/
int get_current_time(char *time_str);

/* return HUPU_OK: success, return HUPU_ERR: Fail*/
int nac_exec_system(const char *string);

/* return HUPU_OK: success, return HUPU_ERR: Fail*/
int nac_preg_match_ip(char *src_str);

/* return HUPU_OK: success, return HUPU_ERR: Fail*/
int nac_app_preg_match_iprange(char* min_ipstr, char* max_ipstr);

/* return HUPU_OK: success, return HUPU_ERR: Fail*/
int nac_preg_match_mac(char *src_str);

/* return HUPU_OK: success, return HUPU_ERR: Fail*/
int nac_preg_match_url(char *src_str);

/*-1:error; 0: unlink; 1: link*/
int nac_netdev_link_detect(const char* net_name);

/*-1:error; 0: down; 1: up*/
int nac_netdev_enable_detect(const char* net_name);

/*
return netdev count if return <=0 error
*/
int nac_get_netdev_count(void);


/* return 0: success get if_info; return -1: fail to get if_info*/
int nac_app_get_system_netcard_info(const char *szDevName, NAC_NET_DEVICE *netcard_info);

/*return 0: get gateway; return -1: no gateway*/
int nac_app_get_system_default_gateway(char* default_gateway);

/*return 0: get dns_server; return -1: no dns_server*/
int nac_app_get_system_resolv_conf(const char* filename, NAC_DNS_SERVER* st_dnserver);

/*get manage eth0 ipaddr(host_bytes)*/
int nac_app_get_netdev_ipaddr(const char *szDevName);

int nac_app_get_netdev_link_status(const char *szDevName);
int nac_app_get_netdev_enable_status(const char *szDevName);

/*get netdev enable and link*/
int nac_app_get_netdev_enable_link_status(const char *szDevName);
int nac_app_get_netdev_link_and_enable_status(const char *szDevName,
                                    unsigned char* link_flag, unsigned char* enable_flag);

#endif //nac_system_common_lib_h
