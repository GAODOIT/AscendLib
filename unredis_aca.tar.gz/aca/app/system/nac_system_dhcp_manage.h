#ifndef __DHCP_MANAGE__
#define __DHCP_MANAGE__
#include"nac_system_exceptapp.h"

typedef struct __MANGE_DHCP__
{
	HUPU_CHAR ip[32];
	HUPU_CHAR comment[MAX_LEN];
	HUPU_INT32 status;
} O_MANAGE_DHCP, *P_MANAGE_DHCP;
typedef struct __MANAGE_DHCP_DATA__
{
	HUPU_INT32 enable;
	HUPU_INT32 type;
	HUPU_INT32 num;
	P_MANAGE_DHCP pData;

}O_MANAGE_DHCP_DATA, *P_MANAGE_DHCP_DATA;


HUPU_INT32 nac_sys_flush_dhcp_manage_config(void);

HUPU_INT32 nac_sys_write_dhcp_manage_data_to_configure(FILE* fp);

HUPU_INT32  nac_sys_get_dhcp_manage_data_form_configure(const HUPU_CHAR *file_path);

xmlDocPtr nac_sys_return_dhcp_manage_result(HUPU_INT32 action_type, P_MANAGE_DHCP_DATA pData);

HUPU_INT32 nac_sys_parse_dhcp_manage_result(xmlNodePtr cur_node, P_MANAGE_DHCP_DATA pData, HUPU_UINT8 action_type);

HUPU_INT32 nac_system_set_dhcp_manage_data_to_kernel(P_MANAGE_DHCP_DATA pData);

xmlDocPtr nac_system_parse_dhcp_manage_config(xmlDocPtr doc, HUPU_UINT16 cmd_id);




#endif


