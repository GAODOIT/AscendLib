/*
 *
 * Part:        NAC ioctl.
 *
 * Author:      yudonghai
 *
 */

#include "include/precomp.h"

static int nac_knl_cmd_set(PNAC_CMD_MSG_HEAD msg)
{
	int rc = NAC_KNL_ERR;
    nac_knl_debug(NAC_KNL_MODULE_IOCTL, "nac_knl_cmd_set-->cmd = %x\n", msg->subjor);
	switch (msg->subjor)
    {
		case NAC_CMD_USER_INS:
            rc = nac_knl_user_add(msg->data, msg->data_len);
			break;
        case NAC_CMD_USER_RMV:
            rc = nac_knl_user_del(msg->data, msg->data_len);
			break;
		case NAC_CMD_USER_MOD:
			if (msg->iden == NAC_KNL_NETAPP_CLR_EXCEPT_STATUS)
			{
				rc = nac_knl_user_clear_netapp_except_status();
			}
			else if (msg->iden == NAC_KNL_NETAPP_SET_EXCEPT_STATUS)
			{
				rc = nac_knl_user_set_status(msg->data, msg->data_len,
											 USER_STATE_IS_NETAPP_EXCEPT);
			}
			break;
        case NAC_CMD_USER_FLUSH:
			rc = nac_knl_user_flush();
			break;
        case NAC_CMD_POLICY_INS:
            rc = nac_knl_policy_add(msg->data, msg->data_len);
            break;
        case NAC_CMD_POLICY_RMV:
            rc = nac_knl_policy_del(msg->data, msg->data_len);
            break;
        case NAC_CMD_POLICY_FLUSH:
            nac_knl_policy_flush(msg->iden);
            rc = NAC_KNL_OK;
            break;
        case NAC_CMD_SYS_SET_MODE:
            rc = nac_knl_policy_set_mode(msg->iden);
            break;
        case NAC_CMD_SYS_SET_PBR_2_ETH_SWITCH:
            rc = nac_knl_policy_pbr_2_eth_switch(msg->iden);
            break;
        case NAC_CMD_SYS_SET_PBR_2_ETH_MAC:
            rc = nac_knl_policy_pbr_2_eth_mac(msg->data, msg->data_len);
            break;
        case NAC_CMD_SYS_SET_ETH0_MAC:
            rc = nac_knl_policy_eth0_mac(msg->data, msg->data_len);
            break;
        case NAC_CMD_SYS_SET_IN_OUT_ETH:
            rc = nac_knl_policy_in_out_eth(msg->data, msg->data_len);
            break;
        case NAC_CMD_SYS_SET_VLAN_MAP:
            rc = nac_knl_policy_set_vlan_map(msg->data, msg->data_len, NAC_CMD_SYS_SET_VLAN_MAP);
            break;
        case NAC_CMD_SYS_FLUSH_VLAN_MAP:
            rc = nac_knl_policy_set_vlan_map(msg->data, msg->data_len, NAC_CMD_SYS_FLUSH_VLAN_MAP);
            break;
        case NAC_CMD_SYS_SET_BYPASS:
            rc = nac_knl_policy_set_bypass(msg->data, msg->data_len);
            break;
        case NAC_CMD_SYS_SET_IP_INFO:
            rc = nac_knl_policy_set_ip_info(msg->data, msg->data_len);
            break;
        case NAC_CMD_SYS_SET_NETAPP:
            rc = nac_knl_policy_set_net_app(msg->data, msg->data_len);
            break;
        case NAC_CMD_RBTREE_INS:
            rc = nac_knl_rbtree_insert(msg->data, msg->data_len);
            break;
        case NAC_CMD_RBTREE_RMV:
    		rc = nac_knl_rbtree_delete(msg->data, msg->data_len);
    		break;
		case NAC_CMD_RBTREE_FLUSH:
            if(msg->iden == 0)
            {
                rc = nac_knl_rbtree_flush();
            }
            else
            {
                rc = nac_knl_rbtree_flush_single(msg->iden);
            }
			break;
        case NAC_CMD_USER_AGENT_INS:
            rc = nac_knl_wm_add(msg->data, msg->data_len, msg->iden,
                                pst_user_agent_wm, nac_knl_user_agent_wm, "user_agent");
            break;
        case NAC_CMD_USER_AGENT_FLUSH:
            rc = nac_knl_wm_flush(pst_user_agent_wm, nac_knl_user_agent_wm);
            break;
        case NAC_CMD_URL_INS:
            rc = nac_knl_wm_add(msg->data, msg->data_len, msg->iden,
                                pst_url_wm, nac_knl_url_wm, "url");
            break;
        case NAC_CMD_URL_RMV:
            rc = nac_knl_wm_rmv(msg->data, msg->data_len, pst_url_wm, nac_knl_url_wm, "url");
            break;
        case NAC_CMD_URL_INS_FINISH:
            rc = nac_knl_wm_add_finish(pst_url_wm, nac_knl_url_wm);
            break;
        case NAC_CMD_URL_FLUSH:
            rc = nac_knl_wm_flush(pst_url_wm, nac_knl_url_wm);
            break;
        case NAC_CMD_DOMAIN_INS:
            rc = nac_knl_domain_add(msg->data, msg->data_len);
            break;
        case NAC_CMD_DOMAIN_RMV:
            rc = nac_knl_domain_del(msg->data, msg->data_len);
            break;
        case NAC_CMD_NAT_INS:
            rc = nac_knl_nat_add(msg->data, msg->data_len);
            break;
        case NAC_CMD_NAT_RMV:
            rc = nac_knl_nat_del(msg->data, msg->data_len);
            break;
		case NAC_CMD_SYS_SET_NAT_SWIT:
            nac_knl_nat_set_swit(msg->iden);
			rc = NAC_KNL_OK;
            break;
        case NAC_CMD_DHCP_SET_SWIT:
            rc = nac_knl_dhcp_set_swit(msg->data, msg->data_len);
            break;
        case NAC_CMD_PORT_IP_INS:
            rc = nac_knl_hash_add(msg->data, msg->data_len);
            break;
        case NAC_CMD_PORT_IP_FLUSH:
            rc = nac_knl_port_ip_flush();
            break;
		default:
			break;
	}
	return rc;
}

static int nac_knl_cmd_get(PNAC_CMD_MSG_HEAD msg)
{
    return NAC_KNL_OK;
}


int nac_knl_cmd_dispatch(PNAC_CMD_MSG_HEAD msg)
{
	switch (msg->major)
    {
		case NAC_CMD_SET:
			return nac_knl_cmd_set(msg);
		case NAC_CMD_GET:
			return nac_knl_cmd_get(msg);
		default:
            nac_knl_debug(NAC_KNL_MODULE_IOCTL, "nac_knl_cmd_dispatch-->error, major = %d\n", msg->major);
			return NAC_KNL_ERR;
	}
}

static long nac_knl_cmd_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	int err = 0;
	NAC_CMD_MSG_HEAD msg, *umsg;

	umsg = (void *)arg;

	memset(&msg, 0, sizeof(msg));

	if(cmd != NAC_CMD_COMMAND)
    {
        nac_knl_debug(NAC_KNL_MODULE_IOCTL, "nac_knl_cmd_ioctl-->error, cmd = %d\n", cmd);
		err = -EINVAL;
		goto OUT;
	}

	// �����û���Ϣͷ
	err = copy_from_user(&msg, (void*)umsg, sizeof(*umsg));
	if(err != 0)
    {
        nac_knl_debug(NAC_KNL_MODULE_IOCTL, "nac_knl_cmd_ioctl-->bad msg header\n");
		err =  -EACCES;
		goto OUT;
	}

	// ������Ϣ�ַ�
	err = nac_knl_cmd_dispatch(&msg);
OUT:
	return err;
}

static int nac_knl_cmd_open(struct inode *inode, struct file *file)
{
	return NAC_KNL_OK;
}

static int nac_knl_cmd_close(struct inode *inode, struct file *file)
{
	return NAC_KNL_OK;
}

static struct file_operations nac_cmd_fops =
{
	.owner		= THIS_MODULE,
	.open 		= nac_knl_cmd_open,
	.release	= nac_knl_cmd_close,
	.unlocked_ioctl = nac_knl_cmd_ioctl,
};

int nac_knl_cmd_init(void)
{
	return register_chrdev(NAC_DEV_MAJOR, NAC_KNL_DEV_NAME, &nac_cmd_fops);
}

void nac_knl_cmd_exit(void)
{
    printk("nac_knl_cmd_exit\n");
	unregister_chrdev(NAC_DEV_MAJOR, NAC_KNL_DEV_NAME);
}
