/*
 *
 * Part:        nac framwork.
 *
 * Author:      ydh
 *
 */

#include "include/precomp.h"

int nac_knl_pbr(struct sk_buff *skb)
{
    struct ethhdr *pst_eth = NULL;
    unsigned char ac_mac_tmp[ETH_ALEN];

    int iRet;

    if(!skb->dev
       || skb->dev->ifindex != st_in_out_eth.us_in_index)
    {
        return NAC_KNL_ERR;
    }

    //nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_knl_pbr_mvg-->skb->mac_header = %p,skb->network_header = %p,skb->transport_header = %p\n" ,skb->mac_header, skb->network_header, skb->transport_header);
    pst_eth = eth_hdr(skb);
    nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_knl_pbr-->%d.%d.%d.%d===>%d.%d.%d.%d, %02X-%02X-%02X-%02X-%02X-%02X==>%02X-%02X-%02X-%02X-%02X-%02X, protocol = %d, ip_hdr(skb)->protocol = %d, skb->dev->name = %s\n",
                    NIPQUAD(ip_hdr(skb)->saddr),
                    NIPQUAD(ip_hdr(skb)->daddr),
                    MAC_FORMAT(pst_eth->h_source),
                    MAC_FORMAT(pst_eth->h_dest),
                    ntohs(skb->protocol),
                    ip_hdr(skb)->protocol,
                    skb->dev->name);

    iRet = nac_mvg_pbr_check(skb, 0);
    if(NAC_FORWARD == iRet)
    {
        if(!(nac_knl_flag & NAC_KNL_PBR_TWO_ETH))
        {
            memcpy(ac_mac_tmp, pst_eth->h_dest, ETH_ALEN);
            memcpy(pst_eth->h_dest, pst_eth->h_source, ETH_ALEN);
            memcpy(pst_eth->h_source, ac_mac_tmp, ETH_ALEN);
        }
        else
        {
            if(likely(pst_out_interface[0]))
            {
                memcpy(pst_eth->h_source, st_eth3.ac_eth3_mac, ETH_ALEN);
                memcpy(pst_eth->h_dest, st_eth3.ac_eth3_sw_mac, ETH_ALEN);
                skb->dev = pst_out_interface[0];
                nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_knl_pbr1-->%d.%d.%d.%d===>%d.%d.%d.%d, %02X-%02X-%02X-%02X-%02X-%02X==>%02X-%02X-%02X-%02X-%02X-%02X, protocol = %d, ip_hdr(skb)->protocol = %d, skb->dev->name = %s\n",
                              NIPQUAD(ip_hdr(skb)->saddr),
                              NIPQUAD(ip_hdr(skb)->daddr),
                              MAC_FORMAT(pst_eth->h_source),
                              MAC_FORMAT(pst_eth->h_dest),
                              ntohs(skb->protocol),
                              ip_hdr(skb)->protocol,
                              skb->dev->name);
            }
        }
        nac_knl_debug(NAC_KNL_MODULE_SKB, "nac_knl_pbr-->forward\n");
    	skb_forward_csum(skb);
    	skb_push(skb, ETH_HLEN);
    	dev_queue_xmit(skb);
        return NAC_KNL_OK;
    }
    return NAC_KNL_ERR;
}


int nac_knl_pbr_init(void)
{
	return NAC_KNL_OK;
}

void nac_knl_pbr_exit(void)
{

}


