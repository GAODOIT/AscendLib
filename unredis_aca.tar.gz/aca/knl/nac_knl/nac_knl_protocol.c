#include "include/precomp.h"

int nac_knl_dhcp_flag = DHCP_CLOSE;

static struct kmem_cache *nac_knl_port_ip_cachep = NULL;
static struct hlist_head port_ip_hash[PORT_IP_HASH_MAP_SIZE];
LIST_HEAD(g_nac_knl_port_ip_list_head);


static inline int nac_knl_get_hash_by(unsigned short port)
{
	return port&(PORT_IP_HASH_MAP_SIZE - 1);
}

NAC_KNL_PORT_IP * __nac_knl_hash_find(unsigned short port, unsigned int ip, unsigned char protocol, char flag)
{
	struct hlist_node *n;
	NAC_KNL_PORT_IP *u = NULL;
	int hash;

	hash = nac_knl_get_hash_by(port);
	hlist_for_each_entry_rcu(u, n, &port_ip_hash[hash], port_ip)
	{
        if(port != u->port)
        {
            continue;
        }

        if(flag == 1
           && protocol == u->protocol)
        {
            if(!u->ip)
            {
                goto FOUND;
            }
            else if(ip == u->ip)
            {
                goto FOUND;
            }
        }

        if(flag == 0
           && (protocol == u->protocol
               || IPPROTO_TCP_UDP == u->protocol))
        {
            if(!u->ip)
            {
                goto FOUND;
            }
            else if(ip == u->ip)
            {
                goto FOUND;
            }
        }
	}

	u = NULL;
FOUND:
	return u;
}

int __nac_knl_hash_add(NAC_KNL_PORT_IP *pst_nac_knl_port_ip)
{
    int hash;

	hash = nac_knl_get_hash_by(pst_nac_knl_port_ip->port);
    hlist_add_head_rcu(&pst_nac_knl_port_ip->port_ip, &port_ip_hash[hash]);
    list_add_tail_rcu(&pst_nac_knl_port_ip->port_ip_list, &g_nac_knl_port_ip_list_head);
    return NAC_KNL_OK;
}

void nac_knl_hash_free_rcu(struct rcu_head *head)
{
	NAC_KNL_PORT_IP *dying;

	dying = container_of(head, NAC_KNL_PORT_IP, port_ip_rcu);

    //nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_hash_free_rcu-->delete :%d.%d.%d.%d\n",NIPQUAD(dying->ip));

	kmem_cache_free(nac_knl_port_ip_cachep, dying);
}


static inline void nac_knl_nat_put(NAC_KNL_PORT_IP *u)
{
    call_rcu(&u->port_ip_rcu, nac_knl_hash_free_rcu);
}

int __nac_knl_hash_del(unsigned short port, unsigned int ip, unsigned char protocol,
                       NAC_KNL_PORT_IP *pst_nac_knl_port_ip_tmp)
{
    NAC_KNL_PORT_IP *pst_nac_knl_port_ip;
    if(port)
    {
        pst_nac_knl_port_ip = __nac_knl_hash_find(port, ip, protocol, 1);
    }
    else
    {
        pst_nac_knl_port_ip = pst_nac_knl_port_ip_tmp;
    }

	if(!pst_nac_knl_port_ip)
	{
		goto OUT ;
	}
	hlist_del_rcu(&pst_nac_knl_port_ip->port_ip);
    list_del_rcu(&pst_nac_knl_port_ip->port_ip_list);

	nac_knl_nat_put(pst_nac_knl_port_ip);

OUT:
	return NAC_KNL_OK;
}
int nac_knl_hash_del(const NAC_KNL_PORT_IP *pst_nac_knl_port_ip, int len)
{
    if(sizeof(NAC_KNL_PORT_IP) != len)
    {
        printk("nac_knl_hash_del error\n");
        return -EINVAL;
    }

    //nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_hash_del-->src_ip:%d.%d.%d.%d\n", NIPQUAD(pst_nac_knl_port_ip->ip));
	mutex_lock(&nac_knl_app_mutex);
    __nac_knl_hash_del(pst_nac_knl_port_ip->port, pst_nac_knl_port_ip->ip, pst_nac_knl_port_ip->protocol, NULL);
	mutex_unlock(&nac_knl_app_mutex);
	return NAC_KNL_OK;
}

int nac_knl_hash_add(NAC_KNL_PORT_IP *pst_nac_knl_port_ip, int len)
{
	NAC_KNL_PORT_IP *pst_nac_knl_port_ip_tmp;
	int err = 0;

	if(len != sizeof(*pst_nac_knl_port_ip_tmp))
	{
        printk("nac_knl_hash_add error\n");
		return -EINVAL;
	}

	mutex_lock(&nac_knl_app_mutex);

	err = -ENOMEM;
	pst_nac_knl_port_ip_tmp = kmem_cache_alloc(nac_knl_port_ip_cachep, GFP_KERNEL);
	if(!pst_nac_knl_port_ip_tmp)
	{
		goto DONE;
	}

	if (0 != copy_from_user(pst_nac_knl_port_ip_tmp, pst_nac_knl_port_ip, len))
    {
		err = -EACCES;
ERR:
		kmem_cache_free(nac_knl_port_ip_cachep, pst_nac_knl_port_ip_tmp);
		goto DONE;
	}

    //nac_knl_debug(NAC_KNL_MODULE_NAT, "nac_knl_hash_add-->src_ip:%d.%d.%d.%d\n", NIPQUAD(pst_nac_knl_port_ip_tmp->ip));
    __nac_knl_hash_del(pst_nac_knl_port_ip_tmp->port, pst_nac_knl_port_ip_tmp->ip, pst_nac_knl_port_ip_tmp->protocol, NULL);

	err = -ENOMEM;
	if(0 > __nac_knl_hash_add(pst_nac_knl_port_ip_tmp))
	{
		goto ERR;
	}

	err = 0;
DONE:
	mutex_unlock(&nac_knl_app_mutex);
	return err;
}

int nac_knl_port_ip_init(void)
{
    int i;
    for(i = 0; i < PORT_IP_HASH_MAP_SIZE; i++)
	{
		INIT_HLIST_HEAD(&port_ip_hash[i]);
	}

    nac_knl_port_ip_cachep = kmem_cache_create("nac_knl_port_ip_cachep", sizeof(NAC_KNL_PORT_IP), 0, 0, NULL);
    if (!nac_knl_port_ip_cachep)
	{
		return NAC_KNL_ERR;
	}
    printk("nac_knl_port_ip_init->Cache object size is %d\n", kmem_cache_size(nac_knl_port_ip_cachep));

	return NAC_KNL_OK;
}

void nac_knl_port_ip_show(void)
{
	NAC_KNL_PORT_IP *dying, *tmp;
    unsigned int ip;

    nac_knl_debug(NAC_KNL_MODULE_POLICY, "except dport start-----------------\n");
	list_for_each_entry_safe(dying, tmp, &g_nac_knl_port_ip_list_head, port_ip_list)
    {
        ip = htonl(dying->ip);
        nac_knl_debug(NAC_KNL_MODULE_POLICY, "dst_port = %d, dst_ip = %d.%d.%d.%d, protocol = %d\n", dying->port, NIPQUAD(ip), dying->protocol);
	}
    nac_knl_debug(NAC_KNL_MODULE_POLICY, "end-----------------\n");
}


int nac_knl_port_ip_flush(void)
{
	NAC_KNL_PORT_IP *dying, *tmp;

    mutex_lock(&nac_knl_app_mutex);

	list_for_each_entry_safe(dying, tmp, &g_nac_knl_port_ip_list_head, port_ip_list)
    {
        __nac_knl_hash_del(0, 0, 0, dying);
	}
    mutex_unlock(&nac_knl_app_mutex);
	return 0;
}

void nac_knl_hash_exit(void)
{
    nac_knl_port_ip_flush();
    synchronize_rcu();
    if(nac_knl_port_ip_cachep)
    {
		kmem_cache_destroy(nac_knl_port_ip_cachep);
    }
	nac_knl_port_ip_cachep = NULL;
}


int nac_knl_dhcp_set_swit(NAC_KNL_DHCP_CONFIG *pst_dhcp, int len)
{
    if(sizeof(NAC_KNL_DHCP_CONFIG) != len)
    {
        printk("nac_knl_dhcp_set_swit error\n");
        return -EINVAL;
    }

    mutex_lock(&nac_knl_app_mutex);

    if(pst_dhcp->status == DHCP_CLOSE)
    {
        nac_knl_dhcp_flag = pst_dhcp->status;
    }
    else
    {
        nac_knl_dhcp_flag = pst_dhcp->switc;
    }
    mutex_unlock(&nac_knl_app_mutex);
	return NAC_KNL_OK;
}


void nac_knl_protocol_dhcp(struct udphdr *udph, int payload_len, unsigned int *ip)
{
    char *payload, *tmp, *tmp1;
    unsigned char len = 0;
    NAC_KNL_DHCP_PRO *pst_pro;


    payload     = (char *)((char *)udph + sizeof(struct udphdr));
    tmp         = payload + 240;
    payload_len = payload_len - 240;
    pst_pro     = (NAC_KNL_DHCP_PRO *)tmp;
    while(payload_len > 0)
    {
        if(pst_pro->type == 255)
        {
            return;
        }
        if(pst_pro->type == 54)
        {
            tmp1 = (char *)(pst_pro + 1);
            *ip = nac_knl_get_u32(tmp1, 0);
            return;
        }

       len += sizeof(NAC_KNL_DHCP_PRO) + pst_pro->len;
       pst_pro = (NAC_KNL_DHCP_PRO *)(tmp + len);
       payload_len = payload_len - len;
    }
}


int nac_knl_protocol_init(void)
{
    nac_knl_port_ip_init();
	return NAC_KNL_OK;
}


void nac_knl_protocol_exit(void)
{
    nac_knl_hash_exit();
}

