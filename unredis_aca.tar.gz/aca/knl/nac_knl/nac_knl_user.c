/*
 *
 * Part:        nac framwork.
 *
 * Author:      ydh
 *
 */

#include "include/precomp.h"

static struct kmem_cache *nac_knl_usr_cachep = NULL;
static LIST_HEAD(g_nac_knl_tmp_user_list_head);

int usertimeout = 86400; //24 hour

static int ewma_log = 2;
atomic_t g_user_number = {0};

static DEFINE_SPINLOCK(nac_knl_usr_spinlock);
DEFINE_MUTEX(nac_knl_app_mutex);

LIST_HEAD(g_nac_knl_user_list_head);
static struct hlist_head user_hash_online_by_ip[USER_HASH_MAP_SIZE];
static struct hlist_head user_hash_online_by_id[USER_HASH_MAP_SIZE];
static struct hlist_head user_hash_online_by_mac[NAC_MAC_HASH_SIZE];

static unsigned int mac_salt;
int nac_knl_user_get_hash_by_mac(const unsigned char *mac) //br_mac_hash
{
	unsigned int key = get_unaligned((unsigned int *)(mac + 2));
	return jhash_1word(key, mac_salt) & (NAC_MAC_HASH_SIZE - 1);
}


static unsigned long nac_knl_usr_exception = 0;

static inline int nac_knl_user_invalid(const NAC_KNL_USER_OBJECT *pst_usr)
{
	if(unlikely(!pst_usr->ip)
        || pst_usr->isolation_num > 16)
    {
        nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_invalid-->empty insert user\n");
		return 1;
	}

	return 0;
}

void nac_knl_user_check(NAC_KNL_USER_OBJECT *pst_usr, char flag)
{
	NAC_KNL_USER_MSG st_user_new;
    struct nac_knl_rbtree_entry search;

	if(flag == NAC_NETLINK_NETAPP_TIMEOUT
		&& pst_usr->state & USER_STATE_IS_ISOLATION_AUTH_FAIL)
	{
		return;
	}


    if(flag == NAC_NETLINK_NETAPP_TIMEOUT)
    {
        search.type = NAC_KNL_RBTREE_EXCEPT_NET_APP;
        search.union_rbtree.ip_key.ip_addr = pst_usr->ip;
        if(nac_knl_rbtree_search(&search))
        {
            return;
        }
    }

    st_user_new.src_ip    = pst_usr->ip;
    st_user_new.tmp_id    = pst_usr->id;
    st_user_new.dept_id   = pst_usr->gid;
    st_user_new.result    = flag;
    st_user_new.user_type = pst_usr->user_type;
    memcpy(st_user_new.src_mac, pst_usr->mac, sizeof(st_user_new.src_mac));
    nac_knl_netlink_user_send(&st_user_new, sizeof(NAC_KNL_USER_MSG), flag);
	
	return;
}

void nac_knl_user_timeout(unsigned long now, char *pc_time)
{
	NAC_KNL_USER_OBJECT *pst_usr;
	int  rate, ubytes = 0, dbytes = 0;
    unsigned long i, j, time_tmp  = 0;

	if(now & 1)
	{
		return;
	}
	time_tmp = (gst_net_app.times*gst_net_app.cycle > 90)?90:(gst_net_app.times*gst_net_app.cycle);
    rcu_read_lock();
    nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_timeout-->0\n");
    list_for_each_entry_rcu(pst_usr, &g_nac_knl_user_list_head, user_list)
    {
        if(unlikely(nac_knl_switch))
        {
            pst_usr->last_time    = now;
			pst_usr->net_app_time = now;
            continue;
        }
        nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_timeout-->1\n");
        if(time_before((unsigned long)usertimeout + pst_usr->last_time, now))
        {
            nac_knl_user_check(pst_usr, NAC_NETLINK_USER_TIMEOUT);
            nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_timeout-->user_ip = %d.%d.%d.%d, time = %s\n",  NIPQUAD(pst_usr->ip), pc_time);
            continue;
        }

        if((gst_net_app.switc == 1)
            && (pst_usr->state & USER_STATE_NETAPP_CHECK))
        {
            if(!(pst_usr->state & USER_STATE_IS_NETAPP))
            {
                if(++(pst_usr->tmp_count) >= time_tmp)
                {
                    nac_knl_user_check(pst_usr, NAC_NETLINK_NETAPP_TIMEOUT);
                    nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_timeout-->net_app1 user_ip = %d.%d.%d.%d, time = %s\n",  NIPQUAD(pst_usr->ip), pc_time);
                    continue;
                }
            }
            else
            {
                if(time_before((unsigned long)(pst_usr->net_app_time + gst_net_app.times*gst_net_app.cycle), now))
                {
                    nac_knl_user_check(pst_usr, NAC_NETLINK_NETAPP_TIMEOUT);
                    nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_timeout-->net_app2 user_ip = %d.%d.%d.%d, time = %s\n",  NIPQUAD(pst_usr->ip), pc_time);
                    continue;
                }
                pst_usr->tmp_count = 0;
            }
            continue;
        }
        pst_usr->tmp_count = 0;
    }
	rcu_read_unlock();
}

static inline int nac_knl_user_get_hash_by_ip(unsigned long ip)
{
	return ip&(USER_HASH_MAP_SIZE - 1);
}

static inline int nac_knl_user_get_hash_by_id(unsigned long id)
{
	return id&(USER_HASH_MAP_SIZE - 1);
}

static void __nac_knl_user_delt(NAC_KNL_USER_OBJECT *u)
{
	list_del(&u->user_list);
	WARN_ON(atomic_read(&u->refcnt) != 1);

    nac_knl_debug(NAC_KNL_MODULE_USER, "__nac_knl_user_delt-->delete tmp user:%d.%d.%d.%d(%p)\n", NIPQUAD(u->ip), u);

	kmem_cache_free(nac_knl_usr_cachep, u);
}

static void nac_knl_user_delt(unsigned long id, unsigned long ip)
{
	NAC_KNL_USER_OBJECT *u, *tmp;

	if (!id && !ip)
	{
		return;
	}

    nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_delt-->delete tmp user by id %lu\n", id);
	spin_lock_bh(&nac_knl_usr_spinlock);

	list_for_each_entry_safe(u, tmp, &g_nac_knl_tmp_user_list_head, user_list)
	if (u->id == id || u->ip == ip)
    {
		__nac_knl_user_delt(u);
		break;
	}

	spin_unlock_bh(&nac_knl_usr_spinlock);
}

static int nac_knl_user_insert(NAC_KNL_USER_OBJECT *pst_user)
{
	int hash_ip, hash_id, hash_mac;

	hash_ip = nac_knl_user_get_hash_by_ip(pst_user->ip);
    hash_id = nac_knl_user_get_hash_by_id(pst_user->id);
    hash_mac = nac_knl_user_get_hash_by_mac(pst_user->mac);
	pst_user->last_time   = get_seconds();
	pst_user->login_time  = pst_user->last_time;
    pst_user->net_app_time = pst_user->last_time;
    pst_user->tmp_count   = 0;
    atomic_set(&pst_user->refcnt, 1);

	//__ktpn_user_bind_policy(usr);

	hlist_add_head_rcu(&pst_user->user_ip, &user_hash_online_by_ip[hash_ip]);
    hlist_add_head_rcu(&pst_user->user_id, &user_hash_online_by_id[hash_id]);
    hlist_add_head_rcu(&pst_user->user_mac, &user_hash_online_by_mac[hash_mac]);
	list_add_tail_rcu(&pst_user->user_list, &g_nac_knl_user_list_head);

	//TPN_INC_STATS(TPN_USR_ADDNUM);
    nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_insert-->add a usr %d.%d.%d.%d(%d, %lu, %lu, %lu, %lu, %lu, %u), hash_mac = %d\n",
			     NIPQUAD(pst_user->ip), pst_user->state, pst_user->other, pst_user->id,
			     pst_user->gid, pst_user->tpnct_max_tcp, pst_user->tpnct_max_udp, pst_user->user_type, hash_mac);

	return NAC_KNL_OK;
}

int nac_knl_tmp_user_add(void)
{
    NAC_KNL_USER_OBJECT *pst_nac_knl_user;
    pst_nac_knl_user = kmem_cache_alloc(nac_knl_usr_cachep, GFP_ATOMIC);
	if (unlikely(!pst_nac_knl_user))
	{
		return NAC_KNL_ERR;
	}
    atomic_set(&pst_nac_knl_user->refcnt, 1);
    list_add_tail(&pst_nac_knl_user->user_list, &g_nac_knl_tmp_user_list_head);
    return NAC_KNL_OK;
}


int nac_knl_user_init(void)
{
    int i;

	for(i = 0; i < USER_HASH_MAP_SIZE; i++)
	{
		INIT_HLIST_HEAD(&user_hash_online_by_ip[i]);
        INIT_HLIST_HEAD(&user_hash_online_by_id[i]);
	}

    for(i = 0; i < NAC_MAC_HASH_SIZE; i++)
	{
		INIT_HLIST_HEAD(&user_hash_online_by_mac[i]);
	}

   nac_knl_usr_cachep = kmem_cache_create("nac_knl_user_cache", sizeof(NAC_KNL_USER_OBJECT), 0, 0, NULL);

   //printk( "Cache name is %s\n", kmem_cache_name(nac_knl_usr_cachep));

   printk("NAC_KNL_USER_OBJECT size is %d\n", sizeof(NAC_KNL_USER_OBJECT));

   printk("nac_knl_user_init->Cache object size is %d\n", kmem_cache_size(nac_knl_usr_cachep));
   printk("nac_knl_user_init->mac hash size is %d\n", NAC_MAC_HASH_SIZE);

	if (!nac_knl_usr_cachep)
	{
		return NAC_KNL_ERR;
	}
    //nac_knl_tmp_user_add();
    //nac_knl_tmp_user_add();
    //nac_knl_tmp_user_add();
	return NAC_KNL_OK;
}

void nac_knl_user_free_rcu(struct rcu_head *head)
{
	NAC_KNL_USER_OBJECT *dying;
    unsigned int ip;

	dying = container_of(head, NAC_KNL_USER_OBJECT, user_rcu);

    ip = htonl(dying->ip);
    nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_free_rcu-->delete user:%d.%d.%d.%d(%u)\n", NIPQUAD(ip), dying->id);
	kmem_cache_free(nac_knl_usr_cachep, dying);
}


static inline void nac_knl_user_put(NAC_KNL_USER_OBJECT *u)
{
	if (atomic_dec_and_test(&u->refcnt))
	{
		call_rcu(&u->user_rcu, nac_knl_user_free_rcu);
	}
}

NAC_KNL_USER_OBJECT * __nac_knl_user_find_by_mac(const unsigned char *mac, unsigned char flag)
{
	struct hlist_node *n;
	NAC_KNL_USER_OBJECT *u = NULL;
	int hash;
    char ac_mac[ETH_ALEN];
    memcpy(ac_mac, mac, ETH_ALEN);

	hash = nac_knl_user_get_hash_by_mac(ac_mac);
	hlist_for_each_entry_rcu(u, n, &user_hash_online_by_mac[hash], user_mac)
	{
        if(!compare_ether_addr(ac_mac, u->mac))
        {
            if(flag == 0
                && u->other == 0)
            {
                goto FOUND;
            }
            if(flag == 1)//rmv user
            {
                goto FOUND;
            }
            if(flag == 2 //tmp user
                && u->other != 0)
            {
                goto FOUND;
            }
        }
	}

	u = NULL;
FOUND:
    nac_knl_debug(NAC_KNL_MODULE_USER, "__nac_knl_user_find_by_mac-->%02X-%02X-%02X-%02X-%02X-%02X,  u=%p, hash = %d, flag = %d\n",MAC_FORMAT(ac_mac), u, hash, flag);
	return u;
}

NAC_KNL_USER_OBJECT * __nac_knl_user_find(unsigned long ip, unsigned long ip2, unsigned char flag)
{
	struct hlist_node *n;
	NAC_KNL_USER_OBJECT *u = NULL;
	int hash;

	hash = nac_knl_user_get_hash_by_ip(ip);
	hlist_for_each_entry_rcu(u, n, &user_hash_online_by_ip[hash], user_ip)
	{
		if(ip == u->ip)
		{
            if(flag == 0
                && u->other == 0)
            {
                goto FOUND;
            }
            if(flag == 1)//rmv user
            {
                goto FOUND;
            }
            if(flag == 2 //tmp user
                && u->other != 0)
            {
                goto FOUND;
            }
		}
	}

	if(ip2)
    {
		hash = nac_knl_user_get_hash_by_ip(ip2);
		hlist_for_each_entry_rcu(u, n, &user_hash_online_by_ip[hash], user_ip)
		{
			if(ip2 == u->ip)
			{
				goto FOUND;
			}
		}
	}

	u = NULL;

FOUND:
	return u;
}

static int __nac_knl_user_del_by_mac(const unsigned char *mac, NAC_KNL_USER_OBJECT *u)
{
	if (!u && !(u = __nac_knl_user_find_by_mac(mac, 1)))
	{
		goto OUT;
	}

	atomic_dec(&g_user_number);
	list_del_rcu(&u->user_list);
	hlist_del_rcu(&u->user_ip);
    hlist_del_rcu(&u->user_id);
    hlist_del_rcu(&u->user_mac);
	nac_knl_user_put(u);

OUT:
	return NAC_KNL_OK;
}

static int __nac_knl_user_del(unsigned long ip, NAC_KNL_USER_OBJECT *u)
{
	if (!u && !(u = __nac_knl_user_find(ip, 0, 1)))
	{
		goto OUT ;
	}

	atomic_dec(&g_user_number);
	list_del_rcu(&u->user_list);
	hlist_del_rcu(&u->user_ip);
    hlist_del_rcu(&u->user_id);
    hlist_del_rcu(&u->user_mac);
	nac_knl_user_put(u);

OUT:
	return NAC_KNL_OK;
}

int nac_knl_user_del(const NAC_KNL_USER_OBJECT *pst_usr, int len)
{
	mutex_lock(&nac_knl_app_mutex);
    if(nac_mode == NAC_MVG_MODE)
    {
        __nac_knl_user_del_by_mac(pst_usr->mac, NULL);
    }
    else
    {
        __nac_knl_user_del(pst_usr->ip, NULL);
    }

	mutex_unlock(&nac_knl_app_mutex);
	return NAC_KNL_OK;
}

int nac_knl_user_set_status(const NAC_KNL_USER_OBJECT *pst_usr, int len, int flag)
{
	NAC_KNL_USER_OBJECT *pst_user = NULL;
	mutex_lock(&nac_knl_app_mutex);
	if (nac_mode == NAC_MVG_MODE)
	{
		if((pst_user = __nac_knl_user_find_by_mac(pst_usr->mac, 0)))
		{
			pst_user->state |= flag;
		}
	}
	else
	{
		if((pst_user = __nac_knl_user_find(pst_usr->ip, 0, 0)))
		{
			pst_user->state |= flag;
		}
	}
	mutex_unlock(&nac_knl_app_mutex);
	
	return NAC_KNL_OK;
}

int nac_knl_user_clear_netapp_except_status(void)
{
	NAC_KNL_USER_OBJECT *pst_user;
    list_for_each_entry_rcu(pst_user, &g_nac_knl_user_list_head, user_list)
    {
    	pst_user->state &= ~USER_STATE_IS_NETAPP_EXCEPT;
		pst_user->tmp_count = 0;
    }
	return NAC_KNL_OK;
}

int nac_knl_user_add(const NAC_KNL_USER_OBJECT *pst_usr, int len)
{
	NAC_KNL_USER_OBJECT *pst_usr_tmp;
    unsigned int ip;
	int err = 0;

	if (len != sizeof(*pst_usr) || nac_knl_user_invalid(pst_usr))
	{
		return -EINVAL;
	}

	mutex_lock(&nac_knl_app_mutex);

	err = -ENOMEM;
	pst_usr_tmp = kmem_cache_alloc(nac_knl_usr_cachep, GFP_KERNEL);
	if (!pst_usr_tmp)
	{
		goto DONE;
	}
    nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_add--> 1\n");
	if (0 != copy_from_user(pst_usr_tmp, pst_usr, len))
    {
		err = -EACCES;
ERR:
		kmem_cache_free(nac_knl_usr_cachep, pst_usr_tmp);
		goto DONE;
	}
    ip = htonl(pst_usr_tmp->ip);
    nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_add-->ip:%d.%d.%d.%d\n", NIPQUAD(ip));
	//nac_knl_user_delt(pst_usr_tmp->last_time, pst_usr_tmp->ip);
	/* Here, Avoid DUP user, that happens ! not sslvpn user */

    if(nac_mode == NAC_MVG_MODE)
    {
        __nac_knl_user_del_by_mac(pst_usr_tmp->mac, NULL);
    }
    else
    {
        __nac_knl_user_del(pst_usr_tmp->ip, NULL);
    }

    nac_knl_debug(NAC_KNL_MODULE_USER, "nac_knl_user_add-->3\n");
	err = -ENOMEM;
	if (0 > nac_knl_user_insert(pst_usr_tmp))
	{
		goto ERR;
	}

	err = 0;
	atomic_inc(&g_user_number);

DONE:
	mutex_unlock(&nac_knl_app_mutex);
	return err;
}


int nac_knl_user_flush(void)
{
	NAC_KNL_USER_OBJECT *dying, *tmp;

    nac_knl_usr_exception = 0;
	mutex_lock(&nac_knl_app_mutex);
	list_for_each_entry_safe(dying, tmp, &g_nac_knl_user_list_head, user_list)
    {
		__nac_knl_user_del(0, dying);
	}
	mutex_unlock(&nac_knl_app_mutex);

	/* Clean tmp users */
	spin_lock_bh(&nac_knl_usr_spinlock);
	list_for_each_entry_safe(dying, tmp, &g_nac_knl_tmp_user_list_head, user_list)
	{
		__nac_knl_user_delt(dying);
	}
	spin_unlock_bh(&nac_knl_usr_spinlock);

	return 0;
}


void nac_knl_user_exit(void)
{
    NAC_KNL_USER_OBJECT *u, *tmp;

	printk("nac_knl_user_exit\n");
    nac_knl_user_flush();
    synchronize_rcu();
    if(nac_knl_usr_cachep)
    {
		kmem_cache_destroy(nac_knl_usr_cachep);
    }
	nac_knl_usr_cachep = NULL;
}
