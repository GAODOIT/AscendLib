#ifndef __NAC_KNL_RBTREE__
#define __NAC_KNL_RBTREE__

typedef enum
{
	NAC_KNL_RBTREE_NONE = 0,
    NAC_KNL_RBTREE_IP_RANGE,
	NAC_KNL_RBTREE_EXCEPT_TERMINAL,
	NAC_KNL_RBTREE_EXCEPT_MAC,
	NAC_KNL_RBTREE_NETAPP_SERVER,
	NAC_KNL_RBTREE_EXCEPT_SERVER,
	NAC_KNL_RBTREE_EXCEPT_PORT,
	NAC_KNL_RBTREE_EXCEPT_DOMAIN,
	NAC_KNL_RBTREE_EXCEPT_IP_MAC,
	NAC_KNL_RBTREE_EXCEPT_NET_APP,
	NAC_KNL_RBTREE_NAT_SERVER,
	NAC_KNL_RBTREE_ISOLATION_ZONE,
	NAC_KNL_RBTREE_HTTP_PROXY_SERVER,
	NAC_KNL_RBTREE_DHCP_SERVER,
	NAC_KNL_RBTREE_NUM,
}NAC_KNL_RBTREE_TYPE;

typedef enum
{
	NAC_KNL_RBTREE_LOC_TYPE_NONE = 0,
	NAC_KNL_RBTREE_LOC_TYPE_INS,
	NAC_KNL_RBTREE_LOC_TYPE_SRH,
	NAC_KNL_RBTREE_LOC_TYPE_DEL,
}NAC_KNL_RBTREE_ACTION;

enum
{
	NAC_KNL_RBTREE_LOC_WRONG = 0,
	NAC_KNL_RBTREE_LOC_LEFT,
	NAC_KNL_RBTREE_LOC_RIGHT,
	NAC_KNL_RBTREE_LOC_MATCH,
};

struct nac_knl_rbtree_entry
{
	unsigned short type;
	unsigned short sync:2, op: 14;

	int priority;

	union
    {
        struct
        {
			unsigned int ip_addr;
            unsigned short port;
            unsigned short pading;
		}ip_key;
        struct
        {
			char ac_mac[ETH_ALEN];
		}mac_key;
        struct
        {
			unsigned int ip_addr;
            char ac_mac[ETH_ALEN];
		}ip_mac_key;
		struct
        {
			unsigned int ip_min;
			unsigned int ip_max;
            unsigned int isolation_id;
		}ip;
        struct
        {
			char ac_mac[ETH_ALEN];
		}mac;
        struct
        {
            unsigned int ip_addr;
			char ac_mac[ETH_ALEN];
		}ip_mac;
        struct
        {
            unsigned int ip_addr;
			unsigned short dst_port;
            unsigned char protocol;
            unsigned char flag;
		} port;
	} union_rbtree;
};

void nac_knl_rbtree_read_lock(void);
void nac_knl_rbtree_read_unlock(void);

int nac_knl_rbtree_insert(struct nac_knl_rbtree_entry *ety, int len);
int nac_knl_rbtree_delete(struct nac_knl_rbtree_entry *ety, int len);
int nac_knl_rbtree_show(void);
struct nac_knl_rbtree_entry *nac_knl_rbtree_search(struct nac_knl_rbtree_entry *ety);
int nac_knl_rbtree_flush_single(NAC_KNL_RBTREE_TYPE type);
int nac_knl_rbtree_flush(void);
int nac_knl_rbtree_init(void);
int nac_knl_rbtree_exit(void);

#endif
