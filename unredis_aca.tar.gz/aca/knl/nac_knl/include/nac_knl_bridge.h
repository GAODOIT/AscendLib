#ifndef	__NAC_KNL_BRIDGE_H__
#define	__NAC_KNL_BRIDGE_H__

int nac_knl_bridge(struct sk_buff *skb, unsigned short vlan_id);
int nac_knl_bridge_init(void);
void nac_knl_bridge_exit(void);
#endif

