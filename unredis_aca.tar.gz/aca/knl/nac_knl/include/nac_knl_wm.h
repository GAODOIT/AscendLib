#ifndef __NAC_KNL_WM_H__
#define __NAC_KNL_WM_H__

#define HASHTABLESIZE (256 * 256)

typedef struct wm_pattern_struct
{
	struct wm_pattern_struct *next;
	unsigned char *psPat; 	//pattern array
	unsigned psLen;    		//length of pattern in bytes
	int cls;			  		//pattern class for tpn
}WM_PATTERN_STRUCT;

#define HASH_TYPE unsigned short

#define SHIFTTABLESIZE (256 * 256)

typedef struct wm_struct
{
	WM_PATTERN_STRUCT *plist; //pattern list
	WM_PATTERN_STRUCT *msPatArray; //array of patterns
	unsigned short *msNumArray; //array of group counts, # of patterns in each hash group
	int msNumPatterns; //number of patterns loaded
	unsigned int msNumHashEntries;
	HASH_TYPE *msHash; //last 2 characters pattern hash table
	unsigned char* msShift; //bad word shift table
	HASH_TYPE *msPrefix; //first 2 characters prefix table
	int msSmallest; //shortest length of all patterns
}WM_STRUCT;

WM_STRUCT * wm_new(void);
void wm_rmv_single(WM_STRUCT *ps, char *ac_buff);
void wm_free_all(WM_STRUCT *ps);
int wm_add_pattern(WM_STRUCT *ps,unsigned char *P,int m, int cls);
int wm_prep_patterns(WM_STRUCT *ps);
int wm_search(WM_STRUCT *ps,unsigned char *Tx,int n);
void wm_show(WM_STRUCT *ps);

#endif

