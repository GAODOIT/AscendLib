#ifndef __NAC_KNL_PROTOCOL_H__
#define __NAC_KNL_PROTOCOL_H__

typedef enum
{
    DHCP_OPEN       = 0, 
    DHCP_CLOSE,     //dhcp���ܹر�, ���ر�ʱ����Ҫ����ں�dhcp��ص�����
    DHCP_ENABLE ,
    DHCP_DISABLE,
}DHCP_SWIC;

typedef struct NAC_KNL_DHCP_CONFIG_STRU
{
	unsigned short status;
    unsigned short switc;
}NAC_KNL_DHCP_CONFIG;


typedef struct NAC_KNL_DHCP_STRU
{
	unsigned int ip;
    unsigned int flag;
}NAC_KNL_DHCP;

typedef struct NAC_KNL_DHCP_PRO_STRU
{
    unsigned char type;
    unsigned char len;
}NAC_KNL_DHCP_PRO;

extern int nac_knl_dhcp_flag;

int nac_knl_dhcp_set_swit(NAC_KNL_DHCP_CONFIG *pst_dhcp, int len);
void nac_knl_protocol_dhcp(struct udphdr *udph, int len, unsigned int *ip);


#define PORT_IP_HASH_MAP_SIZE 64

typedef struct NAC_KNL_PORT_IP_STRU
{
    struct list_head  port_ip_list;
	struct hlist_node port_ip;
	struct rcu_head   port_ip_rcu;
	unsigned int ip;
    unsigned short port;
    unsigned short protocol;
}NAC_KNL_PORT_IP;


int nac_knl_hash_add(NAC_KNL_PORT_IP *pst_nac_knl_port_ip, int len);
int nac_knl_hash_del(const NAC_KNL_PORT_IP *pst_nac_knl_port_ip, int len);
NAC_KNL_PORT_IP * __nac_knl_hash_find(unsigned short port, unsigned int ip, unsigned char protocol, char flag);
int nac_knl_port_ip_flush(void);
void nac_knl_port_ip_show(void);


int nac_knl_protocol_init(void);
void nac_knl_protocol_exit(void);

#endif

