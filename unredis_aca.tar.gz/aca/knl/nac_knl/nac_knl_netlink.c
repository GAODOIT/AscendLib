/*
 *
 * Part:        nac framwork.
 *
 * Author:      ydh
 *
 */

#include "include/precomp.h"

static DEFINE_MUTEX(nac_knl_netlink_lock);

static struct sock *netlink_sock = NULL;
static unsigned int netlink_pid[NAC_NL_MAX] = {0};




static int nac_knl_netlink_user_open(struct sk_buff *skb, struct nlmsghdr *nlh)
{
	netlink_pid[NAC_NL_USRID] = nlh->nlmsg_pid;

    nac_knl_debug(NAC_KNL_MODULE_NETLINK, "nac_knl_netlink_open-->pid  = %d\n", nlh->nlmsg_pid);
	return NAC_KNL_OK;
}

static int nac_knl_netlink_user_close(struct sk_buff *skb, struct nlmsghdr *nlh)
{
	return NAC_KNL_OK;
}

static int nac_knl_netlink_openlog(struct sk_buff *skb, struct nlmsghdr *nlh)
{
	return NAC_KNL_OK;
}

static int nac_knl_netlink_closelog(struct sk_buff *skb, struct nlmsghdr *nlh)
{
	return NAC_KNL_OK;
}

static struct NAC_KNL_NETLINK_STRU
{
	int (*doit)(struct sk_buff *, struct nlmsghdr *);
	int (*dump)(struct sk_buff *, struct netlink_callback *);
} nac_knl_netlink_dispatch[NAC_NLK_NR_MSGTYPE - NAC_NLK_BASE - 1] =
{
	[NAC_NETLINK_USER_OPEN - NAC_NLK_BASE - 1]  = { .doit = nac_knl_netlink_user_open },
	[NAC_NETLINK_USER_CLOSE - NAC_NLK_BASE - 1] = { .doit = nac_knl_netlink_user_close},
	[NAC_NETLINK_OPENLOG - NAC_NLK_BASE - 1]    = { .doit = nac_knl_netlink_openlog },
	[NAC_NETLINK_CLOSELOG - NAC_NLK_BASE - 1]   = { .doit = nac_knl_netlink_closelog},
};

static void nac_knl_netlink_recv(struct sk_buff *skb)
{
	struct nlmsghdr *nlh;
	struct NAC_KNL_NETLINK_STRU *link;
	int idx;

	nlh = nlmsg_hdr(skb);

	/* Unsupport downstream message-type */
	if(!(nlh->nlmsg_type > NAC_NLK_BASE
         && nlh->nlmsg_type < NAC_NLK_NR_MSGTYPE))
	{
		return;
	}

	/* Bad header */
	if (nlh->nlmsg_len < NLMSG_HDRLEN)
	{
		return;
	}

	idx = nlh->nlmsg_type - NAC_NLK_BASE - 1;
	link = &nac_knl_netlink_dispatch[idx];

	mutex_lock(&nac_knl_netlink_lock);

	if(likely(link->doit))
	{
		link->doit(skb, nlh);
	}

	mutex_unlock(&nac_knl_netlink_lock);
}

static int __nac_knl_netlink_send(unsigned long toid, void *buf,
                                  int len, unsigned long type)
{
	struct sk_buff *skb;
	struct nlmsghdr *nlh;
	int rc = -EINVAL;
	int	skb_len = NLMSG_SPACE(len);

	if (!netlink_sock || !toid || !buf   || len <= 0)
	{
		goto err;
	}

	skb = alloc_skb(skb_len, GFP_ATOMIC);
	if(NULL == skb)
	{
		return rc;
	}

	nlh = nlmsg_put(skb, 0, 0, type, len, 0);
	/* Mark kernel process */
	NETLINK_CB(skb).pid = 0;
	memcpy(NLMSG_DATA(nlh), buf, len);

	rc = netlink_unicast(netlink_sock, skb, toid, MSG_DONTWAIT);
	if(rc < 0)
    {
        nac_knl_debug(NAC_KNL_MODULE_NETLINK, "nac_knl_netlink_open-->applicatin broken = %d\n", rc);
err:
		return rc ;
	}

	return NAC_KNL_OK;
}

int nac_knl_netlink_user_send(void *buf, int len, unsigned long type)
{
	return __nac_knl_netlink_send(netlink_pid[NAC_NL_USRID], buf, len, type);
}


int nac_knl_netlink_init(void)
{
    netlink_sock = netlink_kernel_create(&init_net, NAC_KNL_NETLINK_PROTO, 0,
			                             nac_knl_netlink_recv, NULL, THIS_MODULE);
	if(NULL == netlink_sock)
    {
		return NAC_KNL_ERR;
	}
	return NAC_KNL_OK;
}

void nac_knl_netlink_exit(void)
{
    printk("nac_knl_netlink_exit0\n");
    if(netlink_sock != NULL)
    {
        printk("nac_knl_netlink_exit1\n");
		sock_release(netlink_sock->sk_socket);
    }
}

