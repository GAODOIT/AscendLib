#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <libxml/parser.h>
#include <libxml/xmlmemory.h>

#define PORT 1235
#define SERVER_IP "127.0.0.1"

int main(int argc, char *argv[])
{
	int s;
	struct sockaddr_in addr;
	char buffer[256];


	if (argc < 2)
	{
		printf("Please input a file !\n");
		return -1;
	}

	if ( (s = socket (AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror ("socket");
		return -1;
	}
	
	bzero (&addr, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(PORT);
	addr.sin_addr.s_addr = inet_addr(SERVER_IP);

	if (connect(s, (struct sockaddr *)&addr, sizeof(addr)) < 0)
	{
		perror("connect");
		return -1;
	}
	recv (s, buffer, sizeof(buffer), 0);
	printf ("%s\n", buffer);

	/*Get the xmlfile and parse into string*/
	xmlDocPtr doc;
	xmlChar *xmlbuf;
	char *szDocName;
	int buffersize;
	
	/*while(1)
	{
		bzero (buffer, sizeof(buffer));
		read (STDIN_FILENO, buffer, sizeof(buffer));
	*/
		szDocName = argv[1];
		doc = xmlReadFile(szDocName, "UTF-8", XML_PARSE_RECOVER);
		xmlDocDumpFormatMemory(doc, &xmlbuf, &buffersize, 1);
		printf("-------%s----\n", (char *) xmlbuf);
		
		if (send(s, xmlbuf, strlen(xmlbuf)+1, 0) < 0)
		{
			perror("send");
			return -1;
		}
		xmlFree(xmlbuf);
	/*
	}
	*/
	
	close (s);
	xmlFreeDoc (doc);
	return 0;
}
