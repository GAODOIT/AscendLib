path = File.absolute_path(__FILE__)
$LOAD_PATH.unshift(File.dirname(path))
require "switch"
conf = CfgMgr.get_config({"vendor" => "h3c", "model" => "5510"})
puts conf
puts conf["fetch_mac"]
