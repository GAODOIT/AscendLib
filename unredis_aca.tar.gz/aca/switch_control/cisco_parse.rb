#######################################################################
#### Author: rubyer                                                 ###
#### Date: 2015.1.23												###
#### Description: parse cisco_switch methods function   			###	
#### Modify reason:													###
#### Version: 1.0													###
#### Support switch list:                                           ###   
#### Cisco:3750 4503                                                ###
#### bugs report to hp104@hupu.net									###
#######################################################################
module Switch
	class Fetch
        def Fetch.get_cisco_arp(recv_buffer)
        	arp_list_array = []
            recv_buffer.each_line do |line|
                if /([0-9]{1,3}[.]){3}[0-9]{1,3}/ =~ line
                    arp_entry_dic = {}
                    tmp_array = line.chomp.split
        		    arp_entry_dic["ip"]	= tmp_array[1]
        		    arp_entry_dic["mac"]= format_mac_addr(tmp_array[3]).upcase
        		    #arp_entry_dic["vlan"]	= tmp_array[5]
                    arp_list_array.push(arp_entry_dic)
        		end
        	end
        	return arp_list_array
        end

        def Fetch.get_cisco_mac_addr(recv_buffer)	
        	mac_addr_list_array = []
            recv_buffer.each_line do |line|
        		line_tmp = line.lstrip.chomp
        		if /\A\d/ =~ line_tmp && /DYNAMIC/i =~ line_tmp 
        		    mac_addr_entry_dic  = {}
                    tmp_array = line_tmp.split
                    #if !(/Ethernet/ =~ tmp_array[-1]) #C4503 2015-01-21
                    if /Ethernet/ !~ tmp_array[-1]
        		        if /^Fa/ =~ tmp_array[-1]
        			        tmp_array[-1].insert(2, "stEthernet")
        		        elsif /^Gi/ =~ tmp_array[-1]	
        			        tmp_array[-1].insert(2, "gabitEthernet")
        		        end
                    end
        		    mac_addr_entry_dic["port"] = tmp_array[-1]	
        		    mac_addr_entry_dic["mac"] = format_mac_addr(tmp_array[1]).upcase
        		    mac_addr_entry_dic["vlan"] = tmp_array[0]
                    mac_addr_list_array.push(mac_addr_entry_dic)
        		end
        	end
        	return mac_addr_list_array	
        end
        
        # port:describe:status:vlan:iftrunk
        def Fetch.get_cisco_port_status(recv_buffer)
        	int_status_list_array = []
            recv_buffer.each_line do |line|
        		if /^(Fa|Gi)/ !~ line
                    next
                end
                tmp_array = line.split
        		int_status_entry_dic  = {}
        		if /^Fa/ =~ tmp_array[0]
        		    port_name = tmp_array[0].sub(/Fa/, "FastEthernet")
                elsif /^Gi/ =~ tmp_array[0] 
        			port_name = tmp_array[0].sub(/Gi/, "GigabitEthernet")
        		end
                int_status_entry_dic["port"] = port_name 
                if /.*TX$/ =~ tmp_array[-1] #Type_string no blank 
                    int_status_entry_dic["describe"] = tmp_array[1...-5].join(" ")
        		    int_status_entry_dic["status"] = tmp_array[-5]	
        		    int_status_entry_dic["vlan"] = tmp_array[-4]
                else
        			int_status_entry_dic["describe"] = tmp_array[1...-6].join(" ")
        			int_status_entry_dic["status"] = tmp_array[-6]
        			int_status_entry_dic["vlan"] = tmp_array[-5]
        		end
        
        		if int_status_entry_dic["vlan"] == "trunk"
        			int_status_entry_dic["iftrunk"] = "1"	
        		else
        			int_status_entry_dic["iftrunk"] = "0"	
        		end
        		int_status_list_array.push(int_status_entry_dic)
        	end
        
        	return int_status_list_array
        end
        
        # port:describe:vlan:iftrunk
        def Fetch.get_cisco_current_config(recv_buffer)
        	current_config_tmp_array = []
        	current_config_tmp_array = recv_buffer.split(/!\n/)
        	current_int_status_list = {}
        	current_config_tmp_array.each do |each_item|
        		if /^interface (F|G)/ =~ each_item
        			current_int_status_dic = {}
        			port_name = /^interface .*\d$/.match(each_item)[0]
        			array_tmp = port_name.split
        			current_int_status_dic["port"] = array_tmp[1]	
        			current_int_status_dic["describe"] = ""	
        			current_int_status_dic["vlan"] = "1"	
        			current_int_status_dic["iftrunk"] = "0"
        		
        			access_vlan = /switchport access vlan \d*/.match(each_item)
        			if access_vlan != nil	
        				current_int_status_dic["vlan"] = /\d+/.match(access_vlan[0])[0]
                    end
        
        			if /switchport mode trunk/ =~ each_item
        				current_int_status_dic["iftrunk"] = "1"
        			end
        
        			trunk_vlan = /switchport trunk native vlan \d*/.match(each_item)
        			if trunk_vlan != nil
        				current_int_status_dic["vlan"] = /\d+/.match(trunk_vlan[0])[0]	
        			end
        
        			current_int_status_list[current_int_status_dic["port"]] = current_int_status_dic	
        		end
        	end
        	return current_int_status_list
        end
        
        def Fetch.get_cisco_vlan_id(recv_text)
        	ret_result = []
        	vlan_type_index = recv_text.index('VLAN Type')
            if vlan_type_index == nil
                vlan_type_index = 0
            end
        	result = recv_text[vlan_type_index..-1]
        	result.each_line do |line|
        		if /\A\d/ =~ line && /enet/i =~ line
        			tmp_array = line.split
        			ret_result.push(tmp_array[0])
        		end
        	end
        	return ret_result
        end

        def Fetch.get_cisco_show_vlan_id(recv_text)
        	vlan_port_array = []	
        	line_end_status = 0
        	line_text = ""
        	vlan_name_index = recv_text.index('VLAN Name')        	
            if vlan_name_index == nil
                vlan_name_index = 0
            end

            vlan_type_index = recv_text.index('VLAN Type')
            if vlan_type_index == nil
                vlan_type_index = 0
            end
        	result = recv_text[vlan_name_index..vlan_type_index-1]
        	
            result.each_line do |line|
        		line = line.chomp
        		if /\A\d/ =~ line && line_end_status == 0
        			if line_text.length > 0
        				vlan_port_array.push(line_text)
        				line_text = ""
        			end
        			line_text += line
        		elsif /\A\d/ =~ line && line_end_status == 1
        			line_text = line_text.gsub(", ", ",")
        			vlan_port_array.push(line_text)
        			line_text = ""
        			line_end_status = 0
        			line_text += line
        		elsif /\A\s+\w+/ =~ line
        			line_tmp   = ", %s" %line.lstrip.chomp
        			line_text += line_tmp
        			line_end_status = 1
        		else
        			if line_text.length > 0
                        vlan_port_array.push(line_text)
                    end
        			line_text = ""
        		end
        	end
        
        	vlan_dic = {}
        	vlan_array = []
        	vlan_port_array.each do |each_vlan|
        		tmp_array = each_vlan.split
        		vlan_dic["vlan"] = tmp_array[0]
        		vlan_dic["name"] = tmp_array[1]
        		vlan_dic["status"] = tmp_array[2]
        		if tmp_array.length > 3
        			vlan_dic["ports"] = tmp_array[3]
        		end
        	
        		vlan_array.push(vlan_dic)
        		vlan_dic = {}
        	end
        	
        	puts "*" * 60
        	return vlan_array	
        end

	end #end class Fetch
end #end module Switch
