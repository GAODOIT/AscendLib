#!/bin/bash
#bugs report to chenxiaokang
TMP_PATH="/tmp/switch"
rm -rf $TMP_PATH
mkdir -p $TMP_PATH/lib
mkdir -p $TMP_PATH/bin
cp  *.rb $TMP_PATH/lib
cp -r config $TMP_PATH/lib
cp -r test    $TMP_PATH/lib
cp main_switch.rb $TMP_PATH/bin/main_switch
cp run_ruby.sh $TMP_PATH/bin
cp switch.gemspec $TMP_PATH
chmod +x $TMP_PATH/bin -R
CURRENT_PATH=$PWD
cd nac_console
./build.sh
if [ $? != 0 ]; then
    echo "build nac console failed"
    exit -1
fi
cd $TMP_PATH
gem build switch.gemspec
mkdir -p switch
cp *.gem switch
cp -r $CURRENT_PATH/redis ./switch/
cp $CURRENT_PATH/run_ruby.sh switch
cp $CURRENT_PATH/nac_console/out/nac_console switch
cp -r $CURRENT_PATH/nac_console/mjson switch
cp $CURRENT_PATH/nac_console/install.sh ./
tar zcf switch.tar.gz switch
cat install.sh switch.tar.gz > switch.bin
chmod +x switch.bin
cp switch.bin $CURRENT_PATH
#cp *.gem $CURRENT_PATH
