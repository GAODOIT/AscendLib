#!/usr/bin/env ruby
#encoding: utf-8
########################################################################
##### Author: chenxiaokang                                           ###
##### Date: 2015.1.13                                                ###
##### Description: switch controll main function                     ### 
##### Modify reason:                                                 ###
##### Version: 1.0                                                   ###
##### bugs report to hp104@hupu.net                                  ###
########################################################################
path = File.absolute_path(__FILE__)
path = File.dirname(path)
path = File.split(path)[0]+ "/"
puts path
$LOAD_PATH.unshift(path)
require "switch"
require "test/switch_text"

# text = SwitchText.new("cisco_7609")
text = SwitchText.new("rj_2928")
#puts text.arp

# switch = ParseCisco.new
switch = ParseRuiJie.new
arp_arry = switch.get_arp(text.arp)
puts "arp_arry = #{arp_arry}"
puts "########################################################"
# mac_dic = switch.get_mac_7609(text.mac)
mac_dic = switch.get_mac(text.mac)
puts "mac_dic = #{mac_dic}"
puts "########################################################"
#puts "interface = #{text.interface}"
interface_dic = switch.get_interface(text.interface)
puts "interface_dic = #{interface_dic}"
puts "########################################################"
config_dic = switch.get_config(text.config)
puts "config_dic = #{config_dic}"


#text = {}
#text["arp"] = text.arp
#text["mac"] = text.mac
#text["interface"] = text.interface
#text["config"]    = text.config
#puts "result = #{text.result}"
switch_info = switch.get_info(text.result)
puts "########################################################"
puts "switch_info = #{switch_info}"
