path = File.absolute_path(__FILE__)
path = File.dirname(path)
path = File.split(path)[0]+ "/"
puts path
$LOAD_PATH.unshift(path)
require "switch"
head = "MessageMethod: HeartBeat\r\nMessageType: json\r\nDateTime: Tue, 07 Apr 2015 03.18.00 GMT\r\nControllerCode: 11111111\r\nAddress: 127.0.0.1\r\nMessageLength: 0\r\nMessageMethod: TestSwitch\r\nMessageType: json\r\nDateTime: Tue, 07 Apr 2015 03.18.00 GMT\r\nControllerCode: 11111111\r\nAddress: 127.0.0.1\r\nMessageLength: 142\r\n{\"ip\":\"10.10.2.250\",\"vendor\":\"H3C\",\"model\":\"3600\",\"type\":\"telnet\",\"params\":{\"loginparamtype\":\"0\",\"user\":\"\",\"password\":\"\",\"enablepassword\":\"\"}}\r\nMessageMethod: HeartBeat\r\nMessageType: json\r\nDateTime: Tue, 07 Apr 2015 03.18.00 GMT\r\nControllerCode: 11111111\r\nAddress: 127.0.0.1\r\nMessageLength: 0\r\nMessageMethod: AddSwitch\r\nMessageType: json\r\nDateTime: Tue, 07 Apr 2015 03.18.00 GMT\r\nControllerCode: 11111111\r\nAddress: 127.0.0.1\r\nMessageLength: 142\r\n{\"ip\":\"10.10.2.250\",\"vendor\":\"H3C\",\"model\":\"3600\",\"type\":\"telnet\",\"params\":{\"loginparamtype\":\"0\",\"user\":\"\",\"password\":\"\",\"enablepassword\":\"\"}}\r\n"
p head


msg_proc = ParseMsg.new 
msgs = msg_proc.parse(head)
msgs.each do |msg|
	Switch.log.info "rev msg:\n[\n#{msg}\n]"
end
