#encoding: utf-8
########################################################################
##### Author: chenxiaokang                                           ###
##### Date: 2015.3.25                                                ###
##### Description: switch parsing function                           ### 
##### Modify reason:                                                 ###
##### Version: 1.0                                                   ###
##### bugs report to hp104@hupu.net                                  ###
########################################################################
require "analysis"
module Switch
#	class ParseHuawei
#		def initialize
#			@option = {}
#			@option["mac_flag"] = "-"
#			content = {}
#			content["s_txt"] = "IP ADDRESS"
#			content["d_txt"] = "Total"
#			content["number"] = 2
#			@option["content"] = content
#			replace = {}
#			reg = {}
#			reg["GE"] = /GE/
#			txt={}
#			txt["GE"] = "GigabitEthernet"
#			replace["reg"] = reg
#			replace["txt"] = txt
#			@option["replace"] = replace
#			fetch = {}
#			fetch["start"] = "" 
#			fetch["first"] = ""
#			fetch["key"]
#			@option["fetch"] = fetch
#			config = {}
#			config["flag"] = "#\n"
#			config["regex"] = "interface GigabitEthernet"
#			@option["config"] = config
#			arp = {}
#			arp["mac"] = 1
#			arp["ip"] = 0
#			@option["arp"] = arp
#			##############################
#			@parse = Parsing.new
#		end
#		def get_info(text)
#			arp_txt = text["arp"]
#			config_txt = text["config"]
#			interface_txt = text["interface"]
#			mac_txt   = text["mac"]
#			cfg_dic = get_config(config_txt)
#			if_dic  = get_interface(interface_txt)
#			mac_dic = get_mac(mac_txt)
#			arp_list = get_arp(arp_txt)
#			#get interface status and port list
#			port_list = []
#			if_dic.each do |key, array_t|
#				if cfg_dic.has_key?(key)
#				cfg_dic[key]["status"] = array_t[1]
#				port_list << cfg_dic[key]
#				end
#			end
#			#get mac list
#			mac_list = []
#			mac_dic.each do |key, arr|
#				mac_tmp = {}
#				mac_tmp["port"] = arr[2]
#				mac_tmp["mac"]  = arr[0]
#				mac_tmp["vlan"] = cfg_dic[mac_tmp["port"]]["vlan"]
#				mac_list << mac_tmp
#			end
#			switch_info = {}
#			switch_info["arpList"] = arp_list
#			switch_info["macList"] = mac_list
#			switch_info["portList"] = port_list
#			return switch_info
#		end
#		def get_arp(text)
#			content = {}
#			content["s_txt"] = "IP ADDRESS"
#			content["d_txt"] = "Total"
#			content["number"] = 2
#			@option["content"] = content
#			####################################
#			replace = {}
#			reg = {}
#			reg["GE"] = /GE/
#			txt={}
#			txt["GE"] = "GigabitEthernet"
#			replace["reg"] = reg
#			replace["txt"] = txt
#			@option["replace"] = replace
#			####################################
#			fetch = {}
#			fetch["start"] = /\A\d/
#			#fetch["first"] = ""
#			fetch["key"] = 0
#			@option["fetch"] = fetch	
#			arp_array = @parse.parse_arp(@option, text)
#
#		end
#		def get_mac(text)
#			content = {}
#			content["s_txt"] = "MAC Address"
#			content["d_txt"] = "Total items displayed"
#			content["number"] = 2
#			@option["content"] = content
#			####################################
#			replace = {}
#			reg = {}
#			reg["GE"] = /GE/
#			txt={}
#			txt["GE"] = "GigabitEthernet"
#			replace["reg"] = reg
#			replace["txt"] = txt
#			@option["replace"] = replace
#			####################################
#			fetch = {}
#			fetch["start"] = /\A[0-9a-fA-F]{4}-[0-9a-fA-F]{4}/
#			#fetch["first"] = ""
#			fetch["key"] = 0
#			@option["fetch"] = fetch	
#			mac_dic = @parse.parse_mac(@option, text)
#		end
#		def get_interface(text)
#			content = {}
#			content["s_txt"] = "Interface                   PHY"
#			content["d_txt"] = ""
#			content["number"] = 1
#			@option["content"] = content
#			replace = {}
#			reg = {}
#			reg["cnt1"] = /up/
#			reg["cnt2"] = /down/
#			txt={}
#			txt["cnt1"] = "connected"
#			txt["cnt2"] = "notconnect"
#			replace["reg"] = reg
#			replace["txt"] = txt
#			@option["replace"] = replace
#			####################################
#			fetch = {}
#			fetch["start"] = /\AGigabitEthernet/
#			#fetch["first"] = ""
#			fetch["key"] = 0
#			@option["fetch"] = fetch	
#			interface_dic = @parse.parse_interface(@option, text)
#		end
#		def get_config(text)
#			config = {}
#			config["flag"] = "#\n"
#			config["regex"] = /interface GigabitEthernet\d\/\d\/\d/
#			@option["config"] = config
#			config_array = @parse.parse_config(@option, text)
#			config_dic =  {}
#			config_array.each do |item|
#				iface = item.split("\n")[0].split(" ", 2)[1]
#				config_dic[iface] = item.split("\n")
#			end
#			regx_vlan = /port default vlan \d+/
#			regx_trunk = /port link-type trunk/
#			regx_trunk_vlan = /port trunk pvid vlan \d+/
#			regx_access = /port link-type access/
#			regx_dsrp   = /description/
#			cfg_dic = {}
#			keyes = config_dic.keys
#			keyes.each do |key|
#				t_cfg = {}
#				t_cfg["port"] = key
#				t_cfg["describe"] = ""
#				t_cfg["status"] = "notconnect"
#				t_cfg["vlan"]   = "1"
#				t_cfg["iftrunk"] = "0"
#				config_dic[key].each do |item|
#					if regx_vlan =~ item
#						t_cfg["vlan"] = item.split(" ", 4)[3]
#					elsif regx_trunk =~ item
#						t_cfg["iftrunk"] = "1"
#					elsif regx_trunk_vlan =~ item
#						t_cfg["vlan"] = item.split(" ", 5)[4]
#					elsif regx_dsrp =~ item
#						t_cfg["describe"] = item.split(" ", 2)[1]
#					end
#					cfg_dic[key] = t_cfg
#				end
#			end
#			return cfg_dic
#		end
#	end
	class Parsing
        attr_accessor :regexp_mac, :regexp_ip, :regexp_iface
		def initialize(options = nil)
			@analyze = Analyze.new
			@regexp_mac = /[0-9a-fA-F]{2}-[0-9a-fA-F]{2}-[0-9a-fA-F]{2}-[0-9a-fA-F]{2}-[0-9a-fA-F]{2}-[0-9a-fA-F]{2}/
			@regexp_ip  = /[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/
			@regexp_iface = /Ethernet\d+\/\d+/
			@regexp_status = /connected|notconnect/
		end
		def init_option(option)
			mac_flag = option["mac_flag"] if option.has_key?("mac_flag")
			option.each do |key, args|
				option[key] = nil
			end
			option["mac_flag"] = mac_flag
			return option
		end
		def parse_arp(option, text)
			arp = option["arp"]
			arp["ip"]
			arp["mac"]
			content = @analyze.get_content(text, option["content"]) if option["content"]
			content = @analyze.replace(option["replace"], content) if option["replace"]
			content_dic = @analyze.string_table_fetch(content, option["fetch"]) if option["fetch"]
			return nil if !content_dic
			arp_array = []
			keys = content_dic.keys
			keys.each do |key|
				arp_dic = {}
				#content_dic[key][arp["mac"]] = @analyze.mac_format(option["mac_flag"], content_dic[key][arp["mac"]])
				arp_dic["mac"]= @analyze.mac_format(option["mac_flag"], content_dic[key][arp["mac"]])
				arp_dic["ip"] =  content_dic[key][arp["ip"]]
				if /\d+\.\d+\.\d+\.\d+/ =~ arp_dic["ip"] && /[0-9a-fA-F]{2}-[0-9a-fA-F]{2}-[0-9a-fA-F]{2}/ =~ arp_dic["mac"]
					arp_array << arp_dic
				end
			end
			return arp_array
		end
		def parse_mac(option, text)
			content = @analyze.get_content(text, option["content"]) if option["content"]
			content = @analyze.replace(option["replace"], content) if option["replace"]
			content_dic = @analyze.string_table_fetch(content, option["fetch"]) if option["fetch"]
			return nil if !content_dic
			f = option["mac_flag"]
			f = '\\' + f if f == "."
			keys = content_dic.keys
			keys.each do |key|
				content_dic[key].length.times do |i|
					if content_dic[key][i] =~ /\A[0-9a-fA-F]{4}#{f}[0-9a-fA-F]{4}#{f}[0-9a-fA-F]{4}|\A[0-9a-fA-F]{6}#{f}[0-9a-fA-F]{6}/
						content_dic[key][i] = @analyze.mac_format(option["mac_flag"], content_dic[key][i])
					end
				end
			end
			return content_dic
		end
		def parse_interface(option, text)
			analyze = Analyze.new
			content = @analyze.get_content(text, option["content"]) if option["content"]
			content = @analyze.replace(option["replace"], content)  if option["replace"]
			content_dic = @analyze.string_table_fetch(content, option["fetch"]) if option["fetch"]
		end
		def parse_config(option, text)
			#content = @analyze.get_content(text, option["content"]) if option.has_key?("content")
			#content = @analyze.replace(option["replace"], content) if option.has_key?("replace")
			#content_dic = @analyze.string_table_fetch(content, option["fetch"]) if option.has_key?("fetch")
			content = @analyze.get_config(text, option["config"])
		end
		def parse_vlan(option, text)
			content = @analyze.get_content(text, option["content"]) if option["content"]
			content = @analyze.replace(option["replace"], content) if option["replace"]
			content_dic = @analyze.string_table_fetch(content, option["fetch"]) if option["fetch"]
		end
		def parse_h3c_interface(option, text)
			inface_dic = @analyze.text_format(text, option["format"])
			return nil if !inface_dic
			if_dic = {}
			if inface_dic
				inface_dic.each do |key, txt|
					t_txt =  @analyze.replace(option["replace"], txt)
					if_dic[key.split[0]] = t_txt.split("\n")
				end
			end
			if_dic == {}? nil : if_dic
		end
		def parse_args(sw_text)
			sw_txt = {}
			sw_txt["method"] = sw_text["method"]
			sw_txt["ip"]     = sw_text["ip"]
			sw_txt["status"] = sw_text["status"]
			sw_txt["sw_type"] = sw_text["sw_type"]
			result = sw_text["result"]
			if result
				sw_txt["arp"] = result["show_arp"]
				sw_txt["arp_cmd"] = result["show_arp_command"]
				sw_txt["interface"] = result["show_interfaces_status"]
				sw_txt["interface_cmd"] = result["show_interfaces_status_command"]
				sw_txt["mac"] = result["show_mac_address_table"]
				sw_txt["mac_cmd"] = result["show_mac_address_table_command"]
				sw_txt["config"] = result["show_running_config"]
				sw_txt["config_cmd"] = result["show_running_config_command"]
				sw_txt["vlan"]       = result["show_vlan"]
			end
			return sw_txt
		end
		def verify_info(json_info, key)
			return false if json_info == nil
			info = JSON.parse(json_info)
			ret = true
			if key == "arpList"
				info_arry = info[key]
				info_check = lambda{|tmp| tmp["ip"] =~ @regexp_ip && tmp["mac"] =~ @regexp_mac}
				if info_arry.kind_of?(Array) && info_arry.size > 0
					info_arry.each do |info_dic|
						if !info_check.call(info_dic)
							ret = false
							break
						end
					end
				else
					ret = false
				end
			elsif key == "macList"
				info_arry = info[key]
				info_check = lambda{|tmp| tmp["vlan"] =~ /\d+/ && tmp["mac"] =~ @regexp_mac}
				if info_arry.kind_of?(Array) && info_arry.size > 0
					info_arry.each do |info_dic|
						if !info_check.call(info_dic)
							ret = false
							break
						end
					end
				else
					ret = false
				end
			elsif key == "portList"
				info_arry = info[key]
				info_check = lambda{|tmp| tmp["vlan"] =~ /\d+/ && tmp["port"] =~ /Ethernet\d+\/\d+|\A\d+|\APort-channel\d+/ && tmp["status"] =~ @regexp_status}
				if info_arry.kind_of?(Array) && info_arry.size > 0
					info_arry.each do |info_dic|
						if !info_check.call(info_dic)
							ret = false
							break
						end
					end
				else
					ret = false
				end
			end
			return ret
		end
		def parse_test_switch(sw_text)
						ret = {}
            ret["link"] = "连接交换机[#{sw_text["ip"]}]成功"
            if sw_text["status"] == 201
                ret["link"] = "登陆交换机[#{sw_text["ip"]}]失败"
						end
            if sw_text["status"] == 203
                ret["link"] = "连接交换机[#{sw_text["ip"]}]失败"
            else
                ret["login"] = "交换机身份验证[%s]成功" % "#{sw_text["ip"]}"
                if sw_text["status"] == 205 || sw_text["status"] == 206
                    ret["login"] = "交换机身份验证[%s]失败" % "#{sw_text["ip"]}"    
                else
                    ret["super"] = "进入交换机[%s]enable/super模式成功" % sw_text["ip"]
                    if sw_text["status"] == 208
                        ret["super"] = "进入交换机[%s]enable/super模式失败" % sw_text["ip"]
                    end
                end
            end
			if sw_text["status"] == 210
				ret["type"] = "交换机#{sw_text["ip"]}暂时不支持"
			elsif sw_text["status"] == 211
				ret["type"] = "交换机#{sw_text["ip"]}型号不匹配"
			end
			if sw_text["status"] == 200
				ret["result"] = "测试交换机[%s]成功" % sw_text["ip"]
			else
				ret["result"] = "测试交换机[%s]失败" % sw_text["ip"]
			end
			ret
		end
	end
end
