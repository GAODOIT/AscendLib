#######################################################################
#### Author: rubyer                                                 ###
#### Date: 2015.1.28												###
#### Description: parse huawei_switch methods function				###	
#### Modify reason:													###
#### Version: 1.0													###
#### Support switch list:                                           ###   
#### Huawei: S5700                                                  ###
#### bugs report to hp104@hupu.net									###
#######################################################################
require "analysis"
module Switch
	class Fetch
        def Fetch.get_huawei_arp(recv_text)
            arp_list_array = []
            recv_text.each_line do |line|
                if /([0-9]{1,3}[.]){3}[0-9]{1,3}/ =~ line
                    arp_entry_dic = {}
                    tmp_array = line.chomp.split
        		    arp_entry_dic["ip"]	= tmp_array[0]
        		    arp_entry_dic["mac"]= format_mac_addr(tmp_array[1], "-").upcase
                    arp_list_array.push(arp_entry_dic)
        		end
        	end
        	return arp_list_array
        end

        #Eth1/0/8 == Ethernet1/0/24
        #GE1/1/3  == GigabitEthernet1/1/3
        def Fetch.get_huawei_mac_addr(recv_text)
            mac_addr_array = []
        	recv_text.each_line do |line| 
        		if /dynamic/i =~ line
        			line = line.chomp
                    mac_addr_item_dic = {}
        			tmp_array = line.split
                    if /^Eth/ =~ tmp_array[2]
        		        port_name = tmp_array[2].sub(/Eth/, "Ethernet")
                    elsif /^GE/ =~ tmp_array[2] 
        			    port_name = tmp_array[2].sub(/GE/, "GigabitEthernet")
        		    end
        			mac_addr_item_dic["port"] = port_name
        			mac_addr_item_dic["mac"]  = format_mac_addr(tmp_array[0], "-").upcase
                    /(\d+)\/-$/ =~ tmp_array[1]
        			mac_addr_item_dic["vlan"] = $1
        			mac_addr_array.push(mac_addr_item_dic)	
        		end
        	end
        	return mac_addr_array
        end
        
        #Ethernet1/0/1
        #GigabitEthernet0/0/1
        #port:describe:status:vlan:iftrunk
        def Fetch.get_huawei_port_status(recv_text)
            port_status_array = []
			text = recv_text
			text = recv_text.gsub(/up/, "connected") if text != nil
			text = text.gsub(/down/, "notconnect") if text != nil
        	text.each_line do |line|
        		if /Ethernet/ =~ line
        			line = line.chomp	
        			port_status_item_dic = {}
        			tmp_array = line.split
        			port_status_item_dic["port"] = tmp_array[0]
        			port_status_item_dic["describe"] = ""
        			port_status_item_dic["status"] = tmp_array[1]
        			port_status_item_dic["vlan"] = ""
        			port_status_item_dic["iftrunk"] = ""
        			port_status_array.push(port_status_item_dic)
        		end	
        	end
        	return port_status_array
        end
        
        # port:describe:vlan:iftrunk
        def Fetch.get_huawei_current_config(recv_text)
            config_port_status_list = {}
        	config_tmp_array = []
        	config_tmp_array = recv_text.split(/#\n/)
        	config_tmp_array.each do |each_item|
        		if /^interface E/ =~ each_item || /^interface G/ =~ each_item
        			config_port_status_dic = {}
                    each_item = each_item.chomp.lstrip.rstrip
        			port_name = /^interface .*\d$/.match(each_item)[0]
        			array_tmp = port_name.split
        			config_port_status_dic["port"] = array_tmp[1]

                    describe_filed = /description.*$/.match(each_item)
                    if describe_filed != nil
                        tmp_array = describe_filed[0].split(" ", 2)
                        config_port_status_dic["describe"] = tmp_array[-1]
                    end

                    config_port_status_dic["vlan"] = "1"	
        			config_port_status_dic["iftrunk"] = "0"
                    if /port link-type access/ =~ each_item
        				config_port_status_dic["iftrunk"] = "0"
        			end

        			access_vlan = /port default vlan \d*/.match(each_item)
        			if access_vlan != nil
        				config_port_status_dic["vlan"] = /\d+/.match(access_vlan[0])[0]
        			end

        			if /port link-type trunk/ =~ each_item
        				config_port_status_dic["iftrunk"] = "1"
        			end

        			trunk_vlan = /port trunk pvid vlan \d*/.match(each_item)
        			if trunk_vlan != nil
        				config_port_status_dic["vlan"] = /\d+/.match(trunk_vlan[0])[0]
        			end
        
        			config_port_status_list[config_port_status_dic["port"]] = config_port_status_dic		
        		end
        	end
			#Switch.log.debug "config_port_status_list = #{config_port_status_list}"
        	return config_port_status_list
        end
        
        def Fetch.get_huawei_vlan_id(recv_text)
			huawei = Analyze.new
			args = {}
			args["s_txt"] = "VID  Type    Ports"
			args["VID  Status"] = "VID  Status"
			args["number"] = 2
			msg_string = huawei.get_content(recv_text, args)
			condition = {}
			condition["start"] = /\A\d/
			condition["first"] = /\A\s/
			condition["key"]   = 0
			result =huawei.string_table_fetch(msg_string, condition)

            #ret_result = []
        	#vid_index = recv_text.index('VID  Status')
            #if vid_index == nil
            #    vid_index = 0
            #end
        	#result = recv_text[vid_index..-1]
        	#result.each_line do |line|
        	#	if /\A\d/ =~ line && /default/i =~ line
        	#		tmp_array = line.split
        	#		ret_result.push(tmp_array[0])
        	#	end
        	#end
        	return result.keys
        end


    end #end class Fetch

end #end module Switch
