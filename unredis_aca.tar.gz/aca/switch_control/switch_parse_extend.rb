########################################################################
##### Author: chenxiaokang                                           ###
##### Date: 2015.3.25                                                ###
##### Description: switch parsing function                           ###
##### Modify reason:                                                 ###
##### Version: 1.0                                                   ###
##### bugs report to hp104@hupu.net                                  ###
########################################################################
#encoding: UTF-8
require "parsing"
require "json"
module Switch
    class ParseRuiJie
        def initialize
            @option = {}
            @option["mac_flag"] = "."
            content = {}
            content["s_txt"] = "IP ADDRESS"
            content["d_txt"] = "Total"
            content["number"] = 2
            @option["content"] = content
            replace = {}
            reg = {}
            reg["GE"] = /GE/
            txt={}
            txt["GE"] = "GigabitEthernet"
            replace["reg"] = reg
            replace["txt"] = txt
            @option["replace"] = replace
            fetch = {}
            fetch["start"] = ""
            fetch["first"] = ""
            fetch["key"]
            @option["fetch"] = fetch
            config = {}
            config["flag"] = "#\n"
            config["regex"] = "interface GigabitEthernet"
            @option["config"] = config
            arp = {}
            arp["mac"] = 1
            arp["ip"] = 0
            @option["arp"] = arp
            ##############################
            @parse = Parsing.new
        end

        def get_arp(text)
            @option = @parse.init_option(@option)
            content = {}
            content["s_txt"] = "Protocol  Address"
            #content["d_txt"] = "entries found"
            content["d_txt"] = ""
            content["number"] = 1
            @option["content"] = content
            ####################################
            arp = {}
            arp["mac"] = 3
            arp["ip"] = 1
            @option["arp"] = arp
            ###################################
            fetch = {}
            fetch["start"] = /\AInternet/
            #fetch["first"] = ""
            fetch["key"] = 1
            @option["fetch"] = fetch
            ###################################
            arp_array = @parse.parse_arp(@option, text)

        end

        def get_mac(text)
            @option = @parse.init_option(@option)
            content = {}
            content["s_txt"] = "Vlan        MAC Address"
            #content["d_txt"] = "mac address(es)"
            content["d_txt"] = ""
            content["number"] = 2
            @option["content"] = content
            ####################################
            replace = {}
            reg = {}
            reg["cnt1"] = /Ethernet\s/
            # reg["cnt2"] = /Gi/
            txt={}
            txt["cnt1"] = "Ethernet"
            # txt["cnt2"] = "GigabitEthernet"
            replace["reg"] = reg
            replace["txt"] = txt
            @option["replace"] = replace
            ####################################
            fetch = {}
            fetch["start"] = /[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}/
            #fetch["first"] = ""
            fetch["key"] = 1
            @option["fetch"] = fetch
            mac_dic = @parse.parse_mac(@option, text)
        end

        def get_interface(text)
            content = {}
            content["s_txt"] = "Vlan  Duplex"
            content["d_txt"] = ""
            content["number"] = 1
            @option["content"] = content
            replace = {}
            reg = {}
            # reg["cnt1"] = /Fa/
            # reg["cnt2"] = /Gi/
            reg["cnt3"] = /down/
            reg["cnt4"] = /Ethernet\s/
            reg["cnt5"] = /Po/
            reg["cnt6"] = /up/
            txt={}
            # txt["cnt1"] = "FastEthernet"
            # txt["cnt2"] = "GigabitEthernet"
            txt["cnt3"] = "notconnect"
            txt["cnt4"] = "Ethernet"
            txt["cnt5"] = "Port-channel"
            txt["cnt6"] = "connected"
            replace["reg"] = reg
            replace["txt"] = txt
            @option["replace"] = replace
            ####################################
            fetch = {}
            fetch["start"] = /Ethernet\d\/\d/
            #fetch["first"] = ""
            fetch["key"] = 0
            @option["fetch"] = fetch
            interface_dic = @parse.parse_interface(@option, text)
        end

        def get_config(text)
            config = {}
            config["flag"] = "!\n"
            config["regex"] = /Ethernet\s\d\/\d/
            @option["config"] = config
            config_array = @parse.parse_config(@option, text)
            return nil if !config_array
            config_dic =  {}
            config_array.each do |item|
                iface = item.split("\n")[0].split(" ", 2)[1]
                iface = iface.gsub(/Ethernet\s/, "Ethernet")
                config_dic[iface] = item.split("\n")
            end
            regx_vlan = /switchport access vlan \d+/
            regx_trunk = /switchport mode trunk/
            regx_trunk_vlan = /switchport trunk native vlan \d+/
            regx_access = /switchport mode access/
            regx_dsrp   = /description/
            cfg_dic = {}
            if config_dic
                keyes = config_dic.keys
                keyes.each do |key|
                    t_cfg = {}
                    t_cfg["port"] = key
                    t_cfg["describe"] = ""
                    t_cfg["status"] = "notconnect"
                    t_cfg["vlan"]   = "1"
                    t_cfg["iftrunk"] = "0"
                    config_dic[key].each do |item|
                        if regx_vlan =~ item
                            t_cfg["vlan"] = item.split[-1]
                        elsif regx_trunk =~ item
                            t_cfg["iftrunk"] = "1"
                        elsif regx_trunk_vlan =~ item
                            t_cfg["vlan"] = item.split[-1]
                        elsif regx_dsrp =~ item
                            t_cfg["describe"] = item.split(" ", 2)[1]
                        end
                        cfg_dic[key] = t_cfg
                    end
                end
            end
            cfg_dic == {} ? nil : cfg_dic
        end

        def get_vlan(sw_text)
            text = @parse.parse_args(sw_text)
            vlans = []
            if text
                config_s = text["config"]
                config_list = get_config(config_s)
                if config_list
                    config_list.each do |key, info|
                        vlans << info["vlan"]
                    end
                end
            end
            Switch.log.debug "get_vlan text  = #{text}"
            Switch.log.debug "get_vlan vlan list = #{vlans}"
            vlan_obj = {}
            vlan_obj["vlanList"] = vlans unless vlans == []
            vlan_obj["ip"] = text["ip"] unless vlans == []
            vlan_obj["method"] = text["method"] unless vlans == []
            vlan_obj == {} ? nil : JSON.generate(vlan_obj)
        end

        def get_info(sw_text)
            text = @parse.parse_args(sw_text)
            if text
                arp_txt = text["arp"]
                config_txt = text["config"]
                interface_txt = text["interface"]
                mac_txt   = text["mac"]
                cfg_dic = get_config(config_txt)
                if_dic  = get_interface(interface_txt)
                mac_dic = nil
                mac_dic = get_mac(mac_txt)
                arp_list = get_arp(arp_txt)
                return nil if !(if_dic && mac_dic && arp_list && config_txt)
                #get interface status and port list
                port_list = []
                if_dic.each do |key, array_t|
                    iface = array_t[0]
                    if array_t.size < 6
                        iface_status = "connected"
                    else
                        iface_status = array_t[1]
                    end
                    if cfg_dic.has_key?(iface)
                        cfg_dic[iface]["status"] = iface_status
                        port_list << cfg_dic[iface]
                    end

                end
                #get mac list
                mac_list = []
                mac_dic.each do |key, arr|
                    if cfg_dic.has_key?(arr[-1])
                        mac_tmp = {}
                        mac_tmp["port"] = arr[3]
                        mac_tmp["mac"]  = arr[1]
                        mac_tmp["vlan"] = cfg_dic[mac_tmp["port"]]["vlan"]
                        mac_list << mac_tmp
                    end
                end
                switch_info = {}
                switch_info["arpList"] = arp_list if arp_list
                switch_info["macList"] = mac_list if mac_list
                switch_info["portList"] = port_list if port_list
                if !(switch_info == {})
                    switch_info["ip"] = text["ip"]
                    switch_info["linkStatus"] = text["status"]
                end
            end
            switch_info == {} ? nil : JSON.generate(switch_info)
        end

        def test_switch(sw_text)
            text = @parse.parse_args(sw_text)
            result = @parse.parse_test_switch(text)
            #Switch.log.debug "test_switch text = #{text}"
            if text && text["status"] == 200
                arp_txt = text["arp"]
                config_txt = text["config"]
                interface_txt = text["interface"]
                mac_txt   = text["mac"]
                if_dic  = get_interface(interface_txt)
                mac_dic = get_mac(mac_txt)
                arp_list = get_arp(arp_txt)
                cfg_dic  = get_config(config_txt)
                info = get_info(sw_text)
                if arp_list && @parse.verify_info(info, "arpList")
                    result["parseArp"] = "解析ARP信息成功"
                    result["arpCmd"]   = text["arp_cmd"]
                else
                    result["parseArp"] = "解析ARP信息失败"
                    result["arpCmd"]   = text["arp_cmd"]
                    result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
                end
                if mac_dic && @parse.verify_info(info, "macList")
                    result["parseMac"] = "解析MAC信息成功"
                    result["macCmd"]   = text["mac_cmd"]
                else
                    result["parseMac"] = "解析MAC信息失败"
                    result["macCmd"]   = text["mac_cmd"]
                    result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
                end
                if if_dic && @parse.verify_info(info, "portList")
                    result["parsePort"] = "解析PORT信息成功"
                    result["portCmd"]   = text["interface_cmd"]
                else
                    result["parsePort"] = "解析PORT信息失败"
                    result["portCmd"]   = text["interface_cmd"]
                    result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
                end
                if cfg_dic && @parse.verify_info(info, "portList")
                    result["parseConfig"] = "解析CONFIG信息成功"
                    result["configCmd"]   = text["config_cmd"]
                else
                    result["parseConfig"] = "解析CONFIG信息失败"
                    result["configCmd"]   = text["config_cmd"]
                    result["result"] = "测试交换机[%s]失败" % sw_text["ip"]
                end
                result["result"] = "测试交换机[%s]失败" % sw_text["ip"] unless arp_list && mac_dic && if_dic && cfg_dic
            end
            result == nil ? nil : JSON.generate(result)
        end

    end
end