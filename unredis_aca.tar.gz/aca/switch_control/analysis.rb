#encoding: utf-8
########################################################################
##### Author: chenxiaokang                                           ###
##### Date: 2015.3.25                                                ###
##### Description: switch  analyze function                          ### 
##### Modify reason:                                                 ###
##### Version: 1.0                                                   ###
##### bugs report to hp104@hupu.net                                  ###
########################################################################
module Switch
	class Analyze
		def get_content(text ,option = {})
			if !text
				return nil
			end
			s_txt = option["s_txt"]
			d_txt  = option["d_txt"]
			number = option["number"]
			index1 = -1
			index2 = (text.size - 1)
			index1 = text.index(s_txt)
			if d_txt != ""
				index2 = text.index(d_txt)
			end
			txt = nil
			ret = ""
			#Log.debug "index1 = #{index1}, index2 = #{index2}"
			if (index1 && index2)&&(index1 >= 0 && index2 >=0)
				txt = text[index1..index2]
				txt = txt.split("\n")
				txt = txt[number..-1]
				txt.each{|line| ret +="#{line}\n"}
			end
			#Log.debug "get_content ret = #{ret}"
			return ret == ""?nil:ret
		end
		def get_config(text, option)
			if !text
				return nil
			end
			flag = option["flag"]
			regex_s = option["regex"]
			txt = text.split(flag)
			array_t = []
			txt.each do |item|
				if regex_s =~ item
					array_t << item
				end
			end
			#array_t.each do |item|
			#	ret += "#{item}#{flag}"
			#end
		    array_t == [] ? nil : array_t
		end
		def replace(regxs={}, text="")
			if !text
				return nil
			end
			ret = text
			begin
				regxs_dic  = regxs["reg"]
				string_dic = regxs["txt"] 
				keys = regxs_dic.keys
				keys.each do |key|
					result = ret.gsub(regxs_dic[key], string_dic[key])
					if result != nil
						ret = result
					end
				end
			rescue => error_msg
				Log.error error_msg
				ret = text
			end
			return ret
		end
		def string_table_fetch(text, condition={})
			#condition["start"] = /\A\d/
			#condition["first"] = /\A\s/
			#condition["key"]   = 0 
			if !text
				return nil
			end
			mark1 = 0 
			key = nil 
			result = {}
			i = 0
			text.each_line do |line|
				if condition["start"] =~ line
					array_i = line.chomp.split(" ") 
					key = "#{i}_#{array_i[condition["key"]]}"
					result[key] = array_i
				elsif condition.has_key?("first") && condition["first"] =~ line
					result[key].concat(line.split(" "))
				end
				i += 1
			end 
			result == {} ? nil : result
		end
		def text_format(text, option={})
			if !text
				return nil
			end
			regx_key =  option["k_regx"]
			regx_split = option["s_regx"]
			#p "##############text = #{text}"
			txt = text.gsub(regx_split, "||||")
			txt_arry = txt ? txt.split("||||") : nil
			txt_dic = {}
			if txt_arry
				txt_arry.each do |txt_t|
					t_arry = txt_t.split("\n")
					t_arry.each do |line|
						if regx_key =~ line
							txt_dic[line] = txt_t
							break
						end
					end
				end
			end
			txt_dic == {}?nil:txt_dic
		end
		def mac_format(flag, mac)
			array_s = mac.chomp.split(flag)
			txt = ""
			array_s.each{|ss| txt += ss}
			mac = ""
			if txt.length == 12
			   mac = "#{txt[0..1]}-#{txt[2..3]}-#{txt[4..5]}-#{txt[6..7]}-#{txt[8..9]}-#{txt[10..11]}"
			end
			mac == "" ? nil : mac
		end

	end
end
