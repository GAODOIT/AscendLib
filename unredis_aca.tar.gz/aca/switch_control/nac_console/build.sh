#!/bin/bash
#bugs report to kang
CLI_OBJS=`find -name "*.c" | cut -d '/' -f 3 | awk -F '.' '{print $1".o"}'|xargs`
export CLI_OBJS=$CLI_OBJS
export BUILD_DIR=$PWD
echo $BUILD_DIR
help()
{
	case arg in
		nac_cli|clean)
			;;
		*)
			echo ""
			echo "###############please input args  nac_cli or clean###############"
			echo ""
			exit -1
			;;
	esac
}
#if [ $# -ne 1 ]; then
#	help;
#fi
HOST_TYPE=`uname -a | grep "x86_64"`
if [ -z $"HOST_TYPE" ]; then
    export SYS_FLAG=" "
else
    export SYS_FLAG=" -m32 "
fi

mkdir -p out
cd out
make -f  ../make_console clean
make -f  ../make_console console
