#######################################################################
#### Author: chenxiaokang                                           ###
#### Date: 2015.1.13												###
#### Description: message fetch function							###	
#### Modify reason:													###
#### Version: 1.0													###
#### bugs report to hp104@hupu.net									###
#######################################################################
require "ipaddr"
require "util"
require "switch_parse"
require "base64"
module Switch
	class Fetch
	end
	class Code
		def Code.load_code(name, ip, code)
			method = Code.generate_name(name, ip)	
			s_code = "def Fetch.#{method}(sw_text = {})\n#{code}\nend\n"
			if Fetch.respond_to?(method)
				Log.info "method #{method} have been defined will redefine it"
			end
			eval s_code
		end
		def Code.generate_name(name, ip)
			ip = IPAddr.new ip
			"#{name}_#{ip.to_i}"
		end
		def Code.config_load(config = {}, json_msg = {})
			fetchs = config["fetch"]
			methods = SwitchModel.get_methods
			methods.each do |method|
				Log.debug "config_load method = #{method}"
				if fetchs.has_key?(method)
					fetch = fetchs[method]
					if config.has_key?(fetch)
						code = config[fetch]
						Code.load_code(fetch, json_msg["ip"], code)
						#Log.debug "config_load code = #{code}"
						Log.debug "config_load json_msg[\"ip\"] = #{json_msg["ip"]}"
						Log.debug "config_load fetchs[\"#{method}\"] = #{fetch}"
					end
				end
			end
		end
		def Code.get_methods
			Fetch.methods
		end
	end
	class Msg
		@@fetch_method = {"TestSwitch" => nil, "UploadSwitchInfo" => nil, "GetVlan" => nil, "GetSwitchInfo" => nil, "BackupSwitchConfig" => nil}
		#@@fetch_method = {"TestSwitch" => nil, "UploadSwitchInfo" => nil, "GetSwitchInfo" => nil}
		@@multi_fetch = {"ChangePortVlan" => nil, "SetPortTrunk"=>nil, "DelPortTrunk" => nil}
		@@repeat_fetch = {"GetVlan"=>nil, "BackupSwitchConfig" => nil, "RestoreSwitchConfig" => nil, \
		 "GetVlanInside" => nil, "SetVlanTrunkInside" => nil}
		def Msg.fetch(result = {},sw_model = nil)
			#methods = SwitchModel.get_methods
			flag = -1
			result_ret = nil
			if result.kind_of?(Hash) && result.has_key?("ip")
				method = result["method"]
				ip = result["ip"]
				if sw_model != nil && @@fetch_method.has_key?(method)
					Log.debug "Msg fetching method = #{method}"
					fetchs = sw_model.fetch
					method_name = Code.generate_name(fetchs[method], ip)
					if Fetch.respond_to?(method_name)
						begin
							time_start = Time.now
							result_ret = Fetch.send(method_name, result)
							Log.debug "@@@@@@@@@@@@@@@@@@@@@@@@@@parse the switch spend #{Time.now - time_start} second"
							flag = 0 if result_ret
							Log.debug result_ret
						rescue => error_msg
							Log.error error_msg
							flag = -1
						end
					end
				end
				if @@multi_fetch.has_key?(method)
					result_ret = {}
					res_arry = []
					result_ret["ip"] = ip
					Log.debug "multi_fetch = #{result}"
					if result["status"] == 200
						result["result"].each do |res_dic|
							obj_dic = {}
							obj_dic["interface"] = res_dic["target"]
							obj_dic["status"]    = res_dic["status"]
							res_arry << obj_dic
						end
						result_ret["list"] = res_arry
						result_ret = JSON.generate(result_ret)
						flag = 1
					end
				end
			end
			return flag, result_ret
		end
		def Msg.fetch_again(result_msg, model = nil)
			if @@repeat_fetch.has_key?(result_msg["method"])
				ret_msg = []
				msg = result_msg["result"]
				Log.debug "fetch_again result_msg = #{result_msg}"
				if result_msg["method"] == "GetVlan"
					msg.each do |result|
						if result
							obj_msg = JSON.parse(result)
							ret_msg.concat(obj_msg["vlanList"])
						end
					end
					msg_dic = {}
					msg_dic["vlan"] = ret_msg.uniq
					return JSON.generate(msg_dic)
				elsif result_msg["method"] == "BackupSwitchConfig"
					Log.debug "fetch again BackupSwitchConfig"
					msg.each do |result|
						Log.debug "Msg.fetch_again result= #{result}"
						obj_msg = {}
						obj_msg["ip"] = result["ip"]
						obj_msg["status"] = result["status"]
						obj_msg["name"] = "#{result["result"]["tftp_enter_arg"]}"
						if File.exist?("/data/tftproot/#{result["result"]["tftp_enter_arg"]}")
							obj_msg["config"] = Base64.encode64(File.read("/data/tftproot/#{result["result"]["tftp_enter_arg"]}"))
						end
						ret_msg << obj_msg
					end
					msg_dic = {}
					msg_dic["list"] = ret_msg
					return JSON.generate(msg_dic)
				elsif result_msg["method"] == "RestoreSwitchConfig"
					msg.each do |result|
						Log.debug "Msg.fetch_again result= #{result}"
						obj_msg = {}
						obj_msg["ip"] = result["ip"]
						obj_msg["status"] = result["status"]
						ret_msg << obj_msg
					end
					msg_dic = {}
					msg_dic["list"] = ret_msg
					return JSON.generate(msg_dic)
				elsif result_msg["method"] == "GetVlanInside"
					pasing = Parsing.new
					options = {}
					content = {}
					content["s_txt"] = "VLAN ID Name"
					#content["d_txt"] = "mac address(es)"
					content["d_txt"] = ""
					content["number"] = 2
					options["content"] = content
					fetch = {}
					fetch["start"] = /\A\s+\d+/
					#fetch["first"] = ""
					fetch["key"] = 0
					options["fetch"] = fetch
					vlan_t = pasing.parse_vlan(options, msg["show_vlan"])
					p vlan_t
					vlans = []
					vlan_t.each do |key, valn_arry|
						vlans << valn_arry[0]
					end
					vlans
				end
			end
		end
	end
end
