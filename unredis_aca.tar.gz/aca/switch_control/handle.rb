#######################################################################
#### Author: chenxiaokang                                           ###
#### Date: 2015.1.13												###
#### Description: handle method  function							###	
#### Modify reason:													###
#### Version: 1.0													###
#### bugs report to hp104@hupu.net									###
#######################################################################
require 'control_switch'
require 'fetch'
require 'redis'
module Switch
	$nac_status = true
	$ascId = ""
	class Handle
		attr_accessor :switch_queue
		attr_accessor :switch_list, :report_timer
		attr_accessor :result_queue
		attr_accessor :connect, :heart_flag
		def initialize
			@thread_mark = 0
			@switch_list = {}
			self.switch_queue = {}
			self.result_queue = []
			@mutex_switch = Mutex.new 
			@mutex_result = Mutex.new
			@mutex_switch_list = Mutex.new
			@mutex_multi_result = Mutex.new
			@th_list = []
			@th_dic =  {}
			@ret_packet = Message.new
			@heart_packet = Message.new
			@heart_flag = -1000
			@report_timer = {}
			@multi_result  = {}
            if $env_type == 1
                @redis_ip = "10.10.3.223"
                @redis_port = 6999
            else
                @redis_ip = "127.0.0.1"
                @redis_port = 6999
            end
			begin
			$cache = Redis.new(host: @redis_ip, port: @redis_port, db: 6)
			rescue => error_msg
				Log.error "create redis instance error #{error_msg}"
			end

		end
		def handle_AddSwitch(json_msg, head_msg)
			cmd_result = {}
			status = login_test(json_msg, head_msg)
			load_cfg = update_info(json_msg)
			if status == 0 || status < 0
				cmd_result["ip"]   = json_msg["ip"]
				cmd_result["method"] = head_msg["MessageMethod"]
				cmd_result["result"] = nil
				cmd_result["flag"]  = -1
				if status == 0 && 0 == load_cfg
					cmd_result["status"] = 200
					#report to server switch scan info
					head = {}
					head["MessageMethod"] = "UploadSwitchInfo"
					insert_switch_queue(json_msg["ip"], head)
					update_cache_switch_list json_msg["ip"]
				elsif status == -203 && 0 == update_info(json_msg, status.abs)
					cmd_result["status"] = 212
					#update_cache_switch_list json_msg["ip"]
				elsif status < 0 && load_cfg == 0
					cmd_result["status"] = status.abs
				elsif load_cfg == -1
					cmd_result["status"] = 210
				else
					cmd_result["status"] = 201
				end
			else
				cmd_result["status"] = status.abs
			end
			set_result_queue cmd_result
		end
		def handle_TestSwitch(json_msg, head_msg)
			status0 = update_info(json_msg, -2)
			if status0 == 0
					insert_switch_queue(json_msg["ip"], head_msg)
			else
					cmd_result = {}
					cmd_result["ip"]   = json_msg["ip"]
					cmd_result["method"] = head_msg["MessageMethod"]
					cmd_result["status"] = 210
					cmd_result["flag"]   = -1
					cmd_result["result"] = nil
					set_result_queue cmd_result
			end
=begin
			status1 = login_test(json_msg, head_msg)
			if status1 == 0 && status0 == 0
				insert_switch_queue(json_msg["ip"], head_msg)
			elsif status0 != 0 ||  status1 != 0
				cmd_result = {}
				cmd_result["ip"]   = json_msg["ip"]
				cmd_result["method"] = head_msg["MessageMethod"]
				cmd_result["result"] = nil
				if status0 != 0
					cmd_result["status"] = 210
				elsif status1 != 0
					cmd_result["status"] = status1.abs
				end

				set_result_queue cmd_result
			end
=end
		end
		def handle_ModifySwitch(json_msg, head_msg)
			cmd_result = {}
			cmd_result["ip"]   = json_msg["ip"]
			cmd_result["status"] = 200
			cmd_result["method"] = head_msg["MessageMethod"]
			cmd_result["result"] = nil
			cmd_result["flag"]   = -1
			status = login_test(json_msg, head_msg)
            load_cfg_status = update_info(json_msg)
			if status == 0 || status < 0
				if status == 0 && 0 == load_cfg_status
					cmd_result["status"] = 200
					update_cache_switch_list json_msg["ip"]
				elsif status == -203 && 0 == update_info(json_msg, status.abs)
					cmd_result["status"] = 212
					#update_cache_switch_list json_msg["ip"]
					#cmd_result["status"] = 200
                elsif load_cfg_status < 0
                    cmd_result["status"] = 210
				else
					cmd_result["status"] = status.abs
				end

			end
			set_result_queue cmd_result
		end
		def handle_DeleteSwitch(json_msg, head_msg)
			cmd_result = {}
			cmd_result["ip"]   = json_msg["ip"]
			cmd_result["status"] = 200
			cmd_result["method"] = head_msg["MessageMethod"]
			cmd_result["type"]   = 2
			cmd_result["result"] = nil
			cmd_result["flag"] =  0
			result = nil
			if json_msg.has_key?("list")
				result = json_msg["list"]
				cmd_result["result"] = result
			end
			set_result_queue cmd_result
		end
		def handle_GetSwitchStatus(json_msg, head_msg)
			cmd_result = {}
			cmd_result["status"] = 200
			if @switch_list.has_key?(json_msg["ip"])
				args_msg = {}
				args_msg["params"]    = @switch_list[json_msg["ip"]]
				args_msg["vendor"]    = @switch_list[json_msg["ip"]]["vendor"]
				args_msg["model"]     = @switch_list[json_msg["ip"]]["type"]
				args_msg["ip"]     	  = json_msg["ip"]

				status = login_test(args_msg, head_msg)
				if status != 0
					cmd_result["status"] = status.abs
				end
			else
				cmd_result["status"] = 202
			end
			cmd_result["ip"]   = json_msg["ip"]
			cmd_result["method"] = head_msg["MessageMethod"]
			cmd_result["result"] = nil
			set_result_queue cmd_result

		end
		def handle_ChangePortVlan(json_msg, head_msg)
			cmd_args = do_get_args(json_msg, head_msg)
			#Log.debug "handle_ChangePortVlan method args = #{cmd_args}"
			args = cmd_args
			insert_switch_queue(json_msg["ip"], head_msg, args)
		end
		def handle_UploadSwitchInfo(json_msg, head_msg)
			insert_switch_queue(json_msg["ip"], head_msg)
		end
		def handle_GetSwitchInfo(json_msg, head_msg)
			insert_switch_queue(json_msg["ip"], head_msg)
		end
		def handle_SetPortTrunk(json_msg, head_msg)
			return if trunk_type_check(json_msg, head_msg)
			cmd_args = do_get_args(json_msg, head_msg)
			args = cmd_args
			insert_switch_queue(json_msg["ip"], head_msg, args)
		end
		def handle_DelPortTrunk(json_msg, head_msg)
			cmd_args = do_get_args(json_msg, head_msg)
			args = cmd_args
			insert_switch_queue(json_msg["ip"], head_msg, args)
		end
		def handle_GetVlan(json_msg, head_msg)
			switchs = []
			switch_list.each do |key, list_s|
			switchs << key if list_s["flag"] == -1
			end
			insert_switch_queue(switchs, head_msg)
		end
		def handle_MethodError(json_msg, head_msg)
			cmd_result = {}
			cmd_result["ip"]   = json_msg["ip"]
			cmd_result["status"] = 204
			cmd_result["method"] = head_msg["MessageMethod"]
			cmd_result["result"] = nil
			set_result_queue cmd_result
		end
		def handle_HeartBeat(json_msg={}, head_msg)
			if @heart_flag > 0
				@heart_flag = 3
			end
		end
		def handle_BackupSwitchConfig(json_msg={}, head_msg)
			g_msg = []
			switchs = []
			cmd_args = []
			#Log.debug "handle_BackupSwitchConfig json_msg = #{json_msg}"
			switch_arry = json_msg["list"]
			#Log.debug "handle_BackupSwitchConfig switch_arry = #{switch_arry}, #{switch_arry.class}"
			switch_arry.each do |switch_msg|
				g_json = {}
				g_json["tftp_ip"] = @connect.mgIp
				name = "#{switch_msg["vendor"]}#{switch_msg["model"]}_#{switch_msg["ip"]}_#{DateTime.now.strftime('%F-%T')}_#{json_msg["type"]}.cfg"
				g_json["filename"] = name
				g_json["ip"] = "#{switch_msg["ip"]}"
				g_msg << g_json
				sleep(1)
			end
			g_msg.each do |j_msg|
				switchs << j_msg["ip"]
				arg_json = {}
				arg_json["list"] = []
				arg_json["list"] << j_msg
				arg_json["ip"] = j_msg["ip"]
				#Log.debug "handle_BackupSwitchConfig  arg_json = #{arg_json}"
				cmd_args.concat do_get_args(arg_json, head_msg)
				#Log.debug "handle_BackupSwitchConfig  cmd_args = #{cmd_args}"
			end
			Log.debug "handle_BackupSwitchConfig cmd_args = #{cmd_args}"
			insert_switch_queue(switchs, head_msg, cmd_args)
		end
		def handle_RestoreSwitchConfig(json_msg={}, head_msg)
			switch_arry = json_msg["list"]
			g_msg = []
			switchs = []
			cmd_args = []
			switch_arry.each do |sw_msg|
				g_json = {}
				g_json["tftp_ip"]  = @connect.mgIp
				g_json["filename"] = "#{sw_msg["name"]}"
				g_json["ip"]       = "#{sw_msg["ip"]}"
				g_msg << g_json
			end
			g_msg.each do |j_msg|
				switchs << j_msg["ip"]
				arg_json = {}
				arg_json["list"] = []
				arg_json["list"] << j_msg
				arg_json["ip"] = j_msg["ip"]
				#Log.debug "handle_RestoreSwitchConfig  arg_json = #{arg_json}"
				cmd_args.concat do_get_args(arg_json, head_msg)
				#Log.debug "handle_RestoreSwitchConfig  cmd_args = #{cmd_args} " 
			end
			Log.debug "handle_BackupSwitchConfig cmd_args = #{cmd_args}"
			insert_switch_queue(switchs, head_msg, cmd_args)
		end
		def handle_GetSwitchList(json_msg={}, head_msg)
			Log.info "get switch list = #{json_msg}"
			# switch_dic = {}
			# if json_msg.kind_of?(Hash) && json_msg.has_key?("list")
			# 	list = json_msg["list"]
			# 	list.each do |switch|
			# 		sw_info = {}
			# 		sw_info["vendor"] = switch["vendor"]
			# 		sw_info["type"]  = switch["model"]
			# 		if switch.has_key?("cycle")
			# 			sw_info["cycle"] = switch["cycle"].to_i < 10 ? 10: switch["cycle"].to_i
			# 	    else
			# 			sw_info["cycle"] = 60
			# 		end
			# 		user_msg = switch["params"]
			# 		sw_info["user"] = user_msg["user"]
			# 		sw_info["password"] = user_msg["password"]
			# 		sw_info["enablepassword"] = user_msg["enablepassword"]
			# 		sw_info["flag"] = 300
			# 		config = load_config(switch)
			# 		Code.config_load(config, switch)
			# 		sw_info["model"]  = SwitchModel.new(config)
			# 		switch_dic[switch["ip"]] = sw_info
			# 	end
			# end
			# sync_switch_list(switch_dic)
			@switch_list = {}
			if json_msg.kind_of?(Hash) && json_msg.has_key?("list")
				list_switch = json_msg["list"]
                ips = []
				list_switch.each do |switch_info|
					update_info(switch_info, 300)
                    ips << switch_info["ip"]
                end
                update_cache_switch_list *ips
            end
		end
		def do_GetSwitchList
			method_msg = {}
			method_msg["ip"]   = @connect.mgIp
			#method_msg["status"] = 200
			method_msg["method"] = "GetSwitchList"
			method_msg["result"] = nil
			method_msg["flag"]   = -1
			set_result_queue method_msg

		end
		def start_work(number)
			if @thread_mark == 0
				(0..number-1).each do |i|
					@th_list << Thread.new do
						work
					end
					#@th_list[i].join(0.5)
					Log.info "work thread #{i} start success"
					@thread_mark = 1
				end
			end
		end
		def start_thread(ip)
			th = Thread.new do
				work
			end
			@th_dic[ip] = th
		end
		def get_result_msg
			msg = nil
			msg = operate_multi_result(nil,nil,3)
			if msg ==nil
				msg = get_result_queue
			end
			return msg
		end
		# fetch result msg from telnet result
		def fetch_result_msg(results)
			result_msg = {}
			result_msg["method"] = results["method"]
			result_msg["ip"]     = results["ip"]
			result_msg["status"] = results["status"]
			results["type"] = 0 unless results.has_key?("type")
			Log.debug "fetch_result_msg, results=#{results}"
			# Log.debug "fetch_result_msg, keys=#{results.keys}"
			if results["type"] == 1
				result_array = results["result"]
				msg_array = []
				result_array.each do |result|
					Log.debug "fetch_result_msg result=#{result}"
					if @switch_list.has_key?(result["ip"])
						sw_model = @switch_list[result["ip"]]["model"]
						flag, msg = Msg.fetch(result, sw_model)
						Log.debug "@@@@@@@@@@@@@2Msg.fetch #{result["method"]} return flag = #{flag}"
						Log.error "fetch_result_msg fetch error #{result}" if msg == nil
						msg_array << msg
					end
				end
				result_msg["result"] = msg_array
				#Log.debug "fetch_result_msg result_msg[\"result\"] = #{result_msg["result"]}"

				fetch_result = Msg.fetch_again(result_msg)
				result_msg["result"] = fetch_result
				result_msg["flag"] = 3
			elsif results["type"] == 3
				fetch_result = Msg.fetch_again(results)
				result_msg["result"] = fetch_result
				result_msg["flag"] = 3
			elsif results["type"] == 0
					if results.has_key?("flag") == true && results["flag"] == -1
						result_msg["flag"] = results["flag"]
						result_msg["result"] = nil
					else
						if @switch_list.has_key?(results["ip"])
							sw_model = @switch_list[results["ip"]]["model"]
							flag, result = Msg.fetch(results, sw_model)
							result_msg["flag"] = flag
							result_msg["result"] = result
							Log.debug "@@@@@@@@@@@@@2Msg.fetch #{results["method"]} return flag = #{flag}"
						end
					end
			elsif results["type"] == 2
				if results["method"] == "DeleteSwitch"
				   switch_result = []
				   for switch in results["result"]
					   switch_res = {}
					   switch_res["ip"] = switch["ip"]
					   switch_res["status"] = "200"
					   switch_result << switch_res
				   end
				   switch_json = {}
				   switch_json["list"] = switch_result
				   result_msg["result"] = JSON.generate(switch_json)
				   result_msg["flag"] = 2
				end
			elsif results["type"] == 1000
				if results["method"] == "GetVlanInside"
					fetch_result = Msg.fetch_again(results)
					results["do_function"].call(fetch_result) if results.has_key?("do_function")
                elsif results["method"] == "UploadSwitchInfo"
                    sw_model = @switch_list[results["ip"]]["model"]
                    flag, fetch_result = Msg.fetch(results, sw_model)
                    results["do_function"].call(fetch_result) if results.has_key?("do_function")
				end
				result_msg = nil
			end
			#if results.has_key?("ip") && results["ip"] == "0.0.0.0"
			#	result_msg["result"] = results
			#	result_msg["falg"]   = results["flag"]
			#end
			#Log.debug "fetch_result_msg result_msg = #{result_msg}"
			return result_msg
		end
		def msg_fetch
			begin
				msg = get_result_msg
				results = nil
				if msg != nil
					#Log.debug "fetching msg: #{msg}"
					results = fetch_result_msg(msg)
					return unless results
					msg_info = results
					package = @ret_packet.msg_package(results["result"], results)
					if @connect.link_fd != nil
						#if(msg_info["method"] == "UploadSwitchInfo")
						#	100.times{@connect.write package}
						#else
						#	@connect.write package
						#end
						@connect.write package
						#Log.info "send package:\n<#{package}\n>"
					else
						if @heart_flag != -1000
						   @heart_flag -= 1
						end
						Log.error "send package to server package failed, link error"
					end
					if msg_info["method"] == "TestSwitch"
						if switch_list[msg_info["ip"]]["flag"] == -2
							update_info(msg_info, 0)
						end
					end
					if msg_info["method"] == "DeleteSwitch"
						for switch in msg["result"]
							update_info(switch, 0)
                            update_cache_switch_list
						end
					end
				end
			rescue => error_msg
				Log.error error_msg
			end
		end
		# check telnet connect status
		def session_check
			@switch_list.each do |ip, switch_info|
				if switch_info.has_key?("switch")
					switch_info["switch"].close if switch_info["switch"].con_mark == 0
					switch_info["switch"].con_mark -=1 if switch_info["switch"].con_mark > 0 && !switch_info["switch"].con_status
				end
			end
		end

        # send heart beat msg
		def task_timer
			do_time = Thread.new do
				time_1 = 0
				time_2 = 0
				loop do
					#Log.debug "#{Thread.current} task timer thread running"
					begin
						session_check
						if Switch.nac == false
							sleep(5)
							next
						end

						time_2 += 1
						if time_2 >= 10
							send_heartbeat
							time_2 = 0
						end
						time_1 += 1
						if time_1 >= 2
							add_report_task
							time_1 = 0
						end
					rescue => error_msg
						Log.error error_msg
					end
					sleep(1)
				end

			end
			do_offline = Thread.new do
				sleep(5)
				loop do
					if Switch.nac == false
						sleep(1)
						next
					end
					offline_process
					sleep(40)
				end
            end
            Thread.new do
                subscribe_cache
            end
		end
		def offline_check(ip, sw_info)
			crl_sw = ControlSwitch.new(sw_info["model"])
			crl_sw.user = sw_info["user"]
			crl_sw.password = sw_info["password"]
			crl_sw.super_pwd = sw_info["enablepassword"]
			crl_sw.switch = ip
			test_status = 0
			begin
				test_status = crl_sw.connect_switch
				crl_sw.close
			rescue => error_msg
				Log.error "offline_check->connect failed, #{error_msg} #{test_status}"
				test_status = -201
			end
			if test_status == 0
				Log.info "switch #{ip} connect success"
			else
				Log.error "switch #{ip} connect failed #{test_status}"
			end
			return test_status
		end
		def offline_process
			switchs = @switch_list.keys
			switchs.each do |ip|
  				if @switch_list[ip]["flag"] > -1
					status = offline_check(ip, @switch_list[ip])
					if status == 0
						update_a_switch(ip, {"flag" => -1})
					elsif status < 0 
						update_a_switch(ip, {"flag" => status.abs})
					end

				end
			end
		end
		def init_heartbeat
			@heart_flag = 3
		end
		def stop_heartbeat
			@heart_flag = -1000
		end

		private
            # update switch info
			def update_info(json_msg, flag = -1)
				#Log.debug "@@@@@@@@@@@@@@@flag = #{flag}"
				ret = 0
				if flag < 0 || flag > 200
					sw_info = {}
					if @switch_list.has_key?(json_msg["ip"])
						sw_info = @switch_list[json_msg["ip"]]
					else
						sw_info["flag"] = flag
					end
					sw_info["flag"] = flag if flag > -2
					#sw_info["flag"]   = flag
					sw_info["vendor"] = json_msg["vendor"]
					sw_info["type"]  = json_msg["model"]
					if json_msg.has_key?("cycle")
						sw_info["cycle"] = json_msg["cycle"].to_i < 10 ? 30: json_msg["cycle"].to_i
				    else
						sw_info["cycle"] = 70
					end
					user_msg = json_msg["params"]
					sw_info["user"] = user_msg["user"]
					sw_info["password"] = user_msg["password"]
					sw_info["enablepassword"] = user_msg["enablepassword"]
					config = load_config(json_msg)
					unless config.kind_of?(Fixnum)
						Code.config_load(config, json_msg)
						#sw_info["config"] = load_config(json_msg)
						sw_info["model"]  = SwitchModel.new(config)
						#@switch_list[json_msg["ip"]] = sw_info
						sw_info["switch"] = ControlSwitch.new(sw_info["model"])
						sw_info["switch"].user = sw_info["user"]
						sw_info["switch"].password = sw_info["password"]
						sw_info["switch"].super_pwd = sw_info["enablepassword"]
						sw_info["switch"].switch = json_msg["ip"]
						add_a_switch(json_msg["ip"], sw_info)
					else
						ret = -1
					end
				elsif flag == 0
					#if @switch_list.has_key?(json_msg["ip"])
					#	@switch_list.delete(json_msg["ip"])
					#end
					delete_a_switch(json_msg["ip"])
				end
				return ret
			end

			def load_config(json_msg)
				args = {}
				args["vendor"] = json_msg["vendor"].downcase
				args["model"]  = json_msg["model"]
				ret = nil
				begin
					ret = CfgMgr.get_config(args)
				rescue => error_msg
					Log.error error_msg
					ret = -1
				end
				Log.debug "load_config ret = #{ret}"
				return ret
			end
            # get switch list form web
			def sync_switch_list(list = {})
				switchs = @switch_list.keys
				switchs.each do |ip|
					delete_a_switch(ip) unless list.has_key?(ip)
				end
				switchs = list.keys
				switchs.each do |ip|
					if @switch_list.has_key?(ip)
						info_keys = list[ip].keys
						flag = 0
						info_keys.each do |key|
							if !(list[ip][key] == @switch_list[ip][key])
								flag = 1
								break
							end
						end
						if flag == 1
							#@switch_list[ip] = list[ip]
							add_a_switch(ip, list[ip])
						end
					else
						#@switch_list[ip] = list[ip]
						add_a_switch(ip, list[ip])
					end
				end
				Log.debug "sync_switch_list switch_list = #{@switch_list}"
			end
			def add_a_switch(ip, sw_info)
				@mutex_switch_list.lock
				@switch_list[ip] = sw_info
				@mutex_switch_list.unlock
			end
			def update_a_switch(ip, sw_info={})
				@mutex_switch_list.lock
				keys = sw_info.keys
				keys.each do |key|
					@switch_list[ip][key] = sw_info[key] if  @switch_list[ip].kind_of?(Hash)
				end
				@switch_list[ip] 
				@mutex_switch_list.unlock
			end
			def delete_a_switch(ip)
				@mutex_switch_list.lock
					if @switch_list.has_key?(ip)
						@switch_list.delete(ip)
					end
				@mutex_switch_list.unlock
			end
			def insert_switch_queue(sw_ip, msg_head, args = nil)
				msg = {}
				if sw_ip.kind_of?(Array)
					number = sw_ip.length
					seed = rand(90000000)
					number.times do |i|
						msg = {}
						msg["type"] = 1
						msg["key"] = seed
						msg["count"] = number
						msg["ip"]    = sw_ip[i]
						msg["method"]= msg_head["MessageMethod"]
						msg["do_function"] = msg_head["do_function"] if msg_head.has_key?("do_function")
						if  args.kind_of?(Array)
							msg["args"] = args[i]
							msg["type"] = 3
						elsif args != nil
							msg["args"] = args
						end
						msg[sw_ip[i]] = msg_head["MessageMethod"]
						msg["type"] = msg_head["type"] if msg_head.has_key?("type")
						set_switch_queue(sw_ip[i],msg)
					end
				else
					msg = {}
					msg["type"] = 0
					msg["ip"] = sw_ip
					msg["method"] =  msg_head["MessageMethod"]
					msg["do_function"] = msg_head["do_function"] if msg_head.has_key?("do_function")
					if args != nil
						msg["args"] = args
					end
					msg[sw_ip] = msg_head["MessageMethod"]
					msg["type"] = msg_head["type"] if msg_head.has_key?("type")
					set_switch_queue(sw_ip,msg)
				end
				Log.debug "insert_switch_queue task = #{msg}"
			end
			def operate_multi_result(key,value, flag)
				@mutex_multi_result.lock
				result = nil
				if @multi_result.has_key?(key) == false && flag == 1
					list = {}
					list["result"] = []
					list["method"] = value["method"]
					#list["ip"]     = "255.255.255.255"
					list["type"]   = value["type"]
					list["status"] = 200
					list["number"] = 0
					list["count"]  = value["count"]
					@multi_result[key] = list
				end
				if flag == 1
					if value.has_key?("result")
					@multi_result[key]["number"] += 1
					@multi_result[key]["result"] << value
					end
				elsif flag == 2
					if @multi_result.has_key?(key)
					   @multi_result.delete(key)
					end
				elsif flag == 3
					keys = @multi_result.keys
					keys.each do |key_t|
						if @multi_result[key_t]["count"] == @multi_result[key_t]["result"].size && @multi_result[key_t]["count"] != 0
							result = @multi_result[key_t]
							@multi_result.delete(key_t)
							break
						end
					end
				end
				@mutex_multi_result.unlock
				return result
			end
            # work thread run telnet command, get command result
			def work
				loop{
					#Log.debug "#{Thread.current} work thread running"
					key,sw = get_switch_queue
					if sw != nil && key != nil && Switch.nac == true
						if @switch_list.has_key?(sw["ip"])
							begin
								ip = sw["ip"]
								method = sw["method"]
								Log.debug "thread working in #{method}"
								sw_info = @switch_list[ip]
								#Log.debug sw_info
=begin
								sw_model = sw_info["model"]
								#Log.debug sw_model
								crl_sw = ControlSwitch.new(sw_model)
								crl_sw.user = sw_info["user"]
								crl_sw.password = sw_info["password"]
								crl_sw.super_pwd = sw_info["enablepassword"]
								crl_sw.switch = ip
								Log.debug "crl_sw.user = #{crl_sw.user}"
								Log.debug "crl_sw.password = #{crl_sw.password}"
								Log.debug "crl_sw.super_pwd = #{crl_sw.super_pwd}"
=end
								#crl_sw.connect_switch
								method_results = nil
								# method_results = crl_sw.do_method(sw)
								method_results = sw_info["switch"].do_method(sw)
								if method_results["status"] != 200
									sw_ip = method_results["ip"]
									if @switch_list[sw_ip]["flag"] == -1
										update_a_switch(sw_ip, {"flag" => method_results["status"]})
									end
								else
									update_a_switch(sw_ip, {"flag" => -1})
								end
								#crl_sw.close
								if method_results["type"]  == 0 ||  method_results["type"]  >= 1000
									set_result_queue method_results
								elsif method_results["type"] == 1 || method_results["type"] == 3
									operate_multi_result(method_results["key"], method_results, 1)
								end
							rescue => error_msg
								Log.error error_msg
							ensure
								unlock_switch_queue(key)
							end
							Log.debug "result:"
							Log.debug method_results
						end

					else
						#Log.debug "work queue is empty current thread "
						sleep(1)
						Thread.pass
					end
				}
			end
			def set_switch_queue(sw_ip,msg)
				@mutex_switch.lock
				if self.switch_queue.has_key?(sw_ip) == false
					self.switch_queue[sw_ip] = {}
					self.switch_queue[sw_ip]["queue"] = []
					self.switch_queue[sw_ip]["lock"]  = false
				end
				self.switch_queue[sw_ip]["queue"].unshift(msg)
				@mutex_switch.unlock
			end
			def get_switch_queue
				@mutex_switch.lock
				msg = nil
				ip  = nil
				sw_ip = self.switch_queue.keys
				sw_ip.each do |key|
					if self.switch_queue[key]["lock"] == false
						msg = self.switch_queue[key]["queue"].pop
						ip = key
						if msg != nil
							self.switch_queue[key]["lock"] = true
							break
                        end
                    else
                        Log.debug "get_switch_queue key = #{key} lock = #{self.switch_queue[key]["lock"]}"
					end
				end
				#msg = self.switch_queue.pop
				@mutex_switch.unlock
				Log.debug "get switch queen work  switch = #{ip}, work = #{msg}" if ip && msg
				return ip, msg
			end
			def unlock_switch_queue(key)
				@mutex_switch.lock
				self.switch_queue[key]["lock"] = false
				@mutex_switch.unlock
                Log.debug "unlock_switch_queue key = #{key}, lock = #{self.switch_queue[key]["lock"]}"
			end
			def set_result_queue(msg)
				@mutex_result.lock
				self.result_queue.unshift(msg)
				@mutex_result.unlock
			end
			def get_result_queue
				@mutex_result.lock
				msg = self.result_queue.pop
				@mutex_result.unlock
				return msg
			end
            # test switch login
			def login_test(json_msg, head_msg)
				sw_info = {}
				Log.debug "json_msg = #{json_msg}"
				user_msg = json_msg["params"]
				sw_info["user"] = user_msg["user"]
				sw_info["password"] = user_msg["password"]
				sw_info["enablepassword"] = user_msg["enablepassword"]
				sw_info["config"] = load_config(json_msg)
				return -210 if sw_info["config"] == -1
				ip = json_msg["ip"]
				sw_model = SwitchModel.new(sw_info["config"])
				crl_sw = ControlSwitch.new(sw_model)
				crl_sw.user = sw_info["user"]
				crl_sw.password = sw_info["password"]
				crl_sw.super_pwd = sw_info["enablepassword"]
				crl_sw.switch = ip
				begin
					test_status = crl_sw.connect_switch
				rescue => error_msg
					Log.error "login_test->connect failed, #{error_msg} #{test_status}"
				end
				if test_status == 0
					Log.info "switch #{ip} connect success"
				else
					Log.error "switch #{ip} connect failed #{test_status}"
					crl_sw.close
					return test_status
				end
				crl_sw.close
				return test_status
			end
            # send uploadSitch info message
			def add_report_task
				switchs = @switch_list.keys
				switchs.each do |switch|
					unless @report_timer.has_key?(switch)
						@report_timer[switch] = {}
						@report_timer[switch]["cycle"] = switch_list[switch]["cycle"]
						@report_timer[switch]["time"] = 0
						@report_timer[switch]["flag"] = @switch_list[switch]["flag"]
					end
				end
				switchs = @report_timer.keys
				switchs.each do |switch|
					next if @switch_list.has_key?(switch) == false
					@report_timer[switch]["cycle"] = switch_list[switch]["cycle"]
					@report_timer[switch]["flag"] = @switch_list[switch]["flag"]
					Log.debug "switch #{switch} timer activity, flag = #{@report_timer[switch]["flag"]} con_mark = #{@switch_list[switch]["switch"].con_mark}"
					if @report_timer[switch]["flag"] == -1
						@report_timer[switch]["time"] += 2
						if @report_timer[switch]["time"] >= @report_timer[switch]["cycle"]
							head = {}
							head["MessageMethod"] = "UploadSwitchInfo"
							insert_switch_queue(switch, head)
							@report_timer[switch]["time"] = 0
						end
					elsif @report_timer[switch]["flag"] > 200
						if @report_timer[switch]["flag"] < 300
							@report_timer[switch]["time"] += 2
							if @report_timer[switch]["time"] >= @report_timer[switch]["cycle"]
								list = {}
								list["method"] = "UploadSwitchInfo"
								list["ip"]     = "#{switch}"
								list["result"] = nil
								list["status"] = @report_timer[switch]["flag"]
								list["flag"]   = -1
								@report_timer[switch]["time"] = 0
								set_result_queue list
							end
						end
					end
				end
			end
			#get switch command args
			def get_config_args(json_msg, head_msg)
				args_dic = {}
				if @switch_list.has_key?(json_msg["ip"])
					switch_info = switch_list[json_msg["ip"]]
					model = switch_info["model"]
					#Log.debug "head_msg[\"MessageMethod\"] = #{head_msg["MessageMethod"]}"
					method_cmds = model.switch[head_msg["MessageMethod"]]
					args_filter = Proc.new do |args_name, iface_txt|
						iface_string = ""
						if args_name == "interface"
							if /Ethernet/ =~ iface_txt
								interface_arry = iface_txt.split("Ethernet")
								iface_string = "#{interface_arry[0]}Ethernet #{interface_arry[1]}"
							else
								iface_string = iface_txt
							end
						else
							iface_string = iface_txt
						end
						iface_string
					end
					method_cmds.each do |cmd|
						if model.switch[cmd].kind_of?(Hash) && model.switch[cmd].has_key?("args")
							model.switch[cmd]["args"].split(";").each do |arg_name|
								#Log.debug "get_config_args cmd_args value #{model.switch[cmd]["args"]}, args = #{json_msg}"
								if json_msg.has_key?(arg_name)
									if model.switch[cmd]["command"].split.include?("#{arg_name}-args")
										args_dic["#{arg_name}-args"] = args_filter.call(arg_name, json_msg[arg_name])
									else
										args_dic[cmd] = args_filter.call(arg_name, json_msg[arg_name])
									end
									if arg_name == "interface"
										args_dic["key"] =  json_msg[arg_name]
									end
								end
=begin
								args_dic[cmd] = json_msg[arg_name] if json_msg.has_key?(arg_name)
								#Log.debug "get_config_args args_dic = #{args_dic}"
								if model.switch[cmd]["args"] == "interface"
									if /Ethernet/ =~ json_msg["interface"]
										interface_arry = json_msg["interface"].split("Ethernet")
										args_dic[cmd] = "#{interface_arry[0]}Ethernet #{interface_arry[1]}"
									elsif /FastEthernet/ =~ json_msg["interface"]
										args_dic[cmd] = "FastEthernet #{json_msg["interface"].split("FastEthernet")[1]}"
									elsif /GigabitEthernet/ =~ json_msg["interface"]
										args_dic[cmd] = "GigabitEthernet #{json_msg["interface"].split("GigabitEthernet")[1]}"
									elsif /Ethernet/ =~ json_msg["interface"]
										args_dic[cmd] = "Ethernet #{json_msg["interface"].split("Ethernet")[1]}"
									else
										args_dic[cmd] = json_msg["interface"]
									end
									args_dic["key"] = json_msg["interface"]
								end
								args_dic["#{arg_name}-args"] = args_dic[cmd]
=end
							end
						end
					end

				end
				args_dic == {} ? nil : args_dic
			end
			def do_get_args(json_msg, head_msg)
				arg_array = []
				arg_list = json_msg["list"]
				#Log.debug "do_get_args arg_list = #{arg_list}"
				arg_list.each do |arg|
					arg["ip"] = json_msg["ip"]
					arg_dic = get_config_args(arg, head_msg)
					if arg_dic != nil
						arg_array << arg_dic
					end
					#Log.debug "do_get_args arg = #{arg} arg_dic = #{arg_dic}"
				end
				return arg_array
			end
			def send_heartbeat
				result = nil
				msg_info = {}
				msg_info["status"] = 200
				msg_info["ip"] = @connect.mgIp
				msg_info["method"] = "HeartBeat"
				msg_info["flag"]   = -1
				set_result_queue msg_info
				#package = @heart_packet.msg_package(result, msg_info)
				#if @connect.link_fd != nil && @heart_flag != -1000
				#	@connect.write package
				#	Log.debug "$$$$$$$$$$$$$$$$connect.write heartbeat package success"
				#	handle_HeartBeat(nil, nil)
				#else
				#    @heart_flag -= 1 if@heart_flag != -1000
				#	Log.error "response to server heartbeat package failed"
				#end
				if @heart_flag != -1000
					if @heart_flag <= 0
						Log.error "the link to server error"
						Log.error "close connect to server"
						@connect.close
					end
				end
			end
	end
end
