#######################################################################
#### Author: chenxiaokang                                           ###
#### Date: 2015.1.13												###
#### Description: config file handle function						###	
#### Modify reason:													###
#### Version: 1.0													###
#### bugs report to hp104@hupu.net									###
#######################################################################
require "yaml"
require "connect"
module Switch
	class CfgMgr
		def CfgMgr.get_config(options)
			vendor = nil
			model  = nil
			fd     = nil
			vendor = options["vendor"] if options.has_key? "vendor"
			model  = options["model"]  if options.has_key? "model"
			if vendor == nil || model == nil
				raise "switch name error"
			end
			name = "#{vendor}_#{model}"
            path = File.absolute_path(__FILE__)
            path = File.dirname(path)
			file_name = "#{path}/config/#{name}.yaml"
            Log.info "will load template #{File.basename(file_name)}"
			if File.exist?(file_name)
				fd = File.read(file_name)
			elsif /cisco/ =~ name
				fd = File.read("#{path}/config/cisco_3560.yaml")
			elsif /huawei/ =~ name
				fd = File.read("#{path}/config/huawei_5700.yaml")
			elsif /h3c/ =~ name
				fd = File.read("#{path}/config/h3c_3600.yaml")
            elsif /shenzhoushuma/ =~ name
				fd = File.read("#{path}/config/shenzhoushuma_5960.yaml")
			elsif /\Ahp_/ =~ name
				fd = File.read("#{path}/config/hp_2530.yaml")
			else
				Switch.log.error "can not found #{name} config files"
			end
			fd == nil ? -1 : YAML.load(fd)
		end
	end
end

